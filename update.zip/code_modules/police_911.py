from globalvars import *
from code_modules.function import *

__all__ = ["police_911"]

def police_911(lock_webdriver, running_thread, waiting_thread_list, home_city, character_name, boys_list):
	timer_911 = read_file("env/911Timer.txt")
	timer_911 = datetime.datetime.strptime(timer_911, '%Y-%m-%d %H:%M:%S.%f')
	time_difference = datetime.datetime.utcnow() - timer_911
	if not '-' in str(time_difference):

		print_function('911 - THREAD QUEUED')
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_earn)
		print_function('911 - THREAD ACTIVE')

		print_function('MISC - 911 - OPENING PAGE')
		go_to_page(lock_webdriver, '911', running_thread)
		print_function('MISC - 911 - PAGE OPEN')

		Results_911 = Get_911_Results(lock_webdriver, running_thread, waiting_thread_list)
		Results_911_FormatForProcessing = '<div class="bodytext">' + str(Results_911)
		Process_911_Page(lock_webdriver, running_thread, waiting_thread_list, home_city, Results_911_FormatForProcessing)

		# CHECK INTERPOL THREADS
		page_check = get_url(lock_webdriver)
		if 'interpol' in page_check:
			pass
		else:
			element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@class='links']/a[1]", running_thread)

		if element_found(lock_webdriver, "XPATH", ".//*[@id='wrapper']/div[@id='content']/form/div[@id='thread_list']/table"):
			# COMMISH IS DIFFERENT. DONT KNOW WHY
			Interpol_Threads_Table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='wrapper']/div[@id='content']/form/div[@id='thread_list']/table", "innerHTML")
		else:
			Interpol_Threads_Table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='wrapper']/div[@id='content']/div[@id='thread_list']/table", "innerHTML")
			
		count = 0
		thread_number = 0
		last_poster = ""
		thread_found = False
		settings_thread = str(config['Career-Police']['911_Thread'])
		if '&' in str(settings_thread):
			settings_thread = settings_thread.replace('&', '&amp;')

		for thread in Interpol_Threads_Table.split('<tr class="thread">'):
			if ">INTERPOL THREADS<" in str(thread):
				continue

			thread_number += 1
			if settings_thread in str(thread):
				thread_found = True
				for line in thread.splitlines():
					if "userprofile.asp" in str(line):
						count += 1
					if (int(count) == 2):
						if '" ' in str(line):
							last_poster = regex_match_between('userprofile.asp\?u=', '" ', line)
						elif '">' in str(line):
							last_poster = regex_match_between('userprofile.asp\?u=', '">', line)
						else:
							print_function("911 - CANNOT FIND LAST POSTER IN THE THREAD - LINE: " + str(line), "RED")
							while True:
								time.sleep(30)
						break
			if thread_found:
				break

		if thread_found:
			pass
		else:
			print_function("911 - CANNOT FIND FORUM THREAD", "RED")
			while True:
				time.sleep(30)

		open_thread = True
		for boys_name in boys_list:
			if str(boys_name) == str(last_poster):
				print_function("911 - LAST POSTER IS BOYS", "GREEN")
				open_thread = False
				break

		if (open_thread):
			if (character_name == last_poster):
				print_function("911 - YOU ARE THE LAST POSTER IN THE THREAD", "GREEN")
				open_thread = False
			else:
				print_function("911 - UPDATE NEEDED AS LAST POSTER: " + str(last_poster), "RED")

		# OPEN 911 THREAD
		if (config.getboolean('Career-Police', 'Post911')):
			open_thread = True

		if (open_thread):
			# CLICK THREAD
			element_click(lock_webdriver, 'XPATH', ".//*[@id='thread_list']/table/tbody/tr[@class='thread'][" + str(thread_number) + "]/td[@class='topic']/a", running_thread)

			# LAST PAGE BUTTON
			last_page_number = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/form/div[@id='forum_holder']/div[@id='forum_content']/table[@id='ft_top']/tbody/tr/td[@class='forum_pages']", "innerHTML")
			if '">7<' in str(last_page_number):
				last_page_number = 8
			elif '">6<' in str(last_page_number):
				last_page_number = 7
			elif '">5<' in str(last_page_number):
				last_page_number = 6
			elif '">4<' in str(last_page_number):
				last_page_number = 5
			elif '">3<' in str(last_page_number):
				last_page_number = 4
			elif '">2<' in str(last_page_number):
				last_page_number = 3
			elif '">1<' in str(last_page_number):
				last_page_number = 1

			# CLICK LAST PAGE
			try:
				if int(last_page_number) > 1:
					element_click(lock_webdriver, 'XPATH', ".//*[@id='content']/form/div[@id='forum_holder']/div[@id='forum_content']/table[@id='ft_top']/tbody/tr/td[@class='forum_pages']/a[" + str(last_page_number) + "]", running_thread)
			except:
				pass

			Interpol_Page = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='body']/div[@id='wrapper']/div[@id='content']", "innerHTML")
			Process_911_Page(lock_webdriver, running_thread, waiting_thread_list, home_city, Interpol_Page)

			if (config.getboolean('Career-Police', 'Post911')):
				# CLICK POST REPLY
				element_click(lock_webdriver, 'XPATH', ".//*[@id='content']/form/div[@id='forum_holder']/div[@id='forum_content']/table[@id='ft_top']/tbody/tr/td[1]/a[@class='new']", running_thread)
				time.sleep(2)

				# UPDATE NEW POST
				for line in Results_911.splitlines():
					line = line.strip()
					line = line.replace("\t", " ")
					line = line.replace('<span style="color:#ccc;"><b>', "")
					line = line.replace("</b></span>", "")
					print("LINE 911:" + str(line))

					if '|' in str(line):
						sendkeys(lock_webdriver, "XPATH", ".//*[@class='post_reply']/tbody/tr[2]/td/textarea[@id='body']", str("\r\n"))
						sendkeys(lock_webdriver, "XPATH", ".//*[@class='post_reply']/tbody/tr[2]/td/textarea[@id='body']", str(line))
					else:
						sendkeys(lock_webdriver, "XPATH", ".//*[@class='post_reply']/tbody/tr[2]/td/textarea[@id='body']", str(line))
						sendkeys(lock_webdriver, "XPATH", ".//*[@class='post_reply']/tbody/tr[2]/td/textarea[@id='body']", str("\r\n"))

				# SUBMIT POST
				element_click(lock_webdriver, 'XPATH', ".//*[@class='input']", running_thread)

		random_timer = random.randrange(1234, 2457) # 20 - 40mins
		write_file("env/911Timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)))
		thread_remove_from_queue(running_thread, waiting_thread_list)
		print("911 - DONE")
	return

def Get_911_Results(lock_webdriver, running_thread, waiting_thread_list):
	Interpol_Page = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='pd']/div[@class='body'][1]", "innerHTML")
	Results_911 = ""
	for line in Interpol_Page.split("<tr>"):
		print_function("RAW 911 LINE: " + str(line), "RED")
		if "background: #225277" in str(line):
			pass
		elif "background: #CC3300" in str(line):
			# whack background
			pass
		elif 'Last Edited by' in str(line):
			pass
		else:
			continue

		line_split = line.splitlines()
		agg_time = line_split[1]
		agg_time = regex_match_between('>&nbsp;', '&nbsp;<', agg_time)

		agg_type = line_split[2]
		agg_type = regex_match_between('>&nbsp;', '&nbsp;<', agg_type)
		if "B&amp;E" in str(agg_type):
			agg_type = agg_type.replace('B&amp;E', 'B&E')

		agg_victim = line_split[3]
		agg_victim = regex_match_between('username=', '">', agg_victim)

		agg_suspect = line_split[5]
		if "<i>" in str(agg_suspect):
			agg_suspect = "escaped"

		# print("LINE:" + agg_time + " AGG:" + agg_type + " VICTIM:" + agg_victim + " SUSPECT:" + agg_suspect)
		Results_911 = str(Results_911) + str(agg_time) + "\t" + str(agg_type) + "\t" + str(agg_victim) + "\t" + str(agg_suspect) + "\r\n"
		print_function("MISC - 911 - line results: " + str(Results_911), "BLUE")

	full_online_list = ""
	online_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
	online_list_raw_split = online_list_raw.split("|")
	for player_raw in online_list_raw_split:
		if (':Alive:player:' in player_raw) or (':In-Jail:player:' in player_raw):
			if '<font color="#DB70DB">' in str(player_raw):
				player_name = regex_match_between('#DB70DB">', '<', player_raw)
			else:
				player_name = regex_match_between('>', '<', player_raw)
			if "*" in str(player_raw):
				player_name = player_name + "*"
			if full_online_list == "":
				full_online_list = player_name
			else:
				full_online_list = full_online_list + " | " + player_name

	Results_911 = str(Results_911) + str(full_online_list)
	return Results_911

def Process_911_Page(lock_webdriver, running_thread, waiting_thread_list, home_city, Interpol_Page):
	database_update_content = ""
	database_update_date = ""
	previous_911_results = ""
	for Interpol_Post in Interpol_Page.split('<div class="bodytext">'):
		post_date = ""
		post_content = ""
		for Interpol_Post_Details in Interpol_Post.splitlines():
			if ( ("AM" in str(Interpol_Post_Details)) or ("PM" in str(Interpol_Post_Details)) ):
				for Interpol_Line in Interpol_Post_Details.splitlines():
					if (("AM" in str(Interpol_Line)) or ("PM" in str(Interpol_Line))):
						if ( ("Posted:" in str(Interpol_Line)) or ("blockquote style" in str(Interpol_Line)) ):
							pass
						else:
							Interpol_Line = Interpol_Line.strip()

							if 'Last Edited by ' in str(Interpol_Line):
								continue

							# print("LINE: " + str(Interpol_Line))
							count = 1
							agg_time = ""
							agg = ""
							victim = ""
							suspect = ""
							for Tab_Detail in Interpol_Line.split("\t"):
								Tab_Detail = Tab_Detail.strip()
								Tab_Detail = Tab_Detail.replace('<br>', '')
								if Tab_Detail == "":
									pass
								else:
									if (count == 1):
										agg_time = str(Tab_Detail)
										try:
											agg_time = datetime.datetime.strptime(agg_time, '%m/%d/%Y %I:%M:%S %p')
										except:
											continue
										if (database_update_date == ""):
											database_update_date = str(agg_time.year) + "-" + str(agg_time.month)
											if (previous_911_results == ""):
												previous_911_results = read_s3('roastbusters', '911' + str(home_city) + '/' + str(database_update_date) + '.txt')
										if (post_date == ""):
											post_date = str(agg_time.year) + "-" + str(agg_time.month)
										if ( (str(database_update_date) != str(post_date)) and (str(post_date) != "") and (str(database_update_date != "")) ):
											append_s3('roastbusters', '911' + str(home_city) + '/' + str(database_update_date) + '.txt', "\r\n" + str(database_update_content))
											print("DATABASE UPDATE:" + str(database_update_content))
											database_update_content = ""
											database_update_date = ""
											previous_911_results = ""
											print_function("911 - NEW MONTH REACHED: " + str(database_update_date) + ' VS ' + str(post_date), "RED")
									elif (count == 2):
										agg = Tab_Detail

										if ("Pickpocket" in str(agg)):
											agg = "Pickpocket"
										elif ("Armed Robbery" in str(agg)):
											agg = "AR"
										elif ("Hacking" in str(agg)):
											agg = "Hack"
										elif ( ("B&amp;E" in str(agg)) or ("B&amp;E" in str(agg)) or ("B&E" in str(agg)) ):
											agg = "BnE"
										elif ("Mugging" in str(agg)):
											agg = "Mug"
										elif ("Torch Business" in str(agg)):
											agg = "Torch"
										elif ("Torch" in str(agg)):
											agg = "TorchHouse"
										elif ("GTA" in str(agg)):
											agg = "GTA"
										elif ("GBH" in str(agg)):
											agg = "GBH"
										elif ("Attempted Whack" in str(agg)):
											discord_message("911 " + str(home_city) + " - ATTEMPTED WHACK: " + str(Interpol_Line))

										if ( ("Bank Robbery" in str(agg)) or ("Attempted Bank Robbery" in str(agg)) or ("Attempted Whack" in str(agg)) or ("GBH" in str(agg)) or ("GTA" in str(agg)) or ("Dog Whack" in str(agg)) or (agg == "Pickpocket") or (agg == "Mug") or (agg == "Hack") or (agg == "TorchHouse") or (agg == "BnE") or (agg == "GTA") or (agg == "AR") or (agg == "Torch")):
											pass
										else:
											print_function("911 - NEW AGG TYPE: " + str(agg), "RED")
											while True:
												time.sleep(30)

									elif (count == 3):
										victim = Tab_Detail
										victim = victim.replace(" ", "")
									elif (count == 4):
										suspect = Tab_Detail

									if ( (agg == "Torch") and ( ("Drug House" in str(victim)) or ("DrugHouse" in str(victim)) ) ):
										discord_message("911 - " + str(home_city) + " TORCH DH: " + str(Interpol_Line) )
								count += 1

							# print("911 - TIME:" + str(agg_time) + " AGG:" + agg + " VICTIM:" + victim + " SUSPECT:" + suspect)
							if ( ("Attempted Pickpocket" in str(Interpol_Line)) or
							("Attempted Mugging" in str(Interpol_Line)) or
							("Attempted B&E" in str(Interpol_Line)) or
							("Attempted B&amp;E" in str(Interpol_Line)) or
							("Attempted Hacking" in str(Interpol_Line)) or
							("Attempted GTA" in str(Interpol_Line)) or
							("Bank Robbery" in str(Interpol_Line)) or
							("Attempted B &amp;E" in str(Interpol_Line)) or
							("Attempted GBH" in str(Interpol_Line)) or
							("Torch CF" in str(Interpol_Line)) or
							("Attempted Dog Whack" in str(Interpol_Line)) or
							("Attempted Armed Robbery" in str(Interpol_Line)) or
							("Attempted Torch Business" in str(Interpol_Line)) or
							("Attempted Torch" in str(Interpol_Line)) or
							("Attempted Whack" in str(Interpol_Line)) ):
								# STILL GET TIMERS FROM HERE FOR AGGS
								pass
							else:
								post_content = post_content + "\r\n" + str(agg_time) + " " + str(agg) + " " + str(victim) + " " + str(suspect)
							
							if ("Attempted Bank Robbery" in str(Interpol_Line)) or ("Bank Robbery" in str(Interpol_Line)):
								pass
							else:
								Update_Database_For_AggTimer(victim, agg, agg_time, home_city)
			if ("|" in str(Interpol_Post_Details)):
				if "post_options" in str(Interpol_Post_Details):
					pass
				else:
					Interpol_Post_Details = Interpol_Post_Details.strip()
					Interpol_Post_Details = Interpol_Post_Details.replace("<br>", "")
					# print("ONLINELIST: " + str(Interpol_Post_Details))
					post_content = post_content + "\r\n" + str(Interpol_Post_Details)

		if post_content == "":
			pass
		elif (str(post_content) in str(previous_911_results)):
			print_function("911 - ALREADY IN DATABASE: " + str(post_content), "RED")
			pass
		else:
			# print("POST:" + str(post_date) + " - " + str(post_content))
			database_update_content = database_update_content + str(post_content)
	if database_update_content == "":
		print_function("NO NEW 911 RESULTS")
		pass
	else:
		append_s3('roastbusters', '911' + str(home_city) + '/' + str(database_update_date) + '.txt', "\r\n" + str(database_update_content))
		print("DATABASE UPDATE:" + str(database_update_content))
	return

def Update_Database_For_AggTimer(case_victim, case_agg_type, case_agg_time, home_city):
	Update_Business = False
	if (case_agg_type == "AR") or (case_agg_type == "Torch"):
		case_victim = str(home_city) + str(case_victim)
		Update_Business = True


	if (case_agg_type == "Pickpocket"):
		new_pro_time = case_agg_time + datetime.timedelta(minutes=70)
	elif (case_agg_type == "Mug"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif (case_agg_type == "Hack"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=12)
	elif (case_agg_type == "Torch"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=2)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif (case_agg_type == "BnE"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=10)
	elif (case_agg_type == "GTA"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif (case_agg_type == "AR"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif ("Dog Whack" in str(case_agg_type)):
		new_pro_time = case_agg_time - datetime.timedelta(hours=1)
	elif (case_agg_type == "TorchHouse"):
		new_pro_time = case_agg_time - datetime.timedelta(hours=1)
	elif (case_agg_type == "GBH"):
		new_pro_time = case_agg_time - datetime.timedelta(hours=1)
	elif (case_agg_type == ""):
		new_pro_time = datetime.datetime.utcnow() - datetime.timedelta(hours=1)
	elif ('Attempted Whack' in str(case_agg_type)):
		new_pro_time = datetime.datetime.utcnow() - datetime.timedelta(hours=1)
	else:
		print_function("POLICE 911 - UPDATE DATABASE - AGG NOT FOUND: " + str(case_agg_type), "RED")
		while True:
			time.sleep(30)

	minutes_diff = (new_pro_time - datetime.datetime.utcnow()).total_seconds() / 60.0
	if '-' in str(minutes_diff):
		pass
	else:
		if Update_Business:
			update_database('Business', 'BizName', str(case_victim), {"AggPro": str(new_pro_time)})
		else:
			update_database('Player', 'PlayerName', str(case_victim), {"Aggpro_Personal": str(new_pro_time), "UpdatedBy": "Police-Case"})
	return
