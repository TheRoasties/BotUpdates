from globalvars import *
from code_modules.function import *

def obituaries(lock_webdriver, running_thread, waiting_thread_list, next_obituaries_timer, obituaries_locked_until):
	# CHECK TIMER
	obituaries_time_difference = (datetime.datetime.utcnow() - next_obituaries_timer)
	if not '-' in str(obituaries_time_difference):
		locked_time_difference = (datetime.datetime.utcnow() - obituaries_locked_until)
		print_function("OBITUARIES - PASSED TIMER 1", "GREEN")
		if not '-' in str(locked_time_difference):
			print_function("OBITUARIES - PASSED TIMER 2", "GREEN")
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_onlinelist)
			print_function('MISC - OBITUARIES - START')

			# SET LOCKEDTIME NOW + 3MINS - TO PREVENT MULTIPLE PEOPLE ATTEMPTING THE SAME UPDATE
			my_cached_lockeduntil = datetime.datetime.utcnow() + datetime.timedelta(minutes=1)
			update_database('Timers', 'Timer', 'Obituaries', {"LockedUntil": str(my_cached_lockeduntil)})

			go_to_page(lock_webdriver, "Obituaries", running_thread)

			# GET KNOWN DEATHS LIST
			known_deaths_list = read_s3('roastbusters', 'Deaths.txt')

			# GET NAME CHANGE RECORDS
			rename_list = read_s3('roastbusters', 'NameChange.txt')

			# CHECK NO DUPLICATE BEFORE UPDATE
			response = get_from_database('Timers', 'LockedUntil', "Key('Timer').eq('Obituaries')")
			onlinehours_locked_until = datetime.datetime.strptime(response['Items'][0]['LockedUntil'], '%Y-%m-%d %H:%M:%S.%f')
			if my_cached_lockeduntil == onlinehours_locked_until:

				if element_found(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='orbituary_holder']/table"):
					pass
				else:
					print_function("OBITS - NO DEATHS TODAY", "RED")
					# UPDATE OBITUARIES TIMER FOR NEXT CHECK - CLOUD
					random_timer = random.randrange(411, 832)
					print_function('Obituaries - NEXT CHECK: ' + str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
					update_database('Timers', 'Timer', 'Obituaries', {"NextTimer": str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer))})

					thread_remove_from_queue(running_thread, waiting_thread_list)
					return True

				obituaries_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='orbituary_holder']/table", "innerHTML")
				obituaries_line = obituaries_table.split("<tr>")
				for line in reversed(obituaries_line):
					if 'username=' in line:
						pass
					else:
						continue

					line_details = line.split("<td ")
					death_name = regex_match_between('username=', '"', line_details[1])
					death_city = regex_match_between('display_border">', '<', line_details[2])
					death_occupation = regex_match_between('display_border">', '<', line_details[3])
					death_time = regex_match_between('display_border">', '<', line_details[4])
					death_time = datetime.datetime.strptime(death_time, '%m/%d/%Y %H:%M:%S %p')

					if '<b><i>' in line_details[5]:
						death_reason = regex_match_between('<b><i>', '<', line_details[5])
					else:
						death_reason = regex_match_between('display_border">', '<', line_details[5])
					print_function("NAME: " + str(death_name) + " TIME:" + str(death_time) + " REASON:" + str(death_reason))

					# SKIP KNOWN DEATHS
					if str(death_time) in known_deaths_list:
						print_function('MISC - Obituaries - Skipping known death: ' + str(death_name) + " AT: " + str(death_time))
						continue

					# SKIP KNOWN NAME CHANGES
					if str(death_time) in rename_list:
						print_function('MISC - Obituaries - Skipping known name change: ' + str(death_name) + " AT: " + str(death_time))
						continue

					print_function("OBITUARIES - DEAD:" + str(death_name) + " REASON:" + str(death_reason) + " AT:")

					# CHECK FOR NAME CHANGE
					new_name = None
					if 'Change' in death_reason:
						element_click(lock_webdriver, "LINKTEXT", death_name, running_thread)
						try:
							new_name = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='profile_quote']/div[@class='quote_content']/span/strong/span[2]/a", "innerHTML")
						except:
							pass
						print_function('MISC - Obituaries - Name change from ' + str(death_name) + " to: " + str(new_name))
						go_back(lock_webdriver)

					if new_name is None:
						# UPDATE REGULAR RECORDS

						# DELETE DEAD - SHARED PERSONAL
						update_database('Player', 'PlayerName', str(death_name), {"AliveStatus": "Dead", "DeathReason": str(death_reason), "UpdatedBy": "Obituaries"})
						print_function('MISC - Obituaries - Removed Shared Personal record ' + str(death_name))

						# DELETE DEAD - SHARED BOLD LIST
						delete_from_database('BoldList', 'PlayerName', str(death_name))
						print_function('MISC - Obituaries - Removed Shared boldlist record ' + str(death_name))

						# DELETE DEAD - SHARED BOYS LIST
						delete_from_database('Boys', 'PlayerName', str(death_name))
						print_function('MISC - Obituaries - Removed shared hack record ' + str(death_name))


						# DELETE DEAD - LOCAL PERSONAL
						try:
							os.remove('./agg_targets/pickpocket/' + death_name + '.txt')
							print_function('MISC - Obituaries - Removed local personal record ' + str(death_name))
						except:
							pass

						# DELETE DEAD - LOCAL BNE
						try:
							os.remove('./agg_targets/bne/' + death_name + '.txt')
							print_function('MISC - Obituaries - Removed local bne record ' + str(death_name))
						except:
							pass

						# DELETE DEAD - LOCAL HACK
						try:
							os.remove('./agg_targets/hacks/' + death_name + '.txt')
							print_function('MISC - Obituaries - Removed local hack record ' + str(death_name))
						except:
							pass
					else:
						# UPDATE NAME CHANGE RECORDS

						# GET ALL OLD NAME DETAILS
						old_name_details = get_from_database('Player', None, "Key('PlayerName').eq('" + str(death_name) + "')")
						try:
							old_online_hours = old_name_details['Items'][0]['Hours']
						except:
							old_online_hours = 0

						# GET ANY NEW NAME DETAILS
						skip_this_oldname = False
						new_name_details = get_from_database('Player', None, "Key('PlayerName').eq('" + str(new_name) + "')")
						try:
							new_online_hours = new_name_details['Items'][0]['Hours']
						except:
							skip_this_oldname = True
							new_online_hours = 0

						combined_online_hours = int(old_online_hours) + int(new_online_hours)

						# UPDATE OLD NAME FOR DEATH TIME / DEATH REASON / NEW NAME
						update_database('Player', 'PlayerName', str(death_name),
										{"AliveStatus": "NameChange", "DeathTime": str(death_time), "UpdatedBy": "Obituaries", "DeathReason": str(death_reason),
										 "NewName": str(new_name)})

						# CORRECT NEW NAME DETAILS IF NOT ENTERED
						update_string = '{"AliveStatus": "Alive", "PreviousName": str(death_name), "UpdatedBy": "Obituaries", "FirstSeen": str(death_time)'
						if skip_this_oldname:
							# NEW NAME NOT ALREADY IN DATABASE - CREATE
							update_string = str(update_string) + ', "' + "Aggpro_Hack" + '": "' + str(datetime.datetime.utcnow()) + '"'
							update_string = str(update_string) + ', "' + "Aggpro_Personal" + '": "' + str(datetime.datetime.utcnow()) + '"'
							update_string = str(update_string) + ', "' + "Aggpro_BnE" + '": "' + str(datetime.datetime.utcnow()) + '"'
							update_string = str(update_string) + ', "' + "Hours" + '": "' + str(combined_online_hours) + '"'
							update_string = str(update_string) + "}"
							update_database('Player', 'PlayerName', str(new_name), eval(update_string))
						else:
							# NEW NAME IN DATABASE - UPDATE
							update_string = str(update_string) + ', "' + "Hours" + '": "' + str(combined_online_hours) + '"'
							for item_key in old_name_details['Items'][0]:
								if ((item_key in str(update_string)) or (item_key == "PlayerName")):
									continue
								elif item_key in str(new_name_details):
									# EXISTS IN NEW NAME. CHECK IF BLANK
									try:
										new_item_value = new_name_details['Items'][0][item_key]
										if ((new_item_value is None) or (new_item_value == '')):
											# BLANK VALUE. UPDATE WITH THE OLD VALUE
											item_value = old_name_details['Items'][0][item_key]
											update_string = str(update_string) + ', "' + str(item_key) + '": "' + str(item_value) + '"'
										else:
											item_value = new_item_value
											update_string = str(update_string) + ', "' + str(item_key) + '": "' + str(item_value) + '"'
									except:
										item_value = old_name_details['Items'][0][item_key]
										update_string = str(update_string) + ', "' + str(item_key) + '": "' + str(item_value) + '"'
								else:
									# DOES NOT EXIST IN NEW NAME. USE THE OLD VALUE
									item_value = old_name_details['Items'][0][item_key]
									update_string = str(update_string) + ', "' + str(item_key) + '": "' + str(item_value) + '"'

							update_string = str(update_string) + "}"
							print("OBITUARIES NAME CHANGE UPDATE STRING: ", update_string)

							# UPDATE NEW NAME
							update_database('Player', 'PlayerName', str(new_name), eval(update_string))


						# DELETE DEAD - SHARED BOYS LIST
						delete_from_database('Boys', 'PlayerName', str(death_name))
						print_function('MISC - Obituaries - Removed shared hack record ' + str(death_name))

						# UPDATE TIMERS (NAME CHANGE) - BNE LOCAL
						# DELETE NEW NAME & RENAME OLD NAME
						try:
							os.remove('./agg_targets/bne/' + new_name + '.txt')
							print_function('MISC - Obituaries - Removed local bne record ' + str(new_name))
						except:
							pass
						try:
							os.rename('./agg_targets/bne/' + death_name + '.txt', './agg_targets/bne/' + new_name + '.txt')
							print_function('MISC - Obituaries - Renamed local bne record ' + str(death_name) + " to: " + str(new_name))
						except:
							pass

						# UPDATE TIMERS (NAME CHANGE) - PICKPOCKET LOCAL
						# DELETE NEW NAME & RENAME OLD NAME
						try:
							os.remove('./agg_targets/pickpocket/' + new_name + '.txt')
							print_function('MISC - Obituaries - Removed local personal record ' + str(new_name))
						except:
							pass
						try:
							os.rename('./agg_targets/pickpocket/' + death_name + '.txt', './agg_targets/pickpocket/' + new_name + '.txt')
							print_function('MISC - Obituaries - Renamed local personal record ' + str(death_name) + " to: " + str(new_name))
						except:
							pass


						# UPDATE TIMERS (NAME CHANGE) - HACK LOCAL
						# DELETE NEW NAME & RENAME OLD NAME
						try:
							os.remove('./agg_targets/hacks/' + new_name + '.txt')
							print_function('MISC - Obituaries - Removed local hack record ' + str(death_name))
						except:
							pass
						try:
							os.rename('./agg_targets/hacks/' + death_name + '.txt', './agg_targets/hacks/' + new_name + '.txt')
							print_function('MISC - Obituaries - Renamed local hack record ' + str(death_name) + " to: " + str(new_name))
						except:
							pass

						# UPDATE TIMERS - SHARED BOLD LIST
						delete_from_database('BoldList', 'PlayerName', str(death_name))
						update_database('BoldList', 'PlayerName', str(death_name), None)
						print_function('MISC - Obituaries - Renamed shared bold list record ' + str(death_name) + " to: " + str(new_name))

						# UPDATE NAME CHANGE DETAILS. THIS IS DONE AFTER OTHER DETAILS TO MAKE SURE NOTHING IS LOST IF THE PROCESS IS INTERRUPTED PART WAY
						append_s3('roastbusters', 'NameChange.txt', "\r\nName change from " + death_name + " to " + new_name + " on " + str(death_time))

					# UPDATE DEATH RECORDS
					append_s3('roastbusters', 'Deaths.txt', "\r\n" + death_name + " | " + str(death_time) + " | " + death_city + " | " + death_occupation + " | " + death_reason)

					print_function('MISC - Obituaries - Updated deaths record for: ' + str(death_name) + " AT: " + str(death_time))


				# UPDATE OBITUARIES TIMER FOR NEXT CHECK - CLOUD
				random_timer = random.randrange(411, 832)
				print_function('Obituaries - NEXT CHECK: ' + str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
				update_database('Timers', 'Timer', 'Obituaries', {"NextTimer": str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer))})

				thread_remove_from_queue(running_thread, waiting_thread_list)
				return True
			else:
				print_function("Obituaries - SKIP UPDATE AS SOMEONE ELSE STARTED", "RED")
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return True
	return False
