from globalvars import *
from code_modules.function import *

def train_army(lock_webdriver, running_thread, waiting_thread_list):
	if 'JoinArmy' in str(config['Action']['Train']):
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)

		print_function(str(inspect_stack()) + 'train_army')
		# OPEN TRAIN PAGE IF NOT ALREADY
		go_to_page(lock_webdriver, 'TrainIntoArmy', running_thread)

		dropdown = get_dropdown_options(lock_webdriver, "XPATH",
										".//*[@id='study_holder']/div[@id='holder_content']/form/select")

		if "Yes, I want to train" in dropdown:
			select_dropdown_option(lock_webdriver, "XPATH",
								   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
								   "Yes, I want to train")
			print_function(str(inspect_stack()) + ' train_army - Train Chosen')

			# CLICK SUBMIT
			click_continue(lock_webdriver, running_thread)
			print_function(str(inspect_stack()) + ' train_army - Submit')
			open_city(lock_webdriver, running_thread)
		elif "Yes, I want to join the army" in dropdown:
			select_dropdown_option(lock_webdriver, "XPATH",
								   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
								   "Yes, I want to join the army")
			print_function(str(inspect_stack()) + ' train_army - Train Chosen')

			# CLICK SUBMIT
			click_continue(lock_webdriver, running_thread)
			print_function(str(inspect_stack()) + ' train_army - Submit')
			open_city(lock_webdriver, running_thread)
		else:
			print_function(str(inspect_stack()) + ' train_army - train not in options')

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return True
	return False
