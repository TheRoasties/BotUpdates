from globalvars import *
from code_modules.function import *

def mortician_autopsy(lock_webdriver, running_thread, waiting_thread_list):
	if globals()['timers'].__dict__['case_timer'] is None:
		globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
	time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['case_timer']
	if not '-' in str(time_difference):
		print_function('AUTOPSY - QUEUED')
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)
		print_function("AUTOPSY - START")

		go_to_page(lock_webdriver, "Mortician-Autopsy", running_thread)

		if element_found(lock_webdriver, "NAME", "autopsynum"):
			element_click(lock_webdriver, "NAME", "autopsynum", running_thread)
			click_continue(lock_webdriver, running_thread)

			# SET TIMER - AUTOPSY DONE
			globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Case', running_thread))
		else:
			# SET TIMER - NO AUTOPSIES
			random_timer = random.randrange(270, 1800)
			globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)

		thread_remove_from_queue(running_thread, waiting_thread_list)
	return

