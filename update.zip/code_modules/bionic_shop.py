from globalvars import *
from code_modules.function import *


def bionic_shop(lock_webdriver, running_thread, waiting_thread_list, current_city):
	if 'Bionics' in globals()['private_businesses_' + current_city]:
		time_difference = datetime.datetime.utcnow() - globals()[current_city].__dict__['Bionics'].__dict__['restock_timer']
		if not '-' in str(time_difference):
			print_function('MISC - BIOS - ADDED TO QUEUE')
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_restock)
			print_function('MISC - BIOS - ACTIVE')

			open_city(lock_webdriver, running_thread)

			# TORCH CHECK
			torch_check = element_get_attribute(lock_webdriver, "XPATH", "//*[@class='business bionics']", "outerHTML")
			if 'maintenance' in torch_check:
				print_function('MISC - BIOS - TORCHED')
				# UPDATE TIMER FOR NEXT CHECK
				restock_random_timer = random.randrange(1837, 3674)
				globals()[current_city].__dict__['Bionics'].__dict__['restock_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=restock_random_timer)
			else:
				element_click(lock_webdriver, "XPATH", ".//*[@class='business bionics']", running_thread)

				if element_found(lock_webdriver, "ID", "fail"):
					# UPDATE TIMER FOR NEXT CHECK
					restock_random_timer = random.randrange(1837, 3674)
					globals()[current_city].__dict__['Bionics'].__dict__['restock_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=restock_random_timer)
					print_function('MISC - BIOS - FAILED TO OPEN', "RED")
					print_function('MISC - BIOS - FINISHED', "RED")
					open_city(lock_webdriver, running_thread)
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return

				print_function('MISC - BIOS - STORE OPEN')

				# BIONICS SHOP OPEN. CHECK STOCK
				current_city = get_current_city(lock_webdriver)
				discord_string = '@here BIOS STOCK ' + str(current_city) + ' - '
				discord_notify = False

				bios_table = element_get_attribute(lock_webdriver, "XPATH",
												   ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table",
												   "innerHTML")
				bios_table_split = bios_table.split("<tr>")
				count = 0
				bios_list_index = 0
				bios_buy_index = 2
				for item in bios_table_split:
					if count < 2:
						count += 1
						continue
					item_split = item.split("<td")
					price = item_split[3]
					price = regex_match_between('>', '<', price)
					price = re.sub('[^0-9]', "", price)
					quantity = item_split[4]
					quantity = regex_match_between('>', '<', quantity)
					print_function(str(globals()['bionic_stock_' + current_city][bios_list_index]) + " //" + str(price) + " // " + str(quantity))
					if config.getboolean('BionicsNotify', globals()['bionic_stock_' + current_city][bios_list_index]):
						print_function(str(globals()['bionic_stock_' + current_city][bios_list_index]) + ' buy index: ' + str(bios_buy_index))
						# NOTIFY FOR THIS BIO
						if int(quantity) > 0:
							# BIO IN STOCK
							discord_notify = True
							discord_string = discord_string + ' ' + str(
								globals()['bionic_stock_' + current_city][bios_list_index]) + ':' + str(quantity)

							# IF BUYING THIS ITEM
							# enough money (on hand / in bank / withdraw if needed)
							# change priority to 0 so not interrupted?
							# check hands free / have armor / have medipack - need editable ini file?
							# make variables for which items buying / stashing
							# "[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(bios_buy_index) + "]/td[@class='display_border'][4]/input[@id='arms']"
					count += 1
					bios_list_index += 1
					bios_buy_index += 1

				if discord_notify:
					discord_message(discord_string)


				# UPDATE TIMER FOR NEXT CHECK
				restock_random_timer = random.randrange(927, 1227)
				globals()[current_city].__dict__['Bionics'].__dict__['restock_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=restock_random_timer)


				# CHANGE PAGE TO SAVE VIEWS
				open_city(lock_webdriver, running_thread)
				print_function('MISC - BIOS - FINISHED')
				thread_remove_from_queue(running_thread, waiting_thread_list)
	return
