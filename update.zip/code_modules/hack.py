from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

__all__ = ["add_hack_targets_to_arrays", "check_hack_target", "do_hack_thread"]

def add_hack_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager, homecity_hack_list, your_character_name, bold_list):
	# CREATE LISTS
	count = 3
	while count < 32:
		globals()['hack_targets_minute' + str(count)] = []
		locals()['dict_min' + str(count)] = {}
		count += 1

	# DO CALCULATION
	try:
		your_hours = aggtarget_person_list_manager[your_character_name].get_online_hours()
	except:
		your_hours = 1

	for name in homecity_hack_list:
		try:
			their_hours = aggtarget_person_list_manager[name].get_online_hours()
		except:
			# SKIP ANY TARGET NOT FOUND. PRESUMABLY DEAD
			continue

		if (your_character_name == name) or ('' == name):
			continue

		if (name in config['Hack']['Hack_Blacklist']):
			print_function('HACK - SKIP BLACKLIST TARGET ' + str(name))
			continue

		if config.getboolean('Hack', 'Avoid_Bolds'):
			skip_this_name = False
			for bold_name_raw in bold_list['Items']:
				bold_name = bold_name_raw['PlayerName']
				if bold_name == name:
					skip_this_name = True
					break
			if skip_this_name:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - Hack TARGET: " + str(name) + " SKIP AS BOLD")
				continue

		our_aggstr_mins = 29
		while True:
			our_aggstr = math.ceil( your_hours * float(aggstr_percent_modify(our_aggstr_mins)) )
			their_aggstr = math.floor( their_hours * float(config['Hack']['HackAggstrModify']) )

			if (our_aggstr_mins <= 2) or (their_aggstr >= our_aggstr):
				# APPLY LOCAL MODIFIERS TO TARGET REQUIRED MINS
				mins_adjusted = int(our_aggstr_mins) + 1

				if os.path.isfile('./agg_targets/hacks/' + name + '.txt'):
					adjust_value = read_file('./agg_targets/hacks/' + name + '.txt')
					if adjust_value == '':
						adjust_value = 0
				else:
					adjust_value = 0

				if adjust_value == 'FAIL':
					mins_adjusted = 31
				else:
					mins_adjusted = int(mins_adjusted) + int(adjust_value)

					if int(mins_adjusted) > 30:
						mins_adjusted = 30
					elif int(mins_adjusted) < 3:
						mins_adjusted = 3

				globals()['hack_targets_minute' + str(mins_adjusted)].append(name)
				# print('AGGS - HACK ARRAY - ADDED ', name, ' TO MINS ', mins_adjusted, " THEIRS: ", their_aggstr, " VS YOURS: ", our_aggstr)
				break

			our_aggstr_mins -= 1

	count = 3
	while count < 32:
		print_function('Hack list: ' + str(count) + ' // ' + str(globals()['hack_targets_minute' + str(count)]))
		count += 1
	return


def check_hack_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, your_homecity, homecity_hack_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager):
	try:
		viable_hack_targets = []

		for agg_target in globals()['hack_targets_minute' + str(aggstr_min_checking)]:
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - HACK - CHECKING TARGET" + str(agg_target))

			# AGGPRO - LOCAL
			try:
				aggpro_timer = aggtarget_person_list_manager[agg_target].get_local_hack_timer()
			except Exception as e:
				if ('Only one usage of each socket address' in str(e)):
					print_function("HACK - SOCKETS USED FOR " + str(agg_target), "RED")
					write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - HACK - SOCKET USED FOR " + str(agg_target))
					continue
				else:
					raise Exception(e)

			try:
				time_difference = datetime.datetime.utcnow() - aggpro_timer
			except Exception as e:
				if 'datetime.datetime' in str(e):
					aggpro_timer = datetime.datetime.strptime(aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
					time_difference = datetime.datetime.utcnow() - aggpro_timer
				else:
					raise Exception(e)

			if not '-' in str(time_difference):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " Hack - " + str(agg_target) + " PASSED LOCAL AGGPRO")
				# AGGPRO - SHARED
				aggpro_timer = aggtarget_person_list_manager[agg_target].get_shared_hack_timer()
				time_difference = datetime.datetime.utcnow() - aggpro_timer
				if not '-' in str(time_difference):
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " Hack - " + str(agg_target) + " PASSED SHARED AGGPRO")
					# AGGPRO - SHARED
					viable_hack_targets.append(agg_target)
					write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - HACK TARGET: " + str(agg_target) + " MINS REQUIRED: " + str(aggstr_min_checking) )
				else:
					write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - HACK SHARED AGGPRO: " + str(agg_target))
			else:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - HACK LOCAL AGGPRO: " + str(agg_target))

		if viable_hack_targets == []:
			pass
		else:
			# TERMINATE LESSER PRIORITY AGGS - BNE
			if 'do_bne_thread' in str(running_thread[0]):
				if '1' in str(running_thread[0]):
					# SKIP INTERRUPTING HIGH PRIORITY BNE
					return

			if 'do_bne_thread' in str(waiting_thread_list):
				# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK - REQUESTED TERMINATE BNE")
				waiting_thread_list.append('9zterminate_do_bne_thread')
				print_function('9zterminate_do_bne_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
				while True:
					if 'do_bne_thread' in str(waiting_thread_list):
						pass
					else:
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK - TERMINATED BNE")
						break
				# TERMINATED BNE

			# TERMINATE LESSER PRIORITY AGGS - MUG
			if 'do_mug_thread' in str(running_thread[0]):
				if '1' in str(running_thread[0]):
					# SKIP INTERRUPTING HIGH PRIORITY MUG
					return

			if 'do_mug_thread' in str(waiting_thread_list):
				# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK - REQUESTED TERMINATE MUG")
				waiting_thread_list.append('9zterminate_do_mug_thread')
				print_function('9zterminate_do_mug_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
				while True:
					if 'do_mug_thread' in str(waiting_thread_list):
						pass
					else:
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK - TERMINATED MUG")
						break
				# TERMINATED MUG

			# TERMINATE LESSER PRIORITY AGGS - PICKPOCKET
			if 'do_pickpocket_thread' in str(running_thread[0]):
				if '1' in str(running_thread[0]):
					# SKIP INTERRUPTING HIGH PRIORITY PICKPOCKET
					return

			if 'do_pickpocket_thread' in str(waiting_thread_list):
				# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK - REQUESTED TERMINATE PICKPOCKET")
				waiting_thread_list.append('9zterminate_do_pickpocket_thread')
				print_function('9zterminate_do_pickpocket_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
				while True:
					if 'do_pickpocket_thread' in str(waiting_thread_list):
						pass
					else:
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK - TERMINATED PICKPOCKET")
						break
				# TERMINATED PICKPOCKET

			print_function('viable hack targets - ' + str(viable_hack_targets) + " " + str(aggstr_min_checking), "BLUE")
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - VIABLE TARGETS FOR MINUTE " + str(aggstr_min_checking) + ": " + str(viable_hack_targets))

			waiting_thread_list.append('9zAggstrLowest' + str(aggstr_min_checking))
			print_function('9zAggstrLowest' + str(aggstr_min_checking) + ' THREAD QUEUED' + str(waiting_thread_list), "GREEN")

			do_hacks(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_hack_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_homecity, your_character_name)
	except:
		from code_modules.function import PrintException
		PrintException()
	return


def do_hacks(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_hack_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_homecity, your_character_name):
	thread_hack = Process(target=do_hack_thread, name='HackThread',
									args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_hack_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_homecity, your_character_name))

	thread_hack.start()
	waiting_thread_list.append('9zAwaitingHack')
	print_function(str(waiting_thread_list))

	# WAIT TILL THREAD STARTED
	print_function('HACK - WAITING FOR THREAD TO BE RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - WAITING FOR THREAD TO BE RUNNING")
	while True:
		if 'hack' in str(waiting_thread_list):
			break
	print_function('HACK - THREAD RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - THREAD RUNNING")
	return


def do_hack_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_hack_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_homecity, your_character_name):
	try:
		import multiprocessing
		write_file("env/HackPID.txt", str(multiprocessing.current_process().pid))

		for thread in waiting_thread_list:
			if 'AwaitingHack' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK QUEUED")
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_hack_targets)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK STARTED")
		random_timer_haspro = random.randrange(590, 915)

		for target in viable_hack_targets:
			# RETURN PRIORITY TO NORMAL
			running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]

			if go_to_page(lock_webdriver, "Hack", running_thread):
				pass
			else:
				config['Hack']['Do_Hack'] = 'False'
				print_function('Hack - NOT UNLOCKED', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** Hack - NOT UNLOCKED ****")
				return

			if 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** HACK - REQUIRES CS FIRST ****")
				return

			clearkeys(lock_webdriver, "NAME", "hack")
			sendkeys(lock_webdriver, "NAME", "hack", target)
			sendkeys(lock_webdriver, "NAME", "hack", Keys.ESCAPE)
			
			clearkeys(lock_webdriver, "NAME", "cap")
			sendkeys(lock_webdriver, "NAME", "cap", config['Pickpocket']['Max_PP_Amount'])
			sendkeys(lock_webdriver, "NAME", "cap", Keys.ESCAPE)

			# INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
			running_thread[0] = str('1') + inspect.stack()[0][3]
			click_continue(lock_webdriver, running_thread)

			# AGG DONE - GET RESULTS
			agg_results = None
			if element_found(lock_webdriver, "ID", "fail"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			elif element_found(lock_webdriver, "ID", "success"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
				if 'fake account' in str(agg_results):
					pass
				else:
					break
			else:
				print_function('NO AGG RESULTS FOUND', "BLUE")
				print_function('NO AGG RESULTS FOUND', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - NO AGG RESULTS FOUND")
				continue

			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - RESULTS: " + str(agg_results))

			# AGG DONE - EXAMINE RESULTS
			if "nothing to steal" in agg_results:
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - NO MONEY. TRANSFERRING TO " + str(target))
				print_function('HACK - NO MONEY - TRANSFERRING TO ' + str(target))

				go_to_page(lock_webdriver, "TransferMoney", running_thread)

				sendkeys(lock_webdriver, "NAME", "transferamount", 1)
				sendkeys(lock_webdriver, "NAME", "transfername", target)

				print_function('TRANSFER MONEY - SUBMIT')
				# SUBMIT
				click_continue(lock_webdriver, running_thread)

				if element_found(lock_webdriver, "ID", "success"):
					viable_hack_targets.insert(0, target)
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Target " + str(target) + " Cannot Transfer")
					random_timer = random.randrange(20, 25)
					agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)
					aggtarget_person_list_manager[target].set_local_hack_timer(agg_timer)
					aggtarget_person_list_manager[target].set_shared_hack_timer(agg_timer)
				continue


			if "same bank" in agg_results:
				print_function('Hack Results - Target ' + str(target) + " Same Bank", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Target " + str(target) + " Same Bank")
				random_timer = random.randrange(20, 25)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)
				aggtarget_person_list_manager[target].set_local_hack_timer(agg_timer)
				aggtarget_person_list_manager[target].set_shared_hack_timer(agg_timer)
				continue

			if "doesn't exist" in agg_results:
				print_function('Hack Results - Target ' + str(target) + " Doesn't Exist", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Target " + str(target) + " Doesn't Exist")
				random_timer = random.randrange(20, 25)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)
				aggtarget_person_list_manager[target].set_local_hack_timer(agg_timer)
				aggtarget_person_list_manager[target].set_shared_hack_timer(agg_timer)
				continue

			elif ('increased security' in agg_results):
				print_function('Hack Results - Target ' + str(target) + " has pro", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Target " + str(target) + " has pro")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer_haspro)
				aggtarget_person_list_manager[target].set_local_hack_timer(agg_timer)
				continue

			elif ('failed' in agg_results) or ('ran off' in agg_results):
				print_function('Hack Results - Target ' + str(target) + ' FAILED', "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Target " + str(target) + " FAILED")
				last_agg_time[0] = datetime.datetime.utcnow()
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=12)
				aggtarget_person_list_manager[target].set_shared_hack_timer(agg_timer)

				# UPDATE LOCAL MODIFIERS
				desired_mins = int(aggstr_mins_max) + 2
				if desired_mins > 30:
					desired_mins = 30

				mins_adjusted = int(desired_mins) - int(aggstr_min_checking)

				if int(aggstr_mins_max) == 30:
					mins_adjusted = 'FAIL'

				write_file('./agg_targets/hacks/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/Hacks.txt', "\nHack FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nHack FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK THREAD FINISHED")
				return


			elif ('hack into' in agg_results):
				print_function('Hack Results - Target ' + str(target) + ' SUCCESS - AGG: ' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Hack - Target " + str(target) + " SUCCESS")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=12)
				aggtarget_person_list_manager[target].set_shared_hack_timer(agg_timer)

				# UPDATE LOCAL MODIFIERS
				try:
					mins_adjusted = read_file('./agg_targets/hacks/' + target + '.txt')
					if mins_adjusted == 'FAIL':
						mins_adjusted = 30
					mins_adjusted = int(mins_adjusted)
				except:
					mins_adjusted = 0

				mins_adjusted -= 1
				write_file('./agg_targets/hacks/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/Hacks.txt', "\nHack SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nHack SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# UPDATE SHARED ALL AGGS RECORDS
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.utcnow().year) + '-' + str(datetime.datetime.utcnow().month) + '-' + str(datetime.datetime.utcnow().day) + '.txt',
						  "\r\n" + str(your_character_name) + " Hack " + str(target) + " (Success) in " + str(globals()[your_homecity].which_city) + " on " + str(datetime.datetime.utcnow()))

				# REPAY CHECKS
				repay = True
				if not config.getboolean('Hack', 'Repay'):
					print_function('Hack - Repay - TURNED OFF', "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Repay - TURNED OFF")
					repay = False

				repay_blacklist = config['Hack']['Repay_Blacklist'].split()
				for blacklist_name in repay_blacklist:
					if target == blacklist_name:
						print_function('Hack - Repay - TARGET IS BLACKLISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Repay - TARGET IS BLACKLISTED: " + str(target))
						repay = False

				repay_whitelist = config['Hack']['Repay_Whitelist'].split()
				for whitelist_name in repay_whitelist:
					if target == whitelist_name:
						print_function('Hack - Repay - TARGET IS WHITELISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Repay - TARGET IS WHITELISTED: " + str(target))
						repay = True

				if repay:
					repay_amount = regex_match_between('\$', ' to a fake account', agg_results)
					repay_amount = re.sub('[^0-9]', "", repay_amount)

					print_function('Hack - Repaying ' + str(repay_amount) + ' TO ' + str(target), "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK - Repaying " + str(repay_amount) + " TO " + str(target))
					# ADD REPAY TO RECORDS
					append_file('./records/Hacks.txt', "\n Hack - Repaying " + repay_amount + " TO " + target)
					append_file('./records/AllAggs.txt', "\n Hack - Repaying " + repay_amount + " TO " + target)

					if int(repay_amount) > 1:
						transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target)

						# WAIT FOR TRANSFER TO BE QUEUED
						print_function('Hack - Waiting for repay to be queued', "BLUE")

						while True:
							if 'transfer_money_thread' in str(waiting_thread_list):
								break
						print_function('Hack - repay is queued', "BLUE")

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK THREAD FINISHED")
				return

			else:
				print_function('Hack - results not found' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Hack - results not found" + str(agg_results))
				continue

		for thread in waiting_thread_list:
			if ('AggstrLowest' in thread):
				try:
					waiting_thread_list.remove(thread)
				except:
					pass
		thread_remove_from_queue(running_thread, waiting_thread_list)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t HACK THREAD FINISHED")
		return
	except:
		from code_modules.function import PrintException
		PrintException()
