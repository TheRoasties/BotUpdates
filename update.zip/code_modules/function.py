from globalvars import *

__all__ = ["word_in_string", "get_house_from_string", "get_vehicle_from_string", "s3_get_files", "s3_file_exists", "read_s3", "write_s3", "append_s3", "delete_from_database", "bulk_update_database", "discord_error", "print_function", "get_from_database", "update_database", "release_webdriver", "get_aggpro_seconds", "get_your_clean_money", "discord_journal", "append_file", "write_file",
		   "withdraw_money", "read_file", "clearkeys", "get_dirty_money", "get_server_time", "inspect_stack", "get_your_character_name", "get_your_character_rank_percent",
		   "get_your_character_rank", "get_your_character_occupation", "get_home_city", "get_current_city", "open_all_locks", "go_back", "get_players_list_currentcity", "go_to_page",
		   "get_url", "regex_match_between", "sendkeys", "is_element_displayed", "open_income_menu", "thread_remove_from_queue", "thread_add_to_queue", "convert_timer_to_total_seconds",
		   "get_timer", "wait_till_timer_ready", "element_found", "element_count", "element_click", "element_get_attribute", "click_refresh", "open_city", "click_continue",
		   "discord_message", "get_dropdown_options", "select_dropdown_option"]

global driver
global lock_webdriver

def word_in_string(word, string):
	result = string.split(" ")[int(word) - 1]
	return result


def get_house_from_string(string):
	# You witnessed Smok`s Flat get broken into! You vaguely recognised the thief - their name ended with: God.
	if "witnessed" in str(string):
		formatted_string = regex_match_between('`s ', ' get broken into', string)
	elif " and after" in str(string):
		formatted_string = regex_match_between('`s ', ' and after', string)
	elif "failed" in str(string):
		formatted_string = regex_match_between("'s ", ' and failed', string)
	else:
		formatted_string = string

	if "Flat" in str(formatted_string):
		house = "Flat"
	elif "Studio" in str(formatted_string):
		house = "Studio"
	elif "Penthouse" in str(formatted_string):
		house = "Penthouse"
	elif "Palace" in str(formatted_string):
		house = "Palace"
	else:
		house = "NOTFOUND"
	return house


def get_vehicle_from_string(string):
	if "Arcadia" in str(string):
		vehicle = "Brahma"
	elif "Heliades" in str(string):
		vehicle = "Galaxy"
	elif "Galactic" in str(string):
		vehicle = "Solaris"
	elif "Bhaskara" in str(string):
		vehicle = "Nekkar"
	elif "Kalpana" in str(string):
		vehicle = "Scorpii"
	elif "Eco" in str(string):
		vehicle = "Electra"
	elif "Firefly" in str(string):
		vehicle = "Sirius"
	else:
		vehicle = "NOTFOUND"
	return vehicle


def s3_get_files(bucket, key):
	from botocore.errorfactory import ClientError

	s3 = boto3.client('s3', region_name='ap-southeast-2',
					  aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
					  aws_secret_access_key='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')

	results = s3.list_objects_v2(
		Bucket=bucket,
		Prefix=key
	)

	return results

def s3_file_exists(bucket, key):
	from botocore.errorfactory import ClientError

	s3 = boto3.client('s3', region_name='ap-southeast-2',
					  aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
					  aws_secret_access_key='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')

	try:
		s3.head_object(Bucket=bucket, Key=key)
		return True
	except ClientError:
		# Not found
		return False
	return False


def append_s3(bucket_name, key, data_to_append):
	import io
	current_s3_data = read_s3(bucket_name, key)

	s3client = boto3.client('s3', region_name='ap-southeast-2',
						aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
						aws_secret_access_key='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')

	combined_data_to_write = str(current_s3_data) + str(data_to_append)
	s3client.upload_fileobj(io.BytesIO(combined_data_to_write.encode()), bucket_name, key)
	return


def write_s3(bucket_name, key, data_to_write):
	import io
	s3client = boto3.client('s3', region_name='ap-southeast-2',
						aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
						aws_secret_access_key='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')
	s3client.upload_fileobj(io.BytesIO(data_to_write.encode()), bucket_name, key)
	return


def read_s3(bucket_name, key):
	s3 = boto3.resource('s3', region_name='ap-southeast-2',
						aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
						aws_secret_access_key='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')

	try:
		response = s3.Object(bucket_name, key).get()
		return_string = response['Body'].read().decode()
	except:
		if ( ('PromoRecords/' in str(key)) or ('OnlineTimes/' in str(key)) or ('911' in str(key)) or ('FullAggsList/' in str(key)) ):
			pass
		else:
			discord_error(config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + " read_s3 file does not exist: " + str(key))
		return ""
	return return_string


def PrintException(exception=None):
	from code_modules.function import discord_message
	import configparser
	config = configparser.ConfigParser()
	config.read('settings.ini')

	import traceback
	
	if "KeyboardInterrupt" in str(traceback.format_exc()):
		pass
	else:
		discord_error(config['Auth']['discord_id'] + str(traceback.format_exc()) )
	return

def print_function(string, color=None):
	if color is None:
		try:
			print(str(datetime.datetime.utcnow().strftime('%m/%d @ %H:%M:%S')) + " - " + str(string))
		except:
			pass
	else:
		try:
			color_string = "Fore." + str(color)
			print(eval(color_string) + str(datetime.datetime.utcnow().strftime('%m/%d @ %H:%M:%S')) + " - " + str(string) + Style.RESET_ALL)
		except:
			pass
	return


def delete_from_database(table, key_name, key_value):
	client = boto3.resource('dynamodb', region_name='ap-southeast-2', aws_access_key_id='AKIAVJNIZJYFC24IQCMU', aws_secret_access_key='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')
	table = client.Table(table)

	response = table.delete_item(Key={key_name: key_value})
	if '200' in str(response):
		return True
	else:
		return False
	return


def get_from_database(table, attribs_to_get, filter=None):
	# response = get_from_database('Player', 'PlayerName, AggPro, House', "Key('PlayerName').eq('Test')")
	#    for item in response['Items']:
	#    print_function('item: ' + str(item))
	import boto3

	client = boto3.resource('dynamodb', region_name='ap-southeast-2', aws_access_key_id='AKIAVJNIZJYFC24IQCMU', aws_secret_access_key='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')
	table = client.Table(table)
	if filter is None:
		if attribs_to_get is None:
			response = table.scan(ReturnConsumedCapacity='NONE')
		else:
			response = table.scan(Select='SPECIFIC_ATTRIBUTES',ReturnConsumedCapacity='NONE',ProjectionExpression=attribs_to_get)
	else:
		if attribs_to_get is None:
			response = table.scan(ReturnConsumedCapacity='NONE',FilterExpression=eval(filter))
		else:
			response = table.scan(Select='SPECIFIC_ATTRIBUTES',ReturnConsumedCapacity='NONE',ProjectionExpression=attribs_to_get,FilterExpression=eval(filter))


	if 'LastEvaluatedKey' in response:
		input('GET_FROM_DATABASE - LASTEVELUATEDKEY FOUND - CODE FOR THIS')
	return response


def bulk_update_database(table, items):
	append_s3('roastbusters', 'DatabaseUpdates.txt', "\r\nbulk_update_database " + str(table) + " " + str(inspect_stack()) + " " + str(items))
	print("ITEMS: " + str(items))
	total_item_count = len(items)

	print("BULK UPDATE - TOTAL COUNT: " + str(total_item_count))
	# 25 at a time max
	client = boto3.resource('dynamodb', region_name='ap-southeast-2', aws_access_key_id='AKIAVJNIZJYFC24IQCMU', aws_secret_access_key='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')

	item_count = 0
	batch_count = 0
	table_update_string = "{table: ["

	# START BATCH
	for item in items:
		# START ITEM FOR THIS BATCH
		batch_count += 1
		item_count += 1

		# print("BATCH" + str(batch_count) + "-ITEM" + str(item_count) + ": "+ str(item))
		this_item_string = "{'PutRequest': {'Item': {"
		item_is_key = True
		for attribute in item:
			# START ATTRIBUTES FOR THIS ITEM
			if item_is_key:
				this_item_string = this_item_string + "'" + str(attribute) + "': '"
				item_is_key = False
			else:
				this_item_string = this_item_string + str(attribute) + "',"
				item_is_key = True
				# print("BULK UPDATE - BATCH:" + str(batch_count) + "/25 TOTAL:" + str(item_count) + "/" + str(total_item_count) + " - " + str(this_item_string))

		print("UPDATING TABLE STRING FOR ITEM: " + str(item) + " ADDING STRING: " + str(this_item_string))
		table_update_string = table_update_string + this_item_string + "}},},"
		print("TABLE UPDATE STRING: " + str(table_update_string))

		if batch_count >= 25:
			table_update_string = table_update_string + "]}"
			print("BULK UPDATE - BATCH MAX REACHED - STRING: " + str(table_update_string))
			response = client.batch_write_item(
				RequestItems=eval(table_update_string),
				ReturnConsumedCapacity='NONE',
				ReturnItemCollectionMetrics='NONE'
			)
			print(response)
			batch_count = 0
			table_update_string = "{table: ["

	table_update_string = table_update_string + "]}"
	if table_update_string == "{table: []}":
		print("BULK UPDATE - NO ADDITIONAL LAST ITEMS")
		pass
	else:
		print("BULK UPDATE - LAST ITEMS - STRING: " + str(table_update_string))
		response = client.batch_write_item(
			RequestItems=eval(table_update_string),
			ReturnConsumedCapacity='NONE',
			ReturnItemCollectionMetrics='NONE'
		)
		print(response)
	print_function("BULK UPDATE FINISHED")
	return


def update_database(table, table_key, table_value, updates):
	count = 0
	UpdateExpression_String = None
	ExpressionAttributeValues_Dict = {}
	if updates is None:
		client = boto3.resource('dynamodb', region_name='ap-southeast-2', aws_access_key_id='AKIAVJNIZJYFC24IQCMU', aws_secret_access_key='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')
		table = client.Table(table)
		response = table.update_item(
			Key={table_key: table_value}
		)
	else:
		for key, value in updates.items():
			if UpdateExpression_String is None:
				UpdateExpression_String = "set " + str(key) + " = :" + str(count)
			else:
				UpdateExpression_String = UpdateExpression_String + ", " + str(key) + " = :" + str(count)
			ExpressionAttributeValues_Dict[":" + str(count)] = value
			count += 1

		print_function('Update DB - PRIMARY: ' + str(table_key) + "PRIMEKEY:" + str(table_value) + " KEYS: " + str(UpdateExpression_String) + " VALUES: " + str(ExpressionAttributeValues_Dict))

		client = boto3.resource('dynamodb', region_name='ap-southeast-2', aws_access_key_id='AKIAVJNIZJYFC24IQCMU', aws_secret_access_key='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')
		table = client.Table(table)
		response = table.update_item(
			Key={table_key: table_value},
			UpdateExpression=UpdateExpression_String,
			ExpressionAttributeValues=ExpressionAttributeValues_Dict
		)
	return response


def read_file(path):
	text_file = open(path, "r")
	file_contents = text_file.read()
	try:
		text_file.close()
	except:
		pass
	return file_contents


def append_file(path, string_to_append):
	try:
		text_file = open(path, "r")
		file_contents = text_file.read()
		file_contents = file_contents + str(string_to_append)
		text_file.close()
	except:
		file_contents = string_to_append

	text_file = open(path, "w+")
	text_file.write(str(file_contents))
	try:
		text_file.close()
	except:
		pass
	return


def write_file(path, string_to_write):
	try:
		text_file = open(path, "w")
		text_file.write(str(string_to_write))
		try:
			text_file.close()
		except:
			pass
	except Exception as e:
		if ('Aggs_Thread_Log' in str(path)) or ('Business' in str(path)):
			pass
		else:
			raise Exception(e)
	return


def get_aggpro_seconds(lock_webdriver):
	aggpro_timer = element_get_attribute(lock_webdriver, "XPATH",
										 ".//*[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_right']/form/span[@class='donation_timer']",
										 "innerHTML")
	if 'Ready' in aggpro_timer:
		aggpro_timer_total_seconds = 0
	else:
		aggpro_timer_split = aggpro_timer.split(':')
		aggpro_timer_hours = aggpro_timer_split[0]
		aggpro_timer_minutes = aggpro_timer_split[1]
		aggpro_timer_seconds = aggpro_timer_split[2]
		aggpro_timer_total_seconds = ((int(aggpro_timer_hours) * 60) * 60) + (int(aggpro_timer_minutes) * 60) + int(aggpro_timer_seconds) + 1
	return aggpro_timer_total_seconds


def get_home_city(lock_webdriver):
	home_city = element_get_attribute(lock_webdriver, "XPATH",
									  "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_end'][3]",
									  "innerHTML")

	home_city = re.sub('[^a-zA-Z]', "", home_city)
	return home_city


def get_current_city(lock_webdriver):
	current_city = element_get_attribute(lock_webdriver, "XPATH",
										 "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display'][4]",
										 "innerHTML")

	current_city = re.sub('[^a-zA-Z]', "", current_city)
	return current_city


def update_unlocked_aggs(aggs_table, running_thread):
	if 'CS:' in str(running_thread[4]):
		print_function("UPDATE UNLOCKED AGGS - SKIPPED AS CS NEEDED", "RED")
		return
	elif 'In-Jail' in str(running_thread[4]):
		print_function("UNLOCKED AGGS LIST - SKIPPED AS IN JAIL", "RED")
		unlocked_aggs_list = running_thread[3]
		# UPDATE TIMER
		for item in unlocked_aggs_list:
			if 'TIMEAGGS:' in item:
				try:
					unlocked_aggs_list.remove(item)
				except:
					pass
				break

		unlocked_aggs_list.append('TIMEAGGS:' + str(datetime.datetime.utcnow() + datetime.timedelta(hours=2)))

		running_thread[3] = unlocked_aggs_list
		write_file("env/agg_unlocks.txt", running_thread[3])
	else:
		unlocked_aggs_list = running_thread[3]

		if 'Mugging' in aggs_table:
			if not 'Mug' in unlocked_aggs_list:
				unlocked_aggs_list.append('Mug')
		else:
			if 'Mug' in unlocked_aggs_list:
				try:
					unlocked_aggs_list.remove('Mug')
				except:
					pass

		if 'Breaking' in aggs_table:
			if not 'BnE' in unlocked_aggs_list:
				unlocked_aggs_list.append('BnE')
		else:
			if 'BnE' in unlocked_aggs_list:
				try:
					unlocked_aggs_list.remove('BnE')
				except:
					pass

		if 'Armed' in aggs_table:
			if not 'ArmedRobbery' in unlocked_aggs_list:
				unlocked_aggs_list.append('ArmedRobbery')
		else:
			if 'ArmedRobbery' in unlocked_aggs_list:
				try:
					unlocked_aggs_list.remove('ArmedRobbery')
				except:
					pass

		if 'Hack' in aggs_table:
			if not 'Hack' in unlocked_aggs_list:
				unlocked_aggs_list.append('Hack')
		else:
			if 'Hack' in unlocked_aggs_list:
				try:
					unlocked_aggs_list.remove('Hack')
				except:
					pass

		if 'Torch a local Business' in aggs_table:
			if not 'Torch' in unlocked_aggs_list:
				unlocked_aggs_list.append('Torch')
		else:
			if 'Torch' in unlocked_aggs_list:
				try:
					unlocked_aggs_list.remove('Torch')
				except:
					pass

		if 'Pay Daily Tribute' in aggs_table:
			if not 'Tribute' in unlocked_aggs_list:
				unlocked_aggs_list.append('Tribute')
		else:
			if 'Tribute' in unlocked_aggs_list:
				try:
					unlocked_aggs_list.remove('Tribute')
				except:
					pass

		if 'Jail Break' in aggs_table:
			if not 'JailBreak' in unlocked_aggs_list:
				unlocked_aggs_list.append('JailBreak')
		else:
			if 'JailBreak' in unlocked_aggs_list:
				try:
					unlocked_aggs_list.remove('JailBreak')
				except:
					pass

		# UPDATE TIMER
		for item in unlocked_aggs_list:
			if 'TIMEAGGS:' in item:
				try:
					unlocked_aggs_list.remove(item)
				except:
					pass
				break

		unlocked_aggs_list.append('TIMEAGGS:' + str(datetime.datetime.utcnow() + datetime.timedelta(hours=2)))

		running_thread[3] = unlocked_aggs_list
		write_file("env/agg_unlocks.txt", running_thread[3])

		print_function('UPDATED UNLOCKS: ' + str(running_thread[3]))
	return


def cs_needed_check(lock_webdriver, running_thread):
	if element_found(lock_webdriver, "ID", "fail"):
		check_cs_needed = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
		if 'Services to your community' in check_cs_needed:
			cs_needed = regex_match_between('another ', ' Services', check_cs_needed)

			variables_list = running_thread[4]
			for item in running_thread[4]:
				if 'CS:' in item:
					try:
						variables_list.remove(item)
					except:
						pass

			variables_list.append('CS:' + str(cs_needed))
			print_function("CS NEEDED CHECK - NEED " + str(cs_needed), "RED")

			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES FOR CS: ' + str(running_thread[4]), "RED")
			write_file("env/variables.txt", running_thread[4])
			return True
	print_function("CS NEEDED CHECK - NONE FOUND", "GREEN")
	return False


def go_to_page(lock_webdriver, page, running_thread):
	while True:
		if 'In-Jail' in running_thread[4]:
			if ('Messages' in page) or ('Journal' in page):
				pass
			else:
				return False

		page_check = get_url(lock_webdriver)

		if 'Earn' in page:
			if 'earn.asp' in page_check:
				print_function(str(inspect_stack()) + ' Earns - On Manual Earn Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Earns - Opening Manual Earn Page')
				open_income_menu(lock_webdriver, "Earns", running_thread)
				continue

		elif 'Profile' in page:
			if 'profile/default.asp' in page_check:
				print_function(str(inspect_stack()) + ' Profile - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Profile - Opening Page')
				driver.get("https://mafiamatrix.com/profile/default.asp")
				continue

		elif 'ConsumeDrugs' in page:
			if 'consumables.asp' in page_check:
				print_function(str(inspect_stack()) + ' ConsumeDrugs - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' ConsumeDrugs - Opening Page')
				driver.get("https://mafiamatrix.com/profile/consumables.asp")
				continue

		elif 'Skills' in page:
			if 'charskills.asp' in page_check:
				print_function(str(inspect_stack()) + ' Skills - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Skills - Opening Page')
				open_income_menu(lock_webdriver, "Skills", running_thread)
				continue

		elif 'CommunityService' in page:
			if 'communityservice.asp' in page_check:
				print_function(str(inspect_stack()) + ' Community Service - On CS Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Community Service - Opening CS Page')
				open_income_menu(lock_webdriver, "Community", running_thread)
				continue

		elif 'FireDuties' in page:
			if 'fireduties.asp' in page_check:
				print_function(str(inspect_stack()) + ' Fire Duties - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Fire Duties - Opening Page')
				open_income_menu(lock_webdriver, "Fire Fighter Duties", running_thread)
				continue

		elif 'TrainIntoCustoms' in page:
			if 'customs.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoCustoms - On Customs Page')
				break
			elif 'local.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoCustoms - On City Page. Opening customs training')
				element_click(lock_webdriver, 'XPATH', ".//*[@class='customs']", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' TrainIntoCustoms - Opening City Page')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'TrainIntoFire' in page:
			if 'fire.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoFire - On Fire Page')
				break
			elif 'local.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoFire - On City Page. Opening fire training')
				element_click(lock_webdriver, 'XPATH', ".//*[@class='fire']", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' TrainIntoFire - Opening City Page')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'TrainIntoArmy' in page:
			if 'army.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoArmy - On Fire Page')
				break
			elif 'local.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoArmy - On City Page. Opening army training')
				element_click(lock_webdriver, 'XPATH', ".//*[@class='army']", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' TrainIntoArmy - Opening City Page')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'TrainIntoPolice' in page:
			if 'policerecruit.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoArmy - On Police Page')
				break
			elif 'local.asp' in page_check:
				print_function(str(inspect_stack()) + ' TrainIntoPolice - On City Page. Opening police training')
				element_click(lock_webdriver, 'XPATH', ".//*[@class='police']", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' TrainIntoPolice - Opening City Page')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'Gym' in page:
			if 'businesses.asp?name=Gym' in page_check:
				print_function(str(inspect_stack()) + ' Gym - On Page')
				break
			elif 'local.asp' in page_check:
				print_function(str(inspect_stack()) + ' Gym - Opening Business')
				element_click(lock_webdriver, 'XPATH', ".//*[@class='gym']", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' Gym - Opening City Page')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'UniversityDegree' in page:
			if 'university.asp' in page_check:
				print_function(str(inspect_stack()) + ' uni_degree - On Uni Page')
				break
			elif 'local.asp' in page_check:
				print_function(str(inspect_stack()) + ' uni_degree - On City Page. Opening Uni')
				element_click(lock_webdriver, 'XPATH', ".//*[@class='university']", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' uni_degree - Opening City Page')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'TransferMoney' in page:
			if 'bank.asp?option=transfers' in page_check:
				print_function(str(inspect_stack()) + ' TransferMoney - On Transfer Page')
				break
			elif 'bank.asp' in page_check:
				print_function(str(inspect_stack()) + ' TransferMoney - On Bank Page. Clicking Transfer')

				# GET BANK BALANCE VARIABLE
				variables_list = running_thread[4]
				for item in running_thread[4]:
					if 'BankBalance:' in item:
						try:
							variables_list.remove(item)
						except:
							pass

				bank_balance = element_get_attribute(lock_webdriver, "XPATH", ".//*[@class='closing_balance']", "innerHTML")
				bank_balance = regex_match_between('\$', None, bank_balance)
				bank_balance = re.sub('[^0-9]', "", bank_balance)
				variables_list.append('BankBalance:' + str(bank_balance))

				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES FOR BANK BALANCE: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])

				element_click(lock_webdriver, "XPATH", ".//*[@id='bank_links']/ul/li[4]/a", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' TransferMoney - Opening Bank Page')
				open_income_menu(lock_webdriver, "Bank", running_thread)
				continue

		elif 'WithdrawMoney' in page:
			if 'bank.asp?option=withdrawal' in page_check:
				print_function(str(inspect_stack()) + ' WithdrawMoney - On Withdrawl Page')
				break
			elif 'bank.asp' in page_check:
				print_function(str(inspect_stack()) + ' WithdrawMoney - On Bank Page. Clicking Withdrawl')
				element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='bank_holder']/div[@id='holder_content']/div[@id='bank_links']/ul/li[3]/a", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' WithdrawMoney - Opening Bank Page')
				open_income_menu(lock_webdriver, "Bank", running_thread)
				continue

		elif 'Blackmarket' in page:
			if 'BlackMarket.asp' in page_check:
				print_function(str(inspect_stack()) + ' Blackmarket - On Page')
				return True
			else:
				print_function(str(inspect_stack()) + ' Blackmarket - Opening Page')
				if open_income_menu(lock_webdriver, "Black Market", running_thread):
					continue
				else:
					return False

		elif 'Mortician-Autopsy' in page:
			if 'funeral.asp' in page_check:
				print_function(str(inspect_stack()) + ' Mortician-Autopsy - On Page')
				break
			else:
				open_income_menu(lock_webdriver, "Autopsy Work", running_thread)
				continue

		elif 'Messages' in page:
			if 'comms.asp' in page_check:
				print_function(str(inspect_stack()) + ' Messages - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Messages - Opening Page')
				if 'In-Jail' in str(running_thread[4]):
					element_click(lock_webdriver, "XPATH", "//*[@id='nav_left']/p[1]/a/span", running_thread)
				else:
					element_click(lock_webdriver, "XPATH", "//*[@id='nav_left']/div[1]/a[1]/span", running_thread)
				continue

		elif 'Lawyer' in page:
			if 'court.asp' in page_check:
				print_function(str(inspect_stack()) + ' Lawyer - On Page')
				break
			elif element_found(lock_webdriver, "XPATH", "//*[@id='nav_left']/div[6]/a[1]/span"):
				print_function(str(inspect_stack()) + ' Lawyer - Opening Page')
				element_click(lock_webdriver, "XPATH", "//*[@id='nav_left']/div[6]/a[1]/span", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' Lawyer - Opening City')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'Judge' in page:
			if 'sentence.asp' in page_check:
				print_function(str(inspect_stack()) + ' Judge - On Page')
				break
			elif 'court.asp' in page_check:
				print_function(str(inspect_stack()) + ' Judge - On Court Page')
				element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div/a[1]/strong", running_thread)
				continue
			elif element_found(lock_webdriver, "XPATH", ".//*[@class='court']"):
				print_function(str(inspect_stack()) + ' Judge - Opening Court Page')
				element_click(lock_webdriver, "XPATH", ".//*[@class='court']", running_thread)
			else:
				print_function(str(inspect_stack()) + ' Judge - Opening City')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'PoliceCase' in page:
			if 'intray.asp' in page_check:
				print_function(str(inspect_stack()) + ' PoliceCase - On Page')
				break
			elif element_found(lock_webdriver, "XPATH", ".//*[@class='police']"):
				print_function(str(inspect_stack()) + ' PoliceCase - Opening InTray')
				element_click(lock_webdriver, "XPATH", ".//*[@class='police']", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' Police - Opening City')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'PoliceDuties' in page:
			if 'duties.asp' in page_check:
				break
			else:
				open_income_menu(lock_webdriver, "Police", running_thread)
				continue

		elif '911' in page:
			if '911.asp' in page_check:
				print_function(str(inspect_stack()) + ' 911 - On Page')
				break
			elif '/police/' in page_check:
				print_function(str(inspect_stack()) + ' 911 - Opening 911')
				if element_found(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@class='links']/a[7]"):
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@class='links']/a[7]", running_thread)
				else:
					# NO FORENSICS?
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@class='links']/a[6]", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' 911 - Opening Police Menu')
				element_click(lock_webdriver, "XPATH", ".//*[@class='police']", running_thread)
				continue

		elif 'Funeral_Smuggle' in page:
			if 'smugglefuneral.asp' in page_check:
				print_function(str(inspect_stack()) + ' Funeral Smuggle - On Page')
				break
			elif 'agcrime.asp' in page_check:
				aggs_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table", "innerHTML")
				update_unlocked_aggs(aggs_table, running_thread)
				element_click(lock_webdriver, "ID", "smugglefuneral", running_thread)
				element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
				continue
			else:
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'Customs_Blindeye' in page:
			if 'blindeye.asp' in page_check:
				print_function(str(inspect_stack()) + ' Customs Blindeye - On Page')
				break
			elif 'agcrime.asp' in page_check:
				aggs_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table", "innerHTML")
				update_unlocked_aggs(aggs_table, running_thread)
				element_click(lock_webdriver, "ID", "blindeye", running_thread)
				element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
				continue
			else:
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'AggsMenu' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH",
													   ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table",
													   "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)
					break
				else:
					print_function(str(inspect_stack()) + ' AggsMenu - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' AggsMenu - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'Pickpocket' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Pickpocket' in sub_page:
					print_function(str(inspect_stack()) + ' Pickpocket - On Page')
					break
				elif 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH",
													   ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table",
													   "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)

					element_click(lock_webdriver, "ID", "pickpocket", running_thread)
					element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
					continue
				else:
					print_function(str(inspect_stack()) + ' Pickpocket - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' Pickpocket - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'PayTribute' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Tribute' in sub_page:
					print_function(str(inspect_stack()) + ' Tribute - On Page')
					break
				elif 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table", "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)

					if 'Tribute' in running_thread[3]:
						element_click(lock_webdriver, "ID", "tribute", running_thread)
						element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
					else:
						return False
				else:
					print_function(str(inspect_stack()) + ' Tribute - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' Tribute - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'Mug' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Mug' in sub_page:
					print_function(str(inspect_stack()) + ' Mug - On Page')
					break
				elif 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH",
													   ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table",
													   "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)

					if 'Mug' in running_thread[3]:
						element_click(lock_webdriver, "ID", "mugging", running_thread)
						element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
					else:
						return False
				else:
					print_function(str(inspect_stack()) + ' Mug - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' Mug - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'BnE' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Breaking' in sub_page:
					print_function(str(inspect_stack()) + ' BnE - On Page')
					break
				elif 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH",
													   ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table",
													   "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)

					if 'BnE' in running_thread[3]:
						element_click(lock_webdriver, "ID", "breaking", running_thread)
						element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
						continue
					else:
						return False
				else:
					print_function(str(inspect_stack()) + ' BnE - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' BnE - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'Hack' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Hack' in sub_page:
					print_function(str(inspect_stack()) + ' Hack - On Page')
					break
				elif 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH",
													   ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table",
													   "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)

					if 'Hack' in running_thread[3]:
						element_click(lock_webdriver, "ID", "hack", running_thread)
						element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
						continue
					else:
						return False
				else:
					print_function(str(inspect_stack()) + ' Hack - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' Hack - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'ArmedRobbery' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Armed Robbery' in sub_page:
					print_function(str(inspect_stack()) + ' ArmedRobbery - On Page')
					break
				elif 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH",
													   ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table",
													   "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)

					if 'ArmedRobbery' in running_thread[3]:
						element_click(lock_webdriver, "ID", "armed", running_thread)
						element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
						continue
					else:
						return False
				else:
					print_function(str(inspect_stack()) + ' ArmedRobbery - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' ArmedRobbery - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'Torch' in page:
			if 'agcrime.asp' in page_check:
				sub_page = element_get_attribute(lock_webdriver, "ID", "holder_top", "innerHTML")
				if 'Torch' in sub_page:
					print_function(str(inspect_stack()) + ' Torch - On Page')
					break
				elif 'Aggravated Crime' in sub_page:
					aggs_table = element_get_attribute(lock_webdriver, "XPATH",
													   ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form/table",
													   "innerHTML")

					update_unlocked_aggs(aggs_table, running_thread)

					if 'Torch' in running_thread[3]:
						element_click(lock_webdriver, "ID", "torchbusiness", running_thread)
						element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
						continue
					else:
						return False
				else:
					print_function(str(inspect_stack()) + ' Torch - Opening Aggs Menu')
					open_income_menu(lock_webdriver, "Aggravated", running_thread)
					if cs_needed_check(lock_webdriver, running_thread):
						return False
					continue
			else:
				print_function(str(inspect_stack()) + ' Torch - Opening Aggs Menu')
				open_income_menu(lock_webdriver, "Aggravated", running_thread)
				if cs_needed_check(lock_webdriver, running_thread):
					return False
				continue

		elif 'Laundering' in page:
			if 'laundering.asp' in page_check:
				print_function(str(inspect_stack()) + ' Laundering - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Lawyer - Opening Page')
				if open_income_menu(lock_webdriver, "Laundering", running_thread):
					pass
				else:
					print_function('LAUNDER NOT UNLOCKED')
					return False
				continue

		elif 'MayorStocks' in page:
			if 'duties.asp?display=policy' in page_check:
				print_function(str(inspect_stack()) + ' Mayor - On Page')
				break
			elif 'duties.asp' in page_check:
				print_function(str(inspect_stack()) + ' Mayor - Opening Policy Settings')
				element_click(lock_webdriver, "XPATH", ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/div[@id='bank_links']/ul/li[3]/a", running_thread)
				continue
			elif 'politics.asp' in page_check:
				print_function(str(inspect_stack()) + ' Mayor - Opening Mayoral Duties')
				element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder'][1]/div[@id='holder_content']/div/a[5]/strong", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' Mayor - Opening Politics')
				element_click(lock_webdriver, "XPATH", ".//*[@class='politics']", running_thread)
				continue

		elif 'Obituaries' in page:
			if 'obituaries.asp' in page_check:
				print_function(str(inspect_stack()) + ' Obituaries - On Page')
				break
			elif 'forum.asp?t=funeral' in page_check:
				print_function(str(inspect_stack()) + ' Obituaries - On FP page')
				element_click(lock_webdriver, "XPATH", './/*[@id="forum_content"]/table/tbody/tr[6]/td/a', running_thread)
				continue
			elif 'local.asp' in page_check:
				print_function(str(inspect_stack()) + ' Obituaries - On City page - Open FP')
				element_click(lock_webdriver, "XPATH", ".//*[@class='funeral_parlour']", running_thread)

				# TORCHED FP CHECK
				if element_found(lock_webdriver, "ID", "fail"):
					driver.get("https://mafiamatrix.com/localcity/obituaries.asp")
					continue
			else:
				print_function(str(inspect_stack()) + ' Obituaries - Opening City')
				open_city(lock_webdriver, running_thread)
				continue

		elif 'Manufacture_Drugs' in page:
			if 'manufacture.asp' in page_check:
				print_function(str(inspect_stack()) + ' Manufacture_Drugs - On Manufacture Page')
				break
			elif 'drugs.asp' in page_check:
				print_function(str(inspect_stack()) + ' Manufacture_Drugs - On Drugs Page')
				element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[2]/a[1]/strong", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' Manufacture_Drugs - Opening Page')
				open_income_menu(lock_webdriver, "Drugs", running_thread)
				continue

		elif 'Drug_Deal' in page:
			if 'deals.asp' in page_check:
				print_function(str(inspect_stack()) + ' Drug_Deal - On Deals Page')
				break
			elif 'drugs.asp' in page_check:
				print_function(str(inspect_stack()) + ' Drug_Deal - On Drugs Page')
				element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[2]/a[3]/strong", running_thread)
				continue
			else:
				print_function(str(inspect_stack()) + ' Drug_Deal - Opening Page')
				open_income_menu(lock_webdriver, "Drugs", running_thread)
				continue

		elif 'BankCareer' in page:
			if 'banklaunder.asp' in page_check:
				print_function(str(inspect_stack()) + ' Bank Career - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Bank Career - Opening Page')
				open_income_menu(lock_webdriver, "Convert", running_thread)
				continue

		elif 'Mechanic' in page:
			if 'construction.asp' in page_check:
				print_function(str(inspect_stack()) + ' Mechanic - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Mechanic - Opening Page')
				open_income_menu(lock_webdriver, "Construction", running_thread)
				continue

		elif 'Journal' in page:
			if 'journal.asp' in page_check:
				print_function(str(inspect_stack()) + ' Journal - On Page')
				break
			else:
				print_function(str(inspect_stack()) + ' Journal - Opening Page')
				if 'In-Jail' in str(running_thread[4]):
					element_click(lock_webdriver, "XPATH", ".//*[@id='nav_left']/p[2]/a/span", running_thread)
				else:
					element_click(lock_webdriver, "XPATH", ".//*[@id='nav_left']/div[2]/a[1]/span", running_thread)
				continue
		else:
			print_function('go_to_page OPTION NOT FOUND: ' + str(page), "RED")

	return True


def get_players_list_currentcity(lock_webdriver):
	# CLEAR SAVED NAMES
	online_player_list_currentcity = []

	# GETS FULL LIST OF NAMES
	while True:
		online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
		if '|' in online_player_list_raw:
			break

	is_local_list_only = True
	if '*' in online_player_list_raw:
		is_local_list_only = False

	online_player_list_raw_split = online_player_list_raw.split("|")
	for player_raw in online_player_list_raw_split:
		if (':Alive:player:' in player_raw) or (':In-Jail:player:' in player_raw):
			if is_local_list_only or ('*' in player_raw):
				player_name = regex_match_between('>', '<', player_raw)
				online_player_list_currentcity.append(player_name)
	return online_player_list_currentcity


def release_webdriver(lock_webdriver):
	try:
		lock_webdriver.release()
	except ValueError as e:
		if str(e) == 'semaphore or lock released too many times':
			pass
		else:
			raise Exception(e)
	return


def open_all_locks():
	print_function('OPEN ALL THREAD LOCKS. THIS IS TO PREVENT DEADLOCK FROM THE TERMINATED THREAD NOT RELEASING IN PROGRESS LOCKS')
	for lock in lock_list:
		if 'None' not in str(globals()[lock]):
			print_function('releasing ' + str(lock))
			try:
				globals()[lock].release()
			except ValueError as e:
				if str(e) == 'semaphore or lock released too many times':
					print_function('ERROR: LOCK RELEASED TOO MANY TIMES:' + str(lock), "RED")
					pass
				else:
					raise Exception(e)
	return


def get_url(lock_webdriver):
	while True:
		url = get_url_backend(lock_webdriver)
		if isinstance(url, str):
			break
		else:
			print_function('get_url - EXPECTING TYPE STR - ACTUAL: ' + str(type(url)) + " for: " + str(url), "RED")
		time.sleep(1)
	return url


def get_url_backend(lock_webdriver):
	# THIS SHOULD ONLY BE CALLED VIA get_url AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	try:
		url = driver.current_url
	except:
		release_webdriver(lock_webdriver)
		return
	release_webdriver(lock_webdriver)
	return url


def regex_match_between(start_needle, end_needle, haystack):
	if end_needle == None:
		match_result = re.search(rf'{start_needle}(.*)', haystack, re.DOTALL)
	elif start_needle == None:
		match_result = re.search(rf'(.*){end_needle}', haystack, re.DOTALL)
	else:
		match_result = re.search(rf'{start_needle}(.*?){end_needle}', haystack, re.DOTALL)
	if 'match=' in str(match_result):
		pass
	else:
		print_function('REGEX NO MATCH: FROM: ' + str(start_needle) + ' TO: ' + str(end_needle) + ' IN: ' + str(haystack) + ' RESULT: ' + str(match_result))
	if match_result is None:
		discord_error(config['Auth']['discord_id'] + ' REGEX MATCH BETWEEN FAILED - START:' + str(start_needle) + ' END:' + str(end_needle) + ' HAYSTACK:' + str(haystack))
	return match_result.group(1)


def go_back(lock_webdriver):
	lock_webdriver.acquire()
	driver.execute_script("window.history.go(-1)")
	release_webdriver(lock_webdriver)
	return


def clearkeys(lock_webdriver, get_by, element_path, which_item=0):
	while True:
		if clearkeys_backend(lock_webdriver, get_by, element_path, which_item=0):
			break
		else:
			print_function(str(inspect_stack()) + ' clearkeys FAILED - ' + str(element_path), "RED")
		time.sleep(1)
	return


def clearkeys_backend(lock_webdriver, get_by, element_path, which_item=0):
	# THIS SHOULD ONLY BE CALLED VIA clearkeys AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	try:
		if "ID" in get_by:
			driver.find_elements(By.ID, element_path)[which_item].clear()
		elif "XPATH" in get_by:
			driver.find_elements(By.XPATH, element_path)[which_item].clear()
		elif "LINK" in get_by:
			driver.find_elements(By.LINK_TEXT, element_path)[which_item].clear()
		elif "PARTIALLINK" in get_by:
			driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item].clear()
		elif "NAME" in get_by:
			driver.find_elements(By.NAME, element_path)[which_item].clear()
		elif "TAG" in get_by:
			driver.find_elements(By.TAG_NAME, element_path)[which_item].clear()
		elif "CLASS" in get_by:
			driver.find_elements(By.CLASS_NAME, element_path)[which_item].clear()
		elif "CSS" in get_by:
			driver.find_elements(By.CSS_SELECTOR, element_path)[which_item].clear()
		else:
			print_function(str(inspect_stack()) + 'clearkeys ERROR: ' + str(get_by) + " " + str(element_path), "RED")
			release_webdriver(lock_webdriver)
			return False
	except:
		release_webdriver(lock_webdriver)
		return False
	release_webdriver(lock_webdriver)
	return True


def withdraw_money(lock_webdriver, running_thread, amount_to_withdraw):
	go_to_page(lock_webdriver, "WithdrawMoney", running_thread)

	print_function('WITHDRAW MONEY - ENTERED DETAILS: ' + str(amount_to_withdraw))
	sendkeys(lock_webdriver, "XPATH", "//*[@id='bank_action']/form/table/tbody/tr[1]/td[3]/input[@class='input']", amount_to_withdraw)

	print_function('WITHDRAW MONEY - SUBMIT')
	# SUBMIT
	element_click(lock_webdriver, "XPATH", "//*[@id='bank_action']/form/table/tbody/tr[2]/td[3]/input[@class='submit']", running_thread)

	withdraw_money_success = False
	if element_found(lock_webdriver, "ID", "success"):
		withdraw_money_success = True
	return withdraw_money_success


def sendkeys(lock_webdriver, get_by, element_path, keys_to_send, which_item=0):
	while True:
		if sendkeys_backend(lock_webdriver, get_by, element_path, keys_to_send, which_item):
			print_function("SENT KEYS SUCCESSFULLY: " + str(keys_to_send))
			break
		else:
			print_function(str(inspect_stack()) + ' sendkeys FAILED - Keys:' + str(keys_to_send) + " TO PATH: " + str(element_path), "RED")
		time.sleep(1)
	return


def sendkeys_backend(lock_webdriver, get_by, element_path, keys_to_send, which_item=0):
	# THIS SHOULD ONLY BE CALLED VIA sendkeys AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	try:
		if "ID" in get_by:
			element = driver.find_elements(By.ID, element_path)[which_item]
		elif "XPATH" in get_by:
			element = driver.find_elements(By.XPATH, element_path)[which_item]
		elif "LINK" in get_by:
			element = driver.find_elements(By.LINK_TEXT, element_path)[which_item]
		elif "PARTIALLINK" in get_by:
			element = driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item]
		elif "NAME" in get_by:
			element = driver.find_elements(By.NAME, element_path)[which_item]
		elif "TAG" in get_by:
			element = driver.find_elements(By.TAG_NAME, element_path)[which_item]
		elif "CLASS" in get_by:
			element = driver.find_elements(By.CLASS_NAME, element_path)[which_item]
		elif "CSS" in get_by:
			element = driver.find_elements(By.CSS_SELECTOR, element_path)[which_item]
		else:
			print_function(str(inspect_stack()) + 'sendkeys ERROR 1: ' + str(get_by) + " " + str(keys_to_send) + " " + str(element_path) + " " + str(which_item), "RED")
			release_webdriver(lock_webdriver)
			return
	except:
		print_function(str(inspect_stack()) + 'sendkeys ERROR 2: ' + str(get_by) + " " + str(keys_to_send) + " " + str(element_path) + " " + str(which_item), "RED")
		release_webdriver(lock_webdriver)
		release_webdriver(lock_webdriver)
		return

	random_timer = random.randrange(0, 11)
	random_timer = random_timer / 10
	time.sleep(random_timer)
	element.send_keys(keys_to_send)
	time.sleep(0.1)

	sent_keys_string = str(element.get_attribute('value'))
	keys_to_send = str(keys_to_send).strip()
	if ( str(keys_to_send) in str(sent_keys_string) ):
		keys_sent = True
	elif ( (Keys.ESCAPE == keys_to_send) or (Keys.ENTER == keys_to_send) or (Keys.DOWN == keys_to_send) ):
		keys_sent = True
	else:
		keys_sent = False


	release_webdriver(lock_webdriver)
	return keys_sent


def is_element_displayed(lock_webdriver, get_by, element_path, which_item=0):
	while True:
		is_displayed = is_element_displayed_backend(lock_webdriver, get_by, element_path, which_item)
		if isinstance(is_displayed, bool):
			break
		else:
			print_function(str(inspect_stack()) + 'is_element_displayed ERROR: EXPECTING TYPE BOOL - ACTUAL: ' + str(type(is_displayed)) + " FOR: " + str(element_path), "RED")
		time.sleep(1)
	return is_displayed


def is_element_displayed_backend(lock_webdriver, get_by, element_path, which_item=0):
	# THIS SHOULD ONLY BE CALLED VIA is_element_displayed AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	try:
		if "ID" in get_by:
			is_displayed = driver.find_elements(By.ID, element_path)[which_item].is_displayed()
		elif "XPATH" in get_by:
			is_displayed = driver.find_elements(By.XPATH, element_path)[which_item].is_displayed()
		elif "LINK" in get_by:
			is_displayed = driver.find_elements(By.LINK_TEXT, element_path)[which_item].is_displayed()
		elif "PARTIALLINK" in get_by:
			is_displayed = driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item].is_displayed()
		elif "NAME" in get_by:
			is_displayed = driver.find_elements(By.NAME, element_path)[which_item].is_displayed()
		elif "TAG" in get_by:
			is_displayed = driver.find_elements(By.TAG_NAME, element_path)[which_item].is_displayed()
		elif "CLASS" in get_by:
			is_displayed = driver.find_elements(By.CLASS_NAME, element_path)[which_item].is_displayed()
		elif "CSS" in get_by:
			is_displayed = driver.find_elements(By.CSS_SELECTOR, element_path)[which_item].is_displayed()
		else:
			print_function(str(inspect_stack()) + 'is_element_displayed ERROR: ' + str(get_by))
			release_webdriver(lock_webdriver)
			return
	except:
		release_webdriver(lock_webdriver)
		return
	release_webdriver(lock_webdriver)
	return is_displayed


def get_dirty_money(lock_webdriver):
	dirty_money = element_get_attribute(lock_webdriver, "XPATH",
										".//*[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_end'][2]",
										"innerHTML")
	dirty_money = re.sub('[^0-9]', "", dirty_money)
	return dirty_money


def open_income_menu(lock_webdriver, which_menu_item, running_thread):
	running_thread_cache = running_thread[0]
	# OPEN INCOME MENU
	while True:
		if element_found(lock_webdriver, 'XPATH', ".//*[@id='admintoolstable']/tbody/tr"):
			# EXISTS. CHECK DISPLAYED
			if is_element_displayed(lock_webdriver, 'XPATH', ".//*[@id='admintoolstable']/tbody/tr[1]/td/a"):
				break
			else:
				element_click(lock_webdriver, "XPATH", ".//*[@class='income']", running_thread)
		else:
			element_click(lock_webdriver, "XPATH", ".//*[@class='income']", running_thread)

	# USED FOR OLD XPATH METHOD
	# menu_item_count = (element_count(lock_webdriver, "XPATH", "//*[@id='admintoolstable']/tbody/tr") + 1)
	found = False
	menu_counter = 1

	income_menu_table = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='docTipsLayer']/div[@class='tipClass']/table[@id='admintoolstable']", "innerHTML")

	unlocked_aggs_list = running_thread[3]

	if (which_menu_item == 'Laundering'):
		if which_menu_item in income_menu_table:
			pass
		else:
			print_function('LAUNDER NOT UNLOCKED')
			return False

	if 'Black Market' in income_menu_table:
		if not 'BlackMarket' in unlocked_aggs_list:
			unlocked_aggs_list.append('BlackMarket')
	else:
		if 'BlackMarket' in unlocked_aggs_list:
			try:
				unlocked_aggs_list.remove('BlackMarket')
			except:
				pass

	running_thread[3] = unlocked_aggs_list
	write_file("env/agg_unlocks.txt", running_thread[3])
	print_function('blackmarket check: ' + str(running_thread[3]))

	income_menu_table_split = income_menu_table.split('<tr>')
	for menu_item in income_menu_table_split:
		if '<td class=' in menu_item:
			print_function('counter: ' + str(menu_counter) + ' item: ' + str(menu_item))
			if which_menu_item in menu_item:
				found = True
				break
			menu_counter += 1
		else:
			continue

	if found:
		element_click(lock_webdriver, "XPATH", "//*[@id='admintoolstable']/tbody/tr[" + str(menu_counter) + "]/td/a", running_thread)

	'''
	# OLD XPATH METHOD
	while menu_counter < menu_item_count:
		menu_item_path = "//*[@id='admintoolstable']/tbody/tr[" + str(menu_counter) + "]/td/a"
		while True:
			menu_item = element_get_attribute(lock_webdriver, "XPATH", menu_item_path, "innerHTML")
			print('income menu item: ', menu_item)
			if menu_item == "INCOME MENU NOT OPEN":
				if running_thread_cache == running_thread[0]:
					element_click(lock_webdriver, "XPATH", "//*[@class='income']", running_thread)
					break
				else:
					print('OPEN INCOME MENU - RUNNING DIFFERENT TO CACHE: ', running_thread_cache, ' VS: ', running_thread[0])
					return False
			else:
				break
		if which_menu_item in menu_item:
			found = True
		if found:
			# CLICK ITEM
			element_click(lock_webdriver, "XPATH", "//*[@id='admintoolstable']/tbody/tr[" + str(menu_counter) + "]/td/a", running_thread)
			break
		menu_counter += 1
	'''

	return found


def thread_remove_from_queue(running_thread, waiting_thread_list):
	fail_count = 0
	while True:
		try:
			for thread in waiting_thread_list:
				if inspect.stack()[1][3] in thread:
					try:
						waiting_thread_list.remove(thread)
					except:
						pass

			waiting_thread_list.sort()
			running_thread[0] = '999None'
			print_function(str(inspect.stack()[1][3]) + ' THREAD FREE - QUEUE: ' + str(waiting_thread_list), "GREEN")

			# UPDATE TEXT BACKUP
			write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

			if int(fail_count) > 0:
				discord_error("BROKEN PIPE PASSED - THREAD REMOVE FROM QUEUE")
			break
		except Exception as e:
			if int(fail_count >= 10):
				raise Exception(e)
			elif 'pipe' in str(e):
				fail_count += 1
				time.sleep(5)
				pass
			else:
				raise Exception(e)
	return


def thread_add_to_queue(running_thread, waiting_thread_list, thread_priority, additional_string=None):
	fail_count = 0
	while True:
		try:
			if str(inspect.stack()[1][3]) in str(waiting_thread_list):
				print_function(str(inspect.stack()[1][3]) + ' ALREADY IN WAITING THREAD LIST BUT ATTEMPTING TO ADD AGAIN', "RED")
			else:
				print_function('add to queue inspect stack: ' + str(str(inspect.stack()[1][3])))
				if additional_string is None:
					waiting_thread_list.append(str(thread_priority) + str(inspect.stack()[1][3]))
				elif ('hack' in inspect.stack()[1][3]) or ('pickpocket' in inspect.stack()[1][3]) or ('mug' in inspect.stack()[1][3]) or ('torch' in inspect.stack()[1][3]) or (
						'bne' in inspect.stack()[1][3]) or ('armedrobbery' in inspect.stack()[1][3]):
					# SKIP SENDING THE ADDITIONAL STRING (AGG TARGETS)
					waiting_thread_list.append(str(thread_priority) + str(inspect.stack()[1][3]))
				else:
					waiting_thread_list.append(str(thread_priority) + str(inspect.stack()[1][3]) + str(additional_string))

			waiting_thread_list.sort()
			print_function(str(inspect.stack()[1][3]) + ' THREAD QUEUED ' + str(waiting_thread_list), "GREEN")

			# UPDATE TEXT BACKUP
			write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

			while True:
				if inspect.stack()[1][3] in running_thread[0]:
					time.sleep(1)
					break
				time.sleep(1)

			if int(fail_count) > 0:
				discord_error("BROKEN PIPE PASSED - THREAD ADD TO QUEUE")
			break
		except Exception as e:
			if int(fail_count >= 10):
				raise Exception(e)
			elif 'pipe' in str(e):
				fail_count += 1
				time.sleep(5)
				pass
			else:
				raise Exception(e)
	return


def get_your_character_name(lock_webdriver):
	your_character_name = element_get_attribute(lock_webdriver, "XPATH",
												"/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display'][1]/a",
												"innerHTML")

	return str(your_character_name)


def get_your_character_rank(lock_webdriver):
	your_character_rank = element_get_attribute(lock_webdriver, "XPATH",
												"/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display'][2]",
												"innerHTML")
	return str(your_character_rank)


def get_your_character_rank_percent(lock_webdriver):
	#your_character_rank_percent = element_get_attribute(lock_webdriver, "XPATH",
	#														"//*[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_bar'][2]/div[@class='display_green']",
	#													"innerHTML")

	your_character_rank_percent = element_get_attribute(lock_webdriver, "XPATH",
														"//*[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_bar'][2]",
														"outerHTML")

	your_character_rank_percent = regex_match_between('aria-valuenow="', '"', your_character_rank_percent)

	return str(your_character_rank_percent)


def get_your_character_occupation(lock_webdriver):
	#your_character_occupation = element_get_attribute(lock_webdriver, "XPATH",
	#												  "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_end'][1]",
	#												  "innerHTML")
	your_character_occupation = element_get_attribute(lock_webdriver, "XPATH",
													  "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_end']",
													  "innerHTML")
	return str(your_character_occupation)


def get_your_clean_money(lock_webdriver):
	your_clean_money = element_get_attribute(lock_webdriver, "XPATH",
											 "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display'][3]/form",
											 "innerHTML")
	your_clean_money = regex_match_between('\$', None, your_clean_money)
	your_clean_money = re.sub('[^0-9]', "", your_clean_money)
	return int(your_clean_money)


def convert_timer_to_total_seconds(timer_check):
	if "Ready" in timer_check:
		timer_total_seconds = 0
	elif ":" in timer_check:
		timer_split = timer_check.split(":")
		hours = int(timer_split[0])
		minutes = int(timer_split[1])
		seconds = int(timer_split[2])
		timer_total_seconds = ((hours * 3600) + (minutes * 60) + seconds)
	else:
		print_function(str(inspect_stack()) + ' convert_timer_to_total_seconds ERROR: ' + str(timer_check), "RED")
		return 0
	return timer_total_seconds


def get_timer(lock_webdriver, which_timer, running_thread):
	if "Earn" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][1]/form"
	elif "Action" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][2]/form"
	elif "Whack" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][3]/form"
	elif "Launder" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][4]/form"
	elif "Travel" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][5]/form"
	elif "Case" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][6]/form"
	elif "Trafficking" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][7]/form"
	elif "Skill" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][8]/form"
	elif "Event" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][9]"
	else:
		print_function(str(inspect_stack()) + ' get_timer ERROR: ' + str(which_timer), "RED")
		return

	while True:
		timer_check = element_get_attribute(lock_webdriver, 'XPATH', timer_path, 'innerHTML')
		print("TIMER CHECK: ", timer_check)
		if ( ('Ready' in str(timer_check)) or any(i.isdigit() for i in str(timer_check)) ):
			break
		else:
			if 'Earn' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][1]/form", running_thread)
			elif 'Action' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][2]/form", running_thread)
			elif 'Whack' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][3]/form", running_thread)
			elif 'Launder' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][4]/form", running_thread)
			elif 'Travel' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][5]/form", running_thread)
			elif 'Case' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][6]/form", running_thread)
			elif 'Trafficking' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][7]/form", running_thread)
			elif 'Skill' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][8]/form", running_thread)
			elif 'Event' in str(which_timer):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][9]", running_thread)


	regexsearch = re.search(">\d\d:\d\d:\d\d<",
							timer_check)  # WE USE >< TO GET THE TIMER DURATION RATHER THAN THE DATE/TIME WHEN IT ENDS
	if 'match=' in str(regexsearch):
		regexsearch2 = re.search("\d\d:\d\d:\d\d", str(regexsearch.group(0)))  # REMOVE THE >< TO GET A USABLE TIMER
		timer_check = regexsearch2.group(0)

	if ( ("Ready" in timer_check) or (":" in timer_check) ):
		timer_total_seconds = convert_timer_to_total_seconds(timer_check)
	else:
		timer_total_seconds = 0
		print_function('ERROR: NO TIMER RESULTS FOR ' + str(which_timer) + " VERIFY THIS ISNT MINIMIZED ON THE MM PAGE", "RED")
	return timer_total_seconds


def wait_till_timer_ready(lock_webdriver, which_timer):
	timer_path = ""
	if "Earn" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][1]/form/span[@class='donation_timer']"
	elif "Action" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][2]/form/span[@class='donation_timer']"
	elif "Whack" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][3]/form/span[@class='donation_timer']/span"
	elif "Launder" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][4]/form/span[@class='donation_timer']/span"
	elif "Travel" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][5]/form/span[@class='donation_timer']/span"
	elif "Case" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][6]/form/span[@class='donation_timer']/span"
	elif "Trafficking" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][7]/form/span[@class='donation_timer']/span"
	elif "Skill" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][8]/form/span[@class='donation_timer']/span"
	elif "Event" in which_timer:
		timer_path = "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']/div[@id='user_timers_holder']/div[@id='timer_left'][9]/span[@class='donation_timer']/span"
	else:
		print_function(str(inspect_stack()) + ' wait_till_timer_ready ERROR: ' + str(which_timer), "RED")

	print_function(str(inspect_stack()) + ' wait_till_timer_ready - awaiting ready timer' + str(which_timer))
	while True:
		timer_check = element_get_attribute(lock_webdriver, 'XPATH',
											timer_path,
											'innerHTML')
		if "Ready" in timer_check:
			print_function(str(inspect_stack()) + ' wait_till_timer_ready - timer is ready')
			break
		time.sleep(1)
	return


def element_found(lock_webdriver, get_by, element_path):
	while True:
		bool_check = element_found_backend(lock_webdriver, get_by, element_path)
		if isinstance(bool_check, bool):
			break
		else:
			print_function(str(inspect_stack()) + 'element_found ERROR: EXPECTING TYPE BOOL - ACTUAL: ' + str(type(bool_check)) + " FOR: " + str(bool_check), "RED")
		time.sleep(1)
	return bool_check


def element_found_backend(lock_webdriver, get_by, element_path):
	# THIS SHOULD ONLY BE CALLED VIA element_found AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	count_found = 0
	# noinspection PyBroadException
	try:
		if "ID" in get_by:
			count_found = len(driver.find_elements(By.ID, element_path))
		elif "XPATH" in get_by:
			count_found = len(driver.find_elements(By.XPATH, element_path))
		elif "LINK" in get_by:
			count_found = len(driver.find_elements(By.LINK_TEXT, element_path))
		elif "PARTIALLINK" in get_by:
			count_found = len(driver.find_elements(By.PARTIAL_LINK_TEXT, element_path))
		elif "NAME" in get_by:
			count_found = len(driver.find_elements(By.NAME, element_path))
		elif "TAG" in get_by:
			count_found = len(driver.find_elements(By.TAG_NAME, element_path))
		elif "CLASS" in get_by:
			count_found = len(driver.find_elements(By.CLASS_NAME, element_path))
		elif "CSS" in get_by:
			count_found = len(driver.find_elements(By.CSS_SELECTOR, element_path))
		else:
			print_function(str(inspect_stack()) + 'element_found ERROR: ' + str(get_by), "RED")
	except:
		release_webdriver(lock_webdriver)
		return

	found = False
	if count_found > 0:
		found = True

	if "//*[@class ='btn  btn-primary btn-lg btn-play alive']" in element_path:
		# AVOID LOGGED IN CHECK SPAM
		pass
	elif "//*[@class='input-group input-group-lg'][1]/input[@id='email']" in element_path:
		# AVOID LOGGED IN CHECK SPAM
		pass
	elif ((found == False) and ('gbh' == element_path)):
		# AVOID GBH CHECK SPAM
		pass
	elif ('top_bar' == element_path) or ('/html/body/div[4]/div[4]/div[1]/div[2]/center/font[3]' == element_path):
		# AVOID CAPTCHA CHECK SPAM
		pass
	else:
		print_function(str(inspect_stack()) + ' element_found result: ' + str(found) + " " + str(element_path))

	release_webdriver(lock_webdriver)
	return found


def element_count(lock_webdriver, get_by, element_path):
	while True:
		count = element_count_backend(lock_webdriver, get_by, element_path)
		if isinstance(count, int):
			break
		else:
			print_function(str(inspect_stack()) + 'element_found ERROR: EXPECTING TYPE INT - ACTUAL: ' + str(type(count)) + " FOR: " + str(count), "RED")
		time.sleep(1)
	print_function(str(inspect_stack()) + ' element_count returned result: ' + str(count) + " " + str(element_path))
	return count


def element_count_backend(lock_webdriver, get_by, element_path):
	# THIS SHOULD ONLY BE CALLED VIA element_count AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	count_found = 0
	try:
		if "ID" in get_by:
			count_found = len(driver.find_elements(By.ID, element_path))
		elif "XPATH" in get_by:
			count_found = len(driver.find_elements(By.XPATH, element_path))
		elif "LINK" in get_by:
			count_found = len(driver.find_elements(By.LINK_TEXT, element_path))
		elif "PARTIALLINK" in get_by:
			count_found = len(driver.find_elements(By.PARTIAL_LINK_TEXT, element_path))
		elif "NAME" in get_by:
			count_found = len(driver.find_elements(By.NAME, element_path))
		elif "TAG" in get_by:
			count_found = len(driver.find_elements(By.TAG_NAME, element_path))
		elif "CLASS" in get_by:
			count_found = len(driver.find_elements(By.CLASS_NAME, element_path))
		elif "CSS" in get_by:
			count_found = len(driver.find_elements(By.CSS_SELECTOR, element_path))
		else:
			print_function(str(inspect_stack()) + 'element_count ERROR: ' + str(get_by), "RED")
	except Exception as except_error:
		print_function(str(inspect_stack()) + 'element_count EXCEPTION: ' + str(get_by) + " " + str(element_path) + " " + str(except_error), "RED")
		release_webdriver(lock_webdriver)
		return

	print_function(str(inspect_stack()) + ' element_count result: ' + str(count_found) + " " + str(element_path))
	release_webdriver(lock_webdriver)
	return count_found


def element_click(lock_webdriver, get_by, element_path, running_thread, which_item=0):
	while True:
		if 'captcha' in str(running_thread):
			pass
		else:
			url_check = get_url(lock_webdriver)
			if ('random.asp' in url_check):
				print_function(str(inspect_stack()) + 'element_click CLICK BLOCKED - ON CAPTCHA PAGE - PATH: ' + str(element_path), "RED")
				time.sleep(10000)
		if element_click_backend(lock_webdriver, get_by, element_path, running_thread, which_item):
			clicked = True
			break
		elif "[@id='consumables']" in str(element_path):
			random_timer = random.randrange(1440, 1680)
			globals()['timers'].__dict__['consume_drugs_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
			write_file("env/consume_drugs_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
			return True
		else:
			print_function(str(inspect_stack()) + 'element_click FAILED - PATH: ' + str(element_path), "RED")
			clicked = False

			if "[@id='docTipsLayer']/div[@class='tipClass']/form/input" in element_path:
				# QUICK EARN FAILED. RETURN SO THE QUICK EARN LOOP CAN BE RUN AGAIN
				print_function(str(inspect_stack()) + 'element_click QUICK EARN tipClass FAILED - RETURNING FAIL FOR THE QUICK EARN LOOP', "RED")
				break
		time.sleep(1)
	return clicked


def element_click_backend(lock_webdriver, get_by, element_path, running_thread, which_item=0):
	# THIS SHOULD ONLY BE CALLED VIA element_click AS THAT DOES TYPE/CLASS VERIFICATION
	running_thread_cache = running_thread[0]
	print_function('element click - running thread cache: ' + str(running_thread_cache) + ' vs: ' + str(running_thread[0]))
	if 'captcha' in str(running_thread):
		pass
	else:
		url_check = get_url(lock_webdriver)
		if ('random.asp' in url_check):
			print_function(str(inspect_stack()) + 'element_click CLICK BLOCKED - ON CAPTCHA PAGE - PATH: ' + str(element_path), "RED")
			time.sleep(10000)
	lock_webdriver.acquire()
	while True:
		try:
			if "ID" in get_by:
				# element_to_click = driver.find_elements(By.ID, element_path)[which_item]
				element_to_click = driver.find_elements(By.CSS_SELECTOR, "[id*='" + element_path + "']")[which_item]
			elif "XPATH" in get_by:
				element_to_click = driver.find_elements(By.XPATH, element_path)[which_item]
			elif "LINK" in get_by:
				element_to_click = driver.find_elements(By.LINK_TEXT, element_path)[which_item]
			elif "PARTIALLINK" in get_by:
				element_to_click = driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item]
			elif "NAME" in get_by:
				element_to_click = driver.find_elements(By.NAME, element_path)[which_item]
			elif "TAG" in get_by:
				element_to_click = driver.find_elements(By.TAG_NAME, element_path)[which_item]
			elif "CLASS" in get_by:
				element_to_click = driver.find_elements(By.CLASS_NAME, element_path)[which_item]
			elif "CSS" in get_by:
				element_to_click = driver.find_elements(By.CSS_SELECTOR, element_path)[which_item]
			else:
				print_function(str(inspect_stack()) + 'element_click ERROR: ' + str(get_by), "RED")
				release_webdriver(lock_webdriver)
				print_function("CLICK FAILED ERROR 1", "RED")
				return False
		except Exception as e:
			if "[@id='admintoolstable']/tbody" in element_path:
				print_function(str(inspect_stack()) + ' CLICKING ITEM IN INCOME MENU FAILED - OPEN THIS FIRST')
				random_timer = random.randrange(0, 11)
				random_timer = random_timer / 10
				time.sleep(random_timer)
				driver.find_element(By.XPATH, ".//*[@id='nav_left']/p[5]/a[1]/span[@class='income']").click()

			release_webdriver(lock_webdriver)
			print_function("CLICK FAILED ERROR 2", "RED")
			print_function(str(e), "RED")
			return False

		# print(inspect_stack(), ' element_click moving to element: ', element_to_click)
		random_timer = random.randrange(0, 22)
		random_timer = random_timer / 10
		time.sleep(random_timer)

		try:
			webdriver.ActionChains(driver).move_to_element(element_to_click).perform()
		except:
			print_function("CLICK FAILED ERROR 3", "RED")
			return False

		# print(inspect_stack(), ' element_click moved to element: ', element_to_click)

		# RANDOM WAIT TO AVOID BOT DETECTION. WAITS ANYTHING UP TO 3 SECOND BEFORE
		random_timer = random.randrange(0, 11)
		random_timer = random_timer / 10
		time.sleep(random_timer)
		try:
			# print(inspect_stack(), ' element_click - clicking', element_path)
			element_to_click.click()
		except Exception as exception_error_message:
			if 'is not clickable' in str(exception_error_message):
				print_function(str(inspect_stack()) + ' element_click - object is not clickable. refreshing first', "RED")
				# refresh page and try again
				driver.refresh()
				# webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.XPATH, ".//*[@id='logo_hit']/a")[0]).perform()
				# driver.find_elements(By.XPATH, ".//*[@id='logo_hit']/a")[0].click()
				print_function(str(inspect_stack()) + ' element_click - refreshed. trying again', "RED")
				continue
			elif ('element is not attached' or 'stale element reference') in str(exception_error_message):
				print_function('element_click - stale element reference. trying again', "RED")
				continue
			elif (('element not interactable' in str(exception_error_message)) or ('element not visible' in str(exception_error_message))) and (
					'open_income_menu' in str(inspect_stack())):
				print_function('element click - running thread cache: ' + str(running_thread_cache) + ' vs: ' + str(running_thread[0]))
				if str(running_thread_cache) != str(running_thread[0]):
					print_function('element click - different to cache. not clicking income menu')
					release_webdriver(lock_webdriver)
					print_function("CLICK FAILED ERROR 4", "RED")
					return False
				else:
					# INCOME MENU CLOSED WHILE TRYING TO CLICK. REOPEN AND TRY AGAIN
					print_function('element_click - not interactable - opening income menu', "RED")
					random_timer = random.randrange(0, 22)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					webdriver.ActionChains(driver).move_to_element(driver.find_element(By.XPATH, ".//*[@id='nav_left']/p[5]/a[1]/span[@class='income']")).perform()
					random_timer = random.randrange(0, 11)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					driver.find_element(By.XPATH, ".//*[@id='nav_left']/p[5]/a[1]/span[@class='income']").click()
					print_function('element_click - not interactable - trying again', "RED")
					continue
			elif ('element not visible' in str(exception_error_message)):
				if "[@id='docTipsLayer']/div[@class='tipClass']/form/input" in str(element_path):
					print_function('element_click - quick earn not visible - clicking this first', "RED")
					random_timer = random.randrange(0, 22)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					webdriver.ActionChains(driver).move_to_element(driver.find_element(By.XPATH, ".//*[@id='nav_left']/p[5]/a[2]/img")).perform()
					random_timer = random.randrange(0, 11)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					driver.find_element(By.XPATH, ".//*[@id='nav_left']/p[5]/a[2]/img").click()
					continue
				else:
					print_function('element click - not visible. retrying  --  path: ' + element_path, "RED")
					time.sleep(2)
				continue
			else:
				print_function('raising other exception - path: ' + str(element_path), "RED")
				print_function("EXCEPTION ERROR: " + str(exception_error_message), "RED")
				raise Exception(exception_error_message)

		print_function(str(inspect_stack()) + ' element_click - clicked ' + str(element_path))

		if 'quick_earn' in str(inspect_stack()):
			# AVOID AUTOMATICALLY UPDATING FOR EARN SINCE IT CAN HAVE BLANK PAGE AFTERWARDS. THIS IS MANUALLY UPDATED AFTER QUICK EARN
			pass
		else:
			try:
				check_right_bar_correct = driver.find_element(By.XPATH, "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']").get_attribute('innerHTML')
			except:
				check_right_bar_correct = ''
			if '/income/deposit.asp' in check_right_bar_correct:
				running_thread[2] = check_right_bar_correct

				if 'Jail Rank' in check_right_bar_correct:
					if 'In-Jail' in str(running_thread[4]):
						pass
					else:
						variables_list = running_thread[4]
						variables_list.append('In-Jail')
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR IN-JAIL: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])

						waiting_thread_list.append('9zterminate-everything')
						print_function('9zterminate-everything THREAD QUEUED AS IN OR OUT OF JAIL - QUEUED VIA FUNCION - QUICK EARN ' + str(waiting_thread_list), "GREEN")
				else:
					# NOT IN JAIL
					if 'In-Jail' in str(running_thread[4]):
						variables_list = running_thread[4]
						try:
							variables_list.remove('In-Jail')
						except:
							pass
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR NOT IN-JAIL: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])

				running_thread[1] = datetime.datetime.utcnow()

		release_webdriver(lock_webdriver)
		break
	return True


def element_get_attribute(lock_webdriver, get_by, element_path, element_attribute, which_item=0):
	blank_page_check_count = 0
	while True:
		attribute = element_get_attribute_backend(lock_webdriver, get_by, element_path, element_attribute, which_item)
		if isinstance(attribute, str):
			break
		else:
			print_function(str(inspect_stack()) + 'element_get_attrib ERROR: EXPECTING TYPE STR - ACTUAL: ' + str(type(attribute)) + " FOR: " + str(attribute), "RED")
		time.sleep(5)
	return attribute


def element_get_attribute_backend(lock_webdriver, get_by, element_path, element_attribute, which_item=0):
	# THIS SHOULD ONLY BE CALLED VIA element_get_attribute AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	attribute = None

	inspect_stack()

	if 'top_bar' == element_path:
		pass
	else:
		print_function('get_attrib start: ' + str(inspect_stack()) + ' path: ' + str(element_path))

	if "ID" in get_by:
		try:
			attribute = driver.find_elements(By.ID, element_path)[which_item].get_attribute(element_attribute)
		except Exception as e:
			if ('index out of range' or 'stale element') in str(e):
				print_function('get_attrib EXCEPTION: ' + str(inspect_stack()) + ' path: ' + str(element_path) + ' EXCEPTION: ' + str(e), "RED")
				release_webdriver(lock_webdriver)
				return
	elif "XPATH" in get_by:
		try:
			attribute = driver.find_elements(By.XPATH, element_path)[which_item].get_attribute(element_attribute)
		except Exception as e:
			if ('index out of range' in str(e)) or ('stale element' in str(e)):
				print_function('MY get_attrib EXCEPTION: ' + str(inspect_stack()) + ' path: ' + str(element_path) + ' EXCEPTION: ' + str(e), "RED")

				# OPEN INCOME MENU DISAPPEARED. RETURN FALSE. INCOME MENU WILL RESEND THE REQUEST
				if 'open_income_menu' in str(inspect_stack()):
					attribute = "INCOME MENU NOT OPEN"
					return attribute

				release_webdriver(lock_webdriver)
				time.sleep(1)
				return
			elif 'has no attribute' in str(e):
				print_function('MY get_attrib EXCEPTION: ' + str(inspect_stack()) + ' path: ' + str(element_path) + ' EXCEPTION: ' + str(e), "RED")
				release_webdriver(lock_webdriver)
				time.sleep(1)
				return
			elif "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']" == str(element_path):
				print_function('MY get_attrib EXCEPTION: ' + str(inspect_stack()) + ' path: ' + str(element_path) + ' EXCEPTION: ' + str(e), "RED")
				release_webdriver(lock_webdriver)
				time.sleep(3)
				return
			else:
				print_function('my exception:' + str(e), "RED")
				raise Exception(e)
	elif "LINK" in get_by:
		attribute = driver.find_elements(By.LINK_TEXT, element_path)[which_item].get_attribute(element_attribute)
	elif "PARTIALLINK" in get_by:
		attribute = driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item].get_attribute(
			element_attribute)
	elif "NAME" in get_by:
		attribute = driver.find_elements(By.NAME, element_path)[which_item].get_attribute(element_attribute)
	elif "TAG" in get_by:
		attribute = driver.find_elements(By.TAG_NAME, element_path)[which_item].get_attribute(element_attribute)
	elif "CLASS" in get_by:
		attribute = driver.find_elements(By.CLASS_NAME, element_path)[which_item].get_attribute(
			element_attribute)
	elif "CSS" in get_by:
		attribute = driver.find_elements(By.CSS_SELECTOR, element_path)[which_item].get_attribute(element_attribute)
	else:
		print_function(str(inspect_stack()) + 'element_get_attribute ERROR: ' + str(get_by), "RED")
		release_webdriver(lock_webdriver)
		return

	# print('get_attrib return: ', inspect_stack(), ' path: ', element_path, ' result: ', attribute)

	release_webdriver(lock_webdriver)
	return attribute


def inspect_stack():
	loopcount = 1
	all_lines_text = ''
	while True:
		try:
			this_line_text = inspect.stack()[loopcount][3]
		except Exception as stack_error:
			print_function('STACK EXCEPTION. ERROR: ' + str(stack_error), "RED")
			return 'COULD NOT GET STACK --'
		if ('run' in this_line_text) or ('<module>' in this_line_text):
			break

		all_lines_text = this_line_text + ' ' + all_lines_text
		loopcount += 1
	all_lines_text = all_lines_text + ' --'
	return str(all_lines_text)


def click_refresh(lock_webdriver, running_thread):
	print_function(str(inspect_stack()) + 'CLICK REFRESH')
	element_click(lock_webdriver, "XPATH", ".//*[@id='logo_hit']/a", running_thread)
	time.sleep(2)
	return


def open_city(lock_webdriver, running_thread):
	print_function(str(inspect_stack()) + ' open_city')
	while True:
		if element_found(lock_webdriver, "XPATH", "/html/body/div[4]/div[3]/div[3]/a[1]/span"):
			print_function(str(inspect_stack()) + ' open_city - clicking city')
			element_click(lock_webdriver, "XPATH", "/html/body/div[4]/div[3]/div[3]/a[1]/span", running_thread)
			print_function(str(inspect_stack()) + ' open_city - city opened')
			break
		else:
			print_function(str(inspect_stack()) + 'open_city - city not found. refreshing', "RED")
			click_refresh(lock_webdriver, running_thread)
			continue
	return


def click_continue(lock_webdriver, running_thread):
	print_function(str(inspect_stack()) + ' click_continue')
	element_click(lock_webdriver, "NAME", "B1", running_thread)
	return


def discord_message(message):
	url = config['Auth']['discord_webhook']
	webhook = DiscordWebhook(url=url, content=message)
	response = webhook.execute()
	print_function('DISCORD MESSAGE SENT: ' + str(message))
	return


def discord_journal(message):
	url = config['Auth']['discord_webhook_journal']
	webhook = DiscordWebhook(url=url, content=message)
	response = webhook.execute()
	print_function('DISCORD JOURNAL MESSAGE SENT: ' + str(message))
	return

def discord_error(message):
	url = "https://discord.com/api/webhooks/798662082790686752/sOpqUAPqSZ58lo3z8f-YKTjLfg3OJl9l6aasiuDBCoBXcdjiOfHA69w_oI-fQnMhBZiL"
	webhook = DiscordWebhook(url=url, content=message)
	response = webhook.execute()
	print_function('DISCORD ERROR SENT: ' + str(message))
	return


def get_server_time(lock_webdriver, which_time=""):
	gametime_date_raw = ""
	gametime_time_raw = ""
	gametime_array1 = ""
	gametime_array2 = ""
	game_date_month = ""
	game_date_day = ""
	game_date_year = ""
	game_date_hour = ""
	game_date_minute = ""
	game_date_second = ""
	date_array1 = ""
	date_array2 = ""
	date_array3 = ""
	time_array1 = ""
	time_array2 = ""
	time_array3 = ""
	game_time_now = ""

	if (which_time != ""):
		game_time = which_time
	else:
		game_time = element_get_attribute(lock_webdriver, "ID", "header_time", "innerHTML")
		game_time = regex_match_between('serverTime">', '<', game_time)

	gametime_array = game_time.split()
	gametime_date_raw = gametime_array[0]
	gametime_time_raw = gametime_array[1]

	date_array = gametime_date_raw.split("/")
	game_date_month = date_array[0]
	game_date_day = date_array[1]
	game_date_year = date_array[2]

	time_array = gametime_time_raw.split(":")
	game_date_hour = time_array[0]
	game_date_minute = time_array[1]
	game_date_second = time_array[2]

	if (int(game_date_month) < 10):
		game_time_now = game_date_year + '0' + game_date_month
	else:
		game_time_now = game_date_year + game_date_month

	if (int(game_date_day) < 10):
		game_time_now = game_time_now + '0' + game_date_day
	else:
		game_time_now = game_time_now + game_date_day

	if (('AM' in game_time) and (int(game_date_hour) == 12)):
		game_time_now = game_time_now + '00' + game_date_minute + game_date_second

	elif (('PM' in game_time) and (int(game_date_hour) != 12)):
		game_time_now = game_time_now + str(int(game_date_hour) + 12) + game_date_minute + game_date_second
	elif (int(game_date_hour) < 10):
		game_time_now = game_time_now + '0' + game_date_hour + game_date_minute + game_date_second
	else:
		game_time_now = game_time_now + game_date_hour + game_date_minute + game_date_second

	if (len(game_time_now) != 14):
		print_function('ERROR - GAME TIME WRONG LENGTH - ' + str(len(game_time_now)) + ' CONTENT: ' + str(game_time), "RED")

	return game_time_now


def get_dropdown_options(lock_webdriver, get_by, element_path, which_item=0):
	while True:
		dropdown = get_dropdown_options_backend(lock_webdriver, get_by, element_path, which_item)
		if isinstance(dropdown, str):
			break
		else:
			print_function(str(inspect_stack()) + 'get_dropdown_options ERROR: EXPECTING TYPE STR - ACTUAL: ' + str(type(dropdown)) + " FOR: " + str(dropdown), "RED")
		time.sleep(1)
	return dropdown


def get_dropdown_options_backend(lock_webdriver, get_by, element_path, which_item=0):
	# THIS SHOULD ONLY BE CALLED VIA get_dropdown_options AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()
	try:
		if "ID" in get_by:
			dropdown = driver.find_elements(By.ID, element_path)[which_item].text
		elif "XPATH" in get_by:
			dropdown = driver.find_elements(By.XPATH, element_path)[which_item].text
		elif "LINK" in get_by:
			dropdown = driver.find_elements(By.LINK_TEXT, element_path)[which_item].text
		elif "PARTIALLINK" in get_by:
			dropdown = driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item].text
		elif "NAME" in get_by:
			dropdown = driver.find_elements(By.NAME, element_path)[which_item].text
		elif "TAG" in get_by:
			dropdown = driver.find_elements(By.TAG_NAME, element_path)[which_item].text
		elif "CLASS" in get_by:
			dropdown = driver.find_elements(By.CLASS_NAME, element_path)[which_item].text
		elif "CSS" in get_by:
			dropdown = driver.find_elements(By.CSS_SELECTOR, element_path)[which_item].text
		else:
			print_function(str(inspect_stack()) + 'get_dropdown_options ERROR: ' + str(get_by))
			release_webdriver(lock_webdriver)
			return
	except:
		release_webdriver(lock_webdriver)
		return
	release_webdriver(lock_webdriver)
	return dropdown


def select_dropdown_option(lock_webdriver, get_by, element_path, option_to_select, which_item=0):
	while True:
		if select_dropdown_option_backend(lock_webdriver, get_by, element_path, option_to_select, which_item):
			break
		else:
			print_function(str(inspect_stack()) + 'select_dropdown_option FAILED - OPTION: ' + str(option_to_select) + ' - PATH: ' + str(element_path), "RED")
		time.sleep(1)
	return


def select_dropdown_option_backend(lock_webdriver, get_by, element_path, option_to_select, which_item=0):
	# THIS SHOULD ONLY BE CALLED VIA select_dropdown_option_backend AS THAT DOES TYPE/CLASS VERIFICATION
	lock_webdriver.acquire()

	try:
		if "ID" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.ID, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.ID, element_path)[which_item]).select_by_visible_text(option_to_select)
		elif "XPATH" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.XPATH, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.XPATH, element_path)[which_item]).select_by_visible_text(option_to_select)
		elif "LINK" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.LINK_TEXT, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.LINK_TEXT, element_path)[which_item]).select_by_visible_text(option_to_select)
		elif "PARTIALLINK" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.PARTIAL_LINK_TEXT, element_path)[which_item]).select_by_visible_text(option_to_select)
		elif "NAME" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.NAME, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.NAME, element_path)[which_item]).select_by_visible_text(option_to_select)
		elif "TAG" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.TAG_NAME, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.TAG_NAME, element_path)[which_item]).select_by_visible_text(option_to_select)
		elif "CLASS" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.CLASS_NAME, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.CLASS_NAME, element_path)[which_item]).select_by_visible_text(option_to_select)
		elif "CSS" in get_by:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_elements(By.CSS_SELECTOR, element_path)[which_item]).perform()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			Select(driver.find_elements(By.CSS_SELECTOR, element_path)[which_item]).select_by_visible_text(option_to_select)
		else:
			print_function(str(inspect_stack()) + 'select_dropdown_option ERROR: ' + str(get_by), "RED")
			release_webdriver(lock_webdriver)
			return
	except Exception as e:
		discord_error("SELECT DROPDOWN FAILED - ERROR: " + str(e))
		release_webdriver(lock_webdriver)
		return False
	release_webdriver(lock_webdriver)
	return True
