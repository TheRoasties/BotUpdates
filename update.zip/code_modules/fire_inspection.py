from globalvars import *
from code_modules.function import *

def fire_inspection(lock_webdriver, running_thread, waiting_thread_list, your_character_name):
	if config.getboolean('Career-Fire', 'Do_Cases'):
		if globals()['timers'].__dict__['resting_page_timer'] is None:
			globals()['timers'].__dict__['resting_page_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['resting_page_timer']
		fire_stuff_found = False
		if not '-' in str(time_difference):
			# RESTING PAGE UPDATED
			url_check = get_url(lock_webdriver)
			if 'firestation.asp' in url_check:
				fire_table = element_get_attribute(lock_webdriver, "XPATH",
												   ".//*[@id='content']/div[@id='account_holder']/div[@id='account_profile']/div[@id='holder_content']",
												   "innerHTML")
				inspection_count = 0
				for entry in fire_table.split("<tr>"):
					print_function('entry: ' + str(entry))
					if "No fire safety inspection" in fire_table:
						pass
					elif "Inspect" in entry:
						fire_name = regex_match_between('username=', '"', entry)
						if str(your_character_name) == str(fire_name):
							pass
						else:
							fire_stuff_found = True
							break
						inspection_count = int(inspection_count) + 1
					elif "Investigate" in entry:
						fire_stuff_found = True
						break
					elif "Attend fire" in entry:
						fire_stuff_found = True
						break
				print_function('resting page checked')
				globals()['timers'].__dict__['resting_page_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

		if globals()['timers'].__dict__['career_timer'] is None:
			globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['career_timer']
		if (not '-' in str(time_difference)) or (fire_stuff_found):
			print_function('FIRES - QUEUED')
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)
			print_function("FIRES - START")

			# TIMER FOR MANUAL CHECK
			url_check = get_url(lock_webdriver)
			if 'firestation.asp' in url_check:
				pass
			else:
				# NO GOTOPAGE AS WE NEED TO CHECK FOR TORCH
				open_city(lock_webdriver, running_thread)
				element_click(lock_webdriver, "XPATH", ".//*[@class='fire_station']", running_thread)
				print_function('FIRE STATION - CLICKED')

			# FIRST PAGE CHECK
			fire_table = element_get_attribute(lock_webdriver, "XPATH",
											   ".//*[@id='content']/div[@id='account_holder']/div[@id='account_profile']/div[@id='holder_content']",
											   "innerHTML")
			fire_stuff_clicked = False
			inspection_count = 0
			for entry in fire_table.split("<tr>"):
				print_function('entry: ' + str(entry))
				if 'Current Fire Chief' in entry:
					pass
				elif ("Inspect" in entry) and ('username=' in entry):
					fire_name = regex_match_between('username=', '"', entry)
					if str(your_character_name) == str(fire_name):
						pass
					else:
						fire_stuff_clicked = True
						element_click(lock_webdriver, "LINK", "Inspect", running_thread, inspection_count)
						break
					inspection_count = int(inspection_count) + 1
				elif "Investigate" in entry:
					fire_stuff_clicked = True
					element_click(lock_webdriver, "LINK", "Investigate", running_thread)
					break
				elif "Attend fire" in entry:
					fire_stuff_clicked = True
					element_click(lock_webdriver, "LINK", "Attend fire", running_thread)
					break
				else:
					# NO FIRE STUFF
					random_timer = random.randrange(37, 126)
					globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
			if fire_stuff_clicked:
				case_timer_seconds = get_timer(lock_webdriver, 'Case', running_thread)
				if int(case_timer_seconds) > 0:
					globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=case_timer_seconds)
			else:
				if 'Fire ignited at' in fire_table:
					# ON FIRES PAGE - CHANGE TO INSPECTIONS
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='account_holder']/div[@id='account_nav']/ul/li[5]/a", running_thread)
				else:
					# ON INSPECTIONS PAGE - CHANGE TO FIRE
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='account_holder']/div[@id='account_nav']/ul/li[1]/a", running_thread)

				# SECOND PAGE CHECK
				fire_table = element_get_attribute(lock_webdriver, "XPATH",
												   ".//*[@id='content']/div[@id='account_holder']/div[@id='account_profile']/div[@id='holder_content']",
												   "innerHTML")
				fire_stuff_clicked = False
				inspection_count = 0
				for entry in fire_table.split("<tr>"):
					print_function('entry2: ' + str(entry))
					if 'Current Fire Chief' in entry:
						pass
					elif ("Inspect" in entry) and ('username=' in entry):
						fire_name = regex_match_between('username=', '"', entry)
						if str(your_character_name) == str(fire_name):
							pass
						else:
							fire_stuff_clicked = True
							element_click(lock_webdriver, "LINK", "Inspect", running_thread, inspection_count)
							break
						inspection_count = int(inspection_count) + 1
					elif "Investigate" in entry:
						fire_stuff_clicked = True
						element_click(lock_webdriver, "LINK", "Investigate", running_thread)
						break
					elif "Attend fire" in entry:
						fire_stuff_clicked = True
						element_click(lock_webdriver, "LINK", "Attend fire", running_thread)
						break
					else:
						# NO FIRE STUFF
						random_timer = random.randrange(37, 126)
						globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
				if fire_stuff_clicked:
					case_timer_seconds = get_timer(lock_webdriver, 'Case', running_thread)
					if int(case_timer_seconds) > 0:
						globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=case_timer_seconds)

			thread_remove_from_queue(running_thread, waiting_thread_list)
	return

