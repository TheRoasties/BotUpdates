from globalvars import *
from code_modules.function import *

def community_service_non_homecity(lock_webdriver, running_thread, waiting_thread_list):

	if config.getboolean('Action', 'CSNotRemoveBnE'):
		if ('JailBreak' in str(running_thread[3])) or ('CS:' in str(running_thread[4])):
			pass
		else:
			# NO JAILBREAK. STOP CSING AS MAY REMOVE BNE
			return False

	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)

	#### DO FOREIGN CS ####
	go_to_page(lock_webdriver, 'CommunityService', running_thread)
	element_click(lock_webdriver, "NAME", "csinothercities", running_thread)
	click_continue(lock_webdriver, running_thread)

	if 'CS:' in str(running_thread[4]):
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'CS:' in item:
				cs_needed = re.sub('[^0-9]', "", item)
				cs_needed = int(cs_needed) - 1
				try:
					variables_list.remove(item)
				except:
					pass
				if int(cs_needed) > 0:
					variables_list.append('CS:' + str(cs_needed))
				break
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES FOR CS: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

	thread_remove_from_queue(running_thread, waiting_thread_list)
	return True