from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

__all__ = ["add_mug_targets_to_arrays", "get_mug_list_currentcity", "check_mug_target", "do_mug_thread", "get_mug_list_currentcity"]

def get_mug_list_currentcity(lock_webdriver, aggtarget_person_list_manager, running_thread):
	# CLEAR SAVED NAMES
	online_player_list_currentcity = []

	# GETS FULL LIST OF NAMES
	while True:
		online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
		if '|' in online_player_list_raw:
			break

	is_local_list_only = True
	if '*' in online_player_list_raw:
		is_local_list_only = False

	online_player_list_raw_split = online_player_list_raw.split("|")
	for player_raw in online_player_list_raw_split:
		if ':Alive:player:' in player_raw:
			if is_local_list_only or ('*' in player_raw):
				player_name = regex_match_between('>', '<', player_raw)

				skip_this_mug_target = False
				mug_blacklist = config['Mug']['Mug_Blacklist'].split()
				for blacklist_name in mug_blacklist:
					if blacklist_name == player_name:
						print_function('MUG - SKIP BLACKLIST TARGET: ' + str(player_name), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - SKIP BLACKLIST TARGET: " + str(player_name))
						skip_this_mug_target = True

				if skip_this_mug_target:
					pass
				else:
					online_player_list_currentcity.append(player_name)

					if player_name in globals()['all_agg_targets']:
						pass
					else:
						# NEW MUG TARGET
						server_port = read_file("env/ServerPort.txt")
						manager = BaseManager(address=('127.0.0.1', int(server_port)))
						BaseManager.register('person', person)
						BaseManager.register('city', city)

						while True:
							try:
								manager.connect()
								break
							except:
								print_function('AGGS - check_mug_target - FAILED TO CONNECT TO BASEMANAGER', "RED")

						aggtarget_person_list_manager[player_name] = manager.person(player_name)
						aggtarget_person_list_manager[player_name].add_online_hours(1)
						globals()['all_agg_targets'].append(player_name)

						# DO CALCULATION FOR WHICH AGG MINUTE LIST TO ADD THE NEW TARGET
						try:
							your_hours = aggtarget_person_list_manager[
								get_your_character_name(lock_webdriver)].get_online_hours()
						except:
							your_hours = 1

						their_hours = aggtarget_person_list_manager[player_name].get_online_hours()

						our_aggstr_mins = 29
						while True:
							our_aggstr = math.ceil(your_hours * float(aggstr_percent_modify(our_aggstr_mins)))
							their_aggstr = math.floor(their_hours * float(config['Mug']['MugAggstrModify']))

							if (our_aggstr_mins <= 2) or (their_aggstr >= our_aggstr):
								# APPLY LOCAL MODIFIERS TO TARGET REQUIRED MINS
								mins_adjusted = int(our_aggstr_mins) + 1

								if os.path.isfile('./agg_targets/mug/' + player_name + '.txt'):
									adjust_value = read_file('./agg_targets/mug/' + player_name + '.txt')
									if adjust_value == '':
										adjust_value = 0
								else:
									adjust_value = 0

								if adjust_value == 'FAIL':
									mins_adjusted = 31
								else:
									mins_adjusted = int(mins_adjusted) + int(adjust_value)

									if int(mins_adjusted) > 30:
										mins_adjusted = 30
									elif int(mins_adjusted) < 3:
										mins_adjusted = 3

								globals()['mug_targets_minute' + str(mins_adjusted)].insert(0 ,player_name)
								# print('AGGS - MUG ARRAY - ADDED ', player_name, ' TO MINS ', mins_adjusted, " THEIRS: ", their_aggstr, " VS YOURS: ", our_aggstr)
								print_function('list: ' + str(globals()['mug_targets_minute' + str(mins_adjusted)]))
								break
							our_aggstr_mins -= 1

	return online_player_list_currentcity


def add_mug_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager):
	# CREATE LISTS
	count = 3
	while count < 32:
		globals()['mug_targets_minute' + str(count)] = []
		locals()['dict_min' + str(count)] = {}
		count += 1

	# DO CALCULATION
	try:
		your_hours = aggtarget_person_list_manager[get_your_character_name(lock_webdriver)].get_online_hours()
	except:
		your_hours = 1

	for name in globals()['all_agg_targets']:
		their_hours = aggtarget_person_list_manager[name].get_online_hours()

		our_aggstr_mins = 29
		while True:
			our_aggstr = math.ceil( your_hours * float(aggstr_percent_modify(our_aggstr_mins)) )
			their_aggstr = math.floor( their_hours * float(config['Mug']['MugAggstrModify']) )

			if (our_aggstr_mins <= 2) or (their_aggstr >= our_aggstr):
				# APPLY LOCAL MODIFIERS TO TARGET REQUIRED MINS
				mins_adjusted = int(our_aggstr_mins) + 1

				if os.path.isfile('./agg_targets/mug/' + name + '.txt'):
					adjust_value = read_file('./agg_targets/mug/' + name + '.txt')
					if adjust_value == '':
						adjust_value = 0
				else:
					adjust_value = 0

				if adjust_value == 'FAIL':
					mins_adjusted = 31
				else:
					mins_adjusted = int(mins_adjusted) + int(adjust_value)

					if int(mins_adjusted) > 30:
						mins_adjusted = 30
					elif int(mins_adjusted) < 3:
						mins_adjusted = 3

				locals()['dict_min' + str(mins_adjusted)][their_hours] = name
				print_function('AGGS - MUG ARRAY - ADDED ' + str(name) + ' TO MINS ' + str(mins_adjusted) + " THEIRS: " + str(their_aggstr) + " VS YOURS: " + str(our_aggstr))
				break

			our_aggstr_mins -= 1

	count = 3
	while count < 32:
		for key in sorted(locals()['dict_min' + str(count)].keys()):
			globals()['mug_targets_minute' + str(count)].append(locals()['dict_min' + str(count)][key])
		print_function('Mug list:' + str(count) + ' // ' +  str(globals()['mug_targets_minute' + str(count)]))
		count += 1
	return


'''
def get_mug_list_currentcity(lock_webdriver):
	# CLEAR SAVED NAMES
	online_player_list_currentcity = []

	# GETS FULL LIST OF NAMES
	while True:
		online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
		if '|' in online_player_list_raw:
			break

	is_local_list_only = True
	if '*' in online_player_list_raw:
		is_local_list_only = False

	online_player_list_raw_split = online_player_list_raw.split("|")
	for player_raw in online_player_list_raw_split:
		if ':Alive:player:' in player_raw:
			if is_local_list_only or ('*' in player_raw):
				player_name = regex_match_between('>', '<', player_raw)

				skip_this_mug_target = False
				mug_blacklist = config['Mug']['Mug_Blacklist'].split()
				for blacklist_name in mug_blacklist:
					if blacklist_name == player_name:
						print(Fore.BLUE + 'MUG - SKIP BLACKLIST TARGET: ', player_name)
						print(Style.RESET_ALL)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - SKIP BLACKLIST TARGET: " + str(player_name))
						skip_this_mug_target = True

				if skip_this_mug_target:
					pass
				else:
					online_player_list_currentcity.append(player_name)

	return online_player_list_currentcity
'''

def check_mug_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, mug_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, bold_list):
	viable_mug_targets = []

	for mug_target in globals()['mug_targets_minute' + str(aggstr_min_checking)]:
		if mug_target in mug_list:
			pass
		else:
			continue

		if (your_character_name == mug_target) or ('' == mug_target) or (
				mug_target in config['Mug']['Mug_Blacklist']):
			continue


		if config.getboolean('Mug', 'Avoid_Bolds'):
			skip_this_name = False
			for bold_name_raw in bold_list['Items']:
				bold_name = bold_name_raw['PlayerName']
				if bold_name == mug_target:
					skip_this_name = True
					break
			if skip_this_name:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP TARGET: " + str(pickpocket_target) + " SKIP AS BOLD")
				continue

		# AGGPRO - LOCAL
		aggpro_timer = aggtarget_person_list_manager[mug_target].get_local_aggpro_timer()
		try:
			time_difference = datetime.datetime.utcnow() - aggpro_timer
		except:
			continue

		if not '-' in str(time_difference):
			# AGGPRO - SHARED
			aggpro_timer = aggtarget_person_list_manager[mug_target].get_shared_aggpro_timer()
			try:
				time_difference = datetime.datetime.utcnow() - aggpro_timer
			except:
				continue
			if not '-' in str(time_difference):
				# AGGPRO - SHARED
				viable_mug_targets.append(mug_target)
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - MUG TARGET: " + str(mug_target) + " MINS REQUIRED: " + str(aggstr_min_checking) )
			else:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - MUG SHARED AGGPRO: " + str(mug_target) )
		else:
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - MUG LOCAL AGGPRO: " + str(mug_target) )

	if viable_mug_targets == []:
		pass
	else:
		# TERMINATE LESSER PRIORITY AGGS - PICKPOCKET
		if 'do_pickpocket_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY PICKPOCKET
				return

		if 'do_pickpocket_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " MUG - REQUESTED TERMINATE PICKPOCKET")
			waiting_thread_list.append('9zterminate_do_pickpocket_thread')
			print_function('9zterminate_do_pickpocket_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_pickpocket_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " MUG - TERMINATED PICKPOCKET")
					break
			# TERMINATED PICKPOCKET

		print_function('viable mug targets - ' + str(viable_mug_targets) + " " + str(aggstr_min_checking), "BLUE")
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - VIABLE TARGETS FOR MINUTE " + str(aggstr_min_checking) + ": " + str(viable_mug_targets))

		waiting_thread_list.append('9zAggstrLowest' + str(aggstr_min_checking))
		print_function('9zAggstrLowest' + str(aggstr_min_checking) + ' THREAD QUEUED ' + str(waiting_thread_list), "GREEN")

		do_mugs(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_mug_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager)
	return


def do_mugs(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_mug_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager):
	thread_mug = Process(target=do_mug_thread, name='MugThread',
									args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_mug_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager))
	thread_mug.start()
	waiting_thread_list.append('9zAwaitingMug')
	print_function(waiting_thread_list)

	# WAIT TILL THREAD STARTED
	print_function('MUG - WAITING FOR THREAD TO BE RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - WAITING FOR THREAD TO BE RUNNING")
	while True:
		if 'mug' in str(waiting_thread_list):
			break
	print_function('MUG - THREAD RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - THREAD RUNNING")
	return


def do_mug_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_mug_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager):
	try:
		import multiprocessing
		write_file("env/MugPID.txt", str(multiprocessing.current_process().pid))

		for thread in waiting_thread_list:
			if 'AwaitingMug' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG QUEUED")
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_mug_targets)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG STARTED")
		random_timer_haspro = random.randrange(590, 915)

		for target in viable_mug_targets:
			# RETURN PRIORITY TO NORMAL
			running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]

			if go_to_page(lock_webdriver, "Mug", running_thread):
				pass
			else:
				unlocked_aggs_list = running_thread[3]
				try:
					unlocked_aggs_list.remove('Mug')
				except:
					pass
				running_thread[3] = unlocked_aggs_list
				write_file("env/agg_unlocks.txt", running_thread[3])

				print_function('MUG - NOT UNLOCKED', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** MUG - NOT UNLOCKED ****")
				return

			if 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** MUG - REQUIRES CS FIRST ****")
				return

			clearkeys(lock_webdriver, "NAME", "mugging")
			sendkeys(lock_webdriver, "NAME", "mugging", target)
			sendkeys(lock_webdriver, "NAME", "mugging", Keys.ESCAPE)
			
			clearkeys(lock_webdriver, "NAME", "cap")
			sendkeys(lock_webdriver, "NAME", "cap", config['Mug']['Max_Mug_Amount'])
			sendkeys(lock_webdriver, "NAME", "cap", Keys.ESCAPE)

			# INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
			running_thread[0] = str('1') + inspect.stack()[0][3]
			click_continue(lock_webdriver, running_thread)

			# AGG DONE - GET RESULTS
			agg_results = None
			if element_found(lock_webdriver, "ID", "fail"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			elif element_found(lock_webdriver, "ID", "success"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			else:
				print_function('NO AGG RESULTS FOUND', "BLUE")
				print_function('NO AGG RESULTS FOUND', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - NO AGG RESULTS FOUND")

				config['Mug']['Do_Mug'] = 'False'
				print_function('MUG - NOT UNLOCKED', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** MUG - NOT UNLOCKED ****")
				return

			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - RESULTS: " + str(agg_results))

			# AGG DONE - EXAMINE RESULTS
			if 'commit a Mugging' in agg_results:
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass

				variables_list = running_thread[4]
				variables_list.append('NoMug')
				running_thread[4] = variables_list

				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t *** MUG TURNED OFF - NO WEAPON ***")
				return

			elif "doesn't exist" in agg_results:
				print_function('Mug Results - Target ' + str(target) + " Doesn't Exist", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Target " + str(target) + " Doesn't Exist")
				random_timer = random.randrange(60, 90)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				continue

			elif ('same city' in agg_results) or ('must be online' in agg_results) or ('recently survived' in agg_results):
				print_function('Mug Results - Target ' + str(target) + "has pro or not found", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Target " + str(target) + " has pro or not found")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer_haspro)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				continue

			elif ('failed' in agg_results) or ('ran off' in agg_results):
				print_function('Mug Results - Target ' + str(target) + ' FAILED', "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Target " + str(target) + " FAILED")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=2)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

				# UPDATE LOCAL MODIFIERS
				desired_mins = int(aggstr_mins_max) + 2
				if desired_mins > 30:
					desired_mins = 30

				mins_adjusted = int(desired_mins) - int(aggstr_min_checking)

				if int(aggstr_mins_max) == 30:
					mins_adjusted = 'FAIL'

				write_file('./agg_targets/mug/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/Mug.txt', "\nMug FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nMug FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG THREAD FINISHED")
				return


			elif ('You mugged' in agg_results):
				print_function('Mug Results - Target ' + str(target) + ' SUCCESS - AGG: ' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Target " + str(target) + " SUCCESS")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=2)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

				# UPDATE LOCAL MODIFIERS
				try:
					mins_adjusted = read_file('./agg_targets/mug/' + target + '.txt')
					if mins_adjusted == 'FAIL':
						mins_adjusted = 30
					mins_adjusted = int(mins_adjusted)
				except:
					mins_adjusted = 0

				mins_adjusted -= 1
				write_file('./agg_targets/mug/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/Mug.txt', "\nMug SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nMug SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# UPDATE SHARED ALL AGGS RECORDS
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.utcnow().year) + '-' + str(datetime.datetime.utcnow().month) + '-' + str(datetime.datetime.utcnow().day) + '.txt', "\r\n" + str(get_your_character_name(lock_webdriver)) + " Mug " + str(target) + " (Success) in " + str(globals()[get_current_city(lock_webdriver)].which_city) + " on " + str(datetime.datetime.utcnow()))

				# REPAY CHECKS
				repay = True
				if not config.getboolean('Mug', 'Repay'):
					print_function('Mug - Repay - TURNED OFF', "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Repay - TURNED OFF")
					repay = False

				repay_blacklist = config['Mug']['Repay_Blacklist'].split()
				for blacklist_name in repay_blacklist:
					if target == blacklist_name:
						print_function('Mug - Repay - TARGET IS BLACKLISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Repay - TARGET IS BLACKLISTED: " + str(target))
						repay = False

				repay_whitelist = config['Mug']['Repay_Whitelist'].split()
				for whitelist_name in repay_whitelist:
					if target == whitelist_name:
						print_function('Mug - Repay - TARGET IS WHITELISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Repay - TARGET IS WHITELISTED: " + str(target))
						repay = True

				if repay:
					repay_amount = regex_match_between('\$', '!', agg_results)
					repay_amount = re.sub('[^0-9]', "", repay_amount)

					print_function('Mug - Repaying ' + str(repay_amount) + ' TO ' + str(target), "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG - Repaying " + str(repay_amount) + " TO " + str(target))
					# ADD REPAY TO RECORDS
					append_file('./records/Mug.txt', "\n Mug - Repaying " + repay_amount + " TO " + target)
					append_file('./records/AllAggs.txt', "\n Mug - Repaying " + repay_amount + " TO " + target)

					if int(repay_amount) > 0:
						transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target)

						# WAIT FOR TRANSFER TO BE QUEUED
						print_function('Mug - Waiting for repay to be queued', "BLUE")
						while True:
							if 'transfer_money_thread' in str(waiting_thread_list):
								break
						print_function('Mug - repay is queued', "BLUE")

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG THREAD FINISHED")
				return

			else:
				print_function('Mug - results not found' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Mug - results not found" + str(agg_results))
				continue

		for thread in waiting_thread_list:
			if ('AggstrLowest' in thread):
				try:
					waiting_thread_list.remove(thread)
				except:
					pass
		thread_remove_from_queue(running_thread, waiting_thread_list)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t MUG THREAD FINISHED")
		return
	except:
		from code_modules.function import PrintException
		PrintException()
