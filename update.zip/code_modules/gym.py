from globalvars import *
from code_modules.function import *


def gym(lock_webdriver, running_thread, waiting_thread_list):
	gym_timer = read_file("env/gym_timer.txt")
	try:
		gym_timer = datetime.datetime.strptime(gym_timer, '%Y-%m-%d %H:%M:%S')
	except:
		gym_timer = datetime.datetime.strptime(gym_timer, '%Y-%m-%d %H:%M:%S.%f')
	time_difference = datetime.datetime.utcnow() - gym_timer

	if not '-' in str(time_difference):
		# GYM TIMER READY
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_blackmarket)

		go_to_page(lock_webdriver, "Gym", running_thread)

		dropdown = get_dropdown_options(lock_webdriver, "XPATH", ".//*[@class='input']")
		if 'membership card' in dropdown:
			select_dropdown_option(lock_webdriver, "XPATH", ".//*[@class='input']", 'Purchase 1 week membership card')
			click_continue(lock_webdriver, running_thread)
			thread_remove_from_queue(running_thread, waiting_thread_list)
		else:
			select_dropdown_option(lock_webdriver, "XPATH", ".//*[@class='input']", 'Have a spa/sauna')
			click_continue(lock_webdriver, running_thread)

			gym_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=12)
			random_timer = random.randrange(60, 360)
			gym_timer = gym_timer + datetime.timedelta(seconds=random_timer)
			write_file("env/gym_timer.txt", gym_timer)
			thread_remove_from_queue(running_thread, waiting_thread_list)
	return