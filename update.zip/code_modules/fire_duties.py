from globalvars import *
from code_modules.function import *

def fire_duties(lock_webdriver, running_thread, waiting_thread_list):
	if config.getboolean('Career-Fire', 'FireDuties'):
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)
		print_function('ACTION - FIRE DUTIES ACTIVE')

		go_to_page(lock_webdriver, 'FireDuties', running_thread)

		# DO FIRE DUTIES
		if element_found(lock_webdriver, "ID", "firetraining"):
			element_click(lock_webdriver, "ID", "firetraining", running_thread)
		elif element_found(lock_webdriver, "ID", "firerescue"):
			element_click(lock_webdriver, "ID", "firerescue", running_thread)
		elif element_found(lock_webdriver, "ID", "firesafety"):
			element_click(lock_webdriver, "ID", "firesafety", running_thread)
		elif element_found(lock_webdriver, "ID", "firetrain"):
			element_click(lock_webdriver, "ID", "firetrain", running_thread)

		element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return True
	return False
