from globalvars import *
from code_modules.function import *

__all__ = ["check_journal"]

globals()['illness_found'] = False

def victim_entries(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, ahead_one_entry, your_character_name, current_city, home_city, aggtarget_person_list_manager, aggtarget_business_list_manager, manager):
	# PICKPOCKET / Attempted Pickpocket
	# Your pocket was picked by another player and $64,282 was stolen. After catching a glimpse of the person you were able to vaguely recognise the attacker - their name ended with ohn.
	if ('Pickpocket' == entry_title) or ('Attempted Pickpocket' == entry_title):
		print_function('JOURNAL - VICTIM PICKPOCKET FOUND')

		# UPDATE SHARED RECORDS
		aggpro_seconds = get_aggpro_seconds(lock_webdriver)
		new_aggpro_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=aggpro_seconds)
		aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
		update_database('Player', 'PlayerName', str(your_character_name), {"Aggpro_Personal": str(aggtimer_string), "UpdatedBy": "Journal-PPVictim"})
		entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

		# UPDATE LOCAL RECORDS
		try:
			# ALREADY EXISTS
			aggtarget_person_list_manager[your_character_name].set_local_aggpro_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM PICKPOCKET - SET ' + str(your_character_name) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))
		except:
			# CREATE NEW
			aggtarget_person_list_manager[your_character_name] = manager.person(your_character_name)
			aggtarget_person_list_manager[your_character_name].set_local_aggpro_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM PICKPOCKET (NEW ENTRY) - SET ' + str(your_character_name) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

		if 'Attempted' in entry_title:
			pass
		else:
			# GET SUSPECT
			if 'their name ended with' in entry_content:
				suspect = regex_match_between('name ended with ', '\.', entry_content).strip()
			else:
				# STEALTHED
				suspect = '<UNKNOWN>'
				pass

			# CHECK NEXT ENTRY FOR TRANSFER TO PROVE SUSPECT
			if ahead_one_entry is None:
				print_function('JOURNAL - NEXT ENTRY IS NONE - UPDATE SAVED RECORDS TO UPLOAD NEXT JOURNAL ENTRY IN CASE REPAY NOT RECEIVED YET')
				all_aggs_dictionary = [entry_time_for_database, your_character_name, current_city, entry_title, suspect]
				write_file("env/journal_all_aggs_temp.txt", str(all_aggs_dictionary))
			else:
				# FUTURE JOURNAL ENTRIES. UPDATE THE DATABASE WHETHER NEXT IS A TRANSFER OR NOT
				if 'into your bank account' in str(ahead_one_entry):
					if 'anonymous' in str(ahead_one_entry):
						pass
					else:
						transfer_suspect = regex_match_between('<strong>', '</strong>', ahead_one_entry).strip()
						if suspect == '<UNKNOWN>':
							suspect = transfer_suspect
						elif suspect in transfer_suspect:
							suspect = transfer_suspect
						print_function('JOURNAL - TRANSFER FOUND AFTER AGG - SUSPECT: ' + str(suspect) + ' TRANSFER SUSPECT: ' + str(transfer_suspect))

				if suspect == '<UNKNOWN>':
					# NO SUSPECT. THERE IS NO NEED TO UPDATE THE DATABASE WITH USELESS INFORMATION
					print_function('JOURNAL - NO SUSPECT. ALL AGGS DATABASE IS NOT UPDATED')
					pass
				else:
					# UPDATE ALL AGGS RECORD
					# Ghettorig (808) Pickpocket Carlo_Tiscalli (111) (Success) with 15 in MC on 20200928234143
					update_string = "\r\n" + str(suspect) + " Pickpocket " + str(your_character_name) + " (Success) in " + str(current_city) + " on " + str(entry_time_for_database)
					append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
					print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR PICKPOCKET VICTIM')

	# HACKING / Attempted Hack
	# Your bank account was hacked by another player and $79,467 was stolen! The bank was able to get a partial read of their login name which ended with ony
	elif ('Hacking' == entry_title) or ('Attempted Hack' == entry_title):
		print_function('JOURNAL - VICTIM HACKING FOUND')
		# UPDATE SHARED RECORDS
		new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=12)
		aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
		entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

		minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
		if '-' in str(minutes_diff):
			pass
		else:
			update_database('Player', 'PlayerName', str(your_character_name), {"Aggpro_Hack": str(aggtimer_string), "UpdatedBy": "Journal-HackVictim"})

		# UPDATE LOCAL RECORDS
		try:
			# ALREADY EXISTS
			aggtarget_person_list_manager[your_character_name].set_local_hack_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM HACK - SET ' + str(your_character_name) + ' LOCAL HACK TIMER TO ' + str(aggtimer_string))
		except:
			# CREATE NEW
			aggtarget_person_list_manager[your_character_name] = manager.person(your_character_name)
			aggtarget_person_list_manager[your_character_name].set_local_hack_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM HACK (NEW ENTRY) - SET ' + str(your_character_name) + ' LOCAL HACK TIMER TO ' + str(aggtimer_string))

		if 'Attempted' in entry_title:
			pass
		else:
			# GET SUSPECT
			if 'name which ended with' in entry_content:
				suspect = regex_match_between('name which ended with ', None, entry_content).strip()
			else:
				# STEALTHED
				suspect = '<UNKNOWN>'
				pass

			# CHECK NEXT ENTRY FOR TRANSFER TO PROVE SUSPECT
			if ahead_one_entry is None:
				print_function('JOURNAL - NEXT ENTRY IS NONE - UPDATE SAVED RECORDS TO UPLOAD NEXT JOURNAL ENTRY IN CASE REPAY NOT RECEIVED YET')
				entry_title = 'Hack'
				all_aggs_dictionary = [entry_time_for_database, your_character_name, current_city, entry_title, suspect]
				write_file("env/journal_all_aggs_temp.txt", str(all_aggs_dictionary))
			else:
				# FUTURE JOURNAL ENTRIES. UPDATE THE DATABASE WHETHER NEXT IS A TRANSFER OR NOT
				if 'into your bank account' in str(ahead_one_entry):
					if 'anonymous' in str(ahead_one_entry):
						pass
					else:
						transfer_suspect = regex_match_between('<strong>', '</strong>', ahead_one_entry).strip()
						if suspect == '<UNKNOWN>':
							suspect = transfer_suspect
						elif suspect in transfer_suspect:
							suspect = transfer_suspect
						print_function('JOURNAL - TRANSFER FOUND AFTER AGG - SUSPECT: ' + str(suspect) + ' TRANSFER SUSPECT: ' + str(transfer_suspect))

				if suspect == '<UNKNOWN>':
					# NO SUSPECT. THERE IS NO NEED TO UPDATE THE DATABASE WITH USELESS INFORMATION
					print_function('JOURNAL - NO SUSPECT. ALL AGGS DATABASE IS NOT UPDATED')
					pass
				else:
					# UPDATE ALL AGGS RECORD
					# Pams (1099) Hack Dominic (11) (Success) with 25 in MC on 20200929005626
					update_string = "\r\n" + str(suspect) + " Hack " + str(your_character_name) + " (Success) in " + str(home_city) + " on " + str(entry_time_for_database)
					append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
					print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR HACKING VICTIM')

	# MUGGING / Attempted Mugging
	# You were mugged and $39,207 was stolen. After being whacked around the head you are able to vaguely remember the attacker - their name ended with uee.
	# You were mugged and $23,786 was stolen.  You had the upper hand until some Tosa Inu got in the way and grabbed your leg! After being whacked around the head you are able to vaguely remember the attacker - their name ended with ech
	elif ('MUGGING' == entry_title) or ('Attempted Mugging' == entry_title):
		print_function('JOURNAL - VICTIM MUGGING FOUND')
		# UPDATE SHARED RECORDS
		aggpro_seconds = get_aggpro_seconds(lock_webdriver)
		new_aggpro_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=aggpro_seconds)
		aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
		update_database('Player', 'PlayerName', str(your_character_name), {"Aggpro_Personal": str(aggtimer_string), "UpdatedBy": "Journal-MugVictim"})
		entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

		# UPDATE LOCAL RECORDS
		try:
			# ALREADY EXISTS
			aggtarget_person_list_manager[your_character_name].set_local_aggpro_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM MUG - SET ' + str(your_character_name) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))
		except:
			# CREATE NEW
			aggtarget_person_list_manager[your_character_name] = manager.person(your_character_name)
			aggtarget_person_list_manager[your_character_name].set_local_aggpro_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM MUG (NEW ENTRY) - SET ' + str(your_character_name) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

		if 'Attempted' in entry_title:
			pass
		else:
			# GET SUSPECT
			if ('name ended with' in entry_content):
				if 'grabbed your leg' in entry_content:
					suspect = regex_match_between('name ended with ', None, entry_content).strip()
				else:
					suspect = regex_match_between('name ended with ', '\.', entry_content).strip()
			else:
				# STEALTHED
				suspect = '<UNKNOWN>'
				pass

			# CHECK NEXT ENTRY FOR TRANSFER TO PROVE SUSPECT
			if ahead_one_entry is None:
				print_function('JOURNAL - NEXT ENTRY IS NONE - UPDATE SAVED RECORDS TO UPLOAD NEXT JOURNAL ENTRY IN CASE REPAY NOT RECEIVED YET')
				all_aggs_dictionary = [entry_time_for_database, your_character_name, current_city, entry_title, suspect]
				write_file("env/journal_all_aggs_temp.txt", str(all_aggs_dictionary))
			else:
				# FUTURE JOURNAL ENTRIES. UPDATE THE DATABASE WHETHER NEXT IS A TRANSFER OR NOT
				if 'into your bank account' in str(ahead_one_entry):
					if 'anonymous' in str(ahead_one_entry):
						pass
					else:
						transfer_suspect = regex_match_between('<strong>', '</strong>', ahead_one_entry).strip()
						if suspect == '<UNKNOWN>':
							suspect = transfer_suspect
						elif suspect in transfer_suspect:
							suspect = transfer_suspect
						print_function('JOURNAL - TRANSFER FOUND AFTER AGG - SUSPECT: ' + str(suspect) + ' TRANSFER SUSPECT: ' + str(transfer_suspect))

				if suspect == '<UNKNOWN>':
					# NO SUSPECT. THERE IS NO NEED TO UPDATE THE DATABASE WITH USELESS INFORMATION
					print_function('JOURNAL - NO SUSPECT. ALL AGGS DATABASE IS NOT UPDATED')
					pass
				else:
					# UPDATE ALL AGGS RECORD
					# Ghettorig (808) Mug Carlo_Tiscalli (111) (Success) with 15 in MC on 20200928234143
					update_string = "\r\n" + str(suspect) + " Mug " + str(your_character_name) + " (Success) in " + str(current_city) + " on " + str(entry_time_for_database)
					append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
					print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR MUG VICTIM')

	# BNE / Attempted Break-in
	# Your Flat was broken into by another player and $5,707 was stolen! And the thief also stole your Baseball Bat (30/30) that was stashed in your apartment!
	# Your Flat was broken into by another player! You managed to catch a glimpse of the thief - their name ended with un1. They managed to steal $1,000!
	elif ('Break-in!' == entry_title) or ('Attempted Break-in' == entry_title):
		print_function('JOURNAL - VICTIM BNE FOUND')
		# UPDATE SHARED RECORDS
		aggpro_seconds = get_aggpro_seconds(lock_webdriver)
		new_aggpro_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=aggpro_seconds)
		aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
		update_database('Player', 'PlayerName', str(your_character_name), {"Aggpro_Personal": str(aggtimer_string), "UpdatedBy": "Journal-BnEVictim"})
		entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

		if 'stole your' in entry_content:
			discord_journal(config['Auth']['discord_id'] + str(your_character_name) + " SOMEONE STOLE ITEM FROM YOU - On: " + str(entry_time) + " Content: " + str(entry_content))

		# UPDATE LOCAL RECORDS
		try:
			# ALREADY EXISTS
			aggtarget_person_list_manager[your_character_name].set_local_aggpro_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM BNE - SET ' + str(your_character_name) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))
		except:
			# CREATE NEW
			aggtarget_person_list_manager[your_character_name] = manager.person(your_character_name)
			aggtarget_person_list_manager[your_character_name].set_local_aggpro_timer(aggtimer_string)
			print_function('JOURNAL - VICTIM BNE (NEW ENTRY) - SET ' + str(your_character_name) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

		if 'Attempted' in entry_title:
			pass
		else:
			# GET SUSPECT
			if 'name ended with' in entry_content:
				suspect = regex_match_between('name ended with ', '\.', entry_content).strip()
			else:
				# STEALTHED
				suspect = '<UNKNOWN>'
				pass

			# CHECK NEXT ENTRY FOR TRANSFER TO PROVE SUSPECT
			if ahead_one_entry is None:
				print_function('JOURNAL - NEXT ENTRY IS NONE - UPDATE SAVED RECORDS TO UPLOAD NEXT JOURNAL ENTRY IN CASE REPAY NOT RECEIVED YET')
				all_aggs_dictionary = [entry_time_for_database, your_character_name, current_city, entry_title, suspect]
				write_file("env/journal_all_aggs_temp.txt", str(all_aggs_dictionary))
			else:
				# FUTURE JOURNAL ENTRIES. UPDATE THE DATABASE WHETHER NEXT IS A TRANSFER OR NOT
				if 'into your bank account' in str(ahead_one_entry):
					if 'anonymous' in str(ahead_one_entry):
						pass
					else:
						transfer_suspect = regex_match_between('<strong>', '</strong>', ahead_one_entry).strip()
						if suspect == '<UNKNOWN>':
							suspect = transfer_suspect
						elif suspect in transfer_suspect:
							suspect = transfer_suspect
						print_function('JOURNAL - TRANSFER FOUND AFTER AGG - SUSPECT: ' + str(suspect) + ' TRANSFER SUSPECT: ' + str(transfer_suspect))

				if suspect == '<UNKNOWN>':
					# NO SUSPECT. THERE IS NO NEED TO UPDATE THE DATABASE WITH USELESS INFORMATION
					print_function('JOURNAL - NO SUSPECT. ALL AGGS DATABASE IS NOT UPDATED')
					pass
				else:
					# UPDATE ALL AGGS RECORD
					# Ghettorig (808) BnE Carlo_Tiscalli (111) (Success) with 15 in MC on 20200928234143
					update_string = "\r\n" + str(suspect) + " BnE " + str(your_character_name) + " (Success) in " + str(current_city) + " on " + str(entry_time_for_database)
					append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
					print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR BnE VICTIM')

	# GTA / Attempted GTA
	elif ('Car-Jacking' in entry_title):
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'Vehicle:' in item:
				try:
					variables_list.remove(item)
				except:
					pass
		variables_list.append('Vehicle:NONE')
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

		discord_message(config['Auth']['discord_id'] + "GTA - " + entry_content)

	# HOUSE TORCH

	# BUSINESS TORCH / Attempted Torch
	# Your Boxing in Manchester was set ablaze by another player! You had to go $100,000 into debt to get the business up and running again! But you managed to catch a glimpse of the arsonist - their name ended with: ter
	elif ('Torch' == entry_title) or ('Attempted Torch' == entry_title):
		print_function('JOURNAL - VICTIM BIZ TORCH FOUND')
		if ('Drug House' in str(entry_content)) or ('business front' in str(entry_content)):
			discord_message(config['Auth']['discord_id'] + str(entry_content))
		elif ('Flat' in str(entry_content)) or ('Studio' in str(entry_content)) or ('Penthouse' in str(entry_content)) or ('Palace' in str(entry_content)):
			pass
		else:
			# UPDATE SHARED RECORDS
			new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=2)
			new_aggpro_timer = new_aggpro_timer + datetime.timedelta(minutes=40)
			aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
			entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

			if ('Your' in str(entry_content)) and ('was set ablaze by another player' in str(entry_content)):
				# SKIP YOUR FLAT TORCHED
				pass
			else:
				if 'Attempted' in entry_title:
					if 'No one was' in entry_content:
						city = regex_match_between('in ', '\.', entry_content)
					else:
						city = regex_match_between('in ', '!', entry_content)
				else:
					city = regex_match_between('in ', ' was', entry_content)
				city = re.sub('[^a-zA-Z]', "", city)
				city_short = str(globals()[city].city_short_string)
				city = city.replace(" ", "")

				if 'Attempted' in entry_title:
					business_victim = regex_match_between('your ', ' in', entry_content)
				else:
					business_victim = regex_match_between('Your ', ' in', entry_content)
				business_victim_formatted = globals()[city].__dict__[business_victim].which_business

				if city_short == "":
					discord_message(config['Auth']['discord_id'] + "JOURNAL TORCH VICTIM - CITY NOT FOUND IN " + entry_content)
				if business_victim_formatted == "":
					discord_message(config['Auth']['discord_id'] + "JOURNAL TORCH VICTIM - BUSINESS NOT FOUND IN " + entry_content)

				minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
				if '-' in str(minutes_diff):
					pass
				else:
					update_database('Business', 'BizName', str(city) + str(business_victim_formatted), {"AggPro": str(aggtimer_string)})
					print_function('JOURNAL - UPDATED SHARED BIZ TORCH TIMER FOR ' + str(business_victim_formatted) + ' IN ' + str(city_short))

				# UPDATE LOCAL RECORDS
				aggtarget_business_list_manager[city].set_local_aggpro_timer(business_victim, new_aggpro_timer)
				print_function('JOURNAL - VICTIM BIZ TORCH - SET ' + str(business_victim_formatted) + ' IN ' + str(city_short) + 'LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

				if 'Attempted' in entry_title:
					pass
				else:
					# GET SUSPECT
					if 'name ended with:' in entry_content:
						suspect = regex_match_between('name ended with: ', None, entry_content).strip()
					else:
						# STEALTHED
						suspect = '<UNKNOWN>'
						pass

					# CHECK NEXT ENTRY FOR TRANSFER TO PROVE SUSPECT
					if ahead_one_entry is None:
						print_function('JOURNAL - NEXT ENTRY IS NONE - UPDATE SAVED RECORDS TO UPLOAD NEXT JOURNAL ENTRY IN CASE REPAY NOT RECEIVED YET')
						all_aggs_dictionary = [entry_time_for_database, business_victim_formatted, city_short, entry_title, suspect]
						write_file("env/journal_all_aggs_temp.txt", str(all_aggs_dictionary))
					else:
						# FUTURE JOURNAL ENTRIES. UPDATE THE DATABASE WHETHER NEXT IS A TRANSFER OR NOT
						if 'into your bank account' in str(ahead_one_entry):
							if 'anonymous' in str(ahead_one_entry):
								pass
							else:
								transfer_suspect = regex_match_between('<strong>', '</strong>', ahead_one_entry).strip()
								if suspect == '<UNKNOWN>':
									suspect = transfer_suspect
								elif suspect in transfer_suspect:
									suspect = transfer_suspect
								print_function('JOURNAL - TRANSFER FOUND AFTER AGG - SUSPECT: ' + str(suspect) + ' TRANSFER SUSPECT: ' + str(transfer_suspect))

						if suspect == '<UNKNOWN>':
							# NO SUSPECT. THERE IS NO NEED TO UPDATE THE DATABASE WITH USELESS INFORMATION
							print_function('JOURNAL - NO SUSPECT. ALL AGGS DATABASE IS NOT UPDATED')
							pass
						else:
							# UPDATE ALL AGGS RECORD
							update_string = "\r\n" + str(suspect) + " Biz Torch " + str(business_victim_formatted) + " (Success) in " + str(city_short) + " on " + str(entry_time_for_database)
							append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
							print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR TORCH VICTIM')

	# ARMED ROBBERY / Attempted Armed Robbery
	# Your Boxing in Manchester was held up at gun point by another player and $0 was stolen! You managed to catch a glimpse of the armed offender - their name ended with: kyo
	elif ('Armed Robbery!' == entry_title) or ('Attempted Armed Robbery' == entry_title):
		print_function('JOURNAL - VICTIM BIZ ARMEDROBBERY FOUND')
		if 'Drug House' in str(entry_content):
			discord_message(config['Auth']['discord_id'] + str(entry_content))
		else:
			# UPDATE SHARED RECORDS
			new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=1)
			new_aggpro_timer = new_aggpro_timer + datetime.timedelta(minutes=40)
			aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
			entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

			if 'Attempted' in entry_title:
				if 'They were wearing' in str(entry_content):
					city = regex_match_between('in ', '\.', entry_content)
				else:
					city = regex_match_between('in ', '!', entry_content)
			else:
				city = regex_match_between('in ', ' was', entry_content)
			city = city.replace(" ", "")
			city_short = str(globals()[city].city_short_string)

			if 'Attempted' in entry_title:
				business_victim = regex_match_between('your ', ' in', entry_content).strip()
			else:
				business_victim = regex_match_between('Your ', ' in', entry_content).strip()
			business_victim_formatted = globals()[city].__dict__[business_victim].which_business

			if city_short == "":
				discord_message(config['Auth']['discord_id'] + "JOURNAL ARMEDROBBERY VICTIM - CITY NOT FOUND IN " + entry_content)
			if business_victim_formatted == "":
				discord_message(config['Auth']['discord_id'] + "JOURNAL ARMEDROBBERY VICTIM - BUSINESS NOT FOUND IN " + entry_content)

			minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
			if '-' in str(minutes_diff):
				pass
			else:
				update_database('Business', 'BizName', str(city) + str(business_victim_formatted), {"AggPro": str(aggtimer_string)})
				print_function('JOURNAL - UPDATED SHARED ARMEDROBBERY TIMER FOR ' + str(business_victim_formatted) + ' IN ' + str(city_short))

			# UPDATE LOCAL RECORDS
			aggtarget_business_list_manager[city].set_local_aggpro_timer(business_victim, new_aggpro_timer)
			print_function('JOURNAL - VICTIM ARMEDROBBERY - SET ' + str(business_victim_formatted) + ' IN ' + str(city_short) + 'LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

			if 'Attempted' in entry_title:
				pass
			else:
				# GET SUSPECT
				if 'name ended with:' in entry_content:
					suspect = regex_match_between('name ended with: ', None, entry_content).strip()
				else:
					# STEALTHED
					suspect = '<UNKNOWN>'
					pass

				# CHECK NEXT ENTRY FOR TRANSFER TO PROVE SUSPECT
				if ahead_one_entry is None:
					print_function('JOURNAL - NEXT ENTRY IS NONE - UPDATE SAVED RECORDS TO UPLOAD NEXT JOURNAL ENTRY IN CASE REPAY NOT RECEIVED YET')
					all_aggs_dictionary = [entry_time_for_database, business_victim_formatted, city_short, entry_title, suspect]
					write_file("env/journal_all_aggs_temp.txt", str(all_aggs_dictionary))
				else:
					# FUTURE JOURNAL ENTRIES. UPDATE THE DATABASE WHETHER NEXT IS A TRANSFER OR NOT
					if 'into your bank account' in str(ahead_one_entry):
						if 'anonymous' in str(ahead_one_entry):
							pass
						else:
							transfer_suspect = regex_match_between('<strong>', '</strong>', ahead_one_entry).strip()
							if suspect == '<UNKNOWN>':
								suspect = transfer_suspect
							elif suspect in transfer_suspect:
								suspect = transfer_suspect
							print_function('JOURNAL - TRANSFER FOUND AFTER AGG - SUSPECT: ' + str(suspect) + ' TRANSFER SUSPECT: ' + str(transfer_suspect))

					if suspect == '<UNKNOWN>':
						# NO SUSPECT. THERE IS NO NEED TO UPDATE THE DATABASE WITH USELESS INFORMATION
						print_function('JOURNAL - NO SUSPECT. ALL AGGS DATABASE IS NOT UPDATED')
						pass
					else:
						# UPDATE ALL AGGS RECORD
						update_string = "\r\n" + str(suspect) + " Biz AR " + str(business_victim_formatted) + " (Success) in " + str(city_short) + " on " + str(entry_time_for_database)
						append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
						print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR ARMEDROBBERY VICTIM')
	# END OF VICTIM
	return


def witness_entries(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, aggtarget_person_list_manager, aggtarget_business_list_manager, manager, your_character_name):
	if 'WITNESS' == entry_title:
		# WHACK & ATTEMPT WITNESSES
		if ('resembled an explosive' in entry_content) or ('brutally murdered' in entry_content):
			discord_message(config['Auth']['discord_id'] + str(your_character_name) + " @here @everyone: " + str(entry_time) + str(entry_content))

		# PICKPOCKET
		# You witnessed Widow get pickpocketed! The attackers name ended with ams. The person was seen wearing, Dirty tee, Ripped Jeans
		# timer 2 hours
		if 'get pickpocketed!' in entry_content:
			print_function('JOURNAL - WITNESS PICKPOCKET FOUND')
			# UPDATE SHARED RECORDS
			victim = regex_match_between('witnessed <strong>', '<', entry_content).strip()
			new_aggpro_timer = entry_time_edited + datetime.timedelta(minutes=70)
			aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')

			minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
			if '-' in str(minutes_diff):
				pass
			else:
				update_database('Player', 'PlayerName', str(victim), {"Aggpro_Personal": str(aggtimer_string), "UpdatedBy": "Journal-PPWitness"})
			entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

			# UPDATE LOCAL RECORDS
			try:
				# ALREADY EXISTS
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - VICTIM PICKPOCKET - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))
			except:
				# CREATE NEW
				aggtarget_person_list_manager[victim] = manager.person(victim)
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - VICTIM PICKPOCKET (NEW ENTRY) - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

			suspect = regex_match_between('ended with ', '\.', entry_content).strip()

			# UPDATE ALL AGGS RECORD
			update_string = "\r\n" + str(suspect) + " Pickpocket " + str(victim) + " (Witness) in " + str(current_city) + " on " + str(entry_time_for_database)
			append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
			print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR PICKPOCKET WITNESS')

		# MUGGING
		# You witnessed Tezzdog get mugged! The attacker`s name ended with arv.
		# timer 1h 40min
		if 'get mugged!' in entry_content:
			print_function('JOURNAL - WITNESS MUG FOUND')
			# UPDATE SHARED RECORDS
			victim = regex_match_between('witnessed <strong>', '<', entry_content).strip()
			new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=1)
			new_aggpro_timer = new_aggpro_timer + datetime.timedelta(minutes=40)
			aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')

			minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
			if '-' in str(minutes_diff):
				pass
			else:
				update_database('Player', 'PlayerName', str(victim), {"Aggpro_Personal": str(aggtimer_string), "UpdatedBy": "Journal-MugWitness"})
			entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

			# UPDATE LOCAL RECORDS
			try:
				# ALREADY EXISTS
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - VICTIM MUG - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))
			except:
				# CREATE NEW
				aggtarget_person_list_manager[victim] = manager.person(victim)
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - VICTIM MUG (NEW ENTRY) - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

			suspect = regex_match_between('ended with ', '\.', entry_content).strip()

			# UPDATE ALL AGGS RECORD
			update_string = "\r\n" + str(suspect) + " Mug " + str(victim) + " (Witness) in " + str(current_city) + " on " + str(entry_time_for_database)
			append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
			print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR MUG WITNESS')

		# HACK
		# You witnessed ZeeRose`s bank account getting hacked at the local cyber cafe! You saw part of their login name which ended with ams. The person was seen wearing, Dirty tee, Ripped Jeans
		# timer 24 hours
		if 'getting hacked' in entry_content:
			print_function('JOURNAL - WITNESS HACK FOUND')
			# UPDATE SHARED RECORDS
			victim = regex_match_between('witnessed <strong>', '<', entry_content).strip()
			new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=12)
			aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
			entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

			minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
			if '-' in str(minutes_diff):
				pass
			else:
				update_database('Player', 'PlayerName', str(victim), {"Aggpro_Hack": str(aggtimer_string), "UpdatedBy": "Journal-HackWitness"})
				print_function('JOURNAL - UPDATED SHARED HACK WITNESS TIMER FOR ' +  str(victim))

			# UPDATE LOCAL RECORDS
			try:
				# ALREADY EXISTS
				aggtarget_person_list_manager[victim].set_local_hack_timer(aggtimer_string)
				print_function('JOURNAL - VICTIM HACK - SET ' + str(victim) + ' LOCAL HACK TIMER TO ' + str(aggtimer_string))
			except:
				# CREATE NEW
				aggtarget_person_list_manager[victim] = manager.person(victim)
				aggtarget_person_list_manager[victim].set_local_hack_timer(aggtimer_string)
				print_function('JOURNAL - VICTIM HACK (NEW ENTRY) - SET ' + str(victim) + ' LOCAL HACK TIMER TO ' + str(aggtimer_string))

			suspect = regex_match_between('ended with ', '\.', entry_content).strip()

			# UPDATE ALL AGGS RECORD
			update_string = "\r\n" + str(suspect) + " Hack " + str(victim) + " (Witness) in " + str(current_city) + " on " + str(entry_time_for_database)
			append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
			print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR HACK WITNESS')

		# BNE
		# You witnessed Smok`s Flat get broken into! You vaguely recognised the thief - their name ended with: God.
		# timer 1h 40min
		if 'broken into!' in entry_content:
			print_function('JOURNAL - WITNESS BnE FOUND')
			# UPDATE SHARED RECORDS
			victim = regex_match_between('witnessed <strong>', '<', entry_content).strip()
			new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=1)
			new_aggpro_timer = new_aggpro_timer + datetime.timedelta(minutes=10)
			aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
			entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

			minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
			if '-' in str(minutes_diff):
				pass
			else:
				update_database('Player', 'PlayerName', str(victim), {"Aggpro_Personal": str(aggtimer_string), "UpdatedBy": "Journal-BnEWitness"})

			# UPDATE LOCAL RECORDS
			try:
				# ALREADY EXISTS
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - WITNESS BnE - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))
			except:
				# CREATE NEW
				aggtarget_person_list_manager[victim] = manager.person(victim)
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - WITNESS BnE (NEW ENTRY) - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

			house = get_house_from_string(entry_content)
			if house != "NOTFOUND":
				aggtarget_person_list_manager[victim].set_house(house)

			suspect = regex_match_between('ended with:', '\.', entry_content).strip()

			# UPDATE ALL AGGS RECORD
			update_string = "\r\n" + str(suspect) + " BnE " + str(victim) + " (Witness) in " + str(current_city) + " on " + str(entry_time_for_database)
			append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(
				datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(
				datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
			print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR BnE WITNESS')

		# GTA
		# timer 1h 40min
		if 'vehicle get stolen' in entry_content:
			print_function('JOURNAL - WITNESS GTA FOUND')
			# UPDATE SHARED RECORDS
			victim = regex_match_between('witnessed <strong>', '<', entry_content).strip()
			new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=1)
			new_aggpro_timer = new_aggpro_timer + datetime.timedelta(minutes=40)
			aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
			entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

			minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
			if '-' in str(minutes_diff):
				pass
			else:
				update_database('Player', 'PlayerName', str(victim), {"Aggpro_Personal": str(aggtimer_string), "UpdatedBy": "Journal-GTAWitness"})

			# UPDATE LOCAL RECORDS
			try:
				# ALREADY EXISTS
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - WITNESS GTA - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))
			except:
				# CREATE NEW
				aggtarget_person_list_manager[victim] = manager.person(victim)
				aggtarget_person_list_manager[victim].set_local_aggpro_timer(aggtimer_string)
				print_function('JOURNAL - WITNESS GTA (NEW ENTRY) - SET ' + str(victim) + ' LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

			aggtarget_person_list_manager[victim].set_vehicle("None")
			suspect = regex_match_between('ended with ', '\.', entry_content).strip()

			# UPDATE ALL AGGS RECORD
			update_string = "\r\n" + str(suspect) + " GTA " + str(victim) + " (Witness) in " + str(current_city) + " on " + str(entry_time_for_database)
			append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
			print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR GTA WITNESS')

		# HOUSE TORCH
		if ( ('Flat' in entry_content) or ('Studio' in entry_content) or ('Penthouse' in entry_content) or ('Palace' in entry_content) ):
			pass

		# BUSINESS TORCH
		# You witnessed Manchester`s Bank get set ablaze! The arsonist looked vaguely familar, their name ended with: ons.
		# timer 2h 40min
		if 'get set ablaze' in entry_content:
			if 'Drug House' in str(entry_content):
				discord_message(config['Auth']['discord_id'] + str(entry_content))
			else:
				# UPDATE SHARED RECORDS
				print_function('JOURNAL - WITNESS BIZ TORCH FOUND')
				city = regex_match_between('witnessed ', '`s', entry_content).strip()
				city = city.replace(" ", "")
				city_short = str(globals()[city].city_short_string).strip()
				business_victim = regex_match_between('`s', 'get', entry_content).strip()
				business_victim_formatted = (globals()[city].__dict__[business_victim].which_business).strip()
				new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=2)
				new_aggpro_timer = new_aggpro_timer + datetime.timedelta(minutes=40)
				aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
				entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')

				suspect = regex_match_between('ended with: ', '\.', entry_content).strip()

				minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
				if '-' in str(minutes_diff):
					pass
				else:
					update_database('Business', 'BizName', str(city) + str(business_victim_formatted), {"AggPro": str(aggtimer_string)})
					print_function('JOURNAL - UPDATED SHARED WITNESS BIZ TORCH TIMER FOR ' + str(business_victim_formatted) + ' IN ' + str(city_short) + ' TIMER ' + str(aggtimer_string))

				# UPDATE LOCAL RECORDS
				aggtarget_business_list_manager[city].set_local_aggpro_timer(business_victim, new_aggpro_timer)
				print_function('JOURNAL - WITNESS BIZ TORCH - SET ' + str(business_victim_formatted) + ' IN ' + str(city_short) + 'LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

				# UPDATE ALL AGGS RECORD
				update_string = "\r\n" + str(suspect) + " BIZ TORCH " + str(business_victim_formatted) + " (Witness) in " + str(city_short) + " on " + str(entry_time_for_database)
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
				print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR BIZ TORCH WITNESS')

		# ARMED ROBBERY
		# You witnessed the Manchester Fire Station get robbed at gun point! The thief looked vaguely familiar, their name ended with: kyo.
		# timer 1h 40min
		if 'at gun point!' in entry_content:
			if 'Drug House' in str(entry_content):
				discord_message(config['Auth']['discord_id'] + str(entry_content))
			else:
				print_function('JOURNAL - WITNESS ARMEDROBBERY FOUND')
				# UPDATE SHARED RECORDS
				new_aggpro_timer = entry_time_edited + datetime.timedelta(hours=1)
				new_aggpro_timer = new_aggpro_timer + datetime.timedelta(minutes=40)
				aggtimer_string = datetime.datetime.strftime(new_aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
				entry_time_for_database = datetime.datetime.strftime(entry_time_edited, '%Y-%m-%d %H:%M:%S.%f')
				for city_item in globals()['cities_list_spaces']:
					if city_item in str(entry_content):
						city = city_item

				business_victim = regex_match_between(city, 'get robbed', entry_content).strip()
				city = city.replace(" ", "")
				business_victim_formatted = (globals()[city].__dict__[business_victim].which_business).strip()
				city_short = str(globals()[city].city_short_string).strip()
				suspect = regex_match_between('ended with: ', '\.', entry_content).strip()

				minutes_diff = (new_aggpro_timer - datetime.datetime.utcnow()).total_seconds() / 60.0
				if '-' in str(minutes_diff):
					pass
				else:
					update_database('Business', 'BizName', str(city) + str(business_victim_formatted), {"AggPro": str(aggtimer_string)})
					print_function('JOURNAL - UPDATED SHARED WITNESS ARMEDROBBERY TIMER FOR ' + str(business_victim_formatted) + ' IN ' + str(city_short) + ' TIMER ' + str(aggtimer_string))

				# UPDATE LOCAL RECORDS
				aggtarget_business_list_manager[city].set_local_aggpro_timer(business_victim, new_aggpro_timer)
				print_function('JOURNAL - WITNESS ARMEDROBBERY - SET ' + str(business_victim_formatted) + ' IN ' + str(city_short) + 'LOCAL AGGPRO TIMER TO ' + str(aggtimer_string))

				# UPDATE ALL AGGS RECORD
				update_string = "\r\n" + str(suspect) + " AR " + str(business_victim_formatted) + " (Witness) in " + str(city_short) + " on " + str(entry_time_for_database)
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
				print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR ARMEDROBBERY WITNESS')
	# END OF WITNESS
	return


def case_entries(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, your_character_name):
	if 'CONVICTION' == entry_title:
		case_number = regex_match_between('case ', '!', entry_content).strip()
		if 'victim <strong>Administrator' in entry_content:
			case_city = regex_match_between('of ', ' has', entry_content).strip()
		elif 'Administrator' in entry_content:
			case_city = regex_match_between('in ', ' has', entry_content).strip()
		else:
			case_city = regex_match_between('of ', ' has', entry_content).strip()
		case_city = case_city.replace(" ", "")
		city_short = globals()[case_city].city_short_string
		print_function('case: ' + str(case_number) + ' / city: ' + str(case_city) + ' / short: ' + str(city_short))
		write_file("cases/" + str(city_short) + "/" + str(case_number) + ".txt", " ")
	elif 'ARREST' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " ARREST: " + str(entry_content))
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " MANUALLY DELETE THIS CASE IN BOT FOLDER")
	elif 'Auto Arrest' == entry_title:
		case_number = regex_match_between('crime', 'of', entry_content).strip()
		case_number = re.sub('[^0-9]', "", case_number)
		print_function('case: ' + str(case_number))
		# NO CITY IN AUTO ARREST ENTRY. TRY DELETE FROM EVERY CITY
		for city in globals()['cities_list']:
			city_short = str(globals()[city].city_short_string)
			try:
				os.remove("cases/" + str(city_short) + "/" + str(case_number) + ".txt")
			except:
				pass

	elif 'Court Case Result' == entry_title:
		case_number = regex_match_between('<i>#', '</i>', entry_content).strip()
		case_city = regex_match_between('city of ', ',', entry_content).strip()
		case_city = case_city.replace(" ", "")
		city_short = globals()[case_city].city_short_string
		print_function('case: ' + str(case_number) + ' / city: ' + str(case_city) + ' / short: ' + str(city_short))
		globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		try:
			os.remove("cases/" + str(city_short) + "/" + str(case_number) + ".txt")
		except:
			pass
	return


def misc_journal(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, your_character_name, all_boys_list, waiting_thread_list):
	if ('Be Careful' in str(entry_title)) or ('WATCH YOUR BACK' in str(entry_title)):
		waiting_thread_list.append('9zLoggedOut')
		while True:
			if 'LoggedOut' in str(waiting_thread_list):
				break
		print_function('9zterminate-everything THREAD QUEUED FROM MHS WARNING ' + str(waiting_thread_list), "GREEN")
		driver.get("https://mafiamatrix.com/default.asp?action=logout")
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " MHS WARNING: " + str(entry_content))
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " LOGGED OUT - AWAITING RESTART COMMAND")

		sqs = boto3.resource('sqs',
							 region_name='ap-southeast-2',
							 aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
							 aws_secret_access_key='ZHOEqdJJhOlI3ni7Elik+LLso3U9mpKlQUhEG9cs',
							 )
		for boys_name in all_boys_list:
			if boys_name == str(your_character_name):
				continue
			try:
				queue = sqs.get_queue_by_name(QueueName=str(boys_name))
			except:
				continue
			response = queue.send_message(MessageBody="MHSWarn", DelaySeconds=1)
			print_function("MHS WARN MESSAGED: " + str(boys_name) + " RESPONSE: " + str(response), "GREEN")
		waiting_thread_list.append('9zterminate-everything')

		while True:
			time.sleep(5)
	elif 'Fire Inspection Completed' in entry_title:
		if ('Flat' in entry_content) or ('Palace' in entry_content) or ('Penthouse' in entry_content) or ('Studio' in entry_content):
			random_timer = random.randrange(721, 781)  # 12 hours
			write_file("env/fireinspection_house_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
	elif 'Surgery Completed' in entry_title:
		if 'sex change' in str(entry_content):
			random_timer = random.randrange(1443, 1563)  # 24 - 26 hours
			write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
	elif 'SECRET UNLOCKED' in entry_title:
		if 'Street' in entry_content:
			if 'Streetfight' in running_thread[4]:
				pass
			else:
				variables_list = running_thread[4]
				variables_list.append('Streetfight')

				for item in running_thread[4]:
					if 'PizzaBatting' in item:
						try:
							variables_list.remove(item)
						except:
							pass
						break

				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES SECRET STREETFIGHT UNLOCKED: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])
				globals()['relog'] = True
		elif 'Pimp' in entry_content:
			if 'Pimp' in running_thread[4]:
				pass
			else:
				variables_list = running_thread[4]
				variables_list.append('Pimp')

				for item in running_thread[4]:
					if 'PimpSteal' in item:
						try:
							variables_list.remove(item)
						except:
							pass
						break

				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES SECRET PIMP UNLOCKED: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])
				globals()['relog'] = True
		elif 'Whore' in entry_content:
			if 'Whore' in running_thread[4]:
				pass
			else:
				variables_list = running_thread[4]
				variables_list.append('Whore')

				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES SECRET WHORE UNLOCKED: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])
				globals()['relog'] = True
		elif 'Joyride' in entry_content:
			if 'Joyride' in running_thread[4]:
				pass
			else:
				variables_list = running_thread[4]
				variables_list.append('Joyride')

				for item in running_thread[4]:
					if 'JoyrideEarns' in item:
						try:
							variables_list.remove(item)
						except:
							pass
						break

				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES SECRET JOYRIDE UNLOCKED: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])
				globals()['relog'] = True
		elif 'Editor' in entry_content:
			pass
		elif 'Hack' in entry_content:
			pass
		else:
			input('NEW SECRET UNLOCKED')

	# Character skill gained
	# You have just gained the "Drug Runner (Rank 1)" trait and can now start reaping the benefits of its reward!

	elif 'ATTEMPTED WHACK' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " @here @everyone WHACK ATTEMPT: " + str(entry_time) + " " + str(entry_content))
	elif 'Protection whack attempt' in str(entry_title):
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " @here @everyone PRO WHACK ATTEMPT: " + str(entry_time) + " " + str(entry_content))
	elif 'EXILE' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " EXILE: " + str(entry_content))
	elif 'Crew front downgraded' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " CF DOWNGRADE: " + str(entry_content))
	elif 'START A RIOT' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " RIOT REQUEST: " + str(entry_content))
	elif 'Protection Dropped' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " OH NOES: " + str(entry_content))
	elif 'CLEANER CALLED' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " CLEANER: " + str(entry_content))
	elif 'CLEANER COMPLETED JOB' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " CLEANER: " + str(entry_content))
	elif 'TAX EVASION' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " TAX EVADE: " + str(entry_content))
	elif 'Fired' == entry_title:
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + " FIRED: " + str(entry_content))
	elif 'Private investigation completed' in str(entry_title):
		discord_message(config['Auth']['discord_id'] + str(your_character_name) + str(entry_content))
	elif 'Representation Accepted' == entry_title:
		globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Case', running_thread))
	elif 'Illness' == entry_title:
		globals()['illness_found'] = True
		print_function('JOURNAL - YOU HAVE FLU')
	elif 'Money Laundering' == entry_title:
		if 'established a deal' in entry_content:
			globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, "Launder", running_thread))
	elif 'Transfer' == entry_title:
		if 'Reason:' in entry_content:
			discord_journal(config['Auth']['discord_id'] + str(your_character_name) + " MONEY TRANSFER WITH REASON - On: " + str(entry_time) + " Content: " + str(entry_content))
	elif 'REPAIRS' == entry_title:
		if 'repairs on your vehicle' in entry_content:
			# CAR REPAIRED
			variables_list = running_thread[4]
			for item in running_thread[4]:
				if 'Vehicle:' in item:
					try:
						variables_list.remove(item)
					except:
						pass
			variables_list.append('Vehicle:FullyRepaired')
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])
	return


def check_journal(lock_webdriver, running_thread, waiting_thread_list, aggtarget_person_list_manager, aggtarget_business_list_manager, all_boys_list):
	# AVOID CHECKING IF CAPTCHA. THIS GAVE A FALSE POSITIVE FOR SOME REASON
	if 'captcha_thread' in str(waiting_thread_list):
		print_function('JOURNAL - SKIPPED AS CAPTCHA')
		return

	if 'In-Jail' in str(running_thread[4]):
		new_journal_entries = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='nav_left']/p[2]/a/span", "outerHTML")
	else:
		new_journal_entries = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='nav_left']/div[2]/a[1]/span", "outerHTML")

	new_journal_entries = re.sub('[^0-9]', "", new_journal_entries)
	if new_journal_entries == '':
		new_journal_entries = 0

	url_check = get_url(lock_webdriver)

	if (int(new_journal_entries) > 0) or ('journal.asp' in str(url_check)):
		print_function('JOURNAL - THREAD QUEUED')
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_messages)
		print_function('JOURNAL - THREAD ACTIVE')
		globals()['relog'] = False
		buy_drugs = False

		go_to_page(lock_webdriver, "Journal", running_thread)

		# RESET JOURNAL TIMER HERE
		# write_file("env/recent_journal_entry.txt", str(datetime.datetime.utcnow() - datetime.timedelta(days=10)))
		# write_file("env/recent_journal_request.txt", str(datetime.datetime.utcnow() - datetime.timedelta(days=10)))

		your_character_name = get_your_character_name(lock_webdriver)
		current_city = str(globals()[get_current_city(lock_webdriver)].which_city)
		home_city = str(globals()[get_home_city(lock_webdriver)].which_city)

		# CONNECT TO PERSON OBJECT FOR TIMERS
		server_port = read_file("env/ServerPort.txt")
		manager = BaseManager(address=('127.0.0.1', int(server_port)))
		BaseManager.register('person', person)
		BaseManager.register('city', city)

		while True:
			try:
				manager.connect()
				break
			except:
				print_function('JOURNAL - ALL TARGETS LOCAL AGGPRO TIMERS - FAILED TO CONNECT TO BASEMANAGER', "RED")
		# END OF CONNECT


		most_recent_journal_entry = read_file("env/recent_journal_entry.txt")
		try:
			most_recent_journal_entry = datetime.datetime.strptime(most_recent_journal_entry, '%Y-%m-%d %H:%M:%S')
		except:
			most_recent_journal_entry = datetime.datetime.strptime(most_recent_journal_entry, '%Y-%m-%d %H:%M:%S.%f')

		if 'In-Jail' in str(running_thread[4]):
			journal_table_raw = element_get_attribute(lock_webdriver, "XPATH",
													  ".//*[@id='jail_journal_holder']/div[@id='jail_journal_content']",
													  "innerHTML")
		else:
			journal_table_raw = element_get_attribute(lock_webdriver, "XPATH",
												  ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']",
												  "innerHTML")

		requests_check = regex_match_between('Requests/Offers', '<', journal_table_raw)
		requests_check = re.sub('[^0-9]', "", requests_check)
		if requests_check == '':
			pass
		else:
			how_many_request_entires = requests_check
			if int(how_many_request_entires) > 20:
				how_many_request_entires = 20

		how_many_journal_entires = regex_match_between('Events', '<', journal_table_raw)
		how_many_journal_entires = re.sub('[^0-9]', "", how_many_journal_entires)

		if how_many_journal_entires == "":
			thread_remove_from_queue(running_thread, waiting_thread_list)
			return

		if int(how_many_journal_entires) > 20:
			how_many_journal_entires = 20
		journal_entry_number = how_many_journal_entires

		if 'In-Jail' in str(running_thread[4]):
			journal_table_split = journal_table_raw.split('<td class="jail_journal_event')
		else:
			journal_table_split = journal_table_raw.split('<td class="journal_event')
		journal_index_count = len(journal_table_split)
		for journal_entry in reversed(journal_table_split):
			# UPDATE COUNTER
			journal_index_count -= 1

			# GET BEHIND ONE ENTRY
			if journal_index_count >= (len(journal_table_split) - 1):
				behind_one_entry = None
			else:
				behind_one_entry = journal_table_split[int(journal_index_count) + 1]

			# SKIP NON ENTRIES
			if ('<strong class="title">' in journal_entry) or ('class="whack"' in journal_entry):
				pass
			else:
				continue

			# SKIP NEWSPAPER EDITOR
			if 'color: gold' in str(journal_entry):
				continue
			if 'Mass message from' in str(journal_entry):
				# SKIP MAYOR MESSAGES
				continue

			print_function("JOURNAL - ENTRY RAW: " + journal_entry, "BLUE")

			# GET AHEAD ONE ENTRY
			if journal_index_count < 2:
				ahead_one_entry = None
			else:
				ahead_one_entry = journal_table_split[int(journal_index_count) - 1]

			if 'class="whack"' in journal_entry:
				entry_title = regex_match_between('<strong class="whack">', '</', journal_entry)
			else:
				entry_title = regex_match_between('<strong class="title">', '<', journal_entry)

			entry_time = regex_match_between('<span class="time">', '<', journal_entry).strip()
			entry_content = regex_match_between('<br><br>', '</label></td>', journal_entry).strip()

			# ADJUST FOR AUTO ARREST AS THEY HAVE NO TIME. JUST A DATE
			if entry_title == 'Auto Arrest':
				entry_time_edited = datetime.datetime.utcnow()
			else:
				entry_time_edited = datetime.datetime.strptime(entry_time, '%m/%d/%Y %I:%M:%S %p')

			time_difference = most_recent_journal_entry - entry_time_edited
			if '-' in str(time_difference):
				# SENT JOURNAL ENTRY
				if 'Sent by:' in journal_entry:
					entry_title = regex_match_between('</strong><br>', '<', journal_entry)
					sent_by = regex_match_between('Sent by: ', '<', journal_entry)
					print_function('JOURNAL - NEW ENTRY SENT BY ' + str(sent_by) + ' - TITLE: ' + str(entry_title) + ' TIME: ' + str(entry_time) + ' CONTENT: ' + str(entry_content))
					discord_journal(config['Auth']['discord_id'] + str(your_character_name) + " New Journal Sent By: " + str(sent_by) + " On: " + str(entry_time) + " Content: " + str(entry_content))
				else:
					# NEW REGULAR JOURNAL
					print_function('JOURNAL - NEW ENTRY - TITLE: ' + str(entry_title) + ' TIME: ' + str(entry_time) + ' CONTENT: ' + str(entry_content))

					if 'Notice' == entry_title:
						continue


					# IF LAST ENTRY IS TRANFSER THEN MODIFY BEFORE UPDATE. OTHERWISE UPDATE AS WE DID NOT GET REPAYMENT
					#  [entry_time_for_database, business_victim_formatted, city_short, entry_title, suspect]
					all_aggs_dictionary = read_file("env/journal_all_aggs_temp.txt")
					print_function('JOURNAL - ALL AGGS DICTIONARY: ' + str(all_aggs_dictionary))
					if "[]" in str(all_aggs_dictionary):
						# NO SAVED DETAILS
						pass
					else:
						all_aggs_dictionary = eval(all_aggs_dictionary)
						if ( (entry_title == 'Transfer') and (not 'An anonymous person' in str(entry_content)) ):
							# UPDATE SUSPECT FOR THE TRANSFER SUSPECT
							entry_time_for_database = all_aggs_dictionary[0]
							victim = all_aggs_dictionary[1]
							entry_city = all_aggs_dictionary[2]
							title = all_aggs_dictionary[3]
							suspect = all_aggs_dictionary[4]
							transfer_suspect = regex_match_between('<strong>', '</strong>', entry_content).strip()
							if suspect == '<UNKNOWN>':
								suspect = transfer_suspect
							elif suspect in transfer_suspect:
								suspect = transfer_suspect
							print_function(str(entry_time_for_database) + " " + str(victim) + " " + str(entry_city) + " " + str(title) + " " + str(suspect) + " " + str(transfer_suspect))
							if suspect == '<UNKNOWN>':
								# NO NEED TO LOG IF NO SUSPECT
								print_function('JOURNAL - ALL AGGS DATABASE WITH TRANSFER - SKIPPING AS NO SUSPECT')
								pass
							else:
								if title == 'Hacking':
									title = 'Hack'
								update_string = "\r\n" + str(suspect) + " " + str(title) + " " + str(victim) + " (Success) in " + str(current_city) + " on " + str(entry_time_for_database)
								append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
								print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR LATEST ENTRY WITH TRANSFER - VICTIM: ' + str(victim) + ' SUSPECT: ' + str(suspect) + ' AGG: ' + str(title) + ' CITY: ' + str(entry_city))
							write_file("env/journal_all_aggs_temp.txt", "[]")
						else:
							# UPDATE AS IS
							entry_time_for_database = all_aggs_dictionary[0]
							victim = all_aggs_dictionary[1]
							entry_city = all_aggs_dictionary[2]
							title = all_aggs_dictionary[3]
							suspect = all_aggs_dictionary[4]
							print_function(str(entry_time_for_database) + " " + str(victim) + " " + str(entry_city) + " " + str(title) + " " + str(suspect))
							if suspect == '<UNKNOWN>':
								# NO NEED TO LOG IF NO SUSPECT
								print_function('JOURNAL - ALL AGGS DATABASE WITHOUT TRANSFER - SKIPPING AS NO SUSPECT')
								pass
							else:
								if title == 'Hacking':
									title = 'Hack'
								update_string = "\r\n" + str(suspect) + " " + str(title) + " " + str(victim) + " (Success) in " + str(current_city) + " on " + str(entry_time_for_database)
								append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').year) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').month) + '-' + str(datetime.datetime.strptime(entry_time_for_database, '%Y-%m-%d %H:%M:%S.%f').day) + '.txt', "\r\n" + str(update_string))
								print_function('JOURNAL - ALL AGGS DATABASE UPDATED FOR LATEST ENTRY WITHOUT TRANSFER - VICTIM: ' + str(victim) + ' SUSPECT: ' + str(suspect) + ' AGG: ' + str(title) + ' CITY: ' + str(entry_city))
							write_file("env/journal_all_aggs_temp.txt", "[]")



					# IN ORDER FOR PRIORITY:
					# fire investigation / dna - set police case timer now

					if 'Drug Trade Offer' == entry_title:
						if config['Drugs']['BuyDrugs']:
							buy_drugs = True
						else:
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + " U Got Bitches offer drug")

					victim_entries(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, ahead_one_entry, your_character_name, current_city, home_city, aggtarget_person_list_manager, aggtarget_business_list_manager, manager)
					witness_entries(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, aggtarget_person_list_manager, aggtarget_business_list_manager, manager, your_character_name)
					case_entries(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, your_character_name)
					misc_journal(lock_webdriver, running_thread, entry_title, entry_time, entry_content, entry_time_edited, your_character_name, all_boys_list, waiting_thread_list)

					known_journal_entries = ['ATTEMPTED WHACK', 'MUGGING', 'Report Request', 'Dog Whack', 'MISSED FLIGHT', 'Protection Dropped', 'Lawyer Representation Offered',
											 'EXILE', 'Drug Smuggle', 'Drug Run', 'Lawyer Quit', 'Business Protection', 'New Godfather', 'Car-Jacking', 'Fired',
											 'New Mayor Elected', 'BANK ROBBERY', 'Armour Sold', 'Dirty Money Returned', 'JAIL BREAK RESULT', 'Declined Invite',
											 'AUCTION', 'Promotion', 'Surgery Cancelled', 'Consumable Sold', 'Election Day', 'JAIL BREAK FAILED', 'Private investigation completed',
											 'PROMOTION!', 'STOLEN CONTRABAND', 'PRISON BUST', 'DRUG BUST', 'Upkeep payment missed', 'Treatment Cancelled',
											 'Loan Request Accepted', 'Loan Request Put Forward', 'BAD PASSWORD ATTEMPTS', 'Cured', 'Bionics Sold', 'Character skill gained',
											 'Weapon Sold', 'ACCEPTED - JAIL BREAK', 'Jail Smuggle', 'Pseudoephedrine Sold', 'CLEANER COMPLETED JOB',
											 'Huggled', 'Pardoned', 'BREAKING NEWS', 'Autopsy Completed', 'DNA Results', 'Crowd Control#2', 'Bionics For Sale',
											 'BodyGuard Job', 'Fire Investigation Results', 'Boxing Bet', 'Case Solved', 'Crowd Control#1', 'NEW CAPO', 'Sale Decline',
											 'Construction', 'Surgery Completed', 'Accepted', 'Donation Sale', 'Getaway Driver', 'The Safe Expert', 'Locate a Person',
											 'PINCHED SMOKES', 'Money Found', 'WEAPONS SEARCH', 'Diligent Worker', 'New Godfather', 'Auto Arrest', 'Tribute Change',
											 'Fire Inspection Completed', 'Torch', 'Fire Extinguished', 'Armed Robbery!', 'Fire Inspection Completed', 'Commission Paid',
											 'Attempted Armed Robbery', 'Dog Sold', 'Attempted Torch', 'Attempted Mugging', 'Crew Move', 'Crew front downgraded',
											 'Hacking', 'Attempted Break-in', 'WITNESS', 'Car Theft Ring', 'BANK ROBBERY RESULT', 'DECLINED - JAIL BREAK',
											 'Attempted Hack', 'Not Guilty', 'Transfer', 'REPAIRS', 'Pickpocket', 'KICKED FROM CREW!', 'PROMOTION', 'BodyGuard Accepted',
											 'Attempted Pickpocket', 'Illness', 'Money Transfer', 'Money Laundering', 'UNDERBOSS', 'GTA', 'Attempted GTA',
											 'CONVICTION', 'SECRET UNLOCKED', 'Court Case Result', 'Business Partnership', 'New Member', 'Crew Role', '<font color="red">Protection whack attempt',
											 'LOTTERY!', 'Vehicle Sold', 'TAX EVASION', 'J@JMEAIL BREAK RESULT', 'NEW COMMAND', 'Break-in!', 'CLEANER CALLED',
											 'JURY SERVICE', 'JAIL BREAK', 'Drug Trade Offer Accepted', 'START A RIOT', 'Drug Trade Offer Declined', 'Crew Invitation',
											 'Representation Accepted', 'Upkeep - Reminder', 'Fire Reported', 'Mayor Elections', 'Jail Trade', 'NEW CREW MEMBER',
											 'Repay Business Debt', 'Offer Accepted', 'Salary', 'Period', 'Locate', 'Drug Trade Offer', 'Period End', 'Mayor Salary',
											 'Crew front upkeep', 'Protection whack attempt', 'Boxing', 'Pardoned', 'DEMOTION!', 'Bodyguard', 'ARREST', 'MOVING CITIES', 'CONSTRUCTION']
					if entry_title in known_journal_entries:
						pass
					elif ( ('Representation Declined' in entry_title) or ('just read your message' in str(entry_title)) or ('just read your message' in str(entry_content)) ):
						pass
					elif 'color:#FF6633' in str(entry_content):
						pass
					else:
						discord_error(config['Auth']['discord_id'] + str(your_character_name) + " NEW JOURNAL TYPE TO CODE: " + str(entry_title) + str(entry_content))
			else:
				print_function('JOURNAL - SKIP OLD ENTRY - TITLE: ' + str(entry_title) + ' TIME: ' + str(entry_time) + ' CONTENT: ' + str(entry_content))
				journal_entry_number = int(journal_entry_number) - 1
				continue

			# UPDATE SAVED JOURNAL TIMER
			write_file("env/recent_journal_entry.txt", str(entry_time_edited))
			print_function('JOURNAL - PROCESSED ENTRY: ' + str(entry_content))

			journal_entry_number = int(journal_entry_number) - 1
		print_function('JOURNAL - PROCESSED ALL ENTRIES')


		# CHECK REQUESTS
		if requests_check == '':
			print_function("MISC - JOURNAL - NO REQUESTS")
		else:
			print_function("MISC - JOURNAL - REQUESTS PENDING: " + str(requests_check))
			if 'In-Jail' in str(running_thread[4]):
				element_click(lock_webdriver, 'XPATH', ".//*[@id='jail_journal_holder']/div[@id='jail_journal_content']/ul/li[2]/a", running_thread)
			else:
				element_click(lock_webdriver, 'XPATH', ".//*[@id='journal_holder']/div[@id='journal_content']/ul/li[2]/a", running_thread)

			most_recent_journal_request = read_file("env/recent_journal_request.txt")
			try:
				most_recent_journal_request = datetime.datetime.strptime(most_recent_journal_request, '%Y-%m-%d %H:%M:%S')
			except:
				most_recent_journal_request = datetime.datetime.strptime(most_recent_journal_request, '%Y-%m-%d %H:%M:%S.%f')

			if 'In-Jail' in str(running_thread[4]):
				journal_table_raw = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='jail_journal_holder']/div[@id='jail_journal_content']", "innerHTML")
			else:
				journal_table_raw = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']", "innerHTML")

			journal_table_split = journal_table_raw.split('<td class="journal_event')
			journal_index_count = len(journal_table_split)

			for journal_request in reversed(journal_table_split):
				# UPDATE COUNTER
				journal_index_count -= 1

				# SKIP NON ENTRIES
				if '<strong class="title">' in journal_request:
					pass
				else:
					continue

				request_title = regex_match_between('<strong class="title">', '<', journal_request)
				request_time = regex_match_between('<span class="time">', '<', journal_request).strip()
				request_content = regex_match_between('<br><br>', '</label></td>', journal_request).strip()
				request_time_edited = datetime.datetime.strptime(request_time, '%m/%d/%Y %I:%M:%S %p')

				time_difference = most_recent_journal_request - request_time_edited
				if '-' in str(time_difference):
					# NEW REQUEST
					print_function('JOURNAL - NEW REQUEST - TITLE: ' + str(request_title) + ' TIME: ' + str(request_time) + ' CONTENT: ' + str(request_content))

					if 'Weapon For Sale' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " WEAPON OFFERED: " + str(request_content))
					elif 'Bionics For Sale' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " BIONICS OFFERED: " + str(request_content))
					elif 'Armor For Sale' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " ARMOR OFFERED: " + str(request_content))
					elif 'Vehicle For Sale' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " VEHICLE OFFERED: " + str(request_content))
					elif 'Pseudoephedrine For Sale' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " PSEUDO OFFERED: " + str(request_content))
					elif 'Lawyer Representation Offered' in request_title:
						if config.getboolean('Misc', 'Accept_Lawyer_Reps'):
							# tr3 when first comes in, because 'new'? tr2 afterwards // maybe try tr3 except tr2. or look for new flag
							# count how many 'new' entries and add +1 once they start

							if 'In-Jail' in str(running_thread[4]):
								element_click(lock_webdriver, 'XPATH',
											  ".//*[@id='content']/div[@id='jail_journal_holder']/div[@id='jail_journal_content']/form[2]/table[@id='ft_top']/tbody/tr[3]/td[@id='jail_comms_msg_top'][1]/a",
											  running_thread)
							else:
								if element_found(lock_webdriver, "XPATH",
												 ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']/form[2]/table[@id='ft_top']/tbody/tr[3]/td[@id='comms_msg_top'][1]/a"):
									element_click(lock_webdriver, 'XPATH', ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']/form[2]/table[@id='ft_top']/tbody/tr[3]/td[@id='comms_msg_top'][1]/a", running_thread)
								else:
									element_click(lock_webdriver, 'XPATH', ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']/form[2]/table[@id='ft_top']/tbody/tr[2]/td[@id='comms_msg_top'][1]/a", running_thread)

								element_click(lock_webdriver, 'XPATH', ".//*[@id='journal_holder']/div[@id='journal_content']/ul/li[2]/a", running_thread)

							# the changing tr starts at 2 (new entry) or 3 (old entry) - increases by 3 for multiple old entries. unknown how it increases for multiple new entries
							# element_click(lock_webdriver, 'XPATH', ".//*[@id='content']/div[@id='jail_journal_holder']/div[@id='jail_journal_content']/form[2]/table[@id='ft_top']/tbody/tr[2]/td[@id='jail_comms_msg_top'][1]/a", running_thread)
							# element_click(lock_webdriver, 'XPATH', ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']/form[2]/table[@id='ft_top']/tbody/tr[2]/td[@id='comms_msg_top'][1]/a", running_thread)
					elif 'Drug Smuggle' in request_title:
						smuggle_name = regex_match_between('-', ' has offered', journal_request)
						print_function("SMUGGLE NAME: " + str(smuggle_name))

						if 'In-Jail' in str(running_thread[4]):
							element_click(lock_webdriver, 'XPATH',
										  ".//*[@id='content']/div[@id='jail_journal_holder']/div[@id='jail_journal_content']/form[2]/table[@id='ft_top']/tbody/tr[3]/td[@id='jail_comms_msg_top'][1]/a",
										  running_thread)
						else:
							if element_found(lock_webdriver, "XPATH",
											 ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']/form[2]/table[@id='ft_top']/tbody/tr[3]/td[@id='comms_msg_top'][1]/a"):
								element_click(lock_webdriver, 'XPATH',
											  ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']/form[2]/table[@id='ft_top']/tbody/tr[3]/td[@id='comms_msg_top'][1]/a",
											  running_thread)
							else:
								element_click(lock_webdriver, 'XPATH',
											  ".//*[@id='content']/div[@id='journal_holder']/div[@id='journal_content']/form[2]/table[@id='ft_top']/tbody/tr[2]/td[@id='comms_msg_top'][1]/a",
											  running_thread)

							element_click(lock_webdriver, 'XPATH', ".//*[@id='journal_holder']/div[@id='journal_content']/ul/li[2]/a", running_thread)

						if 'blind eye' in str(request_content):
							waiting_thread_list.append('9zBlindEye:' + str(smuggle_name))
							write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
							print_function('9zBlindEye THREAD QUEUED FOR ' + str(smuggle_name) + " " + str(waiting_thread_list), "GREEN")
						else:
							waiting_thread_list.append('9zSmuggleDrugs:' + str(smuggle_name))
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + " Accepted drug smuggle for " + str(smuggle_name))
							write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
							print_function('9zSmuggleDrugs THREAD QUEUED FOR ' + str(smuggle_name) + " " + str(waiting_thread_list), "GREEN")


					elif 'Crew Invitation' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " CREW INVITATION: " + str(request_content))
					elif 'Offer made' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " Offer: " + str(request_content))
					elif 'JAIL BREAK' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " JAILBREAK: " + str(request_content))
					elif 'Dog For Sale' in request_title:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " DOG: " + str(request_content))
					elif ( ('Getaway Driver' in request_title) or ('Lookout' in request_title) or ('The Safe Expert' in request_title) or ('Crowd Control#1' in request_title) or ('Crowd Control#2' in request_title) ):
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " BR Request: " + str(request_content))

					known_journal_requests = ['Getaway Driver', 'Lookout', 'JAIL BREAK', 'Dog For Sale', 'Court Case Result', 'Offer made', 'Drug Smuggle', 'Crowd Control#1', 'Crowd Control#2', 'The Safe Expert', 'Weapon For Sale', 'Lawyer Representation Offered', 'Pseudoephedrine For Sale', 'Bionics For Sale', 'Armor For Sale', 'Vehicle For Sale', 'Armour For Sale', 'Crew Invitation']
					if request_title in known_journal_requests:
						pass
					else:
						discord_error(config['Auth']['discord_id'] + str(your_character_name) + " NEW JOURNAL REQUEST TYPE TO CODE: " + str(request_title) + str(request_content))
						input('code this')
				else:
					print_function('JOURNAL - SKIP OLD REQUEST - TITLE: ' + str(request_title) + ' TIME: ' + str(request_time) + ' CONTENT: ' + str(request_content))
					how_many_request_entires = int(how_many_request_entires) - 1
					continue

				# UPDATE SAVED JOURNAL TIMER
				write_file("env/recent_journal_request.txt", str(request_time_edited))
				print_function('JOURNAL - PROCESSED REQUEST: ' + str(request_content))
				how_many_request_entires = int(how_many_request_entires) - 1
			print_function('JOURNAL - PROCESSED ALL REQUESTS')

		# END OF ALL JOURNAL STUFF
		if 'In-Jail' in str(running_thread[4]):
			element_click(lock_webdriver, 'XPATH', ".//*[@class='income']", running_thread)
		else:
			open_city(lock_webdriver, running_thread)

			if globals()['illness_found']:
				element_click(lock_webdriver, 'XPATH', ".//*[@class='business hospital']", running_thread)
				if element_found(lock_webdriver, "XPATH", ".//*[@class='links']/table/tbody/tr[2]/td[3]/a"):
					element_click(lock_webdriver, 'XPATH', ".//*[@class='links']/table/tbody/tr[2]/td[3]/a", running_thread)
					if element_found(lock_webdriver, "XPATH", ".//*[@id='holder_content']/table/tbody/tr[5]/td[2]/select"):
						select_dropdown_option(lock_webdriver, "XPATH", ".//*[@id='holder_content']/table/tbody/tr[5]/td[2]/select", "Yes")
						element_click(lock_webdriver, 'XPATH', ".//*[@id='holder_content']/table/tbody/tr[7]/td[2]/input", running_thread)
						print_function('JOURNAL - FLU - APPLIED FOR CURE')
				else:
					print_function('JOURNAL - FLU - HOSPITAL TORCHED?')

		if buy_drugs:
			# CLICK HERE
			driver.get("https://mafiamatrix.com/income/drugtrade.asp")

			while True:
				# CHECK TABLE
				if element_found(lock_webdriver, "XPATH", ".//*[@class='viewbutton_small']"):
					# DRUGS AVAILABLE - CLICK VIEW
					element_click(lock_webdriver, 'XPATH', ".//*[@class='viewbutton_small']", running_thread)

					drugs_table = element_get_attribute(lock_webdriver, "XPATH",
														".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']",
														"innerHTML")
					drugs_list = []
					cocaine_count = 0
					heroin_count = 0
					weed_count = 0
					for line in drugs_table.splitlines():
						if 'item_content' in line:
							if drugs_list[0] == 'cocaine':
								cocaine_count = line
								cocaine_count = regex_match_between('>', '<', cocaine_count)
								cocaine_count = re.sub('[^0-9]', "", cocaine_count)
							elif drugs_list[0] == 'heroin':
								heroin_count = line
								heroin_count = regex_match_between('>', '<', heroin_count)
								heroin_count = re.sub('[^0-9]', "", heroin_count)
							elif drugs_list[0] == 'weed':
								weed_count = line
								weed_count = regex_match_between('>', '<', weed_count)
								weed_count = re.sub('[^0-9]', "", weed_count)
							drugs_list.pop(0)
						elif '.gif' in line:
							if 'cocaine' in line:
								drugs_list.append('cocaine')
							elif 'heroin' in line:
								drugs_list.append('heroin')
							elif 'marijuana' in line:
								drugs_list.append('weed')
							else:
								drugs_list.append('junkdrugs')
						elif 'color="#ccc">' in line:
							price = line
							price = regex_match_between('>', '<', price)
							price = re.sub('[^0-9]', "", price)

					coke_value = int(cocaine_count) * int(config['Drugs']['CokePrice'])
					heroin_value = int(heroin_count) * int(config['Drugs']['HeroinPrice'])
					weed_value = int(weed_count) * int(config['Drugs']['WeedPrice'])
					total_value = int(coke_value) + int(heroin_value) + int(weed_value)
					print_function('coke: ' + str(cocaine_count) + 'coke value: ' + str(coke_value) + ' heroin: ' + str(heroin_count) + ' heroin value: ' + str(heroin_value) + ' weed: ' + str(weed_count) + ' weed value: ' + str(weed_value) + ' total value: ' + str(total_value) + ' price: ' + str(price))
					if ( (int(total_value) >= int(price) ) or (int(total_value) == 1) ):
						dirty_money = get_dirty_money(lock_webdriver)

						if config.getboolean('Drugs', 'BuyWithClean'):
							clean_money = get_your_clean_money(lock_webdriver)
						else:
							clean_money = 0

						if (int(dirty_money) >= int(price)) or (int(price) <= 1000) or (int(clean_money) >= int(price)):
							element_click(lock_webdriver, 'XPATH', ".//*[@class='acceptbutton']", running_thread)
							discord_message(config['Auth']['discord_id'] + str(
								your_character_name) + " BOUGHT DRUGS - COKE: " + str(
								cocaine_count) + " HEROIN: " + str(heroin_count) + " WEED: " + str(
								weed_count) + " VALUE: " + str(total_value) + " COST: " + str(
								price))
						else:
							discord_message(config['Auth']['discord_id'] + str(
								your_character_name) + " CANNOT AFFORD DRUGS - COKE: " + str(
								cocaine_count) + " HEROIN: " + str(heroin_count) + " WEED: " + str(
								weed_count) + " VALUE: " + str(total_value) + " COST: " + str(
								price) + " DIRTYMONEY: " + str(dirty_money))
					else:
						discord_message(config['Auth']['discord_id'] + str(
							your_character_name) + " DECLINED DRUGS AS TOO EXPENSIVE - COKE: " + str(
							cocaine_count) + " HEROIN: " + str(heroin_count) + " WEED: " + str(
							weed_count) + " VALUE: " + str(total_value) + " COST: " + str(
							price))
						element_click(lock_webdriver, 'XPATH', ".//*[@class='declinebutton']", running_thread)
				else:
					print_function('DRUGS - NO OFFERS REMAIN')
					break

		if globals()['relog']:
			print_function('JOURNAL - LOGOUT. LIKELY DUE TO SECRET UNLOCKED')
			driver.get("https://mafiamatrix.com/default.asp?action=logout")
			running_thread[1] = datetime.datetime.utcnow()

		thread_remove_from_queue(running_thread, waiting_thread_list)
	return
