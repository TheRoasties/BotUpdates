from globalvars import *
from code_modules.function import *

def drugwork(lock_webdriver, running_thread, waiting_thread_list):
	if config.getboolean('Action', 'DrugWork'):
		if globals()['timers'].__dict__['drugwork_timer'] is None:
			globals()['timers'].__dict__['drugwork_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=1)

		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['drugwork_timer']
		if not '-' in str(time_difference):
				print_function('ACTION - DRUGWORK - ADDED TO QUEUE')
				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)

				go_to_page(lock_webdriver, "Manufacture_Drugs", running_thread)

				dropdown = get_dropdown_options(lock_webdriver, "XPATH",
												".//*[@id='holder_content']/form/select")

				if "Yes, I want to work at the drug house" in dropdown:
					select_dropdown_option(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/select", "Yes, I want to work at the drug house")
					element_click(lock_webdriver, "XPATH", ".//*[@id='study_holder']/div[@id='holder_content']/form/input", running_thread)

					if element_found(lock_webdriver, "ID", "fail"):
						results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
						if 'manufacture at this point in time' in results:
							import random
							random = random.randrange(39, 62)
							# SET RANDOM TIME FOR NEXT DRUGWORK CHECK
							globals()['timers'].__dict__['drugwork_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random)

				print_function('ACTION - DRUGWORK - FINISHED')
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return True
	return False