from globalvars import *
from code_modules.function import *

def pay_tribute(lock_webdriver, running_thread, waiting_thread_list, dirty_money):
	if int(dirty_money) >= 50000:
		if 'Tribute' in str(running_thread[3]):
			tribute_timer = read_file("env/pay_tribute.txt")
			tribute_timer = datetime.datetime.strptime(tribute_timer, '%Y-%m-%d %H:%M:%S.%f')
			time_difference = datetime.datetime.utcnow() - tribute_timer
			if not '-' in str(time_difference):
				print_function('ACTION - PAY TRIBUTE - ADDED TO QUEUE')
				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)
				print_function('ACTION - PAY TRIBUTE - RUNNING')

				if go_to_page(lock_webdriver, "PayTribute", running_thread):
					pass
				else:
					unlocked_aggs_list = running_thread[3]
					try:
						unlocked_aggs_list.remove('Tribute')
					except:
						pass
					running_thread[3] = unlocked_aggs_list
					write_file("env/agg_unlocks.txt", running_thread[3])

					print_function('Tribute - NOT UNLOCKED', "RED")
					return

				tribute_results = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form", "innerHTML")
				tribute_amount = regex_match_between('\$', ' every ', tribute_results)
				tribute_amount = re.sub('[^0-9]', "", tribute_amount)

				if int(dirty_money) >= int(tribute_amount):
					# PAY TRIBUTE
					dropdown = get_dropdown_options(lock_webdriver, "XPATH",
													".//*[@id='earns_holder']/div[@id='holder_content']/form/p[2]/select[@class='dropdown']")

					if "Yes" in dropdown:
						select_dropdown_option(lock_webdriver, "XPATH",
											   ".//*[@id='earns_holder']/div[@id='holder_content']/form/p[2]/select[@class='dropdown']",
											   "Yes")
						element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)

					# UPDATE TIMER FOR NEXT CHECK - 24 to 27 hours
					random_timer = random.randrange(1456, 1623)
					write_file("env/pay_tribute.txt", str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
				else:
					# CANNOT AFFORD
					print_function('ACTION - PAY TRIBUTE - CANNOT AFFORD - RECHECK LATER')
					random_timer = random.randrange(42, 57)
					write_file("env/pay_tribute.txt", str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return False

				print_function('ACTION - PAY TRIBUTE - FINISHED')
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return True
	return False