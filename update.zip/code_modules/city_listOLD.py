'''
from globalvars import *
from code_modules.function import *

def city_list_record(lock_webdriver, running_thread, waiting_thread_list, next_citylist_timer, citylist_locked_until):
	# CHECK TIMER
	citylist_time_difference = (datetime.datetime.utcnow() - next_citylist_timer)
	if not '-' in str(citylist_time_difference):
		locked_time_difference = (datetime.datetime.utcnow() - citylist_locked_until)
		print_function("CITYLIST - PASSED TIMER 1")
		if not '-' in str(locked_time_difference):
			print_function("CITYLIST - PASSED TIMER 2")
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_onlinelist)
			print_function('CITYLIST - START')
			write_file("env/Aggs_Thread_Log.txt", "CITY LIST - START")

			# SET LOCKEDTIME NOW + 3MINS - TO PREVENT MULTIPLE PEOPLE ATTEMPTING THE SAME UPDATE
			my_cached_lockeduntil = datetime.datetime.utcnow() + datetime.timedelta(minutes=3)
			update_database('Timers', 'Timer', 'CityList', {"LockedUntil": str(my_cached_lockeduntil)})

			# GET EXISTING PLAYER CLOUD DATABASE
			player_database = get_from_database('Player', None)
			print_function("PLAYER DATABASE:" + str(player_database), "BLUE")

			driver.get("https://mafiamatrix.com/skin/updateusers.php?q=1")

			online_list_raw = element_get_attribute(lock_webdriver, "XPATH", ".//html/body/pre", "innerHTML")
			write_file("env/Aggs_Thread_Log.txt", "CITY LIST - ONLINE LIST RAW " + str(online_list_raw))

			online_list_raw_split = online_list_raw.split("}")
			player_bulk_update_list = []
			bulk_moved_city_string = ""
			bulk_new_name_string = ""
			for player_raw in online_list_raw_split:
				if 'userName' in player_raw:
					character_name = regex_match_between('"userName":"', '"', player_raw)
					character_homecity = regex_match_between('"userHomeCity":"', '"', player_raw)
					character_homecity = re.sub('[^a-zA-Z0-9]', "", character_homecity)
					character_rank = regex_match_between('"userRank":"', '"', player_raw)
					character_rank = re.sub('[^a-zA-Z0-9]', "", character_rank)
					character_occupation = regex_match_between('"userOccupation":"', '"', player_raw)
					character_occupation = re.sub('[^a-zA-Z0-9]', "", character_occupation)
					write_file("env/Aggs_Thread_Log.txt", "CITY LIST - NAME " + str(character_name) + " " + str(character_homecity) + " " + str(character_rank) + " " + str(character_occupation))


					# CHECK CACHED CLOUD DATABASE
					global new_name
					new_name = True
					item_count = (len(player_database['Items']) - 1)
					while item_count >= 0:
						database_player_name = player_database['Items'][item_count]['PlayerName']
						if character_name == database_player_name:
							new_name = False
							try:
								database_homecity = player_database['Items'][item_count]['HomeCity']
							except:
								database_homecity = ""
							try:
								database_occupation = player_database['Items'][item_count]['Occupation']
							except:
								database_occupation = ""
							try:
								database_rank = player_database['Items'][item_count]['Player_Rank']
							except:
								database_rank = ""
							try:
								database_status = player_database['Items'][item_count]['AliveStatus']
							except:
								database_status = ""

							if character_homecity == "Locked":
								if ( (database_occupation == character_occupation) and (database_rank == character_rank) and (database_status == 'Locked') ):
									print_function("CITYLIST - EXISTING LOCKED NAME UP TO DATE: " + str(character_name), "BLUE")
								else:
									# BULK METHOD - UPDATE EXISTING NAME
									if any(character_name in sublist for sublist in player_bulk_update_list):
										discord_error("UPDATE NAME DUPLICATE: " + str(character_name))
									else:
										this_player_list = ['PlayerName', character_name, 'AliveStatus', 'Locked', 'Player_Rank', character_rank, 'Occupation', character_occupation, 'UpdatedBy', 'Citylist-UpdateExistingLocked']
										for item_key in player_database['Items'][item_count]:
											if item_key in this_player_list:
												pass
											else:
												item_value = player_database['Items'][item_count][item_key]
												this_player_list.append(item_key)
												this_player_list.append(item_value)
										player_bulk_update_list.append(this_player_list)
										print_function("CITYLIST - UPDATED EXISTING NAME LOCKED: " + str(character_name), "BLUE")
							else:
								if ( (database_homecity == character_homecity) and (database_occupation == character_occupation) and (database_rank == character_rank) and (database_status == 'Alive') ):
									print_function("CITYLIST - EXISTING NAME UP TO DATE: " + str(character_name), "BLUE")
								else:
									# BULK METHOD
									if any(character_name in sublist for sublist in player_bulk_update_list):
										discord_error("UPDATE NAME DUPLICATE: " + str(character_name))
									else:
										this_player_list = ['PlayerName', character_name, 'AliveStatus', 'Alive', 'Player_Rank', character_rank, 'Occupation', character_occupation, 'HomeCity', character_homecity, 'UpdatedBy', 'Citylist-UpdateExisting']
										for item_key in player_database['Items'][item_count]:
											if item_key in this_player_list:
												pass
											else:
												item_value = player_database['Items'][item_count][item_key]
												this_player_list.append(item_key)
												this_player_list.append(item_value)
										player_bulk_update_list.append(this_player_list)
										print_function("CITYLIST - UPDATED EXISTING NAME: " + str(character_name), "BLUE")

									# SINGLE METHOD
									# update_database('Player', 'PlayerName', character_name, {"Player_Rank": character_rank, "Occupation": character_occupation, "HomeCity": character_homecity})

							player_database['Items'].pop(item_count)
							break
						item_count -= 1

					if new_name:
						database_homecity = ""
						database_occupation = ""
						database_rank = ""
						database_status = ""


					# UPDATE CLOUD DATABASE - BRAND NEW NAME
					if ( (character_homecity in globals()['cities_list']) or (character_homecity == 'Locked') ):
						if new_name:
							# BULK METHOD
							if any(character_name in sublist for sublist in player_bulk_update_list):
								discord_error("NEW NAME DUPLICATE: " + str(character_name))
							else:
								if (character_homecity == "Locked"):
									this_player_list = ['PlayerName', character_name, 'AliveStatus', 'Locked', 'Player_Rank', character_rank, 'Occupation', character_occupation,
														'HomeCity', character_homecity, 'Aggpro_Personal', str(datetime.datetime.utcnow()), 'Aggpro_BnE', str(datetime.datetime.utcnow()), 'Aggpro_Hack',
														str(datetime.datetime.utcnow()), 'FirstSeen', str(datetime.datetime.utcnow()), 'Hours', 1, 'UpdatedBy', 'Citylist-NewNameLocked']
									player_bulk_update_list.append(this_player_list)
								else:
									this_player_list = ['PlayerName', character_name, 'AliveStatus', 'Alive', 'Player_Rank', character_rank, 'Occupation', character_occupation, 'HomeCity', character_homecity, 'Aggpro_Personal', str(datetime.datetime.utcnow()), 'Aggpro_Hack', str(datetime.datetime.utcnow()), 'Aggpro_BnE', str(datetime.datetime.utcnow()), 'FirstSeen', str(datetime.datetime.utcnow()), 'Hours', 1, 'UpdatedBy', 'Citylist-NewName']
									player_bulk_update_list.append(this_player_list)

							# SINGLE METHOD
							#update_database('Player', 'PlayerName', character_name, {"Player_Rank": character_rank, "Occupation": character_occupation, "HomeCity": character_homecity, "Aggpro_Personal": str(datetime.datetime.utcnow()), "Aggpro_Hack": str(datetime.datetime.utcnow()), "FirstSeen": str(datetime.datetime.utcnow())})

							# UPDATE S3 - NEW NAMES RECORD
							bulk_new_name_string = bulk_new_name_string + '\r\nNew name ' + str(character_name) + ' with homecity ' + str(character_homecity) + ' on ' + str(datetime.datetime.utcnow()) + ' found via Citylist check'
							print_function("CITYLIST - ADDED NEW NAME: " + str(character_name), "BLUE")


					if ( (character_homecity in globals()['cities_list']) or (character_homecity == 'Locked') ):
						# ONLY LOOK AT PLAYERS WITH A VALID HOMECITY. THIS IS TO IGNORE ADMINS ETC
						print_function("NAME:" + str(character_name) + " HOMECITY:" + str(character_homecity) + " OCCUPATION:" + str(character_occupation) + " RANK:" + str(character_rank))

						# MOVED CITY CHECK
						if ( ( str(database_homecity) == str(character_homecity) ) or (new_name) or (character_homecity == 'Locked') ):
							pass
						else:
							# MOVED CITY - UPDATE S3
							print_function("CITYLIST - MOVED CITY - " + str(character_name) + ' FROM:' + str(database_homecity) + ' TO:' + str(character_homecity), "BLUE")
							bulk_moved_city_string = bulk_moved_city_string + '\r\n' + str(character_name) + ' moved HomeCity from ' + str(database_homecity) + ' to ' + str(character_homecity) + ' on ' + str(datetime.datetime.utcnow())

						# BOLD
						if ('Don' in str(character_rank)) or ('Boss' in str(character_rank)) or ('Capoditutticapi' in str(character_rank)) or ('Godfather' in str(character_rank)) or ('Godmother' in str(character_rank)):
							update_database('BoldList', 'PlayerName', str(character_name), None)
							print_function('CITYLIST - BOLD NAME - ' + str(character_name) + ' IS: ' + str(character_rank), "BLUE")


						# CAREER PROMO RECORDS
						if ((database_occupation == character_occupation) and (database_rank == character_rank) ):
							pass
						else:
							# UPDATE PROMO RECORDS - S3
							append_s3('roastbusters', 'PromoRecords/' + str(character_name) + '.txt', '\r\n' + str(character_name) + " - " + str(character_homecity) + " - " + str(character_occupation) + " - " + str(character_rank) + " - " + str(datetime.datetime.utcnow()))
							print_function('CITYLIST - ADDING PROMO RECORDS: ' + str(character_name) + " - " + str(character_homecity) + " - " + str(character_occupation) + " - " + str(character_rank), "BLUE")


			# CHECK NO DUPLICATE BEFORE UPDATE
			response = get_from_database('Timers', 'LockedUntil', "Key('Timer').eq('CityList')")
			citylist_locked_until = datetime.datetime.strptime(response['Items'][0]['LockedUntil'], '%Y-%m-%d %H:%M:%S.%f')
			if my_cached_lockeduntil == citylist_locked_until:
				# NO ONE ELSE HAS STARTED A CITYLIST UPDATE
				# BULK UPDATE CLOUD DATABASE

				# CHECK NAMES IN THE DATABASE BUT NOT CITYLIST SCREEN - THEY ARE ASSUMED DEAD
				item_count = (len(player_database['Items']) - 1)
				while item_count >= 0:
					remaining_player_name = player_database['Items'][item_count]['PlayerName']
					try:
						remaining_player_status = player_database['Items'][item_count]['AliveStatus']
					except:
						remaining_player_status = ""
					if remaining_player_status == 'Dead':
						# SKIP AS ALREADY DEAD
						pass
					else:
						print_function("CITYLIST - REMAINING DEAD NAME: " + str(remaining_player_name))

						this_player_list = ['PlayerName', remaining_player_name, 'AliveStatus', 'Dead', 'DeathTime', str(datetime.datetime.utcnow()), 'UpdatedBy', 'Citylist-Dead']
						for item_key in player_database['Items'][item_count]:
							if item_key in this_player_list:
								pass
							else:
								item_value = player_database['Items'][item_count][item_key]
								this_player_list.append(item_key)
								this_player_list.append(item_value)
						player_bulk_update_list.append(this_player_list)
						print_function("CITYLIST - UPDATED EXISTING NAME LOCKED: " + str(remaining_player_name), "BLUE")

					player_database['Items'].pop(item_count)
					item_count -= 1

				bulk_update_database('Player', player_bulk_update_list)

				# BULK UPDATE MOVED CITY
				if str(bulk_moved_city_string) != "":
					append_s3('roastbusters', 'MovedCity.txt', bulk_moved_city_string)
				print_function("MOVED CITY: " + str(bulk_moved_city_string), "RED")

				# BULK UPDATE NEW NAMES
				if str(bulk_new_name_string) != "":
					append_s3('roastbusters', 'NewNames.txt', bulk_new_name_string)
				print_function("NEW NAMES: " + str(bulk_new_name_string), "RED")
			else:
				# SOMEONE ELSE HAS TAKEN OVER. DO NOT UPDATE
				print_function("CITYLIST - SKIP UPDATE AS SOMEONE ELSE HAS STARTED", "RED")
				pass


			# UPDATE CITYLIST TIMER FOR NEXT CHECK - CLOUD
			random_timer = random.randrange(411, 832)
			print_function('CITYLIST - NEXT CHECK: ' + str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)))
			update_database('Timers', 'Timer', 'CityList', {"NextTimer": str(datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer))})

			go_back(lock_webdriver)
			print_function("CITYLIST - FINISHED - GO BACK", "BLUE")
			thread_remove_from_queue(running_thread, waiting_thread_list)
			write_file("env/Aggs_Thread_Log.txt", "CITY LIST - FINISHED")

			return True
	return False
'''