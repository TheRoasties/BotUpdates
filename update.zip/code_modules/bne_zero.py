from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

__all__ = ["check_bne_zero_target", "do_bne_zero_thread"]

def check_bne_zero_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, your_current_city, currentcity_bne_list, aggtarget_person_list_manager, bold_list):
	viable_bne_zero_targets = []

	for agg_target in currentcity_bne_list:
		write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BnEZero CHECKING TARGET: " + str(agg_target))

		if config.getboolean('BnE_Zero', 'Avoid_Bolds'):
			skip_this_name = False
			for bold_name_raw in bold_list['Items']:
				bold_name = bold_name_raw['PlayerName']
				if bold_name == agg_target:
					skip_this_name = True
					break

			if skip_this_name:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BnEZero TARGET: " + str(agg_target) + " SKIP AS BOLD")
				continue

		# AGGPRO - LOCAL
		try:
			aggpro_timer = aggtarget_person_list_manager[agg_target].get_local_aggpro_timer()
		except Exception as e:
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BnEZero TARGET: " + str(agg_target) + " BROKEN")
			write_file("env/Aggs_Thread_Log.txt", str(e))
			continue

		try:
			time_difference = datetime.datetime.utcnow() - aggpro_timer
		except:
			aggpro_timer = datetime.datetime.strptime(aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
			time_difference = datetime.datetime.utcnow() - aggpro_timer

		if not '-' in str(time_difference):
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BNEZero - " + str(agg_target) + " PASSED LOCAL AGGPRO")
			# AGGPRO - SHARED
			try:
				aggpro_timer = aggtarget_person_list_manager[agg_target].get_shared_aggpro_timer()
			except:
				aggpro_timer = datetime.datetime.utcnow()

			time_difference = datetime.datetime.utcnow() - aggpro_timer
			if not '-' in str(time_difference):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BNEZero - " + str(agg_target) + " PASSED SHARED AGGPRO")
				# AGGPRO - SHARED

				# CHECK NO HOUSE TIMER
				aggpro_timer = aggtarget_person_list_manager[agg_target].get_bne_timer()
				time_difference = datetime.datetime.utcnow() - aggpro_timer
				if not '-' in str(time_difference):
					viable_bne_zero_targets.append(agg_target)
					write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BNE-ZERO TARGET READY: " + str(agg_target) )
				else:
					write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BNE-ZERO SHARED AGGPRO: " + str(agg_target) )
			else:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BNE-ZERO LOCAL AGGPRO: " + str(agg_target) )

	if viable_bne_zero_targets == []:
		return
	else:
		print_function('viable bne zero targets - ' + str(viable_bne_zero_targets), "BLUE")
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - TARGETS: " + str(viable_bne_zero_targets))
		do_bne_zero(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_zero_targets, aggtarget_person_list_manager, your_current_city, your_character_name)
	return


def do_bne_zero(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_zero_targets, aggtarget_person_list_manager, your_current_city, your_character_name):
	thread_bne_zero = Process(target=do_bne_zero_thread, name='BnEZeroThread',
									args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_zero_targets, aggtarget_person_list_manager, your_current_city, your_character_name))
	thread_bne_zero.start()
	waiting_thread_list.append('9zAwaitingBnEZero')
	print_function(str(waiting_thread_list))

	# WAIT TILL THREAD STARTED
	print_function('BNE Zero - WAITING FOR THREAD TO BE RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - WAITING FOR THREAD TO BE RUNNING")
	while True:
		if 'bne' in str(waiting_thread_list):
			break
	print_function('BNE Zero - THREAD RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - THREAD RUNNING")
	return


def do_bne_zero_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_zero_targets, aggtarget_person_list_manager, your_current_city, your_character_name):
	try:
		import multiprocessing
		write_file("env/BnEZeroPID.txt", str(multiprocessing.current_process().pid))

		for thread in waiting_thread_list:
			if 'AwaitingBnEZero' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE ZERO QUEUED")
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_bne_zero_targets)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE ZERO STARTED")
		random_timer_haspro = random.randrange(590, 915)

		for target in viable_bne_zero_targets:
			# RETURN PRIORITY TO NORMAL
			running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]

			if your_character_name == target:
				continue

			if go_to_page(lock_webdriver, "BnE", running_thread):
				pass
			else:
				unlocked_aggs_list = running_thread[3]
				try:
					unlocked_aggs_list.remove('BnE')
				except:
					pass
				running_thread[3] = unlocked_aggs_list
				write_file("env/agg_unlocks.txt", running_thread[3])

				print_function('BnE - NOT UNLOCKED', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** BnE Zero - NOT UNLOCKED ****")
				return

			if 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** BnE ZERO - REQUIRES CS FIRST ****")
				return

			clearkeys(lock_webdriver, "NAME", "breaking")
			sendkeys(lock_webdriver, "NAME", "breaking", target)
			sendkeys(lock_webdriver, "NAME", "breaking", Keys.ESCAPE)

			# INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
			running_thread[0] = str('1') + inspect.stack()[0][3]
			click_continue(lock_webdriver, running_thread)

			# AGG DONE - GET RESULTS
			agg_results = None
			if element_found(lock_webdriver, "ID", "fail"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			elif element_found(lock_webdriver, "ID", "success"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			else:
				print_function('NO AGG RESULTS FOUND', "BLUE")
				print_function('NO AGG RESULTS FOUND', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - NO AGG RESULTS FOUND")
				continue

			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - RESULTS: " + str(agg_results))

			# AGG DONE - EXAMINE RESULTS
			if ("doesn't exist" in agg_results) or ("same city" in agg_results):
				print_function('BnE Zero Results - Target ' + str(target) + " Doesn't Exist", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - Target " + str(target) + " Doesn't Exist")
				random_timer = random.randrange(20, 25)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

			elif ('recently survived' in agg_results):
				print_function('BnE Zero Results - Target ' + str(target) + "has pro", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - Target " + str(target) + " has pro")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer_haspro)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				continue

			elif ('doesnt have' in agg_results):
				print_function('BnE Zero Results - Target ' + str(target) + " no house", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - Target " + str(target) + " no house")
				random_timer = random.randrange(24, 48)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)
				aggtarget_person_list_manager[target].set_bne_timer(agg_timer)
				continue

			elif ('failed' in agg_results) or ('ran off' in agg_results):
				print_function('BnE Zero Results - Target ' + str(target) + ' FAILED', "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - Target " + str(target) + " FAILED")
				last_agg_time[0] = datetime.datetime.utcnow()
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
				agg_timer = agg_timer + datetime.timedelta(minutes=10)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

				house = get_house_from_string(agg_results)
				if house != "NOTFOUND":
					aggtarget_person_list_manager[target].set_house(house)

				# ADD TO RECORDS
				append_file('./records/BnE.txt', "\nBnE Zero FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nBnE Zero FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE ZERO FINISHED")
				return


			elif ('managed to' in agg_results):
				repay = True
				print_function('BnE Zero Results - Target ' + str(target) + ' SUCCESS - AGG: ' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE Zero - Target " + str(target) + " SUCCESS")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
				agg_timer = agg_timer + datetime.timedelta(minutes=10)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

				house = get_house_from_string(agg_results)
				if house != "NOTFOUND":
					aggtarget_person_list_manager[target].set_house(house)

				# ADD TO RECORDS
				append_file('./records/BnE.txt', "\nBnE Zero SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nBnE Zero SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# TOOK DRUGS
				if 'helped' in agg_results:
					if config.getboolean('BnE_Zero', 'Discord_Notify_Drugs'):
						discord_message(config['Auth']['discord_id'] + "BNE Zero TOOK DRUGS: " + agg_results)

				# TOOK WEAPON
				# You managed to break-into chadwick_is_dead`s Flat and after turning the place up, found yourself $0! You also managed to find a Colt .45 Revolver (30/30) - after tearing the place apart!
				if 'also' in agg_results:
					if 'to find a' in agg_results:
						which_weapon_taken = regex_match_between('to find a ', ' \(', agg_results)
					else:
						which_weapon_taken = regex_match_between('to find ', ' \(', agg_results)
					weapon_durability = regex_match_between('\(', '\)', agg_results)
					print_function('weapon: ' + str(which_weapon_taken) + ' durability: ' + str(weapon_durability) + ' target: ' + str(target))

					if config.getboolean('BnE_Weapon_Found', 'Discord_Notify_Weapon'):
						discord_message(config['Auth']['discord_id'] + "BNE Zero TOOK WEAPON: " + agg_results)

					whitelist_return_weapon = False
					repay_whitelist = config['BnE']['Repay_Whitelist'].split()
					for whitelist_name in repay_whitelist:
						if target == whitelist_name:
							print_function('BnE - Return Weapon - TARGET IS WHITELISTED: ' + str(target), "BLUE")
							whitelist_return_weapon = True

					if whitelist_return_weapon:
						print_function('BnE Zero - Return Weapon - TARGET IS WHITELISTED: ' + str(target), "BLUE")
						waiting_thread_list.append('9zSellItem//' + str(which_weapon_taken) + '//' + str(target) + '//1')
						discord_message(
							config['Auth']['discord_id'] + "RETURNING " + str(which_weapon_taken) + " AS TARGET " + str(
								target) + " IS IN WHITELIST")
					else:
						if config.getboolean('BnE_Weapon_Found', 'Return_Items'):
							print_function('BnE Zero - Return Weapon - return items TRUE: ' + str(target), "BLUE")
							return_weapon_found = False
							if config['BnE_Weapon_Found']['Items_To_Return'] == '':
								config['BnE_Weapon_Found']['Items_To_Return'] = 'None'
							for item in config['BnE_Weapon_Found']['Items_To_Return'].split():
								if (item in which_weapon_taken) or (which_weapon_taken in item) or (item == 'All'):
									return_weapon_found = True

							if return_weapon_found:
								waiting_thread_list.append('9zSellItem//' + str(which_weapon_taken) + '//' + str(target) + '//1')
								print_function('BnE Zero - Return Weapon - RETURNING WEAPON TO: ' + str(target), "BLUE")
								print_function('9zSellItem THREAD QUEUED' + str(waiting_thread_list), "GREEN")
								# UPDATE TEXT BACKUP
								write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
								if config.getboolean('BnE_Weapon_Found', 'Discord_Notify_Weapon'):
									discord_message(config['Auth']['discord_id'] + "BNE ZERO RETURNING WEAPON: " + str(which_weapon_taken) + " TO: " + str(target))
							else:
								print_function('BnE Zero - Return Weapon - KEEPING WEAPON FROM: ' + str(target), "BLUE")
								repay = False
								discord_message(config['Auth']['discord_id'] + "KEEPING " + str(which_weapon_taken) + " AS IT IS NOT IN RETURN LIST - TV: " + config['Auth']['teamviewer_details'])
						else:
							print_function('BnE Zero - Return Weapon - return items FALSE: ' + str(target), "BLUE")
							repay = False
							discord_message(config['Auth']['discord_id'] + "KEEPING " + str(which_weapon_taken) + " AS RETURN ITEMS TURNED OFF - TV: " + config['Auth']['teamviewer_details'])

				# UPDATE SHARED ALL AGGS RECORDS
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.utcnow().year) + '-' + str(datetime.datetime.utcnow().month) + '-' + str(datetime.datetime.utcnow().day) + '.txt', "\r\n" + str(your_character_name) + " BnEZero " + str(target) + " (Success) in " + str(globals()[your_current_city].which_city) + " on " + str(datetime.datetime.utcnow()))

				# REPAY CHECKS
				if not config.getboolean('BnE_Zero', 'Repay'):
					print_function('BnE Zero - Repay - TURNED OFF', "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - Repay - TURNED OFF")
					repay = False

				repay_blacklist = config['BnE_Zero']['Repay_Blacklist'].split()
				for blacklist_name in repay_blacklist:
					if target == blacklist_name:
						print_function('BnE Zero - Repay - TARGET IS BLACKLISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE Zero - Repay - TARGET IS BLACKLISTED: " + str(target))
						repay = False

				repay_whitelist = config['BnE_Zero']['Repay_Whitelist'].split()
				for whitelist_name in repay_whitelist:
					if target == whitelist_name:
						print_function('BnE Zero - Repay - TARGET IS WHITELISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE Zero - Repay - TARGET IS WHITELISTED: " + str(target))
						repay = True

				if repay:
					repay_amount = regex_match_between('yourself', '!', agg_results)
					repay_amount = re.sub('[^0-9]', "", repay_amount)

					print_function('BnE Zero - Repaying ' + str(repay_amount) + ' TO ' + str(target), "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE Zero - Repaying " + str(repay_amount) + " TO " + str(target))
					# ADD REPAY TO RECORDS
					append_file('./records/BnE.txt', "\n BnE Zero - Repaying " + repay_amount + " TO " + target)
					append_file('./records/AllAggs.txt', "\n BnE Zero - Repaying " + repay_amount + " TO " + target)

					if int(repay_amount) > 0:
						transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target)

						# WAIT FOR TRANSFER TO BE QUEUED
						print_function('BnE Zero - Waiting for repay to be queued', "BLUE")
						while True:
							if 'transfer_money_thread' in str(waiting_thread_list):
								break
						print_function('BnE Zero - repay is queued', "BLUE")

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE ZERO FINISHED")
				return

			else:
				print_function('BnE Zero - results not found' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE Zero - results not found" + str(agg_results))
				continue

		thread_remove_from_queue(running_thread, waiting_thread_list)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE ZERO FINISHED")
		return
	except:
		from code_modules.function import PrintException
		PrintException()
