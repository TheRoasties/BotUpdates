from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

__all__ = ["get_engineer_lists", "check_engineer_online", "check_torch_target", "do_torch_thread"]

def get_engineer_lists(lock_webdriver, running_thread, waiting_thread_list):
	time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['torch_engi_list_timer']
	if not '-' in str(time_difference):
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg)
		# MAKE ENGINEER LISTS
		for this_city in cities_list:
			globals()['engineer_list_' + this_city] = []

		open_city(lock_webdriver, running_thread)
		element_click(lock_webdriver, "XPATH", ".//*[@class='business yellow_pages']", running_thread)
		element_click(lock_webdriver, "XPATH",".//*[@id='content']/center/div/div[2]/table[2]/tbody/tr[2]/td[@class='display_border'][5]/form", running_thread)
		yellowpages_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='wrapper']/div[@id='content']/center/div/div[2]/table", "innerHTML")
		yellowpages_table_split = yellowpages_table.split('<tr>')
		for row in yellowpages_table_split:
			if 'userprofile.asp' in row:
				name = row.splitlines()[2]
				name = regex_match_between('>', '<', name)
				occupation = row.splitlines()[5].strip()
				rank = row.splitlines()[8].strip()
				city = row.splitlines()[11].strip()
				city = city.replace(" ", "")
				if (city in globals()['cities_list']) and (occupation != 'Mechanic'):
					globals()['engineer_list_' + city].append(name)
				print_function('name: ' + str(name) + ' occupation: ' + str(occupation) + ' rank: ' + str(rank) + ' city: ' + str(city))
		thread_remove_from_queue(running_thread, waiting_thread_list)
		globals()['timers'].__dict__['torch_engi_list_timer'] = (datetime.datetime.utcnow() + datetime.timedelta(hours=3))
	return


def check_engineer_online(lock_webdriver, running_thread, waiting_thread_list, current_city):
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg)
	# GET LOCAL ONLINE LIST. CHECK IF IT INCLUDES ENGINEER NAME FOR THE CURRENTCITY
	while True:
		online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
		if '|' in online_player_list_raw:
			break

	is_local_list_only = True
	if '*' in online_player_list_raw:
		is_local_list_only = False

	engineer_online_string = ''

	online_player_list_raw_split = online_player_list_raw.split("|")
	for player_raw in online_player_list_raw_split:
		if (':Alive:player:' in player_raw) and (is_local_list_only or ('*' in player_raw)):
			player_name = regex_match_between('>', '<', player_raw)
			if player_name in globals()['engineer_list_' + current_city]:
				# CLICK NAME IN ONLINE LIST
				element_click(lock_webdriver, "XPATH", "//*[@id='profileLink:" + str(player_name) + ":Alive:player:']", running_thread)

				while True:
					if element_found(lock_webdriver, "XPATH", ".//*[@id='quickprofile']/div[@id='user_popup']/div[@class='user_details']/table/tbody/tr/td[1]"):
						person_details_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='quickprofile']/div[@id='user_popup']/div[@class='user_details']/table/tbody/tr/td[1]", "innerHTML")
						if player_name in person_details_table:
							break

				occupation = regex_match_between('"occupationSpan">', '<', person_details_table)
				occupation = occupation.strip()
				rank = regex_match_between('rankSpan">', '<', person_details_table)
				rank = rank.strip()
				homecity = regex_match_between('homecitySpan">', '<', person_details_table)
				homecity = homecity.strip()
				activity = regex_match_between('lastactivitySpan">', '<', person_details_table)
				activity = activity.strip()
				print_function('name:' + str(player_name) + ' occupation: ' + str(occupation) + ' rank: ' + str(rank) + ' homecity: ' + str(homecity) + ' activity: ' + str(activity))
				if ((occupation == 'Technician') or (occupation == 'Engineer') or (occupation == 'Chief Engineer')) and ( (activity == 'less than a minute ago') or (activity == '1 minute ago') or (activity == '2 minutes ago') or (activity == '3 minutes ago') or (activity == '5 minutes ago')):
					engineer_online_string = str(engineer_online_string) + "|" + player_name + ", " + occupation + ", " + rank + ", " + homecity + ", " + activity
	thread_remove_from_queue(running_thread, waiting_thread_list)
	globals()['timers'].__dict__['torch_engi_online_timer'] = (datetime.datetime.utcnow() + datetime.timedelta(minutes=5))
	return engineer_online_string


def check_torch_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name):
	viable_torch_targets = []
	business_list = globals()['public_businesses'] + globals()['private_businesses_' + your_current_city]

	aggstr_minutes_needed = config['Torch']['StartingMinutesRequired']

	# GET MODIFIED AGGSTR
	if os.path.isfile('./agg_targets/torch/' + your_current_city + '.txt'):
		mins_adjusted = int(read_file('./agg_targets/torch/' + your_current_city + '.txt'))
	else:
		mins_adjusted = 0

	aggstr_minutes_needed = int(aggstr_minutes_needed) + int(mins_adjusted)
	if aggstr_minutes_needed > 30:
		aggstr_minutes_needed = 30
	elif aggstr_minutes_needed < 3:
		aggstr_minutes_needed = 3

	# CHECK ENOUGH AGGSTR
	if int(aggstr_mins_max) >= int(aggstr_minutes_needed):
		 # SUFFICIENT AGGSTRENGTH
		 if 'Torch|AR' in running_thread[4]:
			 pass
		 else:
			 variables_list = running_thread[4]
			 variables_list.append('Torch|AR')
			 running_thread[4] = variables_list
			 print_function('UPDATED VARIABLES - NOT GO BELOW TORCH/AR')
			 write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " UPDATED VARIABLES - NOT GO BELOW TORCH/AR")
	else:
		# NOT ENOUGH AGGSTRENGTH
		return


	# AVOID BLACKLIST TARGETS
	for business in business_list:
		# CANNOT TORCH FIRE STATION :)
		if 'Fire' in business:
			continue

		# WHITELIST
		whitelist = config['Torch']['Torch_Whitelist_' + your_current_city].split()
		whitelist_item_found = False
		for item in whitelist:
			if item in business:
				whitelist_item_found = True

			if 'PRIVATE' in whitelist:
				if item in globals()['private_businesses_' + your_current_city]:
					whitelist_item_found = True

			if 'PUBLIC' in whitelist:
				if item in globals()['public_businesses']:
					whitelist_item_found = True

		if whitelist_item_found:
			# WHITELIST OVERRIDES BLACKLIST
			pass
		else:
			# BLACKLIST
			blacklist = config['Torch']['Torch_Blacklist_' + your_current_city].split()

			if 'PRIVATE' in blacklist:
				if business in globals()['private_businesses_' + your_current_city]:
					continue

			if 'PUBLIC' in blacklist:
				if business in globals()['public_businesses']:
					continue

			blacklist_item_found = False
			for item in blacklist:
				if item in business:
					blacklist_item_found = True
					break
			if blacklist_item_found:
				continue

		# AGGPRO - LOCAL
		try:
			aggpro_timer = aggtarget_business_list_manager[your_current_city].get_local_aggpro_timer(business)
		except:
			aggpro_timer = datetime.datetime.utcnow()

		try:
			time_difference = datetime.datetime.utcnow() - aggpro_timer
		except:
			continue

		if not '-' in str(time_difference):
			# AGGPRO - SHARED
			try:
				aggpro_timer = aggtarget_business_list_manager[your_current_city].get_shared_aggpro_timer(business)
			except:
				aggpro_timer = datetime.datetime.utcnow()

			try:
				time_difference = datetime.datetime.utcnow() - aggpro_timer
			except:
				continue

			if not '-' in str(time_difference):
				# AGGPRO - SHARED
				viable_torch_targets.append(business)
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - TORCH - VIABLE TARGET " + str(business))
			else:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - TORCH - TARGET HAS SHARED AGGPRO " + str(business))
		else:
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - TORCH - TARGET HAS LOCAL AGGPRO " + str(business))

	if viable_torch_targets == []:
		pass
	else:
		if config.getboolean('Torch', 'Engineer_Needed_Online'):
			get_engineer_lists(lock_webdriver, running_thread, waiting_thread_list)
			time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['torch_engi_online_timer']
			if not '-' in str(time_difference):
				globals()['engineer_list'] = check_engineer_online(lock_webdriver, running_thread, waiting_thread_list, your_current_city)

			# REMOVE TARGETS THAT NEED AN ENGI IF NONE ONLINE
			if globals()['engineer_list'] == '':
				for biz_need_engi in config['Torch']['Business_Need_Engineer'].split():
					biz_need_engi.strip()
					for torch_target in viable_torch_targets:
						torch_target.strip()
						if (biz_need_engi in torch_target) or (torch_target in biz_need_engi):
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "TORCH - REMOVING TARGET " + str(torch_target) + " AS NO ENGINEER ONLINE")
							try:
								viable_torch_targets.remove(torch_target)
							except:
								pass
							# breaks inner loop. no need to check the rest once found
							break
				# NO VIABLE TARGETS REMAINING
				if viable_torch_targets == []:
					return
		else:
			globals()['engineer_list'] = ''

		# TERMINATE LESSER PRIORITY AGGS - ARMEDROBBERY
		if 'do_armedrobbery_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY ARMEDROBBERY
				return

		if 'do_armedrobbery_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - REQUESTED TERMINATE ARMEDROBBERY")
			waiting_thread_list.append('9zterminate_do_armedrobbery_thread')
			print_function('9zterminate_do_armedrobbery_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_armedrobbery_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - TERMINATED ARMEDROBBERY")
					break
			# TERMINATED ARMEDROBBERY

		# TERMINATE LESSER PRIORITY AGGS - HACK
		if 'do_hack_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY HACK
				return

		if 'do_hack_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - REQUESTED TERMINATE HACK")
			waiting_thread_list.append('9zterminate_do_hack_thread')
			print_function('9zterminate_do_hack_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_hack_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - TERMINATED HACK")
					break
			# TERMINATED HACK

		# TERMINATE LESSER PRIORITY AGGS - BNE
		if 'do_bne_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY BNE
				return

		if 'do_bne_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - REQUESTED TERMINATE BNE")
			waiting_thread_list.append('9zterminate_do_bne_thread')
			print_function('9zterminate_do_bne_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_bne_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - TERMINATED BNE")
					break
			# TERMINATED BNE

		# TERMINATE LESSER PRIORITY AGGS - MUG
		if 'do_mug_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY MUG
				return

		if 'do_mug_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - REQUESTED TERMINATE MUG")
			waiting_thread_list.append('9zterminate_do_mug_thread')
			print_function('9zterminate_do_mug_thread THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_mug_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - TERMINATED MUG")
					break
			# TERMINATED MUG

		# TERMINATE LESSER PRIORITY AGGS - PICKPOCKET
		if 'do_pickpocket_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY PICKPOCKET
				return

		if 'do_pickpocket_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - REQUESTED TERMINATE PICKPOCKET")
			waiting_thread_list.append('9zterminate_do_pickpocket_thread')
			print_function('9zterminate_do_pickpocket_thread THREAD QUEUED' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_pickpocket_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TORCH - TERMINATED PICKPOCKET")
					break
			# TERMINATED PICKPOCKET

		print_function('viable torch targets - ' + str(viable_torch_targets), "BLUE")
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t TORCH - VIABLE TARGETS " + str(viable_torch_targets))

		if 'AggstrLowest' in str(waiting_thread_list):
			pass
		else:
			waiting_thread_list.append('9zAggstrLowest' + str(aggstr_min_checking))
			print_function('9zAggstrLowest' + str(aggstr_min_checking) + ' THREAD QUEUED ' + str(waiting_thread_list), "GREEN")

		do_torch(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_torch_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name, globals()['engineer_list'])
	return


def do_torch(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_torch_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name, engineer_list):
	thread_torch = Process(target=do_torch_thread, name='TorchThread', args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_torch_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name, engineer_list))

	thread_torch.start()
	waiting_thread_list.append('9zAwaitingTorch')
	print_function(waiting_thread_list)

	# WAIT TILL THREAD STARTED
	print_function('Torch - WAITING FOR THREAD TO BE RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - WAITING FOR THREAD TO BE RUNNING")
	while True:
		if 'torch' in str(waiting_thread_list):
			break
	print_function('Torch - THREAD RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - THREAD RUNNING")
	return


def do_torch_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_torch_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name, engineer_list):
	try:
		import multiprocessing
		write_file("env/TorchPID.txt", str(multiprocessing.current_process().pid))

		for thread in waiting_thread_list:
			if 'AwaitingTorch' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t TORCH QUEUED")
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_torch_targets)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t TORCH STARTED")
		random_timer = random.randrange(590, 915)

		for target in viable_torch_targets:
			# RETURN PRIORITY TO NORMAL
			running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]

			if go_to_page(lock_webdriver, "Torch", running_thread):
				pass
			else:
				unlocked_aggs_list = running_thread[3]
				try:
					unlocked_aggs_list.remove('Torch')
				except:
					pass
				running_thread[3] = unlocked_aggs_list
				write_file("env/agg_unlocks.txt", running_thread[3])

				print_function('Torch - NOT UNLOCKED', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** Torch - NOT UNLOCKED ****")
				return

			if 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** TORCH - REQUIRES CS FIRST ****")
				return

			# ENTER DROPDOWN OPTION OF TARGET
			dropdown = get_dropdown_options(lock_webdriver, "XPATH", ".//*[@id='earns_holder']/div[@id='holder_content']/form/p[2]/select[@class='dropdown']")
			if target in dropdown:
				pass
			else:
				print_function('TORCH TARGET NOT IN DROPDOWN: ' + str(target), "RED")
				continue

			# GET THE TARGET FROM THE DROPDOWN LIST. ITS DONE THIS WAY TO ACCOUNT FOR WEIRD WORDING LIKE BANK TILLS
			continue_outer_loop = False
			for line in dropdown.splitlines():
				if target in line:
					if config.getboolean('Torch', 'RequireAsterisk'):
						if '*' in line:
							pass
						else:
							print_function('Torch Results - Target ' + str(target) + " in " + str(your_current_city) + " NO ASTERISK", "BLUE")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Target " + str(target) + " in " + str(your_current_city) + " NO ASTERISK")
							agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
							aggtarget_business_list_manager[your_current_city].set_local_aggpro_timer(target, agg_timer)
							continue_outer_loop = True
					target_dropdown = line.strip()
					break
			if continue_outer_loop:
				continue
			
			select_dropdown_option(lock_webdriver, "XPATH", ".//*[@id='earns_holder']/div[@id='holder_content']/form/p[2]/select[@class='dropdown']", target_dropdown)

			# INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
			running_thread[0] = str('1') + inspect.stack()[0][3]
			click_continue(lock_webdriver, running_thread)

			# AGG DONE - GET RESULTS
			agg_results = None
			if element_found(lock_webdriver, "ID", "fail"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			elif element_found(lock_webdriver, "ID", "success"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			else:
				print_function('NO AGG RESULTS FOUND', "BLUE")
				print_function('NO AGG RESULTS FOUND', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t TORCH - NO AGG RESULTS FOUND")
				continue

			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t TORCH - RESULTS: " + str(agg_results))

			# AGG DONE - EXAMINE RESULTS
			if ('recently survived' in agg_results) or ('not yet repaired' in agg_results):
				print_function('Torch Results - Target ' + str(target) + " in " + str(your_current_city) + " has pro", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Target " + str(target) + " in " + str(your_current_city) + " has pro")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
				aggtarget_business_list_manager[your_current_city].set_local_aggpro_timer(target, agg_timer)
				continue

			elif ('own business' in agg_results):
				print_function('Torch Results - Target ' + str(target) + " in " + str(your_current_city) + " your own biz" + "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Target " + str(target) + " in " + str(your_current_city) + " your own biz")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(days=1)
				aggtarget_business_list_manager[your_current_city].set_local_aggpro_timer(target, agg_timer)
				continue

			elif ('failed' in agg_results) or ('ran off' in agg_results):
				print_function('Torch Results - Target ' + str(target) + ' in ' + str(your_current_city) + ' FAILED', "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Target " + str(target) + " in " + str(your_current_city) + " FAILED")
				last_agg_time[0] = datetime.datetime.utcnow()
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=2)
				agg_timer = agg_timer + datetime.timedelta(minutes=40)
				aggtarget_business_list_manager[your_current_city].set_shared_aggpro_timer(target, agg_timer)

				# UPDATE LOCAL MODIFIERS
				desired_mins = int(aggstr_mins_max) + 2
				if desired_mins > 30:
					desired_mins = 30

				mins_adjusted = int(desired_mins) - int(aggstr_min_checking)

				write_file('./agg_targets/torch/' + your_current_city + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				add_engi_list = False
				if config.getboolean('Torch', 'Engineer_Needed_Online'):
					for biz_need_engi in config['Torch']['Business_Need_Engineer'].split():
						biz_need_engi.strip()
						if (biz_need_engi in target) or (target in biz_need_engi):
							add_engi_list = True

				if add_engi_list:
					append_file('./records/Torch.txt', "\nTorch FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city) + " ENGILIST: " + str(engineer_list))
					append_file('./records/AllAggs.txt', "\nTorch FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city) + " ENGILIST: " + str(engineer_list))
				else:
					append_file('./records/Torch.txt', "\nTorch FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))
					append_file('./records/AllAggs.txt', "\nTorch FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch THREAD FINISHED")
				return


			elif ('managed to set ablaze' in agg_results):
				print_function('Torch Results - Target ' + str(target) + ' SUCCESS - AGG: ' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Target " + str(target) + " in " + str(your_current_city) + " SUCCESS")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=2)
				agg_timer = agg_timer + datetime.timedelta(minutes=40)
				aggtarget_business_list_manager[your_current_city].set_shared_aggpro_timer(target, agg_timer)

				# UPDATE LOCAL MODIFIERS
				try:
					mins_adjusted = int(read_file('./agg_targets/torch/' + your_current_city + '.txt'))
				except:
					mins_adjusted = 0

				mins_adjusted -= 1

				write_file('./agg_targets/torch/' + your_current_city + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				add_engi_list = False
				if config.getboolean('Torch', 'Engineer_Needed_Online'):
					for biz_need_engi in config['Torch']['Business_Need_Engineer'].split():
						biz_need_engi.strip()
						if (biz_need_engi in target) or (target in biz_need_engi):
							add_engi_list = True

				if add_engi_list:
					append_file('./records/Torch.txt', "\nTorch FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city) + " ENGILIST: " + str(engineer_list))
					append_file('./records/AllAggs.txt', "\nTorch FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city) + " ENGILIST: " + str(engineer_list))
				else:
					append_file('./records/Torch.txt', "\nTorch SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))
					append_file('./records/AllAggs.txt', "\nTorch SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))

				# UPDATE SHARED ALL AGGS RECORDS
				target_s3_string = target.replace(" ", "")
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.utcnow().year) + '-' + str(datetime.datetime.utcnow().month) + '-' + str(datetime.datetime.utcnow().day) + '.txt', "\r\n" + str(your_character_name) + " Torch " + str(target_s3_string) + " (Success) in " + str(globals()[your_current_city].which_city) + " on " + str(datetime.datetime.utcnow()))


				# REPAY CHECKS
				repay = True
				if not config.getboolean('Torch', 'Repay'):
					print_function('Torch - Repay - TURNED OFF', "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Repay - TURNED OFF")
					repay = False

				repay_blacklist = config['Torch']['Repay_Blacklist_' + your_current_city].split()
				for blacklist_name in repay_blacklist:
					if blacklist_name in target:
						print_function('Torch - Repay - TARGET IS BLACKLISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Repay - TARGET IS BLACKLISTED: " + str(target))
						repay = False

					if 'PRIVATE' in repay_blacklist:
						if target in globals()['private_businesses_' + your_current_city]:
							repay = False

					if 'PUBLIC' in repay_blacklist:
						if target in globals()['public_businesses']:
							repay = False

				repay_whitelist = config['Torch']['Repay_Whitelist_' + your_current_city].split()
				for whitelist_name in repay_whitelist:
					if whitelist_name in target:
						print_function('Torch - Repay - TARGET IS WHITELISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Repay - TARGET IS WHITELISTED: " + str(target))
						repay = True

					if 'PRIVATE' in repay_whitelist:
						if target in globals()['private_businesses_' + your_current_city]:
							repay = True

					if 'PUBLIC' in repay_whitelist:
						if target in globals()['public_businesses']:
							repay = True

				if repay:
					if target in globals()['public_businesses']:
						repay_type = 'PUBLIC'
					elif target in globals()['private_businesses_' + your_current_city]:
						repay_type = 'PRIVATE'
					else:
						print_function('TORCH - BUSINESS TYPE NOT FOUND FOR ' + str(target))
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch BUSINESS TYPE NOT FOUND FOR " + str(target))


					if repay_type == 'PUBLIC':
						repay_amount = 25000
					else:
						if target in globals()['torch_repay_list_50k']:
							repay_amount = 50000
						elif target in globals()['torch_repay_list_75k']:
							repay_amount = 75000
						elif target in globals()['torch_repay_list_100k']:
							repay_amount = 100000
						else:
							print_function('TORCH - REPAY AMOUNT NOT FOUND FOR ' + str(target))
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch REPAY AMOUNT NOT FOUND FOR " + str(target))

					target_string = 'REPAYBIZ--' + str(repay_type) + '--' + str(target) + '//' + str(your_current_city)
					print_function('TORCH - REPAY TARGET STRING: ' + str(target_string))

					print_function('Torch - Repaying ' + str(repay_amount) + ' TO ' + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' + str(repay_type), "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - Repaying " + str(repay_amount) + " TO " + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' +  str(repay_type))
					# ADD REPAY TO RECORDS
					append_file('./records/Torch.txt', "\n Torch - Repaying " + str(repay_amount) + " TO " + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' +  str(repay_type))
					append_file('./records/AllAggs.txt', "\n Torch - Repaying " + str(repay_amount) + " TO " + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' +  str(repay_type))

					if int(repay_amount) > 0:
						transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target_string)

						# WAIT FOR TRANSFER TO BE QUEUED
						print_function('Torch - Waiting for repay to be queued', "BLUE")
						while True:
							if 'transfer_money_thread' in str(waiting_thread_list):
								break
						print_function('Torch repay is queued', "BLUE")

					# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
					for thread in waiting_thread_list:
						if ('AggstrLowest' in thread):
							try:
								waiting_thread_list.remove(thread)
							except:
								pass
					thread_remove_from_queue(running_thread, waiting_thread_list)
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " \t\t Torch THREAD FINISHED")
					return
				else:
					# NO REPAY
					for thread in waiting_thread_list:
						if ('AggstrLowest' in thread):
							try:
								waiting_thread_list.remove(thread)
							except:
								pass
					thread_remove_from_queue(running_thread, waiting_thread_list)
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " \t\t Torch THREAD FINISHED")
					return

			else:
				print_function('Torch - results not found' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Torch - results not found" + str(agg_results))
				continue

		# THIS DOES NOT LOWER THE AGGSTR MINS. IT WILL BE REMOVED WHEN WE GET A TORCH OR ARMEDROBBERY
		thread_remove_from_queue(running_thread, waiting_thread_list)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " \t\t Torch THREAD FINISHED")
		return
	except:
		from code_modules.function import PrintException
		PrintException()
