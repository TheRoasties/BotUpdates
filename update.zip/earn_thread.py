from globalvars import *
from code_modules.function import *

global driver
global lock_webdriver

__all__ = ["earn_thread", "streetfight_options", "pimp_options", "whore_options", "joyride_options"]


def take_promo(lock_webdriver, running_thread, rank_percent, rank, occupation):
	if config.getboolean('Misc', 'TakePromo'):
		print_function('passed take promo')
		if ('100' in rank_percent) or ('Unknown%' in rank_percent):
			print_function('passed rank percent')
			if ('Mayor' in occupation) or ('Bank Manager' in occupation) or ('Hospital Director' in occupation) or ('Chief Engineer' in occupation) or ('Funeral Director' in occupation) or ('Fire Chief' in occupation) or ('Judge' in occupation) or ('Lawyer' in occupation):
				pass
			elif ('Join' in config['Action']['Train']):
				pass
			elif ('Commissioner-General' in occupation) or ('Field Marshal' in occupation) or ('Detective' in rank) or ('Don' in rank) or ('Lifer' in rank):
				pass
			else:
				print_function('refreshing')
				click_refresh(lock_webdriver, running_thread)

				if element_found(lock_webdriver, "ID", "promotion"):
					which_promo = element_get_attribute(lock_webdriver, "ID", "promotion", "outerHTML")
					do_nothing = False

					if 'Commander' in which_promo:
						do_nothing = True
					elif 'Brigadier' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Schooled' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Mule' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Hardrock' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Lifer' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Inspector' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Supervisor' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Superintendent' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Commissioner-General' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Fire Fighter' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Fire Chief' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'NCO' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif '2nd Lieutenant' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Major' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Nurse' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Doctor' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Surgeon' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Hospital Director' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Mortician Assistant' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Mortician' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Funeral Director' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Mechanic' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Technician' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Chief Engineer' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Engineer' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Bank Teller' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Loan Officer' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Bank Manager' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Senior Sergeant' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Sergeant' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Detective' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Legal Secretary' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Lawyer' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Mayor' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Dealer' in which_promo:
						do_nothing = True
					elif 'Giovane' in which_promo:
						# SKIPPED AS YOU MAY HAVE DROPPED G FOR MHS
						do_nothing = True
					elif 'Enforcer' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Piciotto' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Sgarrista' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Capodecima' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Caporegime' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					elif 'Boss' in which_promo:
						element_click(lock_webdriver, "ID", "two", running_thread)
					elif 'Don' in which_promo:
						element_click(lock_webdriver, "ID", "one", running_thread)
					else:
						print_function('TAKEPROMO - PROMO NOT FOUND: ' + str(which_promo), "RED")
						discord_message(config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + " CROSSROADS? Restart the bot after this is cleared)")
						waiting_thread_list.append('9zLoggedOut')
						while True:
							time.sleep(30)

					if not do_nothing:
						click_continue(lock_webdriver, running_thread)
				else:
					# RANKS NEEDING MANUAL PROMO
					if 'Giovane' in rank:
						config['Misc']['TakePromo'] = 'False'
	return


def quick_earn(lock_webdriver, running_thread):
	quick_earn_dropdown_clicked = False
	while True:
		# METHOD TO FIND LAST EARN IS VISIBLE
		if element_found(lock_webdriver, "XPATH",
						 "//*[@id='docTipsLayer']/div[@class='tipClass']/form/input"):
			print_function(str(inspect_stack()) + ' EARN QUICK - click earn bar')
			#OLD METHOD TO CLICK if element_click(lock_webdriver, "XPATH",
			#			  "//*[@id='docTipsLayer']/div[@class='tipClass']/form/input", running_thread):
			# METHOD TO CLICK FAST EARN
			if element_click(lock_webdriver, "NAME",
							 "lastearn", running_thread):
				break

		else:
			if quick_earn_dropdown_clicked:
				# QUICK EARN DROPDOWN CLICKED BUT NOT VISIBLE. PROBABLY ANOTHER POPUP LIKE TRAVEL STOPPING THIS. REFRESH FIRST
				quick_earn_dropdown_clicked = False
				print_function("QUICK EARN - DROPDOWN CLICKED BUT NOT VISIBLE. REFRESH FIRST", "RED")
				click_refresh(lock_webdriver, running_thread)

			print_function(str(inspect_stack()) + ' EARN QUICK - click earn arrow')
			if element_click(lock_webdriver, "XPATH", ".//*[@id='nav_left']/p[5]/a[2]/img", running_thread):
				quick_earn_dropdown_clicked = True

	print_function(str(get_url(lock_webdriver)))
	if 'rndcnt' in str(get_url(lock_webdriver)):
		print_function('EARN - BLANK PAGE', "RED")
		go_back(lock_webdriver)

	WhichEarn = config['Earn']['WhichEarn']
	if WhichEarn == 'Streetfight':
		if 'Streetfight' in running_thread[4]:
			pass
		else:
			streetfight_options(lock_webdriver, running_thread)
	elif WhichEarn == 'Pimp':
		if 'Pimp' in running_thread[4]:
			pass
		else:
			pimp_options(lock_webdriver, running_thread)
	elif WhichEarn == 'Whore':
		if 'Whore' in running_thread[4]:
			pass
		else:
			whore_options(lock_webdriver, running_thread)
	elif WhichEarn == 'Joyride':
		if 'Joyride' in running_thread[4]:
			pass
		else:
			joyride_options(lock_webdriver, running_thread)

	running_thread[1] = datetime.datetime.utcnow()
	return


def manual_earn(lock_webdriver, running_thread, occupation, rank_percent, supercharge=False):
	rank_percent = re.sub('[^0-9]', "", rank_percent)
	print_function('QUICK EARN NOT FOUND')
	# CHOOSE EARN

	try:
		go_to_page(lock_webdriver, 'Earn', running_thread)
	except:
		# CHECK FOR JAIL
		right_bar_details = driver.find_element(By.XPATH, "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']").get_attribute('innerHTML')
		if 'Jail Rank' in right_bar_details:
			if 'In-Jail' in str(running_thread[4]):
				pass
			else:
				variables_list = running_thread[4]
				variables_list.append('In-Jail')
				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES FOR IN-JAIL: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])

				waiting_thread_list.append('9zterminate-everything')
				print_function('9zterminate-everything THREAD QUEUED' + str(waiting_thread_list), "GREEN")
		return

	# GET CAREER EARNS
	WhichEarn = config['Earn']['WhichEarn']

	if WhichEarn == 'CurrentCareer':
		if 'Fire' in occupation:
			WhichEarn = 'Fire'
		elif ('Bank' in occupation) or ('Loan' in occupation):
			WhichEarn = 'Banking'
		elif ('Mechanic' in occupation) or ('Technician' in occupation) or ('Engineer' in occupation):
			WhichEarn = 'Engineering'
		elif ('Nurse' in occupation) or ('Doctor' in occupation) or ('Surgeon' in occupation) or ('Hospital' in occupation):
			WhichEarn = 'Hospital'
		elif ('Mortician' in occupation) or ('Funeral' in occupation):
			WhichEarn = 'Funeral'
		elif 'Gangster' in occupation:
			WhichEarn = 'Criminal'
		elif 'Armed' in occupation:
			WhichEarn = 'Army'
		elif 'Customs' in occupation:
			WhichEarn = 'Customs'
		elif ('Legal' in occupation) or ('Lawyer' in occupation) or ('Judge' in occupation):
			WhichEarn = 'Law'
		elif 'Police' in occupation:
			WhichEarn = 'Police'
		elif 'Mayor' in occupation:
			WhichEarn = 'Mayor'

		# GANGSTER AVOID TIER2+ EARNS AS THEY FAIL
		if 'Gangster' in occupation:
			if WhichEarn == 'Banking':
				# WhichEarn = 'Bank Teller'
				WhichEarn = 'local bank'
			elif WhichEarn == 'Engineering':
				WhichEarn = 'Mechanic'
			elif WhichEarn == 'Hospital':
				WhichEarn = 'Nurse'
			elif WhichEarn == 'Funeral':
				# WhichEarn = 'Mort Assistant'
				WhichEarn = 'Mortician Assistant'
			elif WhichEarn == 'Law':
				WhichEarn = 'Legal Secretary'


	# GET EARNS TABLE
	earns_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']", "outerHTML")

	# CAREER EARNS - CRIMINAL
	if WhichEarn == 'Criminal':
		if ('Scam' in earns_table):
			WhichEarn = 'Scam'
		elif ('Hack' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			WhichEarn = 'Hack'
		elif ( (('Drags' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Hack' in earns_table) ):
			WhichEarn = 'Drags'
		elif ( (('Cheques' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Drags' in earns_table) ):
			WhichEarn = 'Cheques'
		else:
			WhichEarn = 'Shoplift'

	# CAREER EARNS - FIRE
	elif WhichEarn == 'Fire':
		if ('Fire Chief' in earns_table):
			WhichEarn = 'Fire Chief'
		elif ( ('Firefighter' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])) and (occupation == 'Fire Fighter') ):
			# WhichEarn = 'Fire Fighter'
			WhichEarn = 'Firefighter'
		else:
			# WhichEarn = 'Volunteer Fire Fighter'
			WhichEarn = 'Volunteer Firefighter'

	# CAREER EARNS - BANK
	elif WhichEarn == 'Banking':
		if ('Bank Manager' in earns_table):
			WhichEarn = 'Bank Manager'
		elif ('loan requests' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			# WhichEarn = 'Loan Officer'
			WhichEarn = 'loan requests'
		else:
			# WhichEarn = 'Bank Teller'
			WhichEarn = 'local bank'

	# CAREER EARNS - ENGINEER
	elif WhichEarn == 'Engineering':
		if ('Chief Engineer' in earns_table):
			WhichEarn = 'Chief Engineer'
		elif ('Engineer' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			WhichEarn = 'Engineer'
		elif ( (('Technician' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Engineer' in earns_table) ):
			WhichEarn = 'Technician'
		else:
			WhichEarn = 'Mechanic'

	# CAREER EARNS - HOSPITAL
	elif WhichEarn == 'Hospital':
		if ('Hospital Director' in earns_table):
			WhichEarn = 'Hospital Director'
		elif ('Surgeon' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			WhichEarn = 'Surgeon'
		elif ( (('Doctor' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Surgeon' in earns_table) ):
			WhichEarn = 'Doctor'
		else:
			WhichEarn = 'Nurse'

	# CAREER EARNS - FUNERAL
	elif WhichEarn == 'Funeral':
		if ('Funeral Director' in earns_table):
			WhichEarn = 'Funeral Director'
		elif ('Mortician' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])) and not ("Assistant" in occupation):
			WhichEarn = 'Mortician'
		else:
			#WhichEarn = 'Mort Assistant'
			WhichEarn = 'Mortician Assistant';

	# CAREER EARNS - ARMY
	elif WhichEarn == 'Army':
		if ('Commander' in earns_table):
			WhichEarn = 'Commander'
		elif ('Operations Planning' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			WhichEarn = 'Operations Planning'
		elif ( (('National Guard' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Operations Planning' in earns_table) ):
			WhichEarn = 'National Guard'
		elif ( (('Weapons Training' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('National Guard' in earns_table) ):
			WhichEarn = 'Weapons Training'
		else:
			WhichEarn = 'Training Drills'

	# CAREER EARNS - CUSTOMS
	elif WhichEarn == 'Customs':
		if ('Airport security' in earns_table):
			#WhichEarn = 'Commissioner-General'
			WhichEarn = 'Airport security'
		elif ('Paperwork' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			#WhichEarn = 'Superintendent'
			WhichEarn = 'Paperwork'
		elif ( (('Search luggage' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Superintendent' in earns_table) ):
			#WhichEarn = 'Supervisor'
			WhichEarn = 'Search luggage'
		else:
			#WhichEarn = 'Inspector'
			WhichEarn = 'Stamp passports'

	# CAREER EARNS - LAW
	elif WhichEarn == 'Law':
		if ('Parole sitting' in earns_table):
			#WhichEarn = 'SC Judge'
			WhichEarn = 'Parole sitting'
		elif ('Judge' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			WhichEarn = 'Judge'
		elif ( (('Lawyer' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Judge' in earns_table) ):
			WhichEarn = 'Lawyer'
		else:
			WhichEarn = 'Legal Secretary'

	# CAREER EARNS - POLICE
	elif WhichEarn == 'Police':
		if ('Assign Duties' in earns_table):
			#WhichEarn = 'Commissioner'
			WhichEarn = 'Assign Duties'
		elif ('Arrest Criminals' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn'])):
			WhichEarn = 'Arrest Criminals'
		elif ( (('paper work' in earns_table) and (int(rank_percent) >= int(config['Earn']['PercentNextEarn']))) or ('Arrest Criminals' in earns_table) ):
			#WhichEarn = 'Paper Work'
			WhichEarn = 'paper work'
		else:
			WhichEarn = 'Patrol'

	extra_earn_options = 'None'
	# SECRET - STREETFIGHT
	if WhichEarn == 'Streetfight':
		if 'Street fight' in earns_table:
			pass
		else:
			WhichEarn = 'Pizza'
			extra_earn_options = 'Streetfight'

	if 'Street fight' in earns_table:
		if 'Streetfight' in running_thread[4]:
			pass
		else:
			variables_list = running_thread[4]
			variables_list.append('Streetfight')

			for item in running_thread[4]:
				if 'PizzaBatting' in item:
					try:
						variables_list.remove(item)
					except:
						pass
					break

			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES SECRET STREETFIGHT UNLOCKED: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])

	# SECRET - PIMP
	if WhichEarn == 'Pimp':
		if 'Pimp' in earns_table:
			pass
		else:
			WhichEarn = 'Bar'
			extra_earn_options = 'Pimp'

	if 'Pimp' in earns_table:
		if 'Pimp' in running_thread[4]:
			pass
		else:
			variables_list = running_thread[4]
			variables_list.append('Pimp')

			for item in running_thread[4]:
				if 'PimpSteal' in item:
					try:
						variables_list.remove(item)
					except:
						pass
					break

			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES SECRET PIMP UNLOCKED: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])

	# SECRET - WHORE
	if WhichEarn == 'Whore':
		if 'Whore' in earns_table:
			pass
		else:
			WhichEarn = 'Bar'
			extra_earn_options = 'Whore'

	if 'Whore' in earns_table:
		if 'Whore' in running_thread[4]:
			pass
		else:
			variables_list = running_thread[4]
			variables_list.append('Whore')

			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES SECRET WHORE UNLOCKED: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])

	# SECRET - JOYRIDE
	if WhichEarn == 'Joyride':
		if 'Joyride' in earns_table:
			pass
		else:
			WhichEarn = '711'
			extra_earn_options = 'Joyride'

	if 'Joyride' in earns_table:
		if 'Joyride' in running_thread[4]:
			pass
		else:
			variables_list = running_thread[4]
			variables_list.append('Joyride')

			for item in running_thread[4]:
				if 'JoyrideEarns' in item:
					try:
						variables_list.remove(item)
					except:
						pass
					break

			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES SECRET JOYRIDE UNLOCKED: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])


	# START OF NEW EARN FINDING METHOD
	while True:
		if 'captcha' in str(running_thread):
			pass
		else:
			url_check = get_url(lock_webdriver)
			if ('random.asp' in url_check):
				print_function(str(inspect_stack()) + 'EARN CLICK BLOCKED - ON CAPTCHA PAGE', "RED")
				time.sleep(10000)

			lock_webdriver.acquire()
			earns_list = driver.find_elements(By.XPATH, ".//div[@id='earns_list']/div")
			correct_earn_found = False
			for earn in earns_list:
				earn_outerhtml = earn.get_attribute('outerHTML')
				if "<s>" in str(earn_outerhtml):
					# strikethrough. ignore red options
					continue
				elif WhichEarn == "Firefighter" and "Volunteer" in str(earn_outerhtml):
					continue
				elif WhichEarn == "Mortician" and "Assistant" in str(earn_outerhtml):
					continue
				elif str(WhichEarn) in str(earn_outerhtml):
					correct_earn_found = True

					random_timer = random.randrange(0, 22)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					webdriver.ActionChains(driver).move_to_element(earn).perform()

					random_timer = random.randrange(0, 11)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					earn.click()
					release_webdriver(lock_webdriver)
					break
			if correct_earn_found != True:
				discord_error(config['Auth']['discord_id'] + ' Earn Not Found: ' + str(WhichEarn))
				quit()
			else:
				# break outer while loop as earn found
				break
	# END OF NEW EARN FINDING METHOD

	if supercharge:
		if element_found(lock_webdriver, "ID", "superchargeearn"):
			element_click(lock_webdriver, "ID", "superchargeearn", running_thread)

	# click_continue(lock_webdriver, running_thread)
	if (element_found(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/p/input")):
		element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/p/input", running_thread)
	elif (element_found(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/p/button")):
		element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/p/button", running_thread)
	else:
		print_function('NEITHER EARN WORK BUTTON FOUND', "RED")


	if extra_earn_options == 'Streetfight':
		if 'Streetfight' in running_thread[4]:
			pass
		else:
			streetfight_options(lock_webdriver, running_thread)
	elif extra_earn_options == 'Pimp':
		if 'Pimp' in running_thread[4]:
			pass
		else:
			pimp_options(lock_webdriver, running_thread)
	elif extra_earn_options == 'Whore':
		if 'Whore' in running_thread[4]:
			pass
		else:
			whore_options(lock_webdriver, running_thread)
	elif extra_earn_options == 'Joyride':
		if 'Joyride' in running_thread[4]:
			pass
		else:
			joyride_options(lock_webdriver, running_thread)

	return


def streetfight_options(lock_webdriver, running_thread):
	url_check = get_url(lock_webdriver)
	if ('pizzacrime.asp' in url_check) or ('pizza.asp' in url_check):
		earns_options = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_options']/div[@id='holder_content']", "outerHTML")

		# ALWAYS SAY MUGGED
		if 'you were mugged' in earns_options:
			element_click(lock_webdriver, "ID", "steal", running_thread)
		# ALWAYS BLACKMAIL COWORKER
		elif 'Blackmail him' in earns_options:
			element_click(lock_webdriver, "ID", "bribe", running_thread)
		# BAT 8 TIMES THEN GET BEER
		elif 'beer after work' in earns_options:
			if 'PizzaBatting' in str(running_thread[4]):
				pass
			else:
				variables_list = running_thread[4]
				variables_list.append('PizzaBatting8')
				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES PIZZA SECRET: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])

			variables_list = running_thread[4]
			for item in running_thread[4]:
				if 'PizzaBatting' in item:
					batting_count = re.sub('[^0-9]', "", item)
					try:
						variables_list.remove(item)
					except:
						pass
					break

			# 8 BATS THEN BEER
			if int(batting_count) > 0:
				element_click(lock_webdriver, "ID", "stealfriend", running_thread)
				batting_count = int(batting_count) - 1
			else:
				element_click(lock_webdriver, "ID", "getbeer", running_thread)
				batting_count = 8

			variables_list.append('PizzaBatting' + str(batting_count))
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES PIZZA SECRET: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])
		else:
			print_function('earn options: ' + str(earns_options))
			input('done')
		click_continue(lock_webdriver, running_thread)
	return


def pimp_options(lock_webdriver, running_thread):
	url_check = get_url(lock_webdriver)
	if ('barcrime.asp' in url_check) or ('bar.asp' in url_check):
		earns_options = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_options']/div[@id='holder_content']", "outerHTML")

		# ALWAYS PIMP
		if 'pimp' in earns_options:
			element_click(lock_webdriver, "ID", "pimp", running_thread)
		# ALWAYS BOUNCE
		elif 'bounce' in earns_options:
			element_click(lock_webdriver, "ID", "bounce", running_thread)
		# STEAL 4 THEN DONT STEAL
		elif 'steal' in earns_options:
			if 'PimpSteal' in str(running_thread[4]):
				pass
			else:
				variables_list = running_thread[4]
				variables_list.append('PimpSteal4')
				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES BAR(PIMP) SECRET: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])

			variables_list = running_thread[4]
			for item in running_thread[4]:
				if 'PimpSteal' in item:
					pimpsteal_count = re.sub('[^0-9]', "", item)
					try:
						variables_list.remove(item)
					except:
						pass
					break

			# 4 STEAL THEN DONT
			if int(pimpsteal_count) > 0:
				element_click(lock_webdriver, "ID", "steal", running_thread)
				pimpsteal_count = int(pimpsteal_count) - 1
			else:
				element_click(lock_webdriver, "ID", "dontsteal", running_thread)
				pimpsteal_count = 4

			variables_list.append('PimpSteal' + str(pimpsteal_count))
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES BAR(PIMP) SECRET: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])
		# WORK BEHIND THE BAR - HAS NO OPTIONS
		elif 'work behind the bar' in earns_options:
			pass
		else:
			print_function('earn options: ' + str(earns_options))
			input('done')

		if ('work behind the bar' in earns_options) or ('real eye opener' in earns_options) or ('stoked with you' in earns_options):
			pass
		else:
			click_continue(lock_webdriver, running_thread)
	return


def whore_options(lock_webdriver, running_thread):
	url_check = get_url(lock_webdriver)
	if ('barcrime.asp' in url_check) or ('bar.asp' in url_check):
		earns_options = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_options']/div[@id='holder_content']", "outerHTML")
		# ALWAYS WHORE
		if 'whore' in earns_options:
			element_click(lock_webdriver, "ID", "whore", running_thread)
		# NO FREE DRINKS
		elif 'Make their drinks' in earns_options:
			element_click(lock_webdriver, "ID", "dontsteal", running_thread)
		# WORK EXTRA HOURS
		elif 'extra hours' in earns_options:
			element_click(lock_webdriver, "ID", "work", running_thread)
		# STRIP
		elif 'strip' in earns_options:
			element_click(lock_webdriver, "ID", "strip", running_thread)
		# WORK BEHIND THE BAR - NO OPTIONS FOR THIS
		elif 'work behind the bar' in earns_options:
			pass
		else:
			print_function('earn options: ' + str(earns_options))
			input('done')

		if 'work behind the bar' in earns_options:
			pass
		else:
			click_continue(lock_webdriver, running_thread)
	return


def joyride_options(lock_webdriver, running_thread):
	url_check = get_url(lock_webdriver)
	# 172 EARNS CHOOSING BAD OPTIONS

	variables_list = running_thread[4]
	if 'JoyrideEarns' in str(running_thread[4]):
		pass
	else:
		variables_list.append('JoyrideEarns172')
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES 711 SECRET: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

	for item in running_thread[4]:
		if 'JoyrideEarns' in item:
			earns_count = re.sub('[^0-9-]', "", item)
			try:
				variables_list.remove(item)
			except:
				pass
			break

	if ('711crime.asp' in url_check) or ('711.asp' in url_check):
		earns_options = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_options']/div[@id='holder_content']", "outerHTML")
		if int(earns_count) > 0:
			# BAD OPTIONS
			# WORK HOURS OR TAKE GOODS HOME
			if ('store goods home' in earns_options) or ('work hours' in earns_options):
				element_click(lock_webdriver, "ID", "steal", running_thread) # good equivalent dontsteal
			# STEAL GROCERIES
			elif 'purse' in earns_options:
				element_click(lock_webdriver, "ID", "helprob", running_thread) # good equivalent help
			# STEAL TILL
			elif 'till' in earns_options:
				element_click(lock_webdriver, "ID", "stealtill", running_thread) # dontstealtill
			else:
				print_function('earn options: ' + str(earns_options))
				input('done')
		else:
			# WORK HOURS OR TAKE GOODS HOME
			if ('store goods home' in earns_options) or ('work hours' in earns_options):
				element_click(lock_webdriver, "ID", "dontsteal", running_thread)
			# STEAL GROCERIES
			elif 'purse' in earns_options:
				element_click(lock_webdriver, "ID", "help", running_thread)
			# STEAL TILL
			elif 'till' in earns_options:
				element_click(lock_webdriver, "ID", "dontstealtill", running_thread)
			else:
				print_function('earn options: ' + str(earns_options))
				input('done')

			# IT WILL CONSIDER THE JUST DONE GOOD EARN AS DONE. SO WILL RESULT IN 10 BAD EARNS NEXT BEFORE ANOTHER GOOD
			earns_count = 11

		click_continue(lock_webdriver, running_thread)

	earns_count = int(earns_count) - 1

	variables_list.append('JoyrideEarns' + str(earns_count))
	running_thread[4] = variables_list
	print_function('UPDATED VARIABLES 711 SECRET: ' + str(running_thread[4]))
	write_file("env/variables.txt", running_thread[4])
	return


def jail_earn(lock_webdriver, running_thread):
	while True:
		page_check = get_url(lock_webdriver)
		if 'duties.asp' in page_check:
			print_function(str(inspect_stack()) + ' Jail Earn - on Page')
			break
		else:
			print_function(str(inspect_stack()) + ' Earns - Opening Jail Earn Page')
			lock_webdriver.acquire()
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_element(By.XPATH, ".//*[@class='income']")).perform()
			random_timer = random.randrange(0, 11)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			try:
				driver.find_element(By.XPATH, ".//*[@class='income']").click()
			except:
				pass
			release_webdriver(lock_webdriver)

			page_check = get_url(lock_webdriver)
			if ('.asp' in page_check) and (('duties.asp' in page_check) or ('duty.asp' in page_check) or ('journal.asp' in page_check) or ('comms.asp' in page_check) or ('contraband.asp' in page_check) or ('forum.asp?t=jail' in page_check) or ('conflict.asp' in page_check)):
				# CORRECTLY IN JAIL
				pass
			elif ('random.asp' in page_check):
				# CAPTCHA - DO NOT COMPLETE EARN
				running_thread[1] = datetime.datetime.utcnow()

				# WAIT FOR CAPTCHA TO BE RUNNING
				while True:
					if 'captcha' in str(running_thread):
						break
					# CAPTCHA RUNNING. WAIT FOR IT TO FINISH
				while True:
					if 'captcha' in str(running_thread):
						pass
					else:
						break
				return
			elif ('.asp' in page_check):
				# NOT IN JAIL
				if 'In-Jail' in str(running_thread[4]):
					variables_list = running_thread[4]
					try:
						variables_list.remove('In-Jail')
					except:
						pass
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES FOR NOT IN-JAIL - EARN1: ' + str(running_thread[4]))
					print_function('page check: ' + str(page_check))
					write_file("env/variables.txt", running_thread[4])
					return

			running_thread[1] = datetime.datetime.utcnow()
			continue

	lock_webdriver.acquire()
	jail_earns_list = driver.find_element(By.XPATH, ".//*[@id='content']/div[1]").get_attribute('innerHTML')

	earn_found = False
	if config.getboolean('Earn', 'MakeShank'):
		if 'Make Shank' in jail_earns_list:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_element(By.ID, "makeshank")).perform()
			random_timer = random.randrange(0, 11)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			driver.find_element(By.ID, "makeshank").click()
			earn_found = True

	if earn_found == False:
		if 'Workshop' in jail_earns_list:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_element(By.ID, "workshop")).perform()
			random_timer = random.randrange(0, 11)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			driver.find_element(By.ID, "workshop").click()
		elif 'Kitchen' in jail_earns_list:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_element(By.ID, "kitchen")).perform()
			random_timer = random.randrange(0, 11)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			driver.find_element(By.ID, "kitchen").click()
		else:
			random_timer = random.randrange(0, 22)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			webdriver.ActionChains(driver).move_to_element(driver.find_element(By.ID, "laundry")).perform()
			random_timer = random.randrange(0, 11)
			random_timer = random_timer / 10
			time.sleep(random_timer)
			driver.find_element(By.ID, "laundry").click()
		running_thread[1] = datetime.datetime.utcnow()

	random_timer = random.randrange(0, 22)
	random_timer = random_timer / 10
	time.sleep(random_timer)
	webdriver.ActionChains(driver).move_to_element(driver.find_element(By.XPATH, ".//*[@class='input']")).perform()
	random_timer = random.randrange(0, 11)
	random_timer = random_timer / 10
	time.sleep(random_timer)
	driver.find_element(By.XPATH, ".//*[@class='input']").click()
	release_webdriver(lock_webdriver)

	page_check = get_url(lock_webdriver)
	if ('.asp' in page_check) and (('duties.asp' in page_check) or ('duty.asp' in page_check) or ('journal.asp' in page_check) or ('comms.asp' in page_check) or ('contraband.asp' in page_check) or ('forum.asp?t=jail' in page_check) or ('conflict.asp' in page_check)):
		# CORRECTLY IN JAIL
		pass
	elif ('random.asp' in page_check):
		# CAPTCHA - DO NOT COMPLETE EARN
		running_thread[1] = datetime.datetime.utcnow()

		# WAIT FOR CAPTCHA TO BE RUNNING
		while True:
			if 'captcha' in str(running_thread):
				break
			# CAPTCHA RUNNING. WAIT FOR IT TO FINISH
		while True:
			if 'captcha' in str(running_thread):
				pass
			else:
				break
		return
	elif ('.asp' in page_check):
		# NOT IN JAIL
		if 'In-Jail' in str(running_thread[4]):
			variables_list = running_thread[4]
			try:
				variables_list.remove('In-Jail')
			except:
				pass
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES FOR NOT IN-JAIL - EARN2: ' + str(running_thread[4]))
			print_function('page check:' + str(page_check))
			write_file("env/variables.txt", running_thread[4])
			return

	running_thread[1] = datetime.datetime.utcnow()
	return


def earn_thread(lock_webdriver, running_thread, waiting_thread_list):
	while True:
		try:
			WhichEarn = config['Earn']['WhichEarn']
			if (WhichEarn == 'None') and not ('In-Jail' in str(running_thread[4])):
				time.sleep(5)
				continue
			else:
				earn_timer = get_timer(lock_webdriver, 'Earn', running_thread)
				print_function('EARN THREAD - AWAITING TIMER: ' + str(earn_timer))
				time.sleep(earn_timer)
				wait_till_timer_ready(lock_webdriver, 'Earn')

				supercharge = False
				if 'casino' in str(waiting_thread_list):
					supercharge = True
				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_earn)
				if 'casino' in str(waiting_thread_list):
					supercharge = True

				if config.getboolean('Earn', 'SuperCharge'):
					supercharge = True

				print_function('EARN THREAD ACTIVE')
				# DILLIGENT WORKER
				if config.getboolean('Earn', 'UseDilly'):
					if globals()['timers'].__dict__['skill_timer'] is None:
						globals()['timers'].__dict__['skill_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
							seconds=get_timer(lock_webdriver, 'Skill', running_thread))

					time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['skill_timer']
					if not '-' in str(time_difference):
						# SKILL TIMER READY
						go_to_page(lock_webdriver, 'Skills', running_thread)
						skills_count = element_count(lock_webdriver, "NAME", "doskill")
						print_function('EARN - DILLY - SKILLS COUNT: ' + str(skills_count))
						if skills_count > 0:
							loop_count = 0
							target_count = 0
							while True:
								skill_check = element_get_attribute(lock_webdriver, "NAME", "doskill", "value", loop_count)
								print_function('EARN - DILLY - SKILL CHECK: ' + str(skill_check) + " " + str(loop_count))
								if 'Heal player!' in skill_check:
									target_count += 1
								if 'Enrage!' in skill_check:
									target_count += 1
								if 'Infect!' in skill_check:
									target_count += 1
								if 'Motivate!' in skill_check:
									sendkeys(lock_webdriver, "NAME", "target", get_your_character_name(lock_webdriver), target_count)
									element_click(lock_webdriver, "NAME", "doskill", running_thread, loop_count)
									globals()['timers'].__dict__[
										'skill_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
										seconds=get_timer(lock_webdriver, 'Skill', running_thread))
									break
								if (loop_count + 1) >= skills_count:
									print_function('EARN - DILLY - DILLY NOT UNLOCKED?')
									config['Earn']['UseDilly'] = False
									break
								loop_count += 1

				#  GET RIGHT BAR DETAILS
				right_bar_details = running_thread[2]
				if right_bar_details == '':
					running_thread[2] = element_get_attribute(lock_webdriver, 'XPATH', "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']", 'innerHTML')
					right_bar_details = running_thread[2]

				if 'Jail Rank' in right_bar_details:
					if 'In-Jail' in str(running_thread[4]):
						pass
					else:
						variables_list = running_thread[4]
						variables_list.append('In-Jail')
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR IN-JAIL: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])

						waiting_thread_list.append('9zterminate-everything')
						print_function('9zterminate-everything THREAD QUEUED' + str(waiting_thread_list), "GREEN")
				else:
					# NOT IN JAIL
					if 'In-Jail' in str(running_thread[4]):
						variables_list = running_thread[4]
						try:
							variables_list.remove('In-Jail')
						except:
							pass
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR NOT IN-JAIL - EARN3: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])

				if 'In-Jail' in str(running_thread[4]):
					right_bar_line = right_bar_details.splitlines()
					rank_percent = regex_match_between('title="', '"', right_bar_line[38])
					rank = regex_match_between('>', '<', right_bar_line[7])
					occupation = 'NONE'
					print_function('rank% ' + str(rank_percent) + ' rank ' + str(rank))
				else:
					# NON JAIL DETAILS
					right_bar_line = right_bar_details.splitlines()
					rank_percent = regex_match_between('title="', '"', right_bar_line[40])
					rank = regex_match_between('>', '<', right_bar_line[6])
					if 'Rank:' in rank:
						rank = regex_match_between('>', '<', right_bar_line[7])
					occupation = regex_match_between('>', '<', right_bar_line[11])

				if 'In-Jail' in str(running_thread[4]):
					jail_earn(lock_webdriver, running_thread)
				else:
				# QUICK EARN
					if ( (supercharge == False) and (element_found(lock_webdriver, "XPATH", ".//*[@id='nav_left']/p[5]/a[2]/img")) ):
						try:
							quick_earn(lock_webdriver, running_thread)
						except:
							pass
					else:
						try:
							manual_earn(lock_webdriver, running_thread, occupation, rank_percent, supercharge)
						except:
							pass

				take_promo(lock_webdriver, running_thread, rank_percent, rank, occupation)

				thread_remove_from_queue(running_thread, waiting_thread_list)
				time.sleep(1)
		except:
			from code_modules.function import PrintException
			PrintException()
