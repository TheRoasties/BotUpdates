def manager_thread():
	import os

	# KILLS EXCESS CHROMEDRIVERS
	try:
		os.system("taskkill /f /im  chromedriver.exe")
	except:
		pass

	import re
	import time
	from globalvars import person
	from globalvars import business
	from globalvars import city
	from multiprocessing.managers import BaseManager
	from code_modules.function import print_function


	while True:
		text_file = open("env/ServerPort.txt", "r")
		server_port = text_file.read()
		text_file.close()
		manager = BaseManager(address=('', int(server_port)))

		BaseManager.register('person', person)
		BaseManager.register('business', business)
		BaseManager.register('city', city)
		# manager.start()

		print_function('REGISTERED BASE MANAGER ON PORT ' + str(manager.address[1]))

		try:
			server = manager.get_server()
			print_function('BASE MANAGER RUNNING ON PORT ' + str(manager.address[1]))
			break
		except:
			print_function('FAILED TO CREATE BASE MANAGER - INCREASING PORT NUMBER')
			text_file = open("env/ServerPort.txt", "r")
			server_port = text_file.read()
			text_file.close()

			server_port = int(server_port) + 1

			text_file = open("env/ServerPort.txt", "w")
			text_file.write(str(server_port))
			text_file.close()
	server.serve_forever()
	return


def start_aggs_logging():
	import sys
	import platform
	from subprocess import Popen

	messages = 'AGGS CODE WINDOW'
	# define a command that starts new terminal
	if platform.system() == "Windows":
		new_window_command = "cmd.exe /c start".split()
	else:  # XXX this can be made more portable
		new_window_command = "x-terminal-emulator -e".split()

	# open new consoles, display messages
	echo = [sys.executable, "-c", "import sys; import os; print(sys.argv[1]); os.system('python AggsLog.py')"]
	processes = [Popen(new_window_command + echo + [messages])]
	write_file("env/Aggs_Thread_Log.txt", "AGGS CODE LOGGING WINDOW")
	return


try:
	if __name__ == '__main__':
		from globalvars import *
		from code_modules.function import *
		from earn_thread import *
		from action_thread import *
		from captcha_thread import *
		from remotecontrol_thread import *
		from misc_thread import *
		from find_agg_target_thread import *
		from code_modules.transfer_money import *
		from code_modules.pickpocket import *
		from code_modules.mug import *
		from code_modules.bne import *
		from code_modules.hack import *
		from code_modules.armedrobbery import *
		from code_modules.torch import *


		global thread_transfer_money
		global running_thread
		global waiting_thread_list
		global thread_captcha
		global thread_remotecontrol
		global thread_earn
		global thread_action
		global thread_misc
		global thread_find_agg_targets
		global thread_pickpocket
		global thread_mug
		global thread_bne
		global thread_hack
		global thread_armedrobbery
		global thread_torch
		global last_agg_time
		global manager

		# TEMP TEST NEW CODE HERE
		#print(str("NAME " + get_your_character_name(lock_webdriver)))
		#print(str("RANK " + get_your_character_rank(lock_webdriver)))
		#print(str("OCCUPATION " + get_your_character_occupation(lock_webdriver)))
		#print(str("CLEAN " + str(get_your_clean_money(lock_webdriver))))
		#print(str("PERCENT " + get_your_character_rank_percent(lock_webdriver)))

		#print("FINISHED")
		#exit()
		# END TEMP TEST NEW CODE HERE

		start_aggs_logging()

		# CREATE FILES IF THEY DO NOT EXIST
		if os.path.isfile("env/citylist_timer.txt"):
			pass
		else:
			write_file("env/citylist_timer.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/last_bne_zero.txt"):
			pass
		else:
			write_file("env/last_bne_zero.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/gym_timer.txt"):
			pass
		else:
			write_file("env/gym_timer.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/casino_timer.txt"):
			pass
		else:
			write_file("env/casino_timer.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/agg_unlocks.txt"):
			pass
		else:
			write_file("env/agg_unlocks.txt", "")

		if os.path.isfile("env/variables.txt"):
			pass
		else:
			write_file("env/variables.txt", "[]")

		if os.path.isfile("env/consume_drugs_timer.txt"):
			pass
		else:
			write_file("env/consume_drugs_timer.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/pay_tribute.txt"):
			pass
		else:
			write_file("env/pay_tribute.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/profile_timer.txt"):
			pass
		else:
			write_file("env/profile_timer.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/ServerPort.txt"):
			pass
		else:
			write_file("env/ServerPort.txt", 5000)

		if os.path.isfile("env/sexchange_timer.txt"):
			pass
		else:
			write_file("env/sexchange_timer.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/fireinspection_house_timer.txt"):
			pass
		else:
			write_file("env/fireinspection_house_timer.txt", datetime.datetime.utcnow())

		if os.path.isfile("env/waiting_thread_list.txt"):
			pass
		else:
			write_file("env/waiting_thread_list.txt", "['']")

		if os.path.isfile("env/PoliceSkipCase.txt"):
			pass
		else:
			write_file("env/PoliceSkipCase.txt", "")

		if os.path.isfile("env/911Timer.txt"):
			pass
		else:
			write_file("env/911Timer.txt", datetime.datetime.utcnow())


		# DECLARE MANAGERS
		last_agg_time = Manager().list()
		running_thread = Manager().list()
		waiting_thread_list = Manager().list()

		aggtarget_person_list_manager = Manager().dict()
		aggtarget_business_list_manager = Manager().dict()

		thread_manager = Process(target=manager_thread, name='ManagerThread', args=())
		thread_manager.start()
		while True:
			if thread_manager.is_alive():
				time.sleep(2)
				break


		# SET DEFAULTS TO PREVENT NULL ERRORS
		last_agg_time.append('0initial_checks')

		# RUNNING THREAD USES
		# 0 = the current active process
		running_thread.append('0initial_checks')
		# 1 = timer for last click. this is used to avoid repeatedly checking things which will have not changed without a page load
		running_thread.append(datetime.datetime.utcnow())
		# 2 = right bar details (homecity etc) - the value for this is set before the threads start
		running_thread.append('')
		# 3 = unlocked aggs & blackmarket
		running_thread.append('')
		# 4 = variables
		running_thread.append('')
		# 5 = last travel timer
		running_thread.append(datetime.datetime.utcnow())

		running_thread[3] = read_file("env/agg_unlocks.txt")
		if '[' in str(running_thread[3]):
			running_thread[3] = eval(running_thread[3])
		else:
			running_thread[3] = []
		print_function("PREVIOUS UNLOCKS: " + str(running_thread[3]))

		running_thread[4] = read_file("env/variables.txt")
		if '[' in str(running_thread[4]):
			running_thread[4] = eval(running_thread[4])
		else:
			running_thread[4] = []

				

		# REMOVE SAVED NOT GO BELOW TORCH/AR  // REMOVE CS SO CHECKED AGAIN AT STARTUP
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if ('Torch|AR' in item) or ('CS:' in item):
				try:
					variables_list.remove(item)
				except:
					pass
				break
		running_thread[4] = variables_list
		print_function("PREVIOUS VARIABLES: " + str(running_thread[4]), "GREEN")


		previous_waiting_list = read_file("env/waiting_thread_list.txt")
		if '[' in previous_waiting_list:
			pass
		else:
			previous_waiting_list = "['']"
		print_function("RUNNING PREVIOUS QUEUE: " + str(previous_waiting_list))
		if (previous_waiting_list == "['999None']"):
			waiting_thread_list.append('999None')
		else:
			split_previous_waiting_list = previous_waiting_list.split(",")
			for task in split_previous_waiting_list:
				task = regex_match_between("'", "'", task)
				if '999None' in task:
					waiting_thread_list.append('999None')
				elif 'transfer_money_thread' in task:
					parse_task = task.split("<|>")
					amount = parse_task[1]
					recipient = parse_task[2]
					transfer_money(lock_webdriver, running_thread, waiting_thread_list, amount, recipient)
				elif 'mayor_sell' in task:
					waiting_thread_list.append('9zmayor_sell')
				elif ('TravelToHomecity' in task) or ('9zSmuggleDrugs:' in task) or ('9zSmuggleReady:' in task) or ('9zBlindEye' in task):
					waiting_thread_list.append(str(task))
				elif 'SellItem' in task:
					waiting_thread_list.append(str(task))
				elif 'SendMessage' in task:
					waiting_thread_list.append(str(task))
				elif ('9zAwaiting') or ('mortician_smuggle' in task) or ('judge' in task) or ('customs_blindeye' in task) or ('remotecontrol' in task) or ('misc' in task) or ('event' in task) or ('fire' in task) or ('train' in task) or ('pay_tribute' in task) or ('vehicle' in task) or ('suicide' in task) or ('blackmarket' in task) or ('terminate-everything' in task) or ('get_engineer_lists' in task) or ('check_engineer_online' in task) or ('profile_check' in task) or ('update_unlocked_aggs' in task) or ('casino' in task) or ('gym' in task) or ('torch' in task) or ('armedrobbery' in task) or ('bne' in task) or ('middle_drugs' in task) or ('mug' in task) or ('consume_drugs' in task) or ('drugwork' in task) or ('AggstrLowest' in task) or ('blackmarket_gangster_exp' in task) or ('check_journal' in task) or ('hospital' in task) or ('mechanic' in task) or ('withdraw_money' in task) or ('bank_career' in task) or ('obituaries' in task) or ('community_service' in task) or ('community_service_non_homecity' in task) or ('train_customs' in task) or ('uni_degree' in task) or ('mayor_buy' in task) or ('city_list_record' in task) or ('action_thread' in task) or ('earn_thread' in task) or ('captcha_thread' in task) or ('check_messages' in task) or ('initial_checks' in task) or ('weapon_shop' in task) or ('bionic_shop' in task) or ('lawyer' in task) or ('pickpocket' in task) or ('hack' in task) or ('launder' in task) or ('online_time_record' in task):
					pass
				else:
					print_function('NEW PREVIOUS WAITING LIST OPTION: ' + str(task))
					input('done')

		running_thread[0] = '999None'
		if '999None' not in str(waiting_thread_list):
			waiting_thread_list.append('999None')
		waiting_thread_list.sort()


		thread_captcha = Process(target=captcha_thread, name='CaptchaThread', args=(lock_webdriver, running_thread, waiting_thread_list))
		thread_remotecontrol = Process(target=remotecontrol_thread, name='RemoteControlThread', args=(lock_webdriver, running_thread, waiting_thread_list))
		thread_earn = Process(target=earn_thread, name='EarnThread',  args=(lock_webdriver, running_thread, waiting_thread_list))
		thread_action = Process(target=action_thread, name='ActionThread', args=(lock_webdriver, running_thread, waiting_thread_list))
		thread_misc = Process(target=misc_thread, name='MiscThread', args=(lock_webdriver, running_thread, waiting_thread_list, aggtarget_person_list_manager, aggtarget_business_list_manager))
		thread_find_agg_targets = Process(target=find_agg_target_thread, name='AggTargetsThread', args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, aggtarget_person_list_manager, aggtarget_business_list_manager))
		thread_transfer_money = Process(target=transfer_money_thread, name='TransferMoneyThread',
										args=(lock_webdriver, running_thread, waiting_thread_list, '<|>0<|>NoTransferMoneyRecipient'))

		thread_pickpocket = Process(target=do_pickpocket_thread, name='PickpocketThread',
									args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, '[]'))

		thread_mug = Process(target=do_mug_thread, name='MugThread',
							 args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, '[]'))

		thread_bne = Process(target=do_bne_thread, name='BnEThread',
							 args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, '[]'))

		thread_hack = Process(target=do_hack_thread, name='HackThread',
							  args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, '[]'))

		thread_armedrobbery = Process(target=do_armedrobbery_thread, name='ArmedRobberyThread',
									  args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, '[]'))

		thread_torch = Process(target=do_torch_thread, name='TorchThread',
							   args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, '[]'))

		print_function('GLOBALS SET')

		# CONNECT TO BASEMANAGER AND REGISTER BUSINESS OBJECTS
		server_port = read_file("env/ServerPort.txt")
		server_port_last = server_port
		manager = BaseManager(address=('127.0.0.1', int(server_port)))
		BaseManager.register('person', person)
		BaseManager.register('city', city)
		BaseManager.register('business', business)

		while True:
			try:
				server_port = read_file("env/ServerPort.txt")
				if server_port_last != server_port:
					manager = BaseManager(address=('127.0.0.1', int(server_port)))
					BaseManager.register('person', person)
					BaseManager.register('city', city)
					BaseManager.register('business', business)

				print_function('MAIN THREAD - ATTEMPTING TO CONNECT TO BASEMANAGER ON PORT ' + str(server_port), "GREEN")
				manager.connect()
				print_function('MAIN THREAD - CONNECTED TO BASEMANAGER ON PORT ' + str(server_port), "GREEN")

				break
			except Exception as except_error:
				print_function('MAIN THREAD - FAILED TO CONNECT TO BASEMANAGER ON PORT ' + str(server_port) + ' - ERROR: ' + str(except_error), "RED")
				time.sleep(3)


		# DECLARE BUSINESS OBJECTS SHARED BY DIFFERENT THREADS
		for city in globals()['cities_list']:
			aggtarget_business_list_manager[city] = manager.city(city, globals()['public_businesses'], globals()['private_businesses_' + city])

		# CREATE DATABASE TIMERS FOR THE BUSINESSES, IF THEY DO NOT ALREADY EXIST
		from code_modules.function import get_from_database
		from code_modules.function import update_database

		business_database = get_from_database('Business', None)
		for current_city in cities_list:
			for current_business in globals()['private_businesses_' + current_city]:
				current_business = current_business.replace(" ", "")
				biz_name = str(current_city) + str(current_business)
				biz_name = biz_name.replace(" ", "")
				if str(biz_name) in str(business_database):
					pass
				else:
					update_database('Business', 'BizName', biz_name, {"AggPro": str(datetime.datetime.utcnow()), "City": str(current_city), "Business": str(current_business)})
			for current_business in public_businesses:
				current_business = current_business.replace(" ", "")
				biz_name = str(current_city) + str(current_business)
				biz_name = biz_name.replace(" ", "")
				if str(biz_name) in str(business_database):
					pass
				else:
					update_database('Business', 'BizName', biz_name, {"AggPro": str(datetime.datetime.utcnow()), "City": str(current_city), "Business": str(current_business)})



		thread_captcha.start()
		thread_remotecontrol.start()

		if (config.getboolean('Earn', 'DoEarns')):
			thread_earn.start()
		thread_action.start()
		thread_misc.start()
		thread_find_agg_targets.start()

		'''
		TO DO
			
		time to save aggpro after attempt - make a variable. people want more aggs
		agg target class - rather than adding local aggpro for each person attempted, make a counter variable. the variable is incremented each time the full aggs loop completes. if saved counter loop != current counter loop then do the agg. this way it would go ham on agg targets (only incrmenet the main loop when it gets to mins 0 so everything has been attempted)
		
		compare settings file. discord notify if missing settings (compare every = line and make sure exists in current file)
	
	
	
		
		travel avoid closed cities
		
		judge (include ng list)      
		army - queue multiple train types - rifleman etc. does them in order
		customs - train weapon search / do weapon search
		
		drugstore
		vehicle yard
		restock autobuy
		reserve aggstr for torch / ar
		
		invest
		
		judge - check case against all cases records to see if known correct/incorrect suspect
			 
		blackmarket - check cities are open before doing calcs
		
		check police station just before travel - what to do with failed jt cases? (make a setting for travel failed jt - check career and respect tick)
		if cases in current city don't travel
		
			
		middle only if alraedy sold blackmarket
		middle when interrupted starts the supplier list from scratch. also when buying drugs it starts from scratch - make a variable about the supplier list, and continue it. if list empty then start over
		if 'x in city with drugs' add them to list, but do not recheck the entire supplier list
		check everyone in city - skip anyone unable to use drugs (check promo list for g's incase straight g)
		only count if 3mins or less inactive
		sell a small amount to everyone as a test
		
		make variable file for drugs status - track how much in each city, and who has offers etc. need all sold to travel
		collect drug profits. sell correct amounts for this
		keep white/blacklist of clients
		keep preferred list of clients
	
		
		aws tools:
		dynamodb - 25gb / lambda - 1 million requests / sns - 1 million requests / ses - 62k outbound emails / sqs - 1 million requests / swf - 10k tasks / step functions - 4k / 
		
		   
		all aggs:        
		add 9z for torch and ar. if variable mins away (aggstr or timer) stops all other aggs - reserving aggstr for torch / ar (could just add the torch|ar to variables)
				
		join terminated threads for system resources . how to do by pid? since the thread items are within a function on find_agg_target_thread they no longer exist after the function call, so cannot be altered even by within that function
	 
		  
		
		thread for misc
			invest
			parking / brothel / old trafford etc
			send NE journal at 100% credibility
				bionic restock (autobuy)
				weapon restock (autobuy)
			vehicle restock (autobuy)
			drugstore (autobuy)
				blackmarket (daily amount based on total value of goods sold. so look at profit as percentage of goods, not just total profit)
				travel (lawyer / world in hands / biz targets)
			collect business profit - do after crewfront or vault / big launder as bank manager
			track respect of people of interest - maybe via sqs so checking is distributed?
		
		
		thread for careers
				bm g exp (adjust for daily limit)
				lawyer (prioritize boys / travel)
				mayor (get interpol details)
			police case / 911 (remove 911 names on the boys)
			judge
		
		thread for aggs 
				online time records (remove dead names from total hours record - should be done by obits? done by city list?)
		
		thread for actions
			training as police
			training as army
			police duties
			
		REMOTE CONTROL (own thread)
			view queue of actions
			transfer medkit
			transfer armor
			whack
			gbh
			whackspam
			gbhspam
			mhs - planner
			mhs - gunner
			mhs - other
			mhs all done as group login
			can you change settings from the code? if so do this via remote to turn repay aggs on/off etc remotely
			city search for name
			check cars in city
			 
				  
		MISC STUFF		
			have shared war setting - disabled skill use for everyone
		
			test wrapper for functions. include test input, verify test output. this is how we can unit test them
	
			shared timers (obits etc) - set a shared timer for 5mins as you start doing the process. extend this to the real timer after you complete the process. in this way it works like an sqs visibility timeout so the task is still completed if interrupted
				
			dashboard showing everyone logged in, their timers, total online times, weapons, location, pending cases / dropdown options for remote control
			war dashboard - show everyone in every city (update city options via sqs) and highlight people of interest
			
			dashboard show all online people. sorted into friendly / enemy / neutral. have option to add names for who the player is / show all the known timers
			detect identity by online hours habits & when character created
			
			script has issues with multiple windows. how to choose mm one?
			
			timed logout
		'''

		# THREAD MANAGER
		print_function('THREAD MANAGER START')
		while True:
			if 'terminate_earn_thread' in str(waiting_thread_list):
				thread_earn.terminate()
				while thread_earn.is_alive():
					print_function("WAITING FOR EARN THREAD TO FINISH TERMINATING", "RED")
					time.sleep(1)
				running_thread[1] = datetime.datetime.utcnow()
				print_function('RESTARTED EARN THREAD', "GREEN")

				# thread_earn.join()
				open_all_locks()

				thread_earn = Process(target=earn_thread, name='EarnThread',
									  args=(lock_webdriver, running_thread, waiting_thread_list))
				for thread in waiting_thread_list:
					if 'earn_thread' in thread:
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				waiting_thread_list.sort()
				if (config.getboolean('Earn', 'DoEarns')):
					thread_earn.start()
			elif 'terminate' in str(waiting_thread_list):
				# TERMINATE PICKPOCKET
				if ('terminate_do_pickpocket_thread' in str(waiting_thread_list)) or ('9zterminate-everything' in str(waiting_thread_list)):
					message_sent = False
					while 'AwaitingPickpocket' in str(waiting_thread_list):
						if not message_sent:
							print_function('AWAITING PICKPOCKET THREAD TO START - CANNOT BE TERMINATED YET', "RED")
							message_sent = True
						pass

					PickpocketPID = read_file("env/PickpocketPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(PickpocketPID), signal.SIGKILL)
						else:
							os.kill(int(PickpocketPID), signal.SIGTERM)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED PICKPOCKET")
					except:
						print_function('FAILED TO TERMINATE PICKPOCKET THREAD', "RED")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE PICKPOCKET")

					print_function('TERMINATED PICKPOCKET THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

					agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t PICKPOCKET - THREAD TERMINATED")

					for inner_thread in waiting_thread_list:
						if ('do_pickpocket_thread' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('AggstrLowest' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
					print_function('LIST AFTER TERMINATE PICKPOCKET: ' + str(waiting_thread_list))
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE PICKPOCKET: " + str(waiting_thread_list))
					open_all_locks()

				# TERMINATE MUG
				if ('terminate_do_mug_thread' in str(waiting_thread_list)) or ('9zterminate-everything' in str(waiting_thread_list)):
					message_sent = False
					while 'AwaitingMug' in str(waiting_thread_list):
						if not message_sent:
							print_function('AWAITING MUG THREAD TO START - CANNOT BE TERMINATED YET')
							message_sent = True
						pass

					MugPID = read_file("env/MugPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(MugPID), signal.SIGKILL)
						else:
							os.kill(int(MugPID), signal.SIGTERM)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED MUG")
					except:
						print_function('FAILED TO TERMINATE MUG THREAD', "RED")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE MUG")

					print_function('TERMINATED MUG THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

					agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t MUG - THREAD TERMINATED")

					for inner_thread in waiting_thread_list:
						if ('do_mug_thread' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('AggstrLowest' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
					print_function('LIST AFTER TERMINATE MUG: ' + str(waiting_thread_list))
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE MUG: " + str(waiting_thread_list))
					open_all_locks()

				# TERMINATE BNE
				if ('terminate_do_bne_thread' in str(waiting_thread_list)) or ('9zterminate-everything' in str(waiting_thread_list)):
					message_sent = False
					while 'AwaitingBnE' in str(waiting_thread_list):
						if not message_sent:
							print_function('AWAITING BNE THREAD TO START - CANNOT BE TERMINATED YET')
							message_sent = True
						pass

					BnEPID = read_file("env/BnEPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(BnEPID), signal.SIGKILL)
						else:
							os.kill(int(BnEPID), signal.SIGTERM)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED BNE")
					except:
						print_function('FAILED TO TERMINATE BNE THREAD', "RED")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE BNE")

					print_function('TERMINATED BNE THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

					agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t BNE - THREAD TERMINATED")

					for inner_thread in waiting_thread_list:
						if ('do_bne_thread' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('AggstrLowest' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
					print_function('LIST AFTER TERMINATE BNE: ' + str(waiting_thread_list))
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE BNE: " + str(waiting_thread_list))
					open_all_locks()

				# TERMINATE BNE ZERO
				if ('terminate_do_bne_zero_thread' in str(waiting_thread_list)) or ('9zterminate-everything' in str(waiting_thread_list)):
					message_sent = False
					while 'AwaitingBnEZero' in str(waiting_thread_list):
						if not message_sent:
							print_function('AWAITING BNEZero THREAD TO START - CANNOT BE TERMINATED YET')
							message_sent = True
						pass

					BnEZeroPID = read_file("env/BnEZeroPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(BnEZeroPID), signal.SIGKILL)
						else:
							os.kill(int(BnEZeroPID), signal.SIGTERM)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED BNE ZERO")
					except:
						print_function('FAILED TO TERMINATE BNE ZERO THREAD', "RED")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE BNE ZERO")

					print_function('TERMINATED BNE ZERO THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

					agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t BNE ZERO - THREAD TERMINATED")

					for inner_thread in waiting_thread_list:
						if ('do_bne_zero_thread' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('AggstrLowest' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
					print_function('LIST AFTER TERMINATE BNE ZERO: ' + str(waiting_thread_list))
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE BNE ZERO: " + str(waiting_thread_list))
					open_all_locks()

				# TERMINATE HACK
				if ('terminate_do_hack_thread' in str(waiting_thread_list)) or ('9zterminate-everything' in str(waiting_thread_list)):
					message_sent = False
					while 'AwaitingHack' in str(waiting_thread_list):
						if not message_sent:
							print_function('AWAITING Hack THREAD TO START - CANNOT BE TERMINATED YET')
							message_sent = True
						pass

					HackPID = read_file("env/HackPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(HackPID), signal.SIGKILL)
						else:
							os.kill(int(HackPID), signal.SIGTERM)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED HACK")
					except:
						print_function('FAILED TO TERMINATE HACK THREAD', "RED")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE HACK")

					print_function('TERMINATED HACK THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

					agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t HACK - THREAD TERMINATED")

					for inner_thread in waiting_thread_list:
						if ('do_hack_thread' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('AggstrLowest' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
					print_function('LIST AFTER TERMINATE HACK: ' + str(waiting_thread_list))
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE HACK: " + str(waiting_thread_list))
					open_all_locks()

				print_function("QUEUE AFTER TERMINATE: " + str(waiting_thread_list), "GREEN")
				write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE: " + str(waiting_thread_list))
				running_thread[0] = waiting_thread_list[0]

				# TERMINATE ARMEDROBBERY
				if ('terminate_do_armedrobbery_thread' in str(waiting_thread_list)) or ('9zterminate-everything' in str(waiting_thread_list)):
					message_sent = False
					while 'AwaitingArmedRobbery' in str(waiting_thread_list):
						if not message_sent:
							print_function('AWAITING ArmedRobbery THREAD TO START - CANNOT BE TERMINATED YET')
							message_sent = True
						pass

					ArmedRobberyPID = read_file("env/ArmedRobberyPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(ArmedRobberyPID), signal.SIGKILL)
						else:
							os.kill(int(ArmedRobberyPID), signal.SIGTERM)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED ArmedRobbery")
					except:
						print_function('FAILED TO TERMINATE ArmedRobbery THREAD', "RED")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE ArmedRobbery")

					print_function('TERMINATED ArmedRobbery THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

					agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t ArmedRobbery - THREAD TERMINATED")

					for inner_thread in waiting_thread_list:
						if ('do_armedrobbery_thread' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('AggstrLowest' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
					print_function('LIST AFTER TERMINATE ArmedRobbery: ' + str(waiting_thread_list))
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE ArmedRobbery: " + str(waiting_thread_list))
					open_all_locks()

				# TERMINATE TORCH
				if ('terminate_do_torch_thread' in str(waiting_thread_list)) or ('9zterminate-everything' in str(waiting_thread_list)):
					message_sent = False
					while 'AwaitingTorch' in str(waiting_thread_list):
						if not message_sent:
							print_function('AWAITING Torch THREAD TO START - CANNOT BE TERMINATED YET')
							message_sent = True
						pass

					TorchPID = read_file("env/TorchPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(TorchPID), signal.SIGKILL)
						else:
							os.kill(int(TorchPID), signal.SIGTERM)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED Torch")
					except:
						print_function('FAILED TO TERMINATE Torch THREAD', "RED")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE Torch")

					print_function('TERMINATED Torch THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

					agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t Torch - THREAD TERMINATED")

					for inner_thread in waiting_thread_list:
						if ('do_torch_thread' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('get_engineer_lists' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('check_engineer_online' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass
						if ('AggstrLowest' in inner_thread):
							try:
								waiting_thread_list.remove(inner_thread)
							except:
								pass

					print_function('LIST AFTER TERMINATE Torch: ' + str(waiting_thread_list))
					write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER TERMINATE Torch: " + str(waiting_thread_list))
					open_all_locks()

				print_function("QUEUE AFTER TERMINATE: " + str(waiting_thread_list), "GREEN")
				write_file("env/Aggs_Thread_Log.txt",
						   str(agg_time_string) + "LIST AFTER TERMINATE: " + str(waiting_thread_list))
				running_thread[0] = waiting_thread_list[0]


			# TERMINATE & RESTART ALL MAIN THREADS AS WE ARE TERMINATING EVERYTHING
			if '9zterminate-everything' in str(waiting_thread_list):
				thread_earn.terminate()
				while thread_earn.is_alive():
					print_function("WAITING FOR EARN THREAD TO FINISH TERMINATING", "RED")
					time.sleep(1)
				running_thread[1] = datetime.datetime.utcnow()
				print_function('RESTARTED EARN THREAD', "GREEN")

				# thread_earn.join()
				thread_earn = Process(target=earn_thread, name='EarnThread',
									  args=(lock_webdriver, running_thread, waiting_thread_list))
				for thread in waiting_thread_list:
					if 'earn_thread' in thread:
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				if (config.getboolean('Earn', 'DoEarns')):
					thread_earn.start()
				print_function("RESTARTED EARN THREAD", "BLUE")


				thread_action.terminate()
				while thread_action.is_alive():
					print_function("WAITING FOR ACTION THREAD TO FINISH TERMINATING", "RED")
					time.sleep(1)
				running_thread[1] = datetime.datetime.utcnow()
				print_function('RESTARTED ACTION THREAD', "GREEN")
				# thread_action.join()
				thread_action = Process(target=action_thread, name='ActionThread',
										args=(lock_webdriver, running_thread, waiting_thread_list))
				for thread in waiting_thread_list:
					if ('fire_duties' in thread) or ('train_' in thread) or ('pay_tribute' in thread) or ('community_service' in thread) or ('train_customs' in thread) or ('uni_degree' in thread) or ('drugwork' in thread) or ('action_thread' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_action.start()
				print_function("RESTARTED ACTION THREAD", "BLUE")


				if 'blackmarket_travel' in str(running_thread[0]):
					print_function("RESTARTING MISC THREAD - SKIPPED AS TRAVEL TRIGGERED TERMINATE EVERYTHING", "BLUE")
				else:
					thread_misc.terminate()
					while thread_misc.is_alive():
						print_function("WAITING FOR MISC THREAD TO FINISH TERMINATING", "RED")
						time.sleep(1)
					running_thread[1] = datetime.datetime.utcnow()
					print_function('RESTARTED MISC THREAD', "GREEN")
					# thread_misc.join()
					thread_misc = Process(target=misc_thread, name='MiscThread', args=(lock_webdriver, running_thread, waiting_thread_list, aggtarget_person_list_manager,aggtarget_business_list_manager))
					clear_running_thread = False
					for thread in waiting_thread_list:
						if ('mortician_smuggle' in thread) or ('judge' in thread) or ('customs_blindeye' in thread) or ('fire' in thread) or ('misc' in thread) or ('event' in thread) or ('blackmarket_gangster_exp' in thread) or ('vehicle' in thread) or ('update_unlocked_aggs' in thread) or ('blackmarket' in thread) or ('middle_drugs' in thread) or ('consume_drugs' in thread) or ('profile_check' in thread) or ('casino' in thread) or ('gym' in thread) or ('check_journal' in thread) or ('hospital' in thread) or ('mechanic' in thread) or ('withdraw_money' in thread) or ('check_messages' in thread) or ('weapon_shop' in thread) or ('lawyer' in thread) or ('bionic_shop' in thread) or ('launder' in thread) or ('mayor_buy' in thread) or ('obituaries' in thread) or ('bank_career' in thread) or ('city_list_record' in thread):
							try:
								print_function("RESTARTING MISC THREAD - REMOVED " + thread, "BLUE")
								waiting_thread_list.remove(thread)
							except:
								pass


					thread_misc.start()
					print_function("RESTARTED MISC THREAD", "BLUE")


				thread_find_agg_targets.terminate()
				while thread_find_agg_targets.is_alive():
					print_function("WAITING FOR FIND AGG TARGETS THREAD TO FINISH TERMINATING", "RED")
					time.sleep(1)
				running_thread[1] = datetime.datetime.utcnow()
				print_function('RESTARTED FIND AGG TARGETS THREAD', "GREEN")
				# thread_find_agg_targets.join()
				thread_find_agg_targets = Process(target=find_agg_target_thread, name='AggTargetsThread', args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, aggtarget_person_list_manager, aggtarget_business_list_manager))
				thread_find_agg_targets.start()
				print_function("RESTARTED FIND AGG TARGETS THREAD", "BLUE")

				open_all_locks()

				for thread in waiting_thread_list:
					if ('terminate-everything' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass

				# UPDATE TEXT BACKUP
				waiting_thread_list.sort()
				write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

				print_function("QUEUE AFTER TERMINATE EVERYTHING: " + str(waiting_thread_list), "GREEN")
			#  END OF TERMINATE EVERYTHING

			# INTERRUPT THREADS
			print_running_thread = False
			if int(running_thread[0][0]) > int(waiting_thread_list[0][0]):
				if '999None' in str(running_thread[0]):
					print_function('RUNNING THREAD VACANT TO ' + str(waiting_thread_list), "GREEN")
				else:
					print_running_thread = True
					print_function('RUNNING THREAD INTERRUPTED : ' + str(running_thread[0]) + " FOR: " + str(waiting_thread_list), "GREEN")

					if 'earn_thread' in running_thread[0]:
						print_function('RESTARTED EARN THREAD', "GREEN")
						thread_earn.terminate()
						while thread_earn.is_alive():
							print_function("WAITING FOR EARN THREAD TO FINISH TERMINATING", "RED")
							time.sleep(1)
						running_thread[1] = datetime.datetime.utcnow()
						print_function('RESTARTED EARN THREAD', "GREEN")
						# thread_earn.join()
						open_all_locks()

						thread_earn = Process(target=earn_thread, name='EarnThread',
											  args=(lock_webdriver, running_thread, waiting_thread_list))
						for thread in waiting_thread_list:
							if 'earn_thread' in thread:
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						waiting_thread_list.sort()
						if (config.getboolean('Earn', 'DoEarns')):
							thread_earn.start()

						# UPDATE TEXT BACKUP
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

					elif ('fire_duties' in running_thread[0]) or ('train' in running_thread[0]) or ('pay_tribute' in running_thread[0]) or ('community_service_non_homecity' in running_thread[0]) or ('action_thread' in running_thread[0]) or ('drugwork' in running_thread[0]) or ('community_service' in running_thread[0]) or ('train_customs' in running_thread[0]) or ('uni_degree' in running_thread[0]) or ('mayor_sell' in running_thread[0]):
						print_function('RESTARTED ACTION THREAD', "GREEN")
						thread_action.terminate()
						while thread_action.is_alive():
							print_function("WAITING FOR ACTION THREAD TO FINISH TERMINATING", "RED")
							time.sleep(1)
						running_thread[1] = datetime.datetime.utcnow()
						print_function('RESTARTED ACTION THREAD', "GREEN")
						# thread_action.join()
						open_all_locks()

						thread_action = Process(target=action_thread, name='ActionThread',
												args=(lock_webdriver, running_thread, waiting_thread_list))
						for thread in waiting_thread_list:
							if ('fire_duties' in thread) or ('train_' in thread) or ('pay_tribute' in thread) or ('community_service' in thread) or ('train_customs' in thread) or ('uni_degree' in thread) or ('drugwork' in thread) or ('action_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						waiting_thread_list.sort()
						thread_action.start()

						# UPDATE TEXT BACKUP
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

					elif ('police_case' in running_thread[0]) or ('police_911' in running_thread[0]) or ('fire_inspection' in running_thread[0]) or ('judge' in running_thread[0]) or ('mortician_smuggle' in running_thread[0]) or ('customs_blindeye' in running_thread[0]) or ('misc' in running_thread[0]) or ('event' in running_thread[0]) or ('blackmarket' in running_thread[0]) or ('vehicle' in running_thread[0]) or ('profile_check' in running_thread[0]) or ('casino' in running_thread[0]) or ('gym' in running_thread[0]) or ('update_unlocked_aggs' in running_thread[0]) or ('blackmarket_gangster_exp' in running_thread[0]) or ('middle_drugs' in running_thread[0]) or ('consume_drugs' in running_thread[0]) or ('check_journal' in running_thread[0]) or ('hospital' in running_thread[0]) or ('mechanic' in running_thread[0]) or ('withdraw_money' in running_thread[0]) or ('bank_career' in running_thread[0]) or ('city_list_record' in running_thread[0]) or ('obituaries' in running_thread[0]) or ('mayor_buy' in running_thread[0]) or ('check_messages' in running_thread[0]) or ('weapon_shop' in running_thread[0]) or ('launder' in running_thread[0]) or ('bionic_shop' in running_thread[0]) or ('lawyer' in running_thread[0]):
						print_function('RESTARTED MISC THREAD', "GREEN")
						thread_misc.terminate()
						while thread_misc.is_alive():
							print_function("WAITING FOR EARN THREAD TO FINISH TERMINATING", "RED")
							time.sleep(1)
						running_thread[1] = datetime.datetime.utcnow()
						print_function('RESTARTED MISC THREAD', "GREEN")
						# thread_misc.join()
						open_all_locks()

						thread_misc = Process(target=misc_thread, name='MiscThread', args=(lock_webdriver, running_thread, waiting_thread_list, aggtarget_person_list_manager, aggtarget_business_list_manager))
						for thread in waiting_thread_list:
							if ('police_case' in thread) or ('police_911' in thread) or ('fire_inspection' in thread) or ('customs_blindeye' in thread) or ('judge' in thread) or ('mortician_smuggle' in thread) or ('misc' in thread) or ('event' in thread) or ('blackmarket_gangster_exp' in thread) or ('vehicle' in thread) or ('update_unlocked_aggs' in thread) or ('blackmarket' in thread) or ('middle_drugs' in thread) or ('consume_drugs' in thread) or ('profile_check' in thread) or ('casino' in thread) or ('gym' in thread) or ('check_journal' in thread) or ('hospital' in thread) or ('mechanic' in thread) or ('withdraw_money' in thread) or ('check_messages' in thread) or ('weapon_shop' in thread) or ('lawyer' in thread) or ('bionic_shop' in thread) or ('launder' in thread) or ('mayor_buy' in thread) or ('obituaries' in thread) or ('bank_career' in thread) or ('city_list_record' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass

						waiting_thread_list.sort()
						thread_misc.start()

						# UPDATE TEXT BACKUP
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

					elif 'transfer_money_thread' in str(running_thread[0]):
						interrupted_thread_to_remove = str(running_thread[0])

						parse_task = interrupted_thread_to_remove.split("<|>")
						amount = parse_task[1]
						recipient = parse_task[2]

						TransferMoneyPID = read_file("env/TransferMoneyPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(TransferMoneyPID), signal.SIGKILL)
							else:
								os.kill(int(TransferMoneyPID), signal.SIGTERM)
						except:
							print_function('FAILED TO TERMINATE TRANSFER MONEY THREAD', "RED")

						open_all_locks()

						try:
							waiting_thread_list.remove(str(interrupted_thread_to_remove))
						except:
							pass
						waiting_thread_list.sort()
						transfer_money(lock_webdriver, running_thread, waiting_thread_list, amount, recipient)

						print_function('RESTARTED TRANSFER MONEY - PAYING: ' + str(amount) + ' TO: ' + str(recipient), "GREEN")

						# UPDATE TEXT BACKUP
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

						print_function('LIST AFTER INTERRUPT TRANSFERMONEY: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT TRANSFERMONEY: " + str(waiting_thread_list))

					elif 'do_pickpocket_thread' in str(running_thread[0]):
						PickpocketPID = read_file("env/PickpocketPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(PickpocketPID), signal.SIGKILL)
							else:
								os.kill(int(PickpocketPID), signal.SIGTERM)
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED PICKPOCKET THREAD")
						except:
							print_function('FAILED TO TERMINATE PICKPOCKET THREAD', "RED")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE PICKPOCKET THREAD")

						print_function('TERMINATED PICKPOCKET THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

						agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(
							datetime.datetime.utcnow().minute) + ":" + str(
							datetime.datetime.utcnow().second)
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t PICKPOCKET - THREAD INTERRUPTED BY " + str(waiting_thread_list[0]))

						for thread in waiting_thread_list:
							if ('do_pickpocket_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('AggstrLowest' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						print_function('LIST AFTER INTERRUPT PICKPOCKET: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT PICKPOCKET: " + str(waiting_thread_list))
						open_all_locks()

					elif 'do_mug_thread' in str(running_thread[0]):
						MugPID = read_file("env/MugPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(MugPID), signal.SIGKILL)
							else:
								os.kill(int(MugPID), signal.SIGTERM)
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED MUG THREAD")
						except:
							print_function('FAILED TO TERMINATE MUG THREAD', "RED")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE MUG THREAD")

						print_function('TERMINATED MUG THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

						agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t MUG - THREAD INTERRUPTED BY " + str(waiting_thread_list[0]))

						for thread in waiting_thread_list:
							if ('do_mug_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('AggstrLowest' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						print_function('LIST AFTER INTERRUPT MUG: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT MUG: " + str(waiting_thread_list))
						open_all_locks()

					elif ('do_torch_thread' in str(running_thread[0])) or ('get_engineer_lists' in str(running_thread[0])) or ('check_engineer_online' in str(running_thread[0])):
						TorchPID = read_file("env/TorchPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(TorchPID), signal.SIGKILL)
							else:
								os.kill(int(TorchPID), signal.SIGTERM)
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED Torch THREAD")
						except:
							print_function('FAILED TO TERMINATE Torch THREAD', "RED")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE Torch THREAD")

						print_function('TERMINATED Torch THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

						agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t Torch - THREAD INTERRUPTED BY " + str(waiting_thread_list[0]))

						for thread in waiting_thread_list:
							if ('do_torch_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('get_engineer_lists' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('check_engineer_online' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('AggstrLowest' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass

						print_function('LIST AFTER INTERRUPT Torch: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT Torch: " + str(waiting_thread_list))
						open_all_locks()

					elif 'do_armedrobbery_thread' in str(running_thread[0]):
						ArmedRobberyPID = read_file("env/ArmedRobberyPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(ArmedRobberyPID), signal.SIGKILL)
							else:
								os.kill(int(ArmedRobberyPID), signal.SIGTERM)
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED ArmedRobbery THREAD")
						except:
							print_function('FAILED TO TERMINATE ArmedRobbery THREAD', "RED")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE ArmedRobbery THREAD")

						print_function('TERMINATED ArmedRobbery THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

						agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t ArmedRobbery - THREAD INTERRUPTED BY " + str(waiting_thread_list[0]))

						for thread in waiting_thread_list:
							if ('do_armedrobbery_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('AggstrLowest' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						print_function('LIST AFTER INTERRUPT ArmedRobbery: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT ArmedRobbery: " + str(waiting_thread_list))
						open_all_locks()

					elif 'do_hack_thread' in str(running_thread[0]):
						HackPID = read_file("env/HackPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(HackPID), signal.SIGKILL)
							else:
								os.kill(int(HackPID), signal.SIGTERM)
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED HACK THREAD")
						except:
							print_function('FAILED TO TERMINATE HACK THREAD', "RED")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE HACK THREAD")

						print_function('TERMINATED HACK THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

						agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(
							datetime.datetime.utcnow().minute) + ":" + str(
							datetime.datetime.utcnow().second)
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t HACK - THREAD INTERRUPTED BY " + str(waiting_thread_list[0]))

						for thread in waiting_thread_list:
							if ('do_hack_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('AggstrLowest' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						print_function('LIST AFTER INTERRUPT HACK: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT HACK: " + str(waiting_thread_list))
						open_all_locks()

					elif 'do_bne_thread' in str(running_thread[0]):
						BnEPID = read_file("env/BnEPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(BnEPID), signal.SIGKILL)
							else:
								os.kill(int(BnEPID), signal.SIGTERM)
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED BNE THREAD")
						except:
							print_function('FAILED TO TERMINATE BNE THREAD', "RED")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE BNE THREAD")

						print_function('TERMINATED BNE THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

						agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t BNE - THREAD INTERRUPTED BY " + str(waiting_thread_list[0]))

						for thread in waiting_thread_list:
							if ('do_bne_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
							if ('AggstrLowest' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						print_function('LIST AFTER INTERRUPT BNE: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT BNE: " + str(waiting_thread_list))
						open_all_locks()

					elif 'do_bne_zero_thread' in str(running_thread[0]):
						BnEZeroPID = read_file("env/BnEZeroPID.txt")
						try:
							if platform.system() != 'Windows':
								os.kill(int(BnEZeroPID), signal.SIGKILL)
							else:
								os.kill(int(BnEZeroPID), signal.SIGTERM)
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " TERMINATED BNE ZERO THREAD")
						except:
							print_function('FAILED TO TERMINATE BNE ZERO THREAD', "RED")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FAILED TO TERMINATE BNE ZERO THREAD")

						print_function('TERMINATED BNE ZERO THREAD. THIS WILL AUTOMATICALLY RESTART AS AGGS THREAD ALWAYS RUNS', "GREEN")

						agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(datetime.datetime.utcnow().second)
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "\t\t BNE ZERO - THREAD INTERRUPTED BY " + str(waiting_thread_list[0]))

						for thread in waiting_thread_list:
							if ('do_bne_zero_thread' in thread):
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
						print_function('LIST AFTER INTERRUPT BNE ZERO: ' + str(waiting_thread_list))
						write_file("env/Aggs_Thread_Log.txt", str(agg_time_string) + "LIST AFTER INTERRUPT BNE ZERO: " + str(waiting_thread_list))
						open_all_locks()
					else:
						print_function('THREAD NOT FOUND TO KILL' + str(running_thread[0]), "GREEN")

				running_thread[0] = waiting_thread_list[0]

				if print_running_thread:
					print_function('RUNNING THREAD INTERRUPT FINISHED - NOW RUNNING : ' + str(running_thread[0]), "GREEN")
					print_running_thread = False

			time.sleep(1)
except:
	from code_modules.function import PrintException
	PrintException()