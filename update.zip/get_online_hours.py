def get_from_database(table, attribs_to_get, filter=None):
	# response = get_from_database('Player', 'PlayerName, AggPro, House', "Key('PlayerName').eq('Test')")
	#    for item in response['Items']:
	#    print_function('item: ' + str(item))
	import boto3

	client = boto3.resource('dynamodb', region_name='ap-southeast-2', aws_access_key_id='AKIAVJNIZJYFC24IQCMU', aws_secret_access_key='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')
	table = client.Table(table)
	if filter is None:
		if attribs_to_get is None:
			response = table.scan(ReturnConsumedCapacity='NONE')
		else:
			response = table.scan(Select='SPECIFIC_ATTRIBUTES',ReturnConsumedCapacity='NONE',ProjectionExpression=attribs_to_get)
	else:
		if attribs_to_get is None:
			response = table.scan(ReturnConsumedCapacity='NONE',FilterExpression=eval(filter))
		else:
			response = table.scan(Select='SPECIFIC_ATTRIBUTES',ReturnConsumedCapacity='NONE',ProjectionExpression=attribs_to_get,FilterExpression=eval(filter))


	if 'LastEvaluatedKey' in response:
		input('GET_FROM_DATABASE - LASTEVELUATEDKEY FOUND - CODE FOR THIS')
	return response


if __name__ == '__main__':
	player_database = get_from_database('Player', None)
	item_count = (len(player_database['Items']) - 1)
	while item_count >= 0:
		try:
			player_alive_status = player_database['Items'][item_count]['AliveStatus']
		except:
			player_alive_status == ""

		if str(player_alive_status) == "Alive":
			try:
				name = player_database['Items'][item_count]['PlayerName']
				hours = player_database['Items'][item_count]['Hours']

				if (int(hours) >= 500):
					print(name, '\t', hours)
			except:
				pass

		item_count -= 1


	print('done')
