if __name__ == '__main__':
	from git import Repo
	import os, stat
	import shutil

	def recursive_overwrite(src, dest, ignore=None):
		if os.path.isdir(src):
			if not os.path.isdir(dest):
				os.makedirs(dest)
			files = os.listdir(src)
			if ignore is not None:
				ignored = ignore(src, files)
			else:
				ignored = set()
			for f in files:
				if f not in ignored:
					recursive_overwrite(os.path.join(src, f),
										os.path.join(dest, f),
										ignore)
		else:
			shutil.copyfile(src, dest)

	try:
		print("REMOVING READ ONLY ATTRIBUTES")
		for root, dirs, files in os.walk(str(os.getcwd()) + '\\update-files'):
			for fname in files:
				full_path = os.path.join(root, fname)
				os.chmod(full_path, stat.S_IWRITE)
	except:
		pass

	try:
		print("REMOVING SAVED FILES")
		shutil.rmtree(str(os.getcwd()) + '\\update-files')
	except:
		pass

	HTTPS_REMOTE_URL = 'https://0c1a0352714b69ab096a626fadf90f73703893ff:x-oauth-basic@github.com/Silver-f0x/NewBot'
	DEST_NAME = 'update-files'
	print("CLONING REPO")
	cloned_repo = Repo.clone_from(HTTPS_REMOTE_URL, DEST_NAME)
	print("REPO CLONED")


	print("UPDATING")
	recursive_overwrite(str(os.getcwd()) + '\\update-files', str(os.getcwd()))
	print("UPDATED")