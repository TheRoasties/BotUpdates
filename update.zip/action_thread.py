from globalvars import *
from code_modules.function import *

from code_modules.community_service import *
from code_modules.community_service_non_homecity import *
from code_modules.train_customs import *
from code_modules.train_fire import *
from code_modules.train_army import *
from code_modules.train_police import *
from code_modules.uni_degree import *
from code_modules.mayor_sell import *
from code_modules.fire_duties import *
from code_modules.drugwork import *
from code_modules.pay_tribute import *

global driver
global lock_webdriver

def action_thread(lock_webdriver, running_thread, waiting_thread_list):
	last_click_timer = None

	# GET INITIAL RIGHT BAR DETAILS
	action_timer = get_timer(lock_webdriver, 'Action', running_thread)
	while True:
		try:
			global priority_thread_action
			if int(action_timer > 0):
				print_function('ACTION THREAD - AWAITING TIMER:' + str(action_timer))
				while action_timer > 0:
					time.sleep(1)
					action_timer -= 1
					# RESET TIMER IF REMOTE CONTROL
					if 'ResetActionTimer' in str(waiting_thread_list):
						for thread in waiting_thread_list:
							if 'ResetActionTimer' in thread:
								try:
									waiting_thread_list.remove(thread)
								except:
									pass
								action_timer = get_timer(lock_webdriver, 'Action', running_thread)

				wait_till_timer_ready(lock_webdriver, 'Action')
				print_function('ACTION THREAD ACTIVE')

			if last_click_timer != running_thread[1]:
				right_bar_details = running_thread[2]
				if right_bar_details == '':
					running_thread[2] = element_get_attribute(lock_webdriver, 'XPATH',
															  "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']",
															  'innerHTML')
					right_bar_details = running_thread[2]

				if 'Jail Rank' in right_bar_details:
					if 'In-Jail' in str(running_thread[4]):
						pass
					else:
						variables_list = running_thread[4]
						variables_list.append('In-Jail')
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR IN-JAIL: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])
				else:
					# NOT IN JAIL
					if 'In-Jail' in str(running_thread[4]):
						variables_list = running_thread[4]
						try:
							variables_list.remove('In-Jail')
						except:
							pass
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR NOT IN-JAIL: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])

						waiting_thread_list.append('9zterminate-everything')
						print_function('9zterminate-everything THREAD QUEUED' + str(waiting_thread_list), "GREEN")


				if 'In-Jail' in str(running_thread[4]):
					pass
				else:
					right_bar_line = right_bar_details.splitlines()

					rank = regex_match_between('>', '<', right_bar_line[7])
					occupation = regex_match_between('>', '<', right_bar_line[11])
					current_city = regex_match_between('>', '<', right_bar_line[21])
					current_city = current_city.replace(' ', '')
					home_city = regex_match_between('>', '<', right_bar_line[23])
					home_city = home_city.replace(' ', '')
					dirty_money = regex_match_between('>', '<', right_bar_line[18])
					dirty_money = re.sub('[^0-9]', "", dirty_money)

				last_click_timer = running_thread[1]

			if 'In-Jail' in str(running_thread[4]):
				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_earn)
				try:
					while True:
						page_check = get_url(lock_webdriver)
						if 'contraband.asp' in page_check:
							print_function(str(inspect_stack()) + ' Jail Gym - on Page')
							break
						else:
							print_function(str(inspect_stack()) + ' Jail Gym - Opening Contraband Page')
							lock_webdriver.acquire()
							random_timer = random.randrange(0, 22)
							random_timer = random_timer / 10
							time.sleep(random_timer)
							webdriver.ActionChains(driver).move_to_element(driver.find_element(By.XPATH, ".//*[@class='family']")).perform()
							random_timer = random.randrange(0, 11)
							random_timer = random_timer / 10
							time.sleep(random_timer)
							driver.find_element(By.XPATH, ".//*[@class='family']").click()
							release_webdriver(lock_webdriver)

							page_check = get_url(lock_webdriver)
							if ('duties.asp' in page_check) or ('journal.asp' in page_check) or (
									'comms.asp' in page_check) or ('contraband.asp' in page_check):
								# CORRECTLY IN JAIL
								pass
							elif ('random.asp' in page_check):
								# CAPTCHA - DO NOT COMPLETE EARN
								running_thread[1] = datetime.datetime.utcnow()

								# WAIT FOR CAPTCHA TO BE RUNNING
								while True:
									if 'captcha' in str(running_thread):
										break
									# CAPTCHA RUNNING. WAIT FOR IT TO FINISH
								while True:
									if 'captcha' in str(running_thread):
										pass
									else:
										break
								return
							else:
								# NOT IN JAIL
								if 'In-Jail' in str(running_thread[4]):
									variables_list = running_thread[4]
									try:
										variables_list.remove('In-Jail')
									except:
										pass
									running_thread[4] = variables_list
									print_function('UPDATED VARIABLES FOR NOT IN-JAIL: ' + str(running_thread[4]))
									write_file("env/variables.txt", running_thread[4])
									return

							running_thread[1] = datetime.datetime.utcnow()
							continue

					lock_webdriver.acquire()
					random_timer = random.randrange(0, 22)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					webdriver.ActionChains(driver).move_to_element(driver.find_element(By.ID, "gym")).perform()
					random_timer = random.randrange(0, 11)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					driver.find_element(By.ID, "gym").click()
					running_thread[1] = datetime.datetime.utcnow()
					release_webdriver(lock_webdriver)

					lock_webdriver.acquire()
					random_timer = random.randrange(0, 22)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					webdriver.ActionChains(driver).move_to_element(driver.find_element(By.XPATH, ".//*[@class='submit']")).perform()
					random_timer = random.randrange(0, 11)
					random_timer = random_timer / 10
					time.sleep(random_timer)
					driver.find_element(By.XPATH, ".//*[@class='submit']").click()
					release_webdriver(lock_webdriver)

					right_bar_details = element_get_attribute(lock_webdriver, 'XPATH',
															  "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']",
															  'innerHTML')
					if 'Jail Rank' in right_bar_details:
						pass
					else:
						# NOT IN JAIL
						if 'In-Jail' in str(running_thread[4]):
							variables_list = running_thread[4]
							try:
								variables_list.remove('In-Jail')
							except:
								pass
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR NOT IN-JAIL: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])
							return

					running_thread[1] = datetime.datetime.utcnow()
				except:
					pass

				action_timer = get_timer(lock_webdriver, 'Action', running_thread)
				thread_remove_from_queue(running_thread, waiting_thread_list)
			else:
				# NOT IN JAIL
				if config.getboolean('Action', 'PayTribute'):
					if pay_tribute(lock_webdriver, running_thread, waiting_thread_list, dirty_money):
						action_timer = get_timer(lock_webdriver, 'Action', running_thread)
						continue

				if current_city == home_city:
					# FIRE DUTIES
					if 'Fire' in occupation:
						if fire_duties(lock_webdriver, running_thread, waiting_thread_list):
							action_timer = get_timer(lock_webdriver, 'Action', running_thread)
							continue

					# HOME CITY ACTIONS
					if config.getboolean('Career-Mayor', 'sell_stocks'):
						if 'mayor_sell' in str(waiting_thread_list):
							mayor_sell(lock_webdriver, running_thread, waiting_thread_list)
							thread_remove_from_queue(running_thread, waiting_thread_list)
							continue
					# TRAINING INTO CAREER
					if ('Inspector' in rank) or ('Supervisor' in rank) or ('Superintendent' in rank) or ('Commissioner-General' in rank):
						pass
					else:
						if train_customs(lock_webdriver, running_thread, waiting_thread_list):
							action_timer = get_timer(lock_webdriver, 'Action', running_thread)
							continue
					if 'Fire' in occupation:
						pass
					else:
						if train_fire(lock_webdriver, running_thread, waiting_thread_list):
							action_timer = get_timer(lock_webdriver, 'Action', running_thread)
							continue
					if 'Armed Forces' in occupation:
						pass
					else:
						if train_army(lock_webdriver, running_thread, waiting_thread_list):
							action_timer = get_timer(lock_webdriver, 'Action', running_thread)
							continue
					if 'Police' in occupation:
						pass
					else:
						if train_police(lock_webdriver, running_thread, waiting_thread_list):
							action_timer = get_timer(lock_webdriver, 'Action', running_thread)
							continue
					# UNIVERSITY STUDY
					if uni_degree(lock_webdriver, running_thread, waiting_thread_list):
						action_timer = get_timer(lock_webdriver, 'Action', running_thread)
						continue
					# COMMUNITY SERVICE
					if community_service(lock_webdriver, running_thread, waiting_thread_list):
						action_timer = get_timer(lock_webdriver, 'Action', running_thread)
						continue
				else:
					# NON HOME CITY ACTIONS
					if config.getboolean('Action', 'ForeignCommunityService') or ('CS:' in str(running_thread[4])):
						if ('Gangster' in occupation) or ('Unemployed' in occupation) or ('Constable' in rank) or ('Inspector' in rank) or ('Secretary' in occupation) or ('Volunteer' in occupation) or ('Assistant' in occupation) or ('Mechanic' in occupation) or ('Nurse' in occupation) or ('Teller' in occupation):
							pass
						else:
							print("RANK: " + str(rank))
							if (community_service_non_homecity(lock_webdriver, running_thread, waiting_thread_list)):
								action_timer = get_timer(lock_webdriver, 'Action', running_thread)
								continue

				# ANY CITY ACTIONS
				# DRUGWORK
				if 'Gangster' in occupation:
					if drugwork(lock_webdriver, running_thread, waiting_thread_list):
						action_timer = get_timer(lock_webdriver, 'Action', running_thread)
						continue

			time.sleep(1)
		except:
			from code_modules.function import PrintException
			PrintException()
