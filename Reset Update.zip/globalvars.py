from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import datetime
from datetime import timezone
from multiprocessing import Process, Lock, Manager
from selenium.webdriver.support.ui import Select
import inspect
import re
from discord_webhook import DiscordWebhook
import configparser
import os
import random
from colorama import init, Fore, Style
import boto3
from boto3.dynamodb.conditions import Key, Attr
import math
from lxml import etree
from multiprocessing.managers import BaseManager
import platform
import signal
import sys
import linecache

init()


config = configparser.ConfigParser()
config.read('settings.ini')

chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
chromeurl = config['Auth']['chromedriver_path']
globals()['driver'] = webdriver.Chrome(executable_path=chromeurl, chrome_options=chrome_options)


# THREADS WILL ONLY INTERRUPT IF THEIR PRIORITY IS LOWER THAN THE RUNNING THREAD
priority_thread_captcha = 0
priority_thread_transfermoney = 1
priority_thread_messages = 1
priority_thread_onlinelist = 1
priority_thread_earn = 2
priority_thread_blackmarket = 8
priority_thread_restock = 3
priority_thread_action = 3
priority_thread_launder = 2
priority_thread_career = 4
priority_thread_travel = 7
priority_thread_agg = 7


lock_list = ['lock_webdriver']
globals()['lock_webdriver'] = Lock()


# CITIES
cities_list = {"Miami", "Dewsbury", "Sydney"}
cities_list_spaces = {"Miami", "Dewsbury", "Sydney"}

# BUSINESSES PER CITY
public_businesses = ['Airport', 'Funeral Parlour', 'Hospital', 'Fire Station', 'Bank', 'Construction Company', 'Town Hall']

private_businesses_Miami = ['Bar', 'Bionics', 'Casino', 'Tattoo Parlour', 'Vehicle Yard', 'Weapon Shop', 'Horse Racing', 'Brothel']
private_businesses_Dewsbury = ['Bar', 'Boxing', 'Hotel', 'Underground Auction', 'Drug Store', 'Gym', 'Vehicle Yard', 'Weapon Shop', 'Bionics']
private_businesses_Sydney = ['Bar', 'Bionics', 'Weapon Shop', 'Drug Store', 'Parking Lot', 'Dog Pound', 'Vehicle Yard', 'Dog Fights', 'Clothing Shop']


# 25k repay for public
torch_repay_list_50k = ['Bar', 'Hotel', 'Brothel', 'Horse Racing', 'Clothing Shop', 'Dog Fights', 'Boxing', 'Dog Pound', 'Bionics', 'Vehicle Yard', 'Weapon Shop', 'Casino', 'Tattoo Parlour', 'Drug Store'] # 'Bar', 'Hotel', 'Brothel', 'Horse Racing'
torch_repay_list_75k = ['Parking Lot', 'Underground Auction', 'Gym', 'Dog Training School', 'Old Trafford']
torch_repay_list_100k = [] # 'Clothing Shop', 'Dog Fights', 'Boxing', 'Dog Pound', 'Bionics', 'Vehicle Yard', 'Weapon Shop', 'Casino', 'Tattoo Parlour', 'Drug Store'


# WEAPON SHOP STOCK. PUT THEM IN THE ORDER LISTED IN THE SHOP
weapon_stock_Miami = ['Bat', 'Colt', 'Pistol', 'Nade', 'Shotgun', 'Sniper', 'PLASMA', 'THUNDERGUN', 'ProVest', 'KEVLAR', 'RIOTSHIELD']
weapon_stock_Dewsbury = ['Bat', 'Pistol', 'Nade', 'Shotgun', 'AK', 'Tommy', 'Sniper', 'RAILGUN', 'THUNDERGUN', 'ProVest', 'KEVLAR', 'RIOTSHIELD']
weapon_stock_Sydney = ['Bat', 'Pistol', 'Nade', 'Shotgun', 'AK', 'Sniper', 'ODL', 'THUNDERGUN', 'ProVest', 'KEVLAR', 'RIOTSHIELD']

# BIONICS SHOP STOCK. PUT THEM IN THE ORDER LISTED IN THE SHOP
bionic_stock_Miami = ['Arms', 'Legs', 'Eyes', 'BRAIN', 'HEART']
bionic_stock_Dewsbury = ['Arms', 'Legs', 'Eyes', 'BRAIN', 'HEART']
bionic_stock_Sydney = ['Arms', 'Legs', 'Eyes', 'BRAIN', 'HEART']


class timers(object):
	def __init__(self):
		self.bot_version = "3.1.1"
		self.case_timer = None
		self.event_timer = None
		self.traffic_timer = None
		self.travel_timer = None
		self.career_timer = None
		self.banker_add_clients = datetime.datetime.utcnow()
		self.launder_timer = None
		self.skill_timer = None
		self.agg_minutes = None
		self.next_online_list_timer = None
		self.city_list_timer = None
		self.consume_drugs_timer = None
		self.drugwork_timer = None
		self.blackmarket_timer = None
		self.repair_timer = None
		self.resting_page_timer = None
		self.torch_engi_list_timer = datetime.datetime.utcnow()
		self.torch_engi_online_timer = datetime.datetime.utcnow()

	def set_online_list_timer(self):
		how_many_minutes = 0
		next_timer = None
		time_minute = datetime.datetime.utcnow().minute
		if (time_minute < 30):
			how_many_minutes = (30 - time_minute)
		elif (time_minute >= 30):
			how_many_minutes = (60 - time_minute)

		next_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=how_many_minutes)
		self.next_online_list_timer = next_timer
		return


class person(object):
	def __init__(self, name):
		self.name = name
		self.total_online_hours = 0
		self.aggpro = None
		self.hack_timer = None
		self.bne_timer = None
		self.vehicle = None
		self.house = None
		self.weapon1 = None
		self.weapon2 = None
		self.bodyguard = None

	def add_online_hours(self, hours):
		self.total_online_hours = self.total_online_hours + hours
		return

	def get_online_hours(self):
		return self.total_online_hours

	def set_local_aggpro_timer(self, timer):
		self.aggpro = timer
		return

	def get_local_aggpro_timer(self):
		if self.aggpro == None:
			self.aggpro = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		return self.aggpro


	def get_house(self):
		if self.house == None:
			from code_modules.function import get_from_database
			response = get_from_database('Player', 'House', "Key('PlayerName').eq('" + str(self.name) + "')")
			try:
				return_text = response['Items'][0]['House']
			except:
				return_text = "Unknown"
			self.house = return_text
		else:
			pass
		return self.house

	def set_house(self, house):
		if str(self.house) == str(house):
			pass
		else:
			from code_modules.function import update_database
			self.house = house
			update_database('Player', 'PlayerName', str(self.name), {"House": str(house), "UpdatedBy": "set_shared_house"})
		return

	def set_local_house(self, house):
		self.house = house
		return


	def get_vehicle(self):
		if self.vehicle == None:
			from code_modules.function import get_from_database
			response = get_from_database('Player', 'Vehicle', "Key('PlayerName').eq('" + str(self.name) + "')")
			try:
				return_text = response['Items'][0]['Vehicle']
			except:
				return_text = "Unknown"
			self.vehicle = return_text
		else:
			pass
		return self.vehicle

	def set_vehicle(self, vehicle):
		if str(self.vehicle) == str(vehicle):
			pass
		else:
			from code_modules.function import update_database
			self.vehicle = vehicle
			update_database('Player', 'PlayerName', str(self.name), {"Vehicle": str(vehicle), "UpdatedBy": "set_shared_vehicle"})
		return

	def set_local_vehicle(self, vehicle):
		self.vehicle = vehicle
		return


	def set_local_hack_timer(self, timer):
		self.hack_timer = timer
		return

	def get_local_hack_timer(self):
		if self.hack_timer == None:
			self.hack_timer = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		return self.hack_timer

	def set_shared_aggpro_timer(self, timer):
		from code_modules.function import update_database

		self.aggpro = timer

		#CONVERT TIMER OBJECT TO A YYYYMMDDHHMMSS STRING
		# aggtimer_string = str(datetime.datetime.strftime(timer, '%Y%m%d%H%M%S'))

		update_database('Player', 'PlayerName', str(self.name), {"Aggpro_Personal": str(timer), "UpdatedBy": "set_shared_aggpro_timer"})
		return

	def get_shared_aggpro_timer(self):
		from code_modules.function import get_from_database

		try:
			response = get_from_database('Player', 'Aggpro_Personal', "Key('PlayerName').eq('" + str(self.name) + "')")
			return_text = response['Items'][0]['Aggpro_Personal']
			if '.' in str(return_text):
				return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S.%f')
			else:
				return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S')
		except:
			return_text = datetime.datetime.utcnow()
		self.aggpro = return_text

		return return_text

	def set_bne_timer(self, timer):
		from code_modules.function import update_database

		self.bne_timer = timer

		# CONVERT TIMER OBJECT TO A YYYYMMDDHHMMSS STRING
		# aggtimer_string = datetime.datetime.strftime(timer, '%Y%m%d%H%M%S')

		update_database('Player', 'PlayerName', str(self.name), {"Aggpro_BnE": str(timer), "UpdatedBy": "set_bne_timer"})
		return

	def set_local_bne_timer(self, timer):
		self.bne_timer = timer
		return

	def get_bne_timer(self):
		if self.bne_timer == None:
			from code_modules.function import get_from_database
			try:
				response = get_from_database('Player', 'Aggpro_BnE', "Key('PlayerName').eq('" + str(self.name) + "')")
				return_text = response['Items'][0]['Aggpro_BnE']
				if '.' in str(return_text):
					return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S.%f')
				else:
					return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S')
			except:
				return_text = datetime.datetime.utcnow()

			self.bne_timer = return_text
		return self.bne_timer

	def set_shared_hack_timer(self, timer):
		from code_modules.function import update_database
		self.hack_timer = timer

		#CONVERT TIMER OBJECT TO A YYYYMMDDHHMMSS STRING
		# aggtimer_string = datetime.datetime.strftime(timer, '%Y%m%d%H%M%S')

		update_database('Player', 'PlayerName', str(self.name), {"Aggpro_Hack": str(timer), "UpdatedBy": "set_shared_hack_timer"})
		return

	def get_shared_hack_timer(self):
		from code_modules.function import get_from_database

		try:
			response = get_from_database('Player', 'Aggpro_Hack', "Key('PlayerName').eq('" + str(self.name) + "')")
			return_text = response['Items'][0]['Aggpro_Hack']
			if '.' in str(return_text):
				return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S.%f')
			else:
				return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S')
		except:
			return_text = datetime.datetime.utcnow()

		self.hack_timer = return_text

		return return_text


class business(object):
	def __init__(self, which_city, which_business):
		# ADJUST BUSINESS NAMES FOR ONEDRIVE RECORDS
		if 'Miami' in which_city:
			city_short_string = 'MI'
		if 'Dewsbury' in which_city:
			city_short_string = 'DW'
		if 'Sydney' in which_city:
			city_short_string = 'SY'
		if 'Manchester' in which_city:
			city_short_string = 'MC'
		elif 'Toronto' in which_city:
			city_short_string = 'TO'
		elif 'RioDeJaneiro' in which_city:
			city_short_string = 'RO'
		elif 'Manila' in which_city:
			city_short_string = 'MN'

		try:
			import os
			os.makedirs('cases/' + str(city_short_string))
		except:
			pass

		if 'Funeral Parlour' in which_business:
			new_business_string = 'Funeral'
		elif 'Fire Station' in which_business:
			new_business_string = 'Fire'
		elif 'Airport' in which_business:
			new_business_string = 'Customs'
		elif 'Construction Company' in which_business:
			new_business_string = 'Construction'
		elif 'Old Trafford' in which_business:
			new_business_string = 'OldTrafford'
		elif 'Parking Lot' in which_business:
			new_business_string = 'Parking'
		elif 'Vehicle Yard' in which_business:
			new_business_string = 'Vehicle'
		elif 'Dog Training School' in which_business:
			new_business_string = 'DogTrain'
		elif 'Weapon Shop' in which_business:
			new_business_string = 'Weapon'
		elif 'Drug Store' in which_business:
			new_business_string = 'Drugstore'
		elif 'Tattoo Parlour' in which_business:
			new_business_string = 'Tattoo'
		elif 'Underground Auction' in which_business:
			new_business_string = 'Auction'
		elif 'Dog Fights' in which_business:
			new_business_string = 'Dogfights'
		elif 'Dog Pound' in which_business:
			new_business_string = 'Dogpound'
		elif 'Clothing Shop' in which_business:
			new_business_string = 'Clothing'
		else:
			new_business_string = which_business


		restock_random_timer = random.randrange(327, 927)

		self.which_city = which_city
		self.which_business = which_business
		self.aggpro = None
		self.restock_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=restock_random_timer)
		self.city_name_formatted = city_short_string
		self.business_name_formatted = new_business_string

	def get_shared_aggpro_timer(self):
		from code_modules.function import get_from_database

		which_city = str(self.which_city)
		which_city = which_city.replace(" ", "")

		which_business = str(self.which_business)
		which_business = which_business.replace(" ", "")

		try:
			response = get_from_database('Business', 'AggPro', "Key('BizName').eq('" + str(which_city) + str(which_business) + "')")
			return_text = response['Items'][0]['AggPro']
			if '.' in str(return_text):
				return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S.%f')
			else:
				return_text = datetime.datetime.strptime(return_text, '%Y-%m-%d %H:%M:%S')
		except:
			return_text = datetime.datetime.utcnow()

		self.aggpro = return_text
		return return_text

	def set_shared_aggpro_timer(self, timer):
		from code_modules.function import update_database
		self.aggpro = timer

		#CONVERT TIMER OBJECT TO A YYYYMMDDHHMMSS STRING
		# aggtimer_string = datetime.datetime.strftime(timer, '%Y%m%d%H%M%S')

		which_city = str(self.which_city)
		which_city = which_city.replace(" ", "")

		which_business = str(self.which_business)
		which_business = which_business.replace(" ", "")

		update_database('Business', 'BizName', str(which_city) + str(which_business), {"AggPro": str(timer), "City": str(which_city), "Business": str(which_business)})
		return

	def get_local_aggpro_timer(self):
		if self.aggpro == None:
			self.aggpro = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		return self.aggpro

	def set_local_aggpro_timer(self, timer):
		self.aggpro = timer
		return


class city(object):
	def __init__(self, which_city, public_businesses, private_businesses):
		if 'Miami' in which_city:
			city_short_string = 'MI'
		if 'Dewsbury' in which_city:
			city_short_string = 'DW'
		if 'Sydney' in which_city:
			city_short_string = 'SY'
		if 'Manchester' in which_city:
			city_short_string = 'MC'
		elif 'Toronto' in which_city:
			city_short_string = 'TO'
		elif 'RioDeJaneiro' in which_city:
			city_short_string = 'RO'
		elif 'Manila' in which_city:
			city_short_string = 'MN'

		self.city_short_string = city_short_string
		self.which_city = which_city

		for this_business in public_businesses:
			self.__dict__[this_business] = business(which_city, this_business)
			pass
		for this_business in private_businesses:
			self.__dict__[this_business] = business(which_city, this_business)
			pass

	def get_dict(self, dict_name):
		return self.__dict__[dict_name]

	def get_local_aggpro_timer(self, which_business):
		return self.__dict__[which_business].get_local_aggpro_timer()

	def set_local_aggpro_timer(self, which_business, timer):
		return self.__dict__[which_business].set_local_aggpro_timer(timer)

	def get_shared_aggpro_timer(self, which_business):
		return self.__dict__[which_business].get_shared_aggpro_timer()

	def set_shared_aggpro_timer(self, which_business, timer):
		return self.__dict__[which_business].set_shared_aggpro_timer(timer)


for current_city in cities_list:
	print("checking city: " + str(current_city))
	globals()[current_city] = city(current_city, public_businesses, globals()['private_businesses_' + current_city])
	print("globals done: " + str(current_city))
	for current_business in public_businesses:
		print("checking biz: " + str(current_business))
		globals()[current_city].current_business = current_business
	print("biz done: " + str(current_city))


globals()['timers'] = timers()


'''
testvar = 'Toronto'
testvar2 = 'Bank'
testvar3 = 'city_name_formatted'
testvar4 = 'business_name_formatted'
print(testvar, testvar2, testvar3, ' is: ', globals()[testvar].__dict__[testvar2].__dict__[testvar3])
'''



def log_agg_time():
	agg_time_string = str(datetime.datetime.utcnow().hour) + ":" + str(datetime.datetime.utcnow().minute) + ":" + str(
		datetime.datetime.utcnow().second)
	return str(agg_time_string)


def aggstr_percent_modify(mins):
	mins = int(mins)
	if mins < 3:
		modifier = 0
	elif mins == 3:
		modifier = 2
	elif mins == 4:
		modifier = 2.7
	elif mins == 5:
		modifier = 3.3
	elif mins == 6:
		modifier = 5
	elif mins == 7:
		modifier = 5.8
	elif mins == 8:
		modifier = 6.7
	elif mins == 9:
		modifier = 7.5
	elif mins == 10:
		modifier = 8.3
	elif mins == 11:
		modifier = 9.2
	elif mins == 12:
		modifier = 13.3
	elif mins == 13:
		modifier = 14.4
	elif mins == 14:
		modifier = 15.6
	elif mins == 15:
		modifier = 16.7
	elif mins == 16:
		modifier = 17.8
	elif mins == 17:
		modifier = 18.9
	elif mins == 18:
		modifier = 30
	elif mins == 19:
		modifier = 31.7
	elif mins == 20:
		modifier = 33.3
	elif mins == 21:
		modifier = 35
	elif mins == 22:
		modifier = 36.7
	elif mins == 23:
		modifier = 38.3
	elif mins == 24:
		modifier = 53.3
	elif mins == 25:
		modifier = 55.6
	elif mins == 26:
		modifier = 57.8
	elif mins == 27:
		modifier = 60
	elif mins == 28:
		modifier = 62.2
	elif mins == 29:
		modifier = 64.4
	elif mins > 29:
		modifier = 100

	modifier = modifier / 100
	return modifier


# onedrive_test = open(config['Auth']['database_path'] + "/ProTimes/Business/" + globals()[testvar].__dict__[testvar2].__dict__[testvar3] + "/" + globals()[testvar].__dict__[testvar2].__dict__[testvar4] + ".txt", "r")
# print(onedrive_test.read())
#onedrive_test.close()

# print(Toronto.Bank.get_local_aggpro_timer())
# input('done')


# DEFINE ALL GLOBAL VARIABLES AND DECLARE AS BLANK. THESE WILL HAVE VALUES ASSIGNED AT RUNTIME VIA MAIN.PY - set_globals()
global thread_transfer_money
globals()['thread_transfer_money'] = []

global thread_action
globals()['thread_action'] = []

global thread_earn
globals()['thread_earn'] = []

global thread_misc
globals()['thread_misc'] = []

global thread_captcha
globals()['thread_captcha'] = []

global waiting_thread_list
globals()['waiting_thread_list'] = []

global running_thread
globals()['running_thread'] = []

global all_agg_targets
globals()['all_agg_targets'] = []
