from globalvars import *
from code_modules.function import *


def get_case_index(lock_webdriver, your_character_name, case_count):
	case_index = 2
	skip_case_blacklist = config['Career-Judge']['Skip_Cases_On_Player']
	while True:
		if (case_index > case_count):
			print_function('MISC - JUDGE - NO DOABLE CASES')
			break
		else:
			case_number = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/table/tbody/tr[" + str(case_index) + "]/td[1]/label", "innerHTML")

			case_type = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/table/tbody/tr[" + str(case_index) + "]/td[2]/label", "innerHTML")

			case_suspect = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/table/tbody/tr[" + str(case_index) + "]/td[3]/label", "innerHTML")
			case_suspect = regex_match_between('username=', '">', case_suspect)

			case_victim = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/table/tbody/tr[" + str(case_index) + "]/td[4]/label", "innerHTML")
			case_victim = regex_match_between('username=', '">', case_victim)

			print_function('JUDGE - CASE: ' + case_number + ' SUSPECT:' + case_suspect + ' VICTIM:' + case_victim)

			skip_this_case = False

			# SKIP GBH & WHACKING- SHOULD BE DONE MANUALLY
			if ('Dog Whack' in case_type) or ('Whacking' in case_type) or ('WHACKING' in case_type) or ('GBH' in case_type):
				skip_this_case = True

			if (case_suspect == your_character_name) or (case_victim == your_character_name):
				print_function('JUDGE - CASE: ' + case_number + ' SKIP AS YOU ARE SUSPECT OR VICTIM')
				skip_this_case = True

			for blacklist_name in skip_case_blacklist:
				if blacklist_name == case_suspect:
					print_function('MISC - JUDGE - SKIPPING BLACKLISTED PERSON: ' + str(blacklist_name) + ' FOR CASE:' + case_number)
					skip_this_case = True
					break

			if skip_this_case:
				pass
			else:
				return case_index
		case_index += 1
	return False


def check_name_change(casesuspect):
	name_change_string = ""

	previousname = ""

	text_file = open(config['Auth']['database_path'] + '/Records/NameChange.txt', "r")
	names = text_file.readlines()
	text_file.close()

	check_names_again = True
	while True:
		if check_names_again:
			check_names_again = False
			for name in names:
				if ('from' in name):
					oldname = regex_match_between('from ', ' to', name)
					newname = regex_match_between('to ', ' on', name)

					if (newname == casesuspect) or (newname == previousname):
						if oldname in name_change_string:
							# THIS NAME ALREADY RECORDED
							pass
						else:
							previousname = oldname
							name_change_string = name_change_string + oldname + " "
							check_names_again = True
							break
				else:
					# SKIP BLANK LINES
					pass
		else:
			break


	return name_change_string

def judge(lock_webdriver, running_thread, waiting_thread_list, your_character_name, boys_list):
	if config.getboolean('Career-Judge', 'Do_Cases'):
		print_function('MISC - JUDGE - ADDED TO QUEUE')
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)

		print_function('MISC - JUDGE START')
		go_to_page(lock_webdriver, 'Judge', running_thread)
		case_count = element_count(lock_webdriver, "NAME", "case")
		if ( case_count  >  1 ):
			# CHECK VIABLE CASES EXIST
			case_index = get_case_index(lock_webdriver, your_character_name, case_count)

			if not case_index:
				# SET NEW CASE TIMER
				random_timer = random.randrange(366, 742)
				globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
				print_function('MISC - JUDGE - FINISHED')
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return

			# SET HIGH PRIORITY SO NOT INTERRUPTED
			running_thread[0] = str('1') + inspect.stack()[0][3]
			
			case_number = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/table/tbody/tr[" + str(case_index) + "]/td[1]/label", "innerHTML")

			case_suspect = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/table/tbody/tr[" + str(case_index) + "]/td[3]/label", "innerHTML")
			case_suspect = regex_match_between('username=', '">', case_suspect)

			case_victim = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/table/tbody/tr[" + str(case_index) + "]/td[4]/label", "innerHTML")
			case_victim = regex_match_between('username=', '">', case_victim)
			
			element_click(lock_webdriver, 'XPATH', ".//input[@id='" + str(case_number) + "']", running_thread)
			click_continue(lock_webdriver, running_thread)


			# DO THE CASE
			casenumber = ''
			crime = ''
			pd = ''
			victim = ''
			victim_statement = ''
			suspect = ''
			location = ''
			date_time = ''
			casenotes = ''
			dna = ''
			fingerprint = ''
			witnessstatement = ''
			forensic = ''
			forensiccheck = ''
			fingerprintsuspect = ''
			fingerprintevidence = ''
			fingerprintsuspectlength = ''
			dnasuspect = ''
			dnaevidence = ''
			dnasuspectlength = ''
			previousname = ''
			namechangestring = ''
			suspect_dead = "No"

			name_change_string = check_name_change(case_suspect)

			XPathCount = 9
			# evidence starts at 9
			while True:
				if element_found(lock_webdriver, "XPATH", ".//*[@id='pd']/div/table/tbody/tr[" + str(XPathCount) + "]/td[1]/b"):
					print("CHECKING: ", XPathCount)
					evidence = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='pd']/div/table/tbody/tr[" + str(XPathCount) + "]/td[1]/b", "innerHTML")
					print("EVIDENCE: ", evidence)
					if evidence == 'Evidence':
						XPathCount += 1
						continue
					evidencevalue = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='pd']/div/table/tbody/tr[" + str(XPathCount) + "]/td[2]", "innerHTML")
					print("EVIDENCE: ", evidence, " EVIDENCEVALUE: ", evidencevalue)

					if 'DNA' in evidence:
						if 'None' in evidencevalue:
							pass
							# DO NOTHING AS NO VALUE
						else:
							dna = evidencevalue

						# CHECK IF DNA NO VALUE
						dnacheck = re.sub('[^a-zA-Z]', "", dna)
						if dnacheck == "":
							dna = ""

					if 'Fingerprint' in evidence:
						if 'None' in evidencevalue:
							# DO NOTHING AS NO VALUE
							pass
						else:
							fingerprint = evidencevalue

					if 'Forensic' in evidence:
						if 'investigated the case' in evidencevalue:
							forensic = evidencevalue

					if 'Witness Statement' in evidence:
						witnessstatement = evidencevalue

					if 'Suspect' in evidence:
						suspect = regex_match_between('">', '<', evidencevalue)
						print("EXAMINE EVIDENCE - SUSPECT: ", suspect, " FORENSIC: ", forensic, " FINGERPRINT: ", fingerprint, " DNA:", dna)
						break
				XPathCount += 1
			# END OF EXAMINE EVIDENCE

			# ***************************
			# **** GRAB CASE DETAILS ****
			# ***************************

			casenumber = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='pd']/div/table/tbody/tr[1]/td[2]", "innerHTML")
			casenumber = casenumber.replace("#", "")

			crime = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='pd']/div/table/tbody/tr[1]/td[4]", "innerHTML")
			pd = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='pd']/div/table/tbody/tr[2]/td[2]", "innerHTML")
			victim = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='pd']/div/table/tbody/tr[5]/td[2]/a", "innerHTML")
			victimstatement = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='pd']/div/table/tbody/tr[6]/td[2]", "innerHTML")
			location = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='pd']/div/table/tbody/tr[2]/td[4]", "innerHTML")
			date_time = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='pd']/div/table/tbody/tr[3]/td[2]", "innerHTML")
			casenotes = element_get_attribute(lock_webdriver, "NAME", "notes", "innerHTML")

			# REMOVE CRAZY FORMATTING
			if '<br>' in victimstatement:
				victimstatement = victimstatement.replace("<br>", "")
			if '<br>' in casenotes:
				casenotes = casenotes.replace("<br>", "")
			if 'br>' in casenotes:
				casenotes = casenotes.replace("br>", "")

			if fingerprint != "":
				if 'owner could be' in fingerprint:
					fingerprintsuspect = regex_match_between('owner could be,', None, fingerprint)
					# The fingerprint revealed the owner could be, Elyzea, Katherina.

					suspectinfingerprint = "No"
					if ',' in fingerprintsuspect:
						fingerprint_names = fingerprintsuspect.split(',')
						for currentfingerprint in fingerprint_names:
							currentfingerprint = re.sub('[^a-zA-Z0-9_-]', "", currentfingerprint)
							if suspect == currentfingerprint:
								suspectinfingerprint = "Yes"

						if suspectinfingerprint == "Yes":
							fingerprintsuspect = suspect
						else:
							print_function("PREVIOUS NAMES: " + namechangestring, "RED")
							print_function("FINGERPRINT DOES NOT MATCH SUSPECT")
							correct_suspect = "No"

						fingerprintsuspect = re.sub('[^a-zA-Z0-9_-]', "", fingerprintsuspect)
						fingerprintsuspectlength = len(fingerprintsuspect)
					else:
						fingerprint = ""
						fingerprintsuspect = re.sub('[^a-zA-Z0-9_-]', "", fingerprintsuspect)
						fingerprintsuspectlength = len(fingerprintsuspect)

			if dna != "":
				if 'The DNA revealed' in dna:
					dnasuspect = regex_match_between('The DNA revealed', 'was at the crime scene!', dna)
					dnasuspect = re.sub('[^a-zA-Z0-9_-]', "", dnasuspect)
					dnasuspectlength = len(dnasuspect)
				else:
					dna = ""

			print_function("CASE:" + casenumber + " CRIME:" + crime + " PD:" + pd + " LOCATION:" + location + " DATETIME:" + date_time + " VICTIM:" + victim + " SUSPECT:" + suspect + " FINGERPRINT:" + fingerprint + " DNA:" + dna, "BLUE")
			print_function("VICTIM STATEMENT: " + victimstatement, "BLUE")
			print_function("WITNESS STATEMENT: " + witnessstatement, "BLUE")
			print_function("CASE NOTES: " + casenotes, "BLUE")

			# **************************
			# **** CHECK CASE LOGIC ****
			# **************************

			correctsuspect = "No"

			# FINGERPRINT
			if fingerprintsuspect != "":
				suspectcompare = ""
				print('fingerprintsuspect: ', fingerprintsuspect, ' length: ', fingerprintsuspectlength)
				suspectcompare = fingerprintsuspect[-int(fingerprintsuspectlength):]
				if fingerprintsuspect == suspectcompare:
					correctsuspect = "Yes"
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " FINGERPRINT CORRECT", "BLUE")
				else:
					correctsuspect = "No"
					print_function("JUDGE - FINGERPRINT DOES NOT MATCH: " + fingerprintsuspect + " VS: " + suspectcompare, "RED")

			# DNA
			if dnasuspect != "":
				suspectcompare = ""
				print('dnasuspect: ', dnasuspect, ' length: ', dnasuspectlength)
				suspectcompare = dnasuspect[-int(dnasuspectlength):]
				if dnasuspect == suspectcompare:
					correctsuspect = "Yes"
					print_function("JUDGE - DNA: " + dnasuspect + " VS: " + suspectcompare)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " DNA CORRECT", "BLUE")
				else:
					correctsuspect = "No"
					print_function("JUDGE - DNA DOES NOT MATCH: " + dnasuspect + " VS: " + suspectcompare, "RED")


			# WITNESS STATEMENT
			if 'ended with' in witnessstatement:
				suspectcompare = ""
				suspect = suspect.replace(":", "")
				suspect = suspect.replace(".", "")

				witnessseensuspect = regex_match_between('ended with', '\.', witnessstatement)

				witnessseensuspect = witnessseensuspect.replace(" ended with", "")
				witnessseensuspect = re.sub('[^a-zA-Z0-9_-]', "", witnessseensuspect)
				endednamelength = len(witnessseensuspect)

				suspectcompare = suspect[-int(endednamelength):]
				if suspectcompare == witnessseensuspect:
					correctsuspect = "Yes"
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " WITNESS STATEMENT SEEN SUSPECT", "BLUE")
				else:
					print_function("JUDGE - WITNESS STATEMENT DOES NOT MATCH: " + witnessseensuspect + " VS: " + suspectcompare, "RED")


			# VICTIM STATEMENT
			if 'ended with' in victimstatement:
				suspectcompare = ""
				suspect = suspect.replace(":", "")
				suspect = suspect.replace(".", "")

				if 'They managed' in victimstatement:
					victimseensuspect = regex_match_between('ended with', 'They', victimstatement)
				else:
					victimseensuspect = regex_match_between('ended with', None, victimstatement)

				victimseensuspect = victimseensuspect.replace(" ended with", "")
				victimseensuspect = re.sub('[^a-zA-Z0-9_-]', "", victimseensuspect)
				endednamelength = len(victimseensuspect)

				suspectcompare = suspect[-int(endednamelength):]
				if suspectcompare == victimseensuspect:
					correctsuspect = "Yes"
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " VICTIM SEEN SUSPECT", "BLUE")
				else:
					print_function("JUDGE - VICTIM WITNESS DOES NOT MATCH: " + victimseensuspect + " VS: " + suspectcompare, "RED")

			# VICTIM STATEMENT IN NOTES
			if 'Statement made by' in casenotes:
				if suspect in casenotes:
					correctsuspect = "Yes"
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " SUSPECT IN CASE NOTES", "BLUE")

			# FORENSIC EVIDENCE ENDED WITH
			if 'ended with' in forensic:
				forensicsuspect = ""
				forensiccompare = ""
				forensicsuspect = regex_match_between('ended with', '!', forensic)
				forensicsuspect = re.sub('[^a-zA-Z0-9_-]', "", forensicsuspect)
				forensiclength = len(forensicsuspect)

				forensiccompare = suspect[-int(forensiclength):]
				if forensiccompare == forensicsuspect:
					correctsuspect = "Yes"
					print_function("JUDGE - FORENSICS: " + forensicsuspect + " VS: " + forensiccompare)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " FORENSICS CORRECT", "BLUE")
				else:
					correctsuspect = "No"
					print_function("JUDGE - FORENSIC ENDED WITH: DOES NOT MATCH: " + forensicsuspect + " VS: " + forensiccompare, "RED")

			# FORENSIC
			if 'name is' in forensic:
				forensicsuspect = ""
				forensiccompare = ""
				forensicsuspect = regex_match_between('name is', '!', forensic)
				forensicsuspect = re.sub('[^a-zA-Z0-9_-]', "", forensicsuspect)
				forensiclength = len(forensicsuspect)

				forensiccompare = suspect[-int(forensiclength):]
				if forensiccompare == forensicsuspect:
					correctsuspect = "Yes"
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " FORENSIC MATCH", "BLUE")
				else:
					correctsuspect = "No"
					print_function("JUDGE - FORENSIC NAME IS: DOES NOT MATCH: " + forensicsuspect + " VS: " + forensiccompare, "RED")

			# ADMIN CHECK
			if pd == 'Administrator':
				# ADMIN ALWAYS CORRECT
				correctsuspect = "Yes"
				print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " ADMIN ALWAYS CORRECT", "BLUE")

			# CHECK CASE NOTES
			for currententry in casenotes.split("`n"):
				print_function("JUDGE - CURRENTENTRY RAW: " + currententry)
				currententryblankcheck = re.sub('[^a-zA-Z0-9]', "", currententry)
				currententry = re.sub("`a", "", currententry)  # REMOVE NEW LINES
				currententry = re.sub("AM|PM|\-", "", currententry)
				currententry = re.sub("\d\d/\d\d/\d\d\d\d", "", currententry) # REMOVE DATE DOUBLE
				currententry = re.sub("\d\d:\d\d:\d\d", "", currententry) # REMOVE TIME DOUBLE
				currententry = re.sub("\d/\d\d/\d\d\d\d", "", currententry) # REMOVE MONTH SINGLE
				currententry = re.sub("\d\d/\d/\d\d\d\d", "", currententry) # REMOVE DATE SINGLE
				currententry = re.sub("\d/\d/\d\d\d\d", "", currententry) # REMOVE DATE SINGLE
				currententry = re.sub("\d:\d\d:\d\d", "", currententry) # REMOVE TIME SINGLE

				if 'Time of Death' in currententry:
					# REMOVE AUTOPSY RESULTS
					currententry = re.sub("(Mortician Assistant|Mortician|Undertaker|Funeral Director) \w+ established Time of Death as being", "", currententry)

				currententry = re.sub("Statement made by " + victim + " to the police on", "", currententry)
				currententry = re.sub("Request for fire investigation sent by (Constable|Sergeant|Senior Sergeant|Detective|Commissioner) \w+", "", currententry)
				currententry = re.sub("Body sent to Morgue for Autopsy by (Constable|Sergeant|Senior Sergeant|Detective|Commissioner) \w+", "", currententry)
				currententry = re.sub("Crime scene swabbed for DNA by (Constable|Sergeant|Senior Sergeant|Detective|Commissioner) \w+", "", currententry)
				currententry = re.sub("Case Returned by (Constable|Sergeant|Senior Sergeant|Detective|Commissioner) \w+", "", currententry)
				currententry = re.sub("Crime scene dusted for prints by (Constable|Sergeant|Senior Sergeant|Detective|Commissioner) \w+", "", currententry)
				currententry = re.sub("Case Updated by (Constable|Sergeant|Senior Sergeant|Detective|Commissioner) \w+", "", currententry)
				currententry = re.sub("Case Closed for sentencing by (Constable|Sergeant|Senior Sergeant|Detective|Commissioner) \w+", "", currententry)
				currententry = re.sub(pd, "", currententry)
				currententry = re.sub("Boss", "", currententry)
				currententry = re.sub("Case auto closed for sentencing by &lt;&lt;", "", currententry)
				currententry = re.sub('[^a-zA-Z0-9 _-]', "", currententry)
				print("JUDGE - CURRENTENTRY FORMATTED: ", currententry)

				if 'Report requested from the victim by' in currententry:
					currententry = ""

				if 'Case auto closed for sentencing' in currententry:
					casenotes = ""
					currententry = ""

				# REMOVE ONLINE LIST
				if '|' in currententry:
					if suspect in currententry:
						currententry = ""

				currententry = re.sub(suspect, "", currententry)

				# REMOVE 911
				if victim in currententry:
					if 'B&E' in currententry:
						currententry = re.sub("B&E", "", currententry)
						currententry = re.sub(victim, "", currententry)

				if 'ia frame' in currententry:
					correctsuspect = "No"
					currententry = re.sub("ia frame", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " IA FRAME", "BLUE")

				if 'Not Guilty' in currententry:
					correctsuspect = "No"
					currententry = re.sub("Not Guilty", "", currententry)
					currententry = re.sub("not guilty", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES Not Guilty", "BLUE")

				if 'NOT GUILTY' in currententry:
					correctsuspect = "No"
					currententry = re.sub("NOT GUILTY", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES NOT GUILTY", "BLUE")

				if 'NG' in currententry:
					correctsuspect = "No"
					currententry = re.sub("NG", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES NG", "BLUE")

				if '50/50' in currententry:
					correctsuspect = "No"
					currententry = re.sub("50/50", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES 50/50", "BLUE")

				if 'Ng' in currententry:
					correctsuspect = "No"
					currententry = re.sub("Ng", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES Ng", "BLUE")

				if 'bold ng' in currententry:
					correctsuspect = "No"
					currententry = re.sub("bold ng", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES bold ng", "BLUE")

				if 'Guilty' in currententry:
					correctsuspect = "Yes"
					currententry = re.sub("Guilty", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES Guilty", "BLUE")

				if 'GUILTY' in currententry:
					correctsuspect = "Yes"
					currententry = re.sub("GUILTY", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES GUILTY", "BLUE")

				if 'guilty' in currententry:
					correctsuspect = "Yes"
					currententry = re.sub("guilty", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES guilty", "BLUE")

				if 'Guity' in currententry:
					correctsuspect = "Yes"
					currententry = re.sub("Guity", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES Guity", "BLUE")

				if 'BOLD' in currententry:
					correctsuspect = "No"
					currententry = re.sub("BOLD", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES BOLD", "BLUE")

				if 'GOLD' in currententry:
					correctsuspect = "No"
					currententry = re.sub("GOLD", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES GOLD", "BLUE")

				if 'Gold' in currententry:
					correctsuspect = "No"
					currententry = re.sub("Gold", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTE Gold", "BLUE")

				if 'Bold' in currententry:
					correctsuspect = "No"
					currententry = re.sub("Bold", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES Bold", "BLUE")

				if 'br&gt;' in currententry:
					currententry = re.sub("br&gt;", "", currententry)

				if 'ng' in currententry:
					correctsuspect = "No"
					currententry = re.sub("ng", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES ng", "BLUE")

				if 'DEAD - MAX' in currententry:
					correctsuspect = "Yes"
					currententry = re.sub("DEAD - MAX", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES DEAD - MAX", "BLUE")
					suspect_dead = "Yes"

				currententry = re.sub('[^a-zA-Z]', "", currententry)

				if ('g' == currententry) or ('G' == currententry):
					correctsuspect = "Yes"
					currententry = re.sub("g", "", currententry)
					print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " CASE NOTES g", "BLUE")

				currententryblankcheck = re.sub('[^a-zA-Z0-9]', "", currententry)

				# if currententryblankcheck != "":
				# send {PgDn}
				# WHAT DOES THIS DO?

			print_function("CORRECT SUSPECT: " + correctsuspect, "BLUE")

			# TOO RISKY TO MAX ON DEAD NAMES. SOME GET REUSED
			'''
			deadnames = read_file(config['Auth']['database_path'] + '/Records/Deaths.txt')
			if suspect in deadnames:
				correctsuspect = "Yes"
				suspect_dead = "Yes"
				print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " SUSPECT DEAD", "BLUE")
			'''

			not_guilty_list = config['Career-Judge']['Additional_Not_Guilty_List']
			if suspect in not_guilty_list:
				correctsuspect = "No"
				print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " SUSPECT IN NG LIST", "BLUE")

			if config.getboolean('Career-Judge', 'Not_Guilty_Bolds'):
				for files in os.walk(config['Auth']['database_path'] + "/Records/BoldList/"):
					for file in files[2]:
						bold_name = file.replace(".txt", "")
						if suspect == bold_name:
							print_function('JUDGE - NG BOLD ' + str(bold_name))
							correctsuspect = "No"
							print_function("JUDGE - CORRECTSUSPECT: " + correctsuspect + " SUSPECT IS BOLD", "BLUE")
							break

			# ********************
			# **** SENTENCING ****
			# ********************

			if correctsuspect == "No":
				select_dropdown_option(lock_webdriver, "NAME", "verdict", "Not Guilty")
			elif correctsuspect == "Yes":
				select_dropdown_option(lock_webdriver, "NAME", "verdict", "Guilty")
			click_continue(lock_webdriver, running_thread)

			if correctsuspect == "Yes":
				fine = ""
				if suspect_dead == 'Yes':
					print_function('MISC - JUDGE - FINISHED')
					fine = 99999
				elif suspect in boys_list:
					fine = 1000
					print_function("JUDGE - BOYS: " + suspect + " MIN FINE", "BLUE")
				elif crime == 'Pickpocket':
					fine = config['Career-Judge']['Pickpocket']
				elif crime == 'MUGGING':
					fine = config['Career-Judge']['Mug']
				elif crime == 'Hacking':
					fine = config['Career-Judge']['Hack']
				elif crime == 'Breaking &amp; Entering':
					fine = config['Career-Judge']['BnE']
				elif crime == 'Armed Robbery':
					fine = config['Career-Judge']['ArmedRobbery']
				elif crime == 'GTA':
					fine = config['Career-Judge']['GTA']
				elif crime == 'Torch':
					fine = config['Career-Judge']['Torch']
				else:
					input("JUDGE - CRIME NOT FOUND: " + crime)

				sendkeys(lock_webdriver, "NAME", "fine", fine)

				if suspect_dead == 'Yes':
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)
				else:
					sendkeys(lock_webdriver, "NAME", "communityservice", Keys.DOWN)

				if suspect_dead == 'Yes':
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)
				else:
					sendkeys(lock_webdriver, "NAME", "sentence", Keys.DOWN)

				click_continue(lock_webdriver, running_thread)

			globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Case'))
		else:
			print_function('MISC - JUDGE - NO CASES')
			# SET NEW CASE TIMER
			random_timer = random.randrange(366, 742)
			globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)

		print_function('MISC - JUDGE - FINISHED')
		thread_remove_from_queue(running_thread, waiting_thread_list)
	return