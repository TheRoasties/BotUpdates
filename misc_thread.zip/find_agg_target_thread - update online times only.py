from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

global driver
global lock_webdriver

__all__ = ["find_agg_target_thread", "do_pickpocket_thread", "do_pickpockets"]

globals()['all_pickpocket_targets'] = []


def aggstr_percent_modify(mins):
    mins = int(mins)
    if mins < 3:
        modifier = 0
    elif mins == 3:
        modifier = 2
    elif mins == 4:
        modifier = 2.7
    elif mins == 5:
        modifier = 3.3
    elif mins == 6:
        modifier = 5
    elif mins == 7:
        modifier = 5.8
    elif mins == 8:
        modifier = 6.7
    elif mins == 9:
        modifier = 7.5
    elif mins == 10:
        modifier = 8.3
    elif mins == 11:
        modifier = 9.2
    elif mins == 12:
        modifier = 13.3
    elif mins == 13:
        modifier = 14.4
    elif mins == 14:
        modifier = 15.6
    elif mins == 15:
        modifier = 16.7
    elif mins == 16:
        modifier = 17.8
    elif mins == 17:
        modifier = 18.9
    elif mins == 18:
        modifier = 30
    elif mins == 19:
        modifier = 31.7
    elif mins == 20:
        modifier = 33.3
    elif mins == 21:
        modifier = 35
    elif mins == 22:
        modifier = 36.7
    elif mins == 23:
        modifier = 38.3
    elif mins == 24:
        modifier = 53.3
    elif mins == 25:
        modifier = 55.6
    elif mins == 26:
        modifier = 57.8
    elif mins == 27:
        modifier = 60
    elif mins == 28:
        modifier = 62.2
    elif mins == 29:
        modifier = 64.4
    elif mins > 29:
        modifier = 100

    modifier = modifier / 100
    return modifier


def get_all_targets_online_hours(pickpocket_list_manager):
    '''
    port_file = open("env/ServerPort.txt", "r")
    port_number = port_file.read()
    port_file.close()
    '''

    '''
    manager = BaseManager(address=('127.0.0.1', 5000))
    BaseManager.register('person', person)

    while True:
        try:
            manager.connect()
            break
        except:
            print('failed to connect - trying again')
    '''


    online_checked_file = open("env/OnlineHoursChecked.txt", "r")
    online_records = online_checked_file.read()
    online_checked_file.close()

    online_hours_file = open("env/OnlineHoursTotal.txt", "r")
    online_hours_dictionary = online_hours_file.read()
    online_hours_file.close()

    online_hours_dictionary = eval(online_hours_dictionary)
    '''
    for name in online_hours_dictionary:
        # THESE TARGETS WILL ALL BE NEW AS COMBINED TOTAL HOURS RECORD
        aggtarget_person_list_manager[name] = manager.person(name)
        aggtarget_person_list_manager[name].add_online_hours(online_hours_dictionary[name])
        globals()['all_pickpocket_targets'].append(name)
    '''


    for subdir, dirs, files in os.walk(config['Auth']['database_path'] + "/Records/OnlineTimes/"):
        for file in files:
            # print os.path.join(subdir, file)
            filepath = subdir + os.sep + file
            filepath = re.sub(r'\\', "/", filepath)

            filepath_check = re.search(rf'OnlineTimes(.*)', filepath)
            if (str(filepath_check.group(1)) in online_records):
                print('skipping ', filepath)
                continue

            if filepath.endswith("0.txt"):
                text_file = open(filepath, "r")
                return_text = text_file.read()
                names_split = return_text.split(" | ")

                for name in names_split:
                    '''
                    # TRY / EXCEPT AS A WAY TO TEST IF CLASS OBJECT DEFINED
                    try:
                        aggtarget_person_list_manager[name].add_online_hours(1)
                    except:
                        aggtarget_person_list_manager[name] = manager.person(name)
                        aggtarget_person_list_manager[name].add_online_hours(1)
                        globals()['all_pickpocket_targets'].append(name)
                    '''


                    ### TEMP BEGIN FOR FILE UPDATE ONLY ###
                    if name in online_hours_dictionary:
                        online_hours_dictionary[name] += 1
                    else:
                        online_hours_dictionary[name] = 1
                        globals()['all_pickpocket_targets'].append(name)
                    ### TEMP END FOR FILE UPDATE ONLY ###


                print('total online hours - processed ', filepath)

                '''
                online_hours_dictionary = {}
                for record_name in  globals()['all_pickpocket_targets']:
                    if (record_name == ''):
                        continue

                    online_hours_dictionary[record_name] = aggtarget_person_list_manager[record_name].get_online_hours()
                '''


                online_checked_file = open("env/OnlineHoursTotal.txt", "w")
                online_checked_file.write(str(online_hours_dictionary))
                online_checked_file.close()

                online_checked_file = open("env/OnlineHoursChecked.txt", "a")
                online_checked_file.write(str(filepath))
                online_checked_file.write('\n')
                online_checked_file.close()

                text_file.close()
    print('all online hours records added')


    # ADD NAME CHANGE HOURS
    text_file = open(config['Auth']['database_path'] + "/Records/" + "NameChange.txt", "r")
    rename_list = text_file.readlines()
    text_file.close()

    for line in rename_list:
        if 'Name change from' not in line:
            continue
        old_name = regex_match_between('from ', ' to', line)
        new_name = regex_match_between('to ', ' on', line)

        # OLD NAME MAY HAVE BEEN DELETED
        try:
            old_name_hours = pickpocket_list_manager[old_name].get_online_hours()
        except:
            old_name_hours = 0

        # NEW NAME MAY NOT EXIST IN THE RECORDS YET
        try:
            new_name_hours = pickpocket_list_manager[new_name].get_online_hours()
        except:
            new_name_hours = 0

        total_hours = int(old_name_hours) + int(new_name_hours)
        print('OLD NAME: ', old_name, 'OLDHOURS: ', old_name_hours, " NEWNAME: ", new_name, " NEWHOURS: ", new_name_hours, " TOTALHOURS: ", total_hours)
        if old_name in online_hours_dictionary:
            del online_hours_dictionary[old_name]
            online_hours_dictionary[new_name] = total_hours
    online_checked_file = open("env/OnlineHoursTotal.txt", "w")
    online_checked_file.write(str(online_hours_dictionary))
    online_checked_file.close()

    return


def add_pickpocket_targets_to_arrays(lock_webdriver, pickpocket_list_manager):
    # CREATE LISTS
    count = 3
    while count < 31:
        globals()['pickpocket_targets_minute' + str(count)] = []
        count += 1

    # DO CALCULATION
    your_hours = pickpocket_list_manager[get_your_character_name(lock_webdriver)].get_online_hours()

    for name in globals()['all_pickpocket_targets']:
        their_hours = pickpocket_list_manager[name].get_online_hours()

        our_aggstr_mins = 29
        while True:
            our_aggstr = math.ceil( your_hours * float(aggstr_percent_modify(our_aggstr_mins)) )
            their_aggstr = math.floor( their_hours * float(config['Pickpocket']['PPAggstrModify']) )

            if (our_aggstr_mins <= 2) or (their_aggstr >= our_aggstr):
                # APPLY LOCAL MODIFIERS TO TARGET REQUIRED MINS
                mins_adjusted = int(our_aggstr_mins) + 1

                if os.path.isfile('./agg_targets/pickpocket/' + name + '.txt'):
                    text_file = open('./agg_targets/pickpocket/' + name + '.txt', "r")
                    adjust_value = text_file.read()
                    if adjust_value == '':
                        adjust_value = 0
                    mins_adjusted = int(mins_adjusted) + int(adjust_value)
                    text_file.close()

                if int(mins_adjusted) > 30:
                    mins_adjusted = 30
                elif int(mins_adjusted) < 3:
                    mins_adjusted = 3

                globals()['pickpocket_targets_minute' + str(mins_adjusted)].append(name)
                break

            our_aggstr_mins -= 1
    return


def get_aggstr_mins(lock_webdriver):
    aggstr_percent = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_bar'][4]/div[@class='progress-bar bg-energy']", "innerHTML")
    aggstr_percent = float(aggstr_percent.replace('%', ''))

    if aggstr_percent >= 99:
        aggstr_mins_max = 30
    elif aggstr_percent >= 64:
        aggstr_mins_max = 29
    elif aggstr_percent >= 62:
        aggstr_mins_max = 28
    elif aggstr_percent >= 60:
        aggstr_mins_max = 27
    elif aggstr_percent >= 57:
        aggstr_mins_max = 26
    elif aggstr_percent >= 55:
        aggstr_mins_max = 25
    elif aggstr_percent >= 53:
        aggstr_mins_max = 24
    elif aggstr_percent >= 38:
        aggstr_mins_max = 23
    elif aggstr_percent >= 36:
        aggstr_mins_max = 22
    elif aggstr_percent >= 35:
        aggstr_mins_max = 21
    elif aggstr_percent >= 33:
        aggstr_mins_max = 20
    elif aggstr_percent >= 31:
        aggstr_mins_max = 19
    elif aggstr_percent >= 30:
        aggstr_mins_max = 18
    elif aggstr_percent >= 18:
        aggstr_mins_max = 17
    elif aggstr_percent >= 17:
        aggstr_mins_max = 16
    elif aggstr_percent >= 16:
        aggstr_mins_max = 15
    elif aggstr_percent >= 15:
        aggstr_mins_max = 14
    elif aggstr_percent >= 14:
        aggstr_mins_max = 13
    elif aggstr_percent >= 13:
        aggstr_mins_max = 12
    elif aggstr_percent >= 9:
        aggstr_mins_max = 11
    elif aggstr_percent >= 8:
        aggstr_mins_max = 10
    elif aggstr_percent >= 7:
        aggstr_mins_max = 9
    elif aggstr_percent >= 6:
        aggstr_mins_max = 8
    elif aggstr_percent >= 5.5:
        aggstr_mins_max = 7
    elif aggstr_percent >= 5:
        aggstr_mins_max = 6
    elif aggstr_percent >= 3:
        aggstr_mins_max = 5
    elif aggstr_percent >= 2.5:
        aggstr_mins_max = 4
    elif aggstr_percent >= 2:
        aggstr_mins_max = 3
    else:
        aggstr_mins_max = 0

    return aggstr_mins_max


def get_pickpocket_list_currentcity(lock_webdriver):
    # CLEAR SAVED NAMES
    online_player_list_currentcity = []

    # GETS FULL LIST OF NAMES
    while True:
        online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
        if '|' in online_player_list_raw:
            break

    is_local_list_only = True
    if '*' in online_player_list_raw:
        is_local_list_only = False

    online_player_list_raw_split = online_player_list_raw.split("|")
    for player_raw in online_player_list_raw_split:
        if ':Alive:player:' in player_raw:
            if is_local_list_only or ('*' in player_raw):
                player_name = regex_match_between('>', '<', player_raw)

                skip_this_pickpocket_target = False
                pickpocket_blacklist = config['Pickpocket']['Pickpocket_Blacklist'].split()
                for blacklist_name in pickpocket_blacklist:
                    if blacklist_name == player_name:
                        print('PICKPOCKET - SKIP BLACKLIST TARGET: ', player_name)
                        skip_this_pickpocket_target = True

                if skip_this_pickpocket_target:
                    pass
                else:
                    online_player_list_currentcity.append(player_name)

    return online_player_list_currentcity


def check_pickpocket_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, pickpocket_list, aggstr_min_checking, pickpocket_list_manager):
    viable_pickpocket_targets = []

    '''
    port_file = open("env/ServerPort.txt", "r")
    port_number = port_file.read()
    port_file.close()
    '''
    manager = BaseManager(address=('127.0.0.1', 5000))
    BaseManager.register('person', person)

    while True:
        try:
            manager.connect()
            break
        except:
            print('failed to connect - trying again')

    for pickpocket_target in pickpocket_list:
        if (your_character_name == pickpocket_target) or ('' == pickpocket_target) or (pickpocket_target in config['Pickpocket']['Pickpocket_Blacklist']):
            continue

        if pickpocket_target in globals()['all_pickpocket_targets']:
            pass
        else:
            # NEW PICKPOCKET TARGET
            pickpocket_list_manager[pickpocket_target] = manager.person(pickpocket_target)
            pickpocket_list_manager[pickpocket_target].add_online_hours(1)
            globals()['all_pickpocket_targets'].append(pickpocket_target)
            globals()['pickpocket_targets_minute3'].append(pickpocket_target)

        if pickpocket_target in globals()['pickpocket_targets_minute' + str(aggstr_min_checking)]:
            # PASSED MINUTES REQUIREMENT
            aggpro_timer = pickpocket_list_manager[pickpocket_target].get_aggpro_timer()
            time_difference = datetime.datetime.utcnow() - aggpro_timer
            if not '-' in str(time_difference):
                # PASSED AGGPRO
                viable_pickpocket_targets.append(pickpocket_target)
                # print('PICKPOCKET: ', pickpocket_target, " MINS REQUIRED: ", aggstr_min_checking, " AGGPRO: ", aggtarget_person_list_manager[pickpocket_target].get_aggpro_timer())

    if viable_pickpocket_targets == []:
        pass
    else:
        print('viable pickpocket targets - ', viable_pickpocket_targets, aggstr_min_checking)
        do_pickpockets(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, pickpocket_list_manager)
    return




def do_pickpockets(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, pickpocket_list_manager):
    thread_pickpocket = Process(target=do_pickpocket_thread, name='PickpocketThread',
                                    args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, pickpocket_list_manager))
    thread_pickpocket.start()

    # WAIT TILL THREAD STARTED
    print('PICKPOCKET - WAITING FOR THREAD TO BE RUNNING')
    while True:
        if 'pickpocket' in str(waiting_thread_list):
            break
    print('PICKPOCKET - THREAD RUNNING')
    return


def do_pickpocket_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, pickpocket_list_manager):
    import multiprocessing
    text_file = open("env/PickpocketPID.txt", "w")
    text_file.write(str(multiprocessing.current_process().pid))
    text_file.close()

    thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_pickpocket_targets)

    for target in viable_pickpocket_targets:
        # RETURN PRIORITY TO NORMAL
        running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]
        print('PICKPOCKET THREAD PRIORITY: ', running_thread[0])

        go_to_page(lock_webdriver, "Pickpocket")

        lock_webdriver.acquire()
        driver.find_element(By.NAME, 'pickpocket').clear()
        release_webdriver(lock_webdriver)

        sendkeys(lock_webdriver, "NAME", "pickpocket", target)
        sendkeys(lock_webdriver, "NAME", "pickpocket", Keys.ESCAPE)

        # INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
        running_thread[0] = str('1') + inspect.stack()[0][3]
        print('PICKPOCKET PRIORITY: ', running_thread[0])
        click_continue(lock_webdriver)

        # AGG DONE - GET RESULTS
        agg_results = None
        if element_found(lock_webdriver, "ID", "fail"):
            agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
        elif element_found(lock_webdriver, "ID", "success"):
            agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
        else:
            input('NO AGG RESULTS FOUND')

        # AGG DONE - EXAMINE RESULTS
        if "doesn't exist" in agg_results:
            print('Pickpocket Results - Target ', target, " Doesn't Exist")
            random_timer = random.randrange(60, 90)
            agg_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
            pickpocket_list_manager[target].set_local_aggpro_timer(agg_timer)
            continue

        elif ('same city' in agg_results) or ('must be online' in agg_results) or ('recently survived' in agg_results):
            print('Pickpocket Results - Target ', target, "has pro or not found")
            random_timer = random.randrange(590, 915)
            agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
            pickpocket_list_manager[target].set_local_aggpro_timer(agg_timer)
            continue

        elif ('failed' in agg_results) or ('ran off' in agg_results):
            print('Pickpocket Results - Target ', target, ' FAILED')
            last_agg_time[0] = datetime.datetime.utcnow()

            agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=2)
            pickpocket_list_manager[target].set_shared_aggpro_timer(agg_timer)

            # UPDATE LOCAL MODIFIERS
            try:
                text_file = open('./agg_targets/pickpocket/' + target + '.txt', "r")
                mins_adjusted = int(text_file.read())
                text_file.close()
            except:
                mins_adjusted = 0

            mins_adjusted += 2

            text_file = open('./agg_targets/pickpocket/' + target + '.txt', "w")
            text_file.write(str(mins_adjusted))
            text_file.close()

            # ADD TO RECORDS
            text_file = open('./records/Pickpocket.txt', "a")
            text_file.write("\nPickpocket FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
            text_file.close()

            text_file = open('./records/AllAggs.txt', "a")
            text_file.write("\nPickpocket FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
            text_file.close()

            # REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
            thread_remove_from_queue(running_thread, waiting_thread_list)
            return


        elif ('You pickpocketed' in agg_results):
            print('Pickpocket Results - Target ', target, ' SUCCESS', " AGG: ", agg_results)
            last_agg_time[0] = datetime.datetime.utcnow()

            agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=2)
            pickpocket_list_manager[target].set_shared_aggpro_timer(agg_timer)

            # UPDATE LOCAL MODIFIERS
            try:
                text_file = open('./agg_targets/pickpocket/' + target + '.txt', "r")
                mins_adjusted = int(text_file.read())
                text_file.close()
            except:
                mins_adjusted = 0

            mins_adjusted -= 1

            text_file = open('./agg_targets/pickpocket/' + target + '.txt', "w")
            text_file.write(str(mins_adjusted))
            text_file.close()

            # ADD TO RECORDS
            text_file = open('./records/Pickpocket.txt', "a")
            text_file.write("\nPickpocket SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
            text_file.close()

            text_file = open('./records/AllAggs.txt', "a")
            text_file.write("\nPickpocket SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
            text_file.close()

            # REPAY CHECKS
            repay = True
            if not config.getboolean('Pickpocket', 'Repay'):
                print('Pickpocket - Repay - TURNED OFF')
                repay = False

            repay_blacklist = config['Pickpocket']['Repay_Blacklist'].split()
            for blacklist_name in repay_blacklist:
                if target == blacklist_name:
                    print('Pickpocket - Repay - TARGET IS BLACKLISTED: ', target)
                    repay = False

            repay_whitelist = config['Pickpocket']['Repay_Whitelist'].split()
            for whitelist_name in repay_whitelist:
                if target == whitelist_name:
                    print('Pickpocket - Repay - TARGET IS WHITELISTED: ', target)
                    repay = True

            if repay:
                repay_amount = regex_match_between('\$', '!', agg_results)
                repay_amount = re.sub('[^0-9]', "", repay_amount)

                print('Pickpocket - Repaying ', repay_amount, ' TO ', target)
                # ADD REPAY TO RECORDS
                text_file = open('./records/Pickpocket.txt', "a")
                text_file.write("\n Pickpocket - Repaying " + repay_amount + " TO " + target)
                text_file.close()

                text_file = open('./records/AllAggs.txt', "a")
                text_file.write("\n Pickpocket - Repaying " + repay_amount + " TO " + target)
                text_file.close()

                if int(repay_amount) > 0:
                    transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target)

                    # WAIT FOR TRANSFER TO BE QUEUED
                    print('Pickpocket - Waiting for repay to be queued')
                    while True:
                        if 'transfer_money_thread' in str(waiting_thread_list):
                            break
                    print('Pickpocket - repay is queued')

            # REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
            thread_remove_from_queue(running_thread, waiting_thread_list)
            return

        else:
            print('pickpocket - results not found', agg_results)
            input('pickpocket - results not found')

    thread_remove_from_queue(running_thread, waiting_thread_list)
    return



def find_agg_target_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, pickpocket_list_manager):
    get_all_targets_online_hours(pickpocket_list_manager)
    add_pickpocket_targets_to_arrays(lock_webdriver, pickpocket_list_manager)

    # GET INITIAL AGGPRO
    last_agg_time[0] = datetime.datetime.utcnow() - datetime.timedelta(minutes=get_aggstr_mins(lock_webdriver))
    aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
    if (aggstr_mins_max > 30):
        aggstr_mins_max = 30

    aggstr_min_checking = 0

    your_character_name = get_your_character_name(lock_webdriver)


    while True:
        if (aggstr_min_checking <= 0):
            aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
            if (aggstr_mins_max > 30):
                aggstr_mins_max = 30

            pickpocket_list = get_pickpocket_list_currentcity(lock_webdriver)
            aggstr_min_checking = int(aggstr_mins_max)

            # LIST OF ALL MINS. START AT HIGHEST AND WORK DOWN. REMOVE FROM THE LIST WHEN CHECKED - THIS IS TO MANAGE THE THREAD STILL RUNNING WHILE
            count = int(aggstr_mins_max)
            pickpocket_min_to_check_list = []
            while True:
                pickpocket_min_to_check_list.append(count)
                count -= 1
                if (count < 3):
                    break


        if (aggstr_min_checking > 2):
            # AGGS HERE IN ORDER OF PRIORITY
            if 'pickpocket' in str(waiting_thread_list):
                pass
            elif (int(pickpocket_min_to_check_list[0]) == int(aggstr_min_checking)):
                print('PICKPCOKET CHECKING HIGHEST MIN: ', pickpocket_min_to_check_list[0], ' OUT OF: ', pickpocket_min_to_check_list)

                check_pickpocket_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, pickpocket_list, aggstr_min_checking, pickpocket_list_manager)

                # REMOVE HIGHEST MINUTE AS ALREADY CHECKED
                pickpocket_min_to_check_list.pop(0)

        aggstr_min_checking -= 1
        time.sleep(1)

