from globalvars import *
from code_modules.function import *

global driver
global lock_webdriver


def captcha_thread(lock_webdriver, running_thread, waiting_thread_list):
	while True:
		try:
			#### UPDATE SETTINGS SINCE CAPTCHA THREAD ALWAYS RUNNING ####
			config.read('settings.ini')

			url_check = get_url(lock_webdriver)

			if element_found(lock_webdriver, "ID", "top_bar"):
				try:
					page_check = element_get_attribute(lock_webdriver, "ID", "top_bar", "innerHTML")
				except:
					page_check = ""
			else:
				page_check = ""
				
			#### BROKEN PAGE CHECK ####
			broken_page_check = element_get_attribute(lock_webdriver, "XPATH", "/html/body", "innerHTML")
			if "HTTP Error 503. The service is unavailable." in str(broken_page_check):
				discord_message(
					config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + '@here Broken Page (Service Unavailable) - TV: ' +
					config['Auth']['teamviewer_details'])
				time.sleep(3000)

			#### ADMIN SCRIPT CHECK ####
			script_check_found = False
			if (("activity" in str(page_check)) or ("Test" in str(page_check)) or ('test.asp' in str(url_check))):
				script_check_found = True
			elif element_found(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/div[1]/div[2]/center/font[3]"):
				test_string = element_get_attribute(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/div[1]/div[2]/center/font[3]", "innerHTML")
				if ('first' in str(test_string.lower())) and ('characters' in str(test_string.lower())):
					script_check_found = True

			if script_check_found:
				discord_message(
					config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + '@here ADMIN SCRIPT CHECK - TV: ' +
					config['Auth']['teamviewer_details'])

				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_captcha)
				print_function("ADMIN SCRIPT CHECK - START", "RED")

				# Get Text
				test_string = element_get_attribute(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/div[1]/div[2]/center/font[3]", "innerHTML")
				discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - TEXT: " + str(test_string))
				discord_message("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - TEXT: " + str(test_string))

				if ( ("first" in str(test_string)) and ("characters" in str(test_string)) ):
					# X CHARACTERS IN STRING
					total_chars_required = 0
					total_chars_required = int(regex_match_between("first", "characters", test_string))

					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - CHARS REQUIRED: " + str(total_chars_required))
					discord_message("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - CHARS REQUIRED: " + str(total_chars_required))

					if total_chars_required < 1:
						discord_message(
							config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + '@here ADMIN SCRIPT CHECK FAILED, SOMEONE HELP - TV: ' + config['Auth'][
								'teamviewer_details'])
						discord_error(config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + '@here ADMIN TEST TEXT: ' + str(test_string))

					# Reply with the first 9 characters of the following text: IuGTUuFRRYYyYUyTG<br>
					# Type the first 6 characters: hlshglwye<br>
					if 'the following text' in str(test_string):
						the_string = regex_match_between("the following text: ", "<br>", test_string)
					else:
						the_string = regex_match_between("characters: ", "<br>", test_string)
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - STRING: " + str(the_string))

					# GET SUBSTRING
					string_to_send = the_string[0:total_chars_required]
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - STRING TO SEND: " + str(string_to_send))

					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - SENDING KEYS: " + str(string_to_send))
					sendkeys(lock_webdriver, "XPATH", ".//*[@class='input']", str(string_to_send))
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - KEYS SENT: " + str(string_to_send))
					element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - CLICKED CONTINUE")
				elif ( ("+" in str(test_string)) and ("(number)" in str(test_string)) ):
					# SCRIPT CHECK - ADDITION TYPE
					first_number = regex_match_between("What is ", "+", test_string)
					first_number = re.sub('[^0-9]', "", first_number)
					second_number = regex_match_between("+", "? (number)", test_string)
					second_number = re.sub('[^0-9]', "", second_number)
					string_to_send = int(first_number) + int(second_number)

					sendkeys(lock_webdriver, "XPATH", ".//*[@class='input']", str(string_to_send))
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - KEYS SENT: " + str(string_to_send))
					element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - CLICKED CONTINUE")
				elif ( ( 'What is ' in str(test_string)) and (' divided by ' in str(test_string)) and ('Answer with a number' in str(test_string)) ):
					# SCRIPT CHECK - DIVISION TYPE
					first_number = regex_match_between("What is ", "divided by", test_string)
					first_number = re.sub('[^0-9]', "", first_number)
					second_number = regex_match_between("divided by", "? Answer", test_string)
					second_number = re.sub('[^0-9]', "", second_number)
					string_to_send = int(first_number) / int(second_number)

					sendkeys(lock_webdriver, "XPATH", ".//*[@class='input']", str(string_to_send))
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - KEYS SENT: " + str(string_to_send))
					element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
					discord_error("ADMIN SCRIPT CHECK " + config['Auth']['discord_id'] + " - CLICKED CONTINUE")
				else:
					discord_message(config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + '@here ADMIN SCRIPT CHECK FAILED, SOMEONE HELP - TV: ' + config['Auth']['teamviewer_details'])
					while True:
						time.sleep(30)



				# CHECK RESULTS
				if element_found(lock_webdriver, "ID", "success"):
					test_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
					discord_message("ADMIN SCRIPT CHECK - RESULTS: " + str(test_results))
				else:
					discord_message(config['Auth']['discord_id'] + get_your_character_name(lock_webdriver) + '@here ADMIN SCRIPT CHECK FAILED, SOMEONE HELP - TV: ' + config['Auth'][
										'teamviewer_details'])

				if "verified" in test_results:
					discord_message(
						config['Auth']['discord_id'] + get_your_character_name(lock_webdriver) + '@here ADMIN SCRIPT CHECK PASSED')
					print_function("ADMIN SCRIPT CHECK - PASSED", "RED")
				else:
					print_function("CAPTCHA THREAD INTENTIONALLY PAUSED - DID SCRIPT CHECK WORK?", "RED")
					while True:
						time.sleep(30)

			#### BLANK PAGE CHECK ####
			elif 'rndcnt' in url_check:
				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_captcha)
				print_function('CAPTCHA - BLANK PAGE', "RED")
				go_back(lock_webdriver)
				open_city(lock_webdriver, running_thread)
				continue

			#### LOGGED IN CHECK ####
			elif ('default.asp' in url_check) or (str(url_check) == 'mafiamatrix.com'):
				# FALSE POSITIVES SOMETIMES? RECHECK
				time.sleep(1)
				while True:
					if 'LoggedOut' in str(waiting_thread_list):
						print("LOGGED OUT VARIABLE SET")
						time.sleep(10)
						continue
					else:
						break


				if element_found(lock_webdriver, "XPATH",
								 "//*[@class='input-group input-group-lg'][1]/input[@id='email']"):
					thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_captcha)
					print_function('GAME IS LOGGED OUT - WAITING THREADS: ' + str(waiting_thread_list), "RED")

					discord_message(config['Auth']['discord_id'] + ' IS LOGGED OUT - TV: ' + config['Auth']['teamviewer_details'])

					clearkeys(lock_webdriver, "XPATH",".//*[@class='input-group input-group-lg'][1]/input[@id='email']")
					sendkeys(lock_webdriver, 'XPATH', ".//*[@class='input-group input-group-lg'][1]/input[@id='email']", config['Auth']['username'])
					clearkeys(lock_webdriver, "XPATH",".//*[@class='input-group input-group-lg'][2]/input[@id='pass']")
					sendkeys(lock_webdriver, 'XPATH', ".//*[@class='input-group input-group-lg'][2]/input[@id='pass']", config['Auth']['password'])

					# DO CAPTCHA LOGGED OUT
					if element_found(lock_webdriver, "XPATH", ".//*[@class='recaptcha-random']"):
						print_function("CAPTCHA TYPE - RECAPTCHA", "GREEN")
						element_click(lock_webdriver, 'XPATH', ".//*[@class='recaptcha-random']", running_thread)

						recaptcha_tick_element_found = False
						while True:
							globals()['driver'] = webdriver.Chrome(executable_path=chromeurl, chrome_options=chrome_options)
							try:
								# RECAPTCHA
								driver.switch_to.frame(driver.find_element(By.XPATH, "//*[@class='g-recaptcha']/div/div/iframe"))
								time.sleep(2)
							except:
								pass

							print('on captcha tick iframe')
							ids = driver.find_elements(By.XPATH, "//*[@class]")
							for ii in ids:
								if 'recaptcha-checkbox-checkmark' in (ii.get_attribute('class')):
									print('CAPTCHA - WAITING FOR TICK')
									recaptcha_tick_element_found = True

									discord_message_sent = False
									start_time_check = time.time()

									while True:
										# TEST IF THIS WORKS TO FIND THE TICK
										if 'style' in ii.get_attribute('outerHTML'):
											print('CAPTCHA - TICK FOUND')
											if discord_message_sent:
												discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA PASSED')
											break
										else:
											time.sleep(2)

											if not discord_message_sent:
												elapsed_time_check = time.time() - start_time_check
												if elapsed_time_check >= 15:
													discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth'][
														'teamviewer_details'])
													discord_message_sent = True

								if recaptcha_tick_element_found:
									# BREAK THE UNNECESSARY FOR LOOP
									break

							if recaptcha_tick_element_found:
								# BREAK THE LOOK FOR CAPTCHA FRAME
								break
							else:
								print(Fore.RED + 'RECAPTCHA TICK BOX ELEMENT NOT FOUND ON THIS FRAME. TRY AGAIN')
								print(Style.RESET_ALL)
								driver.switch_to.default_content()
								time.sleep(2)
					# RECAPTCHA END

					# HCAPTCHA
					elif element_found(lock_webdriver, "XPATH", ".//*[@class='h-captcha']"):
						print_function("CAPTCHA TYPE - RECAPTCHA", "HCAPTCHA")
						element_click(lock_webdriver, 'XPATH', ".//*[@class='h-captcha']", running_thread)

						recaptcha_tick_element_found = False
						while True:
							globals()['driver'] = webdriver.Chrome(executable_path=chromeurl, chrome_options=chrome_options)
							try:
								# HCAPTCHA
								driver.switch_to.frame(driver.find_element(By.XPATH, ".//*[@class='h-captcha']/iframe"))
								time.sleep(2)
							except:
								pass

							print_function('on captcha tick iframe')
							ids = driver.find_elements(By.XPATH, "//*[@class]")
							try:
								for ii in ids:
									if 'checkbox-tc' in (ii.get_attribute('class')):
										print_function('CAPTCHA - WAITING FOR TICK')
										recaptcha_tick_element_found = True

										discord_message_sent = False
										start_time_check = time.time()

										while True:
											# TEST IF THIS WORKS TO FIND THE TICK
											try:
												# if 'You are verified' in ii.get_attribute('outerHTML'):
												if 'checkbox checked' in ii.get_attribute('outerHTML'):
													print_function('CAPTCHA - TICK FOUND')
													if discord_message_sent:
														discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA PASSED')
													break
												else:
													time.sleep(2)

													if not discord_message_sent:
														elapsed_time_check = time.time() - start_time_check
														if elapsed_time_check >= 15:
															discord_message(
																config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth'][
																	'teamviewer_details'])
															discord_message_sent = True
											except:
												discord_message(
													config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth']['teamviewer_details'])
												break
									else:
										print_function('CAPTCHA - ON FRAME - OBJECT ' + str(ii.get_attribute('class')) + "--" + str(ii.get_attribute('outerHTML')))

									if recaptcha_tick_element_found:
										# BREAK THE UNNECESSARY FOR LOOP
										break
							except:
								discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth']['teamviewer_details'])

							if recaptcha_tick_element_found:
								# BREAK THE LOOK FOR CAPTCHA FRAME
								break
							else:
								print_function('RECAPTCHA TICK BOX ELEMENT NOT FOUND ON THIS FRAME. TRY AGAIN', "RED")
								driver.switch_to.default_content()
								time.sleep(2)
					# HCAPTCHA END

					# RECAPTCHA SECOND METHOD
					elif element_found(lock_webdriver, "XPATH", ".//*[@class='g-recaptcha']"):
						print_function("CAPTCHA TYPE - RECAPTCHA SECOND", "GREEN")

						element_click(lock_webdriver, 'XPATH', ".//*[@class='g-recaptcha']/div/div/iframe", running_thread)
						print_function("CAPTCHA RECAPTCHA SECOND - CLICKED", "GREEN")

						recaptcha_tick_element_found = False
						while True:
							globals()['driver'] = webdriver.Chrome(executable_path=chromeurl, chrome_options=chrome_options)
							try:
								# RECAPTCHA
								driver.switch_to.frame(driver.find_element(By.XPATH, "//*[@class='g-recaptcha']/div/div/iframe"))
								time.sleep(2)
							except:
								pass

							print('on captcha tick iframe')
							ids = driver.find_elements(By.XPATH, "//*[@class]")
							for ii in ids:
								if 'recaptcha-checkbox-checkmark' in (ii.get_attribute('class')):
									print('CAPTCHA - WAITING FOR TICK')
									recaptcha_tick_element_found = True

									discord_message_sent = False
									start_time_check = time.time()

									while True:
										# TEST IF THIS WORKS TO FIND THE TICK
										if 'style' in ii.get_attribute('outerHTML'):
											print('CAPTCHA - TICK FOUND')
											if discord_message_sent:
												discord_message(config['Auth']['discord_id'] + ' IMAGE CAPTCHA PASSED')
											break
										else:
											time.sleep(2)

											if not discord_message_sent:
												elapsed_time_check = time.time() - start_time_check
												if elapsed_time_check >= 15:
													discord_message(config['Auth']['discord_id'] + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth'][
														'teamviewer_details'])
													discord_message_sent = True

								if recaptcha_tick_element_found:
									# BREAK THE UNNECESSARY FOR LOOP
									break

							if recaptcha_tick_element_found:
								# BREAK THE LOOK FOR CAPTCHA FRAME
								break
							else:
								print(Fore.RED + 'RECAPTCHA TICK BOX ELEMENT NOT FOUND ON THIS FRAME. TRY AGAIN')
								print(Style.RESET_ALL)
								driver.switch_to.default_content()
								time.sleep(2)

					else:
						discord_error("NO CAPTCHA METHOD FOUND")
					# RECAPTCHA SECOND METHOD END

					# CHANGE BACK TO MAIN FRAME
					driver.switch_to.default_content()
					time.sleep(2)
					print_function('CAPTCHA - CHANGED BACK TO DEFAULT FRAME')
					# END OF DO CAPTCHA

					# CLICK SIGN IN
					if element_found(lock_webdriver, "XPATH", "//*[@class ='btn btn-lg btn-danger btn-block btn-login none']"):
						element_click(lock_webdriver, "XPATH", "//*[@class ='btn btn-lg btn-danger btn-block btn-login none']", running_thread)
					elif element_found(lock_webdriver, "XPATH", ".//*[@class='btn btn-lg btn-danger btn-block btn-login christmas']"):
						element_click(lock_webdriver, "XPATH", ".//*[@class='btn btn-lg btn-danger btn-block btn-login christmas']", running_thread)
					elif element_found(lock_webdriver, "XPATH", ".//*[@class='btn btn-lg btn-danger btn-block btn-login easter']"):
						element_click(lock_webdriver, "XPATH", ".//*[@class='btn btn-lg btn-danger btn-block btn-login easter']", running_thread)
					elif element_found(lock_webdriver, "XPATH", ".//*[@class='btn btn-lg btn-danger btn-block btn-login halloween']"):
						element_click(lock_webdriver, "XPATH", ".//*[@class='btn btn-lg btn-danger btn-block btn-login halloween']", running_thread)
					else:
						# NO LOGIN BUTTON FOUND
						print_function('CAPTCHA - LOGGED OUT - NO LOGIN BUTTON FOUND')
						quit()
						
					if element_found(lock_webdriver, "XPATH", "//*[@class ='btn none btn-primary btn-lg btn-play alive text-shadow']"):
						if 'In-Jail' in str(running_thread[4]):
							variables_list = running_thread[4]
							try:
								variables_list.remove('In-Jail')
							except:
								pass
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR NOT IN-JAIL: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])
						element_click(lock_webdriver, "XPATH", "//*[@class ='btn none btn-primary btn-lg btn-play alive text-shadow']", running_thread)

					if element_found(lock_webdriver, "XPATH", "//*[@class='btn none btn-primary btn-lg btn-play in-jail text-shadow']"):
						if 'In-Jail' in str(running_thread[4]):
							pass
						else:
							variables_list = running_thread[4]
							variables_list.append('In-Jail')
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR IN-JAIL: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])

							waiting_thread_list.append('9zterminate-everything')
							print_function('9zterminate-everything THREAD QUEUED' + str(waiting_thread_list), "GREEN")
						element_click(lock_webdriver, "XPATH", "//*[@class='btn none btn-primary btn-lg btn-play in-jail text-shadow']", running_thread)
					discord_message(config['Auth']['discord_id'] + ' LOGGED IN')
					continue

			#### CHECK CAPTCHA ####
			elif ("Random" in page_check) or ('random.asp' in url_check):
				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_captcha)
				print_function('CAPTCHA FOUND - CAPTCHA THREAD ACTIVE')
				your_character_name = get_your_character_name(lock_webdriver)

				# RECAPTCHA
				if element_found(lock_webdriver, "XPATH", ".//*[@class='recaptcha-random']"):
					element_click(lock_webdriver, 'XPATH', ".//*[@class='recaptcha-random']", running_thread)

					recaptcha_tick_element_found = False
					while True:
						globals()['driver'] = webdriver.Chrome(executable_path=chromeurl, chrome_options=chrome_options)
						try:
							# RECAPTCHA
							driver.switch_to.frame(driver.find_element(By.XPATH, "//*[@class='g-recaptcha']/div/div/iframe"))
							time.sleep(2)
						except:
							pass

						print('on captcha tick iframe')
						ids = driver.find_elements(By.XPATH, "//*[@class]")
						for ii in ids:
							if 'recaptcha-checkbox-checkmark' in (ii.get_attribute('class')):
								print('CAPTCHA - WAITING FOR TICK')
								recaptcha_tick_element_found = True

								discord_message_sent = False
								start_time_check = time.time()
								stale_element_count = 0

								while True:
									try:
										# TEST IF THIS WORKS TO FIND THE TICK
										if 'style' in ii.get_attribute('outerHTML'):
											print('CAPTCHA - TICK FOUND')
											if discord_message_sent:
												discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA PASSED')
											if stale_element_count > 0:
												discord_error("CAPTCHA THREAD - STALE ELEMENT COUNT " + str(stale_element_count) + " - WORKED")
											break
										else:
											time.sleep(2)

											if not discord_message_sent:
												elapsed_time_check = time.time() - start_time_check
												if elapsed_time_check >= 15:
													discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth'][
														'teamviewer_details'])
													discord_message_sent = True
									except Exception as except_error:
										if 'stale element reference' in str(except_error):
											stale_element_count += 1
											print_function("CAPTCHA THREAD - STALE ELEMENT COUNT " + str(stale_element_count) + " - RETRYING")
											if stale_element_count > 10:
												discord_message(config['Auth']['discord_id'] + str(your_character_name) + " CAPTCHA FROZE ON STALE ELEMENT - TV: ' + config['Auth']['teamviewer_details']")
												while True:
													time.sleep(30)
										else:
											raise Exception(except_error)

							if recaptcha_tick_element_found:
								# BREAK THE UNNECESSARY FOR LOOP
								break

						if recaptcha_tick_element_found:
							# BREAK THE LOOK FOR CAPTCHA FRAME
							break
						else:
							print(Fore.RED + 'RECAPTCHA TICK BOX ELEMENT NOT FOUND ON THIS FRAME. TRY AGAIN')
							print(Style.RESET_ALL)
							driver.switch_to.default_content()
							time.sleep(2)

						# RECAPTCHA END

				# HCAPTCHA
				elif element_found(lock_webdriver, "XPATH", ".//*[@class='h-captcha']"):
					element_click(lock_webdriver, 'XPATH', ".//*[@class='h-captcha']", running_thread)

					recaptcha_tick_element_found = False
					while True:
						globals()['driver'] = webdriver.Chrome(executable_path=chromeurl, chrome_options=chrome_options)
						try:
							# HCAPTCHA
							driver.switch_to.frame(driver.find_element(By.XPATH, ".//*[@class='h-captcha']/iframe"))
							time.sleep(2)
						except:
							pass

						print_function('on captcha tick iframe')
						ids = driver.find_elements(By.XPATH, "//*[@class]")
						try:
							for ii in ids:
								if 'checkbox-tc' in (ii.get_attribute('class')):
									print_function('CAPTCHA - WAITING FOR TICK')
									recaptcha_tick_element_found = True

									discord_message_sent = False
									start_time_check = time.time()

									while True:
										# TEST IF THIS WORKS TO FIND THE TICK
										try:
											# if 'You are verified' in ii.get_attribute('outerHTML'):
											if 'checkbox checked' in ii.get_attribute('outerHTML'):
												print_function('CAPTCHA - TICK FOUND')
												if discord_message_sent:
													discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA PASSED')
												break
											else:
												time.sleep(2)

												if not discord_message_sent:
													elapsed_time_check = time.time() - start_time_check
													if elapsed_time_check >= 15:
														discord_message(
															config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth']['teamviewer_details'])
														discord_message_sent = True
										except:
											discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth']['teamviewer_details'])
											break
								else:
									print_function('CAPTCHA - ON FRAME - OBJECT ' + str(ii.get_attribute('class')) + "--" + str(ii.get_attribute('outerHTML')))

								if recaptcha_tick_element_found:
									# BREAK THE UNNECESSARY FOR LOOP
									break
						except:
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth']['teamviewer_details'])

						if recaptcha_tick_element_found:
							# BREAK THE LOOK FOR CAPTCHA FRAME
							break
						else:
							print_function('RECAPTCHA TICK BOX ELEMENT NOT FOUND ON THIS FRAME. TRY AGAIN', "RED")
							driver.switch_to.default_content()
							time.sleep(2)
					# HCAPTCHA END

				# RECAPTCHA SECOND METHOD
				elif element_found(lock_webdriver, "XPATH", ".//*[@class='g-recaptcha']"):
					print_function("CAPTCHA TYPE - RECAPTCHA SECOND", "GREEN")

					element_click(lock_webdriver, 'XPATH', ".//*[@class='g-recaptcha']/div/div/iframe", running_thread)
					print_function("CAPTCHA RECAPTCHA SECOND - CLICKED", "GREEN")

					recaptcha_tick_element_found = False
					while True:
						globals()['driver'] = webdriver.Chrome(executable_path=chromeurl, chrome_options=chrome_options)
						try:
							# RECAPTCHA
							driver.switch_to.frame(driver.find_element(By.XPATH, "//*[@class='g-recaptcha']/div/div/iframe"))
							time.sleep(2)
						except:
							pass

						print('on captcha tick iframe')
						ids = driver.find_elements(By.XPATH, "//*[@class]")
						for ii in ids:
							if 'recaptcha-checkbox-checkmark' in (ii.get_attribute('class')):
								print('CAPTCHA - WAITING FOR TICK')
								recaptcha_tick_element_found = True

								discord_message_sent = False
								start_time_check = time.time()

								while True:
									# TEST IF THIS WORKS TO FIND THE TICK
									if 'style' in ii.get_attribute('outerHTML'):
										print('CAPTCHA - TICK FOUND')
										if discord_message_sent:
											discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA PASSED')
										break
									else:
										time.sleep(2)

										if not discord_message_sent:
											elapsed_time_check = time.time() - start_time_check
											if elapsed_time_check >= 15:
												discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' IMAGE CAPTCHA REQUIRED - TV: ' + config['Auth'][
													'teamviewer_details'])
												discord_message_sent = True

							if recaptcha_tick_element_found:
								# BREAK THE UNNECESSARY FOR LOOP
								break

						if recaptcha_tick_element_found:
							# BREAK THE LOOK FOR CAPTCHA FRAME
							break
						else:
							print(Fore.RED + 'RECAPTCHA TICK BOX ELEMENT NOT FOUND ON THIS FRAME. TRY AGAIN')
							print(Style.RESET_ALL)
							driver.switch_to.default_content()
							time.sleep(2)
					# RECAPTCHA SECOND METHOD END
				else:
					discord_error("NEITHER CAPTCHA METHOD FOUND")


				# CHANGE BACK TO MAIN FRAME
				driver.switch_to.default_content()
				time.sleep(2)
				print_function('CAPTCHA - CHANGED BACK TO DEFAULT FRAME')

				# CLICK CONTINUE
				# click_continue(lock_webdriver, running_thread)

				if element_found(lock_webdriver, "XPATH", ".//*[@id='holder_content']/p[2]/input"):
					element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/p[2]/input", running_thread)
				elif element_found(lock_webdriver, "XPATH", ".//*/html/body/div[4]/div[4]/div[2]/form/div[2]/p[2]/input"):
					element_click(lock_webdriver, "XPATH", ".//*/html/body/div[4]/div[4]/div[2]/form/div[2]/p[2]/input", running_thread)
				else:
					discord_error("CAPTCHA - CONTINUE BUTTON NOT FOUND")

				print_function('CAPTCHA - CLICKED CONTINUE')

				if 'In-Jail' in str(running_thread[4]):
					element_click(lock_webdriver, "XPATH", ".//*[@class='income']", running_thread)
				else:
					open_city(lock_webdriver, running_thread)

			# GBH CHECK
			if element_found(lock_webdriver, "ID", "gbh"):
				gbh_message = element_get_attribute(lock_webdriver, "ID", "gbh", "innerHTML")
				if 'launder money through' in gbh_message:
					pass
				elif 'released at' in gbh_message:
					waiting_thread_list.append('9zterminate-everything')
					print_function('9zterminate-everything THREAD QUEUED FROM REMOTE LOGOUT REQUEST' + str(waiting_thread_list), "GREEN")

					your_character_name = get_your_character_name(lock_webdriver)
					gbh_datetime = regex_match_between('released at:', None, gbh_message)
					gbh_datetime = regex_match_between('">', '</', gbh_datetime)
					gbh_datetime = gbh_datetime.strip()
					print_function("gbh_datetime:" + str(gbh_datetime), "GREEN")
					gbh_datetime_split = gbh_datetime.split(' ')
					gbh_date_split = gbh_datetime_split[0].split('/')
					print_function("date before split:" + str(gbh_datetime_split[0]), "GREEN")
					gbh_time_split = gbh_datetime_split[1].split(':')
					print_function("time before split:" + str(gbh_datetime_split[1]), "GREEN")
					gbh_month = gbh_date_split[0]
					if len(gbh_month) == 1:
						gbh_month = "0" + gbh_month
					gbh_day = gbh_date_split[1]
					if len(gbh_day) == 1:
						gbh_day = "0" + gbh_day
					gbh_year = gbh_date_split[2]
					gbh_hour = gbh_time_split[0]
					if len(gbh_hour) == 1:
						gbh_hour = "0" + gbh_hour
					gbh_min = gbh_time_split[1]
					if len(gbh_min) == 1:
						gbh_min = "0" + gbh_min
					gbh_sec = gbh_time_split[2]
					if len(gbh_sec) == 1:
						gbh_sec = "0" + gbh_sec
					gbh_ampm = gbh_datetime_split[2]
					gbh_time_string = gbh_month + " " + gbh_day + " " + gbh_year + " " + gbh_hour + " " + gbh_min + " " + gbh_sec + " " + gbh_ampm
					gbh_time = datetime.datetime.strptime(gbh_time_string, '%m %d %Y %I %M %S %p')
					gbh_wait_time = (gbh_time - datetime.datetime.utcnow()).total_seconds()

					if gbh_wait_time > 0:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' GBH: ' + str(gbh_message) + ' CALCULATED WAIT TIME:' + str(gbh_wait_time))
						random_wait = random.randrange(30, 60)
						gbh_wait_time = gbh_wait_time + random_wait

						if 'about to rob and were hit on the head' in str(gbh_message):
							time.sleep(gbh_wait_time)
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + " GBH WAIT TIMER FINISHED - BOT CONTINUING")
						else:
							waiting_thread_list.append('9zLoggedOut')
							driver.get("https://mafiamatrix.com/default.asp?action=logout")
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + " LOGGED OUT SINCE GBH. WILL DISCORD MESSAGE WHEN HOSPITAL WAIT FINISHED")
							time.sleep(gbh_wait_time)
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + " GBH TIMER FINISHED - AWAITING RESTART COMMAND TO RELOG")
					else:
						click_continue(lock_webdriver, running_thread)

			if 'captcha_thread' in str(waiting_thread_list):
				thread_remove_from_queue(running_thread, waiting_thread_list)
			time.sleep(2)
		except Exception as e:
			from code_modules.function import PrintException
			PrintException()
			if ('stale element reference' in str(e)) or ('window was already closed' in str(e)):
				# IGNORE NOTIFY DISCORD ON KNOWN ERRORS
				pass
			else:
				discord_message(config['Auth']['discord_id'] + "CAPTCHA THREAD HAS AN EXCEPTION - THEY MAY NEED HELP WITH CAPTCHA OR SCRIPT CHECK - TV: " + str(config['Auth']['teamviewer_details']))
