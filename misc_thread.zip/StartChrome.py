google-chrome --remote-debugging-port=9222 --disable-seccomp-filter-sandbox --no-sandbox

# rclone --vfs-cache-mode writes mount onedrive: ~/OneDrive