import time
last_line = None
while True:
	text_file = open("env/Aggs_Thread_Log.txt", "r")
	file_contents = text_file.read()
	if file_contents != last_line:
		if file_contents == '':
			pass
		else:
			print(file_contents)
		last_line = file_contents
	text_file.close()
	# time.sleep(0.0001)
