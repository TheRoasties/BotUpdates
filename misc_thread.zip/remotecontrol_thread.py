from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

global driver
global lock_webdriver

def RemoteTimers(lock_webdriver, your_name):
	timer_results = element_get_attribute(lock_webdriver, "XPATH",
												"/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_mid']",
												"innerHTML")
	timers_string = ""
	timer_results = timer_results.split('<div title="')
	for timer in timer_results:
		lines = timer.splitlines()
		print_function('timer: ' + str(timer))
		if 'Next Event' in str(lines[0]):
			between = regex_match_between('>', '<', lines[1])
			timers_string = str(timers_string) + str(between)
			if 'Ready' in lines[3]:
				timers_string = str(timers_string) + str("READY") + " | "
			else:
				between = regex_match_between('">', '<', lines[3])
				timers_string = str(timers_string) + str(between) + " | "
		elif ('Next ' in str(lines[0])):
			between = regex_match_between('>', '<', lines[3])
			timers_string = str(timers_string) + str(between)
			if 'Ready' in lines[6]:
				timers_string = str(timers_string) + str("READY") + " | "
			else:
				between = regex_match_between('">', '<', lines[6])
				timers_string = str(timers_string) + str(between) + " | "
		elif ('Agg pro ' in str(lines[0])):
			between = regex_match_between('>', '<', lines[3])
			timers_string = str(timers_string) + " || " + str(between)
			if 'Ready' in lines[6]:
				timers_string = str(timers_string) + str("READY")
			else:
				between = regex_match_between('">', '<', lines[6])
				timers_string = str(timers_string) + str(between)
	discord_message(config['Auth']['discord_id'] + str(your_name) + " " + str(timers_string))
	return

def RemoteStatus(lock_webdriver, running_thread, your_name):
	right_bar = element_get_attribute(lock_webdriver, 'XPATH',
											  "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']",
											  'innerHTML')
	right_bar_line = right_bar.splitlines()
	results_string = ""
	rank = regex_match_between('>', '<', right_bar_line[7])
	occupation = regex_match_between('>', '<', right_bar_line[11])
	your_clean_money = regex_match_between('value="', '"', right_bar_line[15])
	your_clean_money = re.sub('[^0-9]', "", your_clean_money)
	dirty_money = regex_match_between('>', '<', right_bar_line[18])
	dirty_money = re.sub('[^0-9]', "", dirty_money)
	current_city = regex_match_between('>', '<', right_bar_line[21])
	current_city = current_city.replace(' ', '')
	home_city = regex_match_between('>', '<', right_bar_line[23])
	home_city = home_city.replace(' ', '')
	rank_percent = regex_match_between('title="', '"', right_bar_line[40])
	warmode_check = right_bar_line[9]
	health = regex_match_between('%">', '<', right_bar_line[31])
	healthmax = regex_match_between('\(', '\)', right_bar_line[30])
	if 'display_red' in warmode_check:
		warmode_check = 'ON'
	else:
		warmode_check = 'Off'

	results_string = "Rank:" + str(rank) + " | Occupation:" + str(occupation) + " | Clean$:" + str(your_clean_money) + " | Dirty$: " + str(dirty_money) + " | CurrentCity:" + str(current_city) + " | HomeCity:" + str(home_city) + " | Rank%:" + str(rank_percent) + " | Warmode:" + str(warmode_check) + " | Health:" + str(health) + "/" + str(healthmax)

	# GET VARIABLES STRING
	for item in running_thread[4]:
		if 'profile-' in item:
			item = item.replace('profile-', '')
			results_string = str(results_string) + " | " + str(item)
		elif 'BankBalance' in item:
			results_string = str(results_string) + " | " + str(item)
		elif 'Vehicle:' in item:
			item = item.replace('Vehicle:', 'VehicleStatus:')
			results_string = str(results_string) + " | " + str(item)

	print_function(results_string)
	discord_message(config['Auth']['discord_id'] + str(your_name) + " " + str(results_string))
	return


def remotecontrol_thread(lock_webdriver, running_thread, waiting_thread_list):

	'''
	lambda_client = boto3.client('lambda',
						 region_name='ap-southeast-2',
						 aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
						 aws_secret_access_key='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'
						 )

	response = lambda_client.invoke(
		FunctionName='test',
		InvocationType='Event',
		LogType='None',
		Payload='{"payload":["John","Smith","Jones","Catherine"]}'
	)
	'''

	sqs = boto3.resource('sqs',
						 region_name='ap-southeast-2',
						 aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
						 aws_secret_access_key='ZHOEqdJJhOlI3ni7Elik+LLso3U9mpKlQUhEG9cs'
						 )

	your_name = get_your_character_name(lock_webdriver)

	# CREATE QUEUE
	response = sqs.create_queue(
	QueueName=your_name,
	Attributes={'ReceiveMessageWaitTimeSeconds': '20', 'MessageRetentionPeriod': '3600'}
	)

	print_function('create queue response: ' + str(response))

	queue = sqs.get_queue_by_name(QueueName=your_name)
	print_function('queue: ' + str(queue))

	while True:
		try:
			messages = queue.receive_messages(MaxNumberOfMessages=10)
			count = 0
			print_function('messages found: ' + str(len(messages)))
			for message in messages:
				count += 1
				print_function('message' + str(count) + ': '+ str(message.body))
				if 'SendMessage' in str(message.body):
					message_body = message.body
					message_body = message_body.replace(',', '')
					message_body_split = message_body.split('--')
					if len(message_body_split) == 4:
						recipient = message_body_split[1]
						subject = message_body_split[2]
						messageToSend = message_body_split[3]
						print("SendMessage Recipient: " + str(recipient) + " Message: " + str(messageToSend))
						waiting_thread_list.append('9zSendMessage//' + str(recipient) + '//' + str(subject) + '//' + str(messageToSend))
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
						print_function(waiting_thread_list)
					else:
						discord_message("SendMessage INVALID - Correct Format: !Roasty <YourName> SendMessage--<Subject>--<RecipientName>--<Message>")
				elif 'SendDrugs' in str(message.body):
					message_body = message.body
					message_body_split = message_body.split(' ')

					if len(message_body_split) == 2:
						recipient = message_body_split[1]
						waiting_thread_list.append('9zSendDrugs//' + str(recipient))
						
						for thread in waiting_thread_list:
							if 'SmuggleDrugs' in thread:
								if str(recipient) in thread:
									try:
										waiting_thread_list.remove(thread)
									except:
										pass
						
						discord_message(config['Auth']['discord_id'] + str(your_name) + " Sending Drugs to: " + str(recipient))
					else:
						discord_message("SendDrugs INVALID - Correct Format: !Roasty <YourName> SendDrugs <Recipient>")
				elif 'Logout' in str(message.body):
					waiting_thread_list.append('9zLoggedOut')
					print_function('9zterminate-everything THREAD QUEUED FROM REMOTE LOGOUT REQUEST' + str(waiting_thread_list), "GREEN")
					driver.get("https://mafiamatrix.com/default.asp?action=logout")
					discord_message(config['Auth']['discord_id'] + str(your_name) + " LOGGED OUT - AWAITING RESTART COMMAND")
					waiting_thread_list.append('9zterminate-everything')
				elif 'MHSWarn' in str(message.body):
					if config.getboolean('Misc', 'LogoutIfSomeoneMHS'):
						waiting_thread_list.append('9zLoggedOut')
						print_function('9zterminate-everything THREAD QUEUED FROM REMOTE LOGOUT REQUEST' + str(waiting_thread_list), "GREEN")
						driver.get("https://mafiamatrix.com/default.asp?action=logout")
						discord_message(config['Auth']['discord_id'] + str(your_name) + " LOGGED OUT - AWAITING RESTART COMMAND")
						waiting_thread_list.append('9zterminate-everything')
				elif 'Restart' in str(message.body):
					running_thread[1] = datetime.datetime.utcnow()
					for thread in waiting_thread_list:
						if 'LoggedOut' in thread:
							try:
								waiting_thread_list.remove(thread)
							except:
								pass
					discord_message(config['Auth']['discord_id'] + str(your_name) + " RESTARTED")
				elif 'Version' in str(message.body):
					discord_message(config['Auth']['discord_id'] + str(your_name) + " BOT VERSION: " + str(globals()['timers'].__dict__['bot_version']))
				elif 'Timers' in str(message.body):
					RemoteTimers(lock_webdriver, your_name)
				elif 'Status' in str(message.body):
					RemoteStatus(lock_webdriver, running_thread, your_name)
				elif 'TransferMoney' in str(message.body):
					message_body = message.body
					message_body_split = message_body.split(' ')

					if len(message_body_split) == 3:
						amount = message_body_split[1]
						amount = re.sub('[^0-9]', "", amount)
						if amount == '':
							discord_message(config['Auth']['discord_id'] + str(your_name) + " MONEY TRANSFER FAIL - AMOUNT IS NOT A NUMBER")
						else:
							recipient = message_body_split[2]
							if transfer_money(lock_webdriver, running_thread, waiting_thread_list, amount, recipient):
								# TRANSFER SUCCESSFUL
								discord_message(config['Auth']['discord_id'] + str(your_name) + " MONEY TRANSFER SUCCESSFUL")
					else:
						discord_message("MoneyTransfer INVALID - Correct Format: !Roasty <Name> TransferMoney <Amount> <Recipient>")
				elif 'TransferWeapon' in str(message.body):
					message_body = message.body
					message_body_split = message_body.split(' ')
					if len(message_body_split) == 3:
						which_weapon = message_body_split[1]
						target = message_body_split[2]
						waiting_thread_list.append('9zSellItem//' + str(which_weapon) + '//' + str(target) + '//1')
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
						print_function(waiting_thread_list)
					else:
						discord_message("TransferWeapon INVALID - Correct Format: !Roasty <Name> TransferWeapon <Weapon> <Recipient>")
				elif ( ('ResetCaseTimer' in str(message.body)) or ('ResetTimerCase' in str(message.body)) ):
					waiting_thread_list.append('9zResetCaseTimer')
				elif ('ResetLaunderTimer' in str(message.body)) or ('ResetTimerLaunder' in str(message.body)):
					waiting_thread_list.append('9zResetLaunderTimer')
				elif 'ResetAggstrTimer' in str(message.body):
					waiting_thread_list.append('9zResetAggstrTimer')
				elif 'ResetTravelTimer' in str(message.body):
					waiting_thread_list.append('9zResetTravelTimer')
				elif 'ResetActionTimer' in str(message.body):
					waiting_thread_list.append('9zResetActionTimer')
				else:
					discord_message(config['Auth']['discord_id'] + str(your_name) + " NEW REMOTE COMMAND: " + str(message.body))
				message.delete()
				print_function('message' + str(count) + ' DELETED')
			print_function('END OF ALL MESSAGES')
			time.sleep(10)
		except:
			from code_modules.function import PrintException
			PrintException()
