from globalvars import *
from code_modules.function import *

def lawyer(lock_webdriver, running_thread, waiting_thread_list, current_city):
	if config.getboolean('Career-Lawyer', 'Do_Cases'):
		print_function('MISC - LAWYER - ADDED TO QUEUE')
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)

		print_function('MISC - LAWYER START')
		go_to_page(lock_webdriver, 'Lawyer', running_thread)

		if element_found(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/center/form/table"):
			all_cases_details = element_get_attribute(lock_webdriver, "XPATH",
													  "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/center/form/table",
													  "innerHTML")
		else:
			# NO TABLE MEANS NO CASES
			random_case_timer = random.randrange(327, 669)
			globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
				seconds=random_case_timer)
			print_function('MISC - LAWYER - NO CASES ANYWHERE')
			thread_remove_from_queue(running_thread, waiting_thread_list)
			return

		which_case = 0
		case_index_to_defend = None
		case_number_to_defend = None
		found_preferred_case = False
		all_cases = all_cases_details.split("<tr>")

		lawyer_blacklist_person = config['Career-Lawyer']['Lawyer_Person_Blacklist'].split()
		lawyer_priority_person = config['Career-Lawyer']['Lawyer_Priority_list'].split()

		for this_case in all_cases:
			case_number = ''
			skip_this_case = False

			regexsearch = re.search(">\d+<", this_case)
			if 'match=' in str(regexsearch):
				regexsearch2 = re.search("\d+", str(regexsearch.group(0)))
				case_number = regexsearch2.group(0)


			if 'action=defendcase' in this_case:

				# SKIP PERSON BLACKLIST
				for blacklist_name in lawyer_blacklist_person:
					if blacklist_name in this_case:
						print_function('MISC - LAWYER - skipping lawyer blacklisted person: ' + str(blacklist_name))
						skip_this_case = True
						break  # BREAKS THE BLACKLIST ONLY

				# SKIP CASE BLACKLIST
				if case_number in config['Career-Lawyer']['Lawyer_Case_Blacklist']:
					print_function('MISC - LAWYER - skipping case in blacklist ' + str(case_number))
					skip_this_case = True

				if skip_this_case:
					pass
				else:
					if case_index_to_defend is None:
						# DO THE FIRST VIABLE CASE. THIS IS OVERWRITTEN IF WE FIND A PREFERRED CLIENT LATER
						if found_preferred_case:
							pass
						else:
							case_index_to_defend = which_case
							case_number_to_defend = case_number
							print_function('MISC - LAWYER - Repping first viable case')

					# PREFERRED PERSON WHITELIST
					for preferred_name in lawyer_priority_person:
						if preferred_name in this_case:
							print_function('MISC - LAWYER - Preferred Client Found: ' + str(preferred_name))
							found_preferred_case = True
							case_index_to_defend = which_case
							case_number_to_defend = case_number
							break  # BREAKS THE WHITELIST ONLY

			if found_preferred_case:
				# NO NEED TO CHECK OTHER CASES AS PREFERRED CLIENT ALREADY FOUND
				break
			which_case += 1


		if case_index_to_defend is None:
			# NO CASES IN THIS CITY. SET TIMER RANDOM 5-10 MINS
			random_case_timer = random.randrange(327, 669)
			globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
				seconds=random_case_timer)
			print_function('MISC - LAWYER - NO CASES IN CITY')
		else:
			# CASE FOUND. REP IT
			print_function('MISC - LAWYER - CASE REPPED ' + str(case_number_to_defend))
			element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/center/form/table/tbody/tr[" + str(case_index_to_defend) + "]/td[@class='display_border'][6]/a[@class='box green']", running_thread)


			set_timer = True
			if element_found(lock_webdriver, "ID", "fail"):
				fail_reason = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
				print_function(fail_reason)
				if ('afford your services' in str(fail_reason)) or ('the victim' in str(fail_reason)):
					print_function('MISC - LAWYER - client cannot afford case ' + str(case_number_to_defend))
					set_timer = False
					config['Career-Lawyer']['Lawyer_Case_Blacklist'] = config['Career-Lawyer']['Lawyer_Case_Blacklist'] + " " + case_number_to_defend

			# SET NEW CASE TIMER
			if set_timer:
				globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
					seconds=get_timer(lock_webdriver, 'Case', running_thread))

		print_function('MISC - LAWYER - FINISHED')
		thread_remove_from_queue(running_thread, waiting_thread_list)
	return