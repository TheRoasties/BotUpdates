from globalvars import *
from code_modules.function import *
from code_modules.vehicle_get_status import *


def blackmarket_gangster_exp(lock_webdriver, running_thread, waiting_thread_list, dirty_money, current_city):
	if 'BlackMarket' in str(running_thread[3]):
		if globals()['timers'].__dict__['traffic_timer'] is None:
			globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Trafficking', running_thread))

		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['traffic_timer']
		if not '-' in str(time_difference):
			dirty_money = int(dirty_money) - int(config['Launder']['reserve_for_drugs'])

			# TRAFFIC TIMER READY
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_travel)

			if go_to_page(lock_webdriver, "Blackmarket", running_thread):
				pass
			else:
				print_function('BLACKMARKET - NOT UNLOCKED', "RED")
				click_refresh(lock_webdriver, running_thread)

				unlocked_aggs_list = running_thread[3]
				if 'BlackMarket' in unlocked_aggs_list:
					try:
						unlocked_aggs_list.remove('BlackMarket')
					except:
						pass
				running_thread[3] = unlocked_aggs_list
				write_file("env/agg_unlocks.txt", running_thread[3])
				print_function('UPDATED VARIABLES FOR BLACKMARKET NOT UNLOCKED: ' + str(running_thread[3]))

				thread_remove_from_queue(running_thread, waiting_thread_list)
				return

			# max / 24
			# ".//*[@id='holder_content']/center[1]/strong[1]"

			# current / 24
			# ".//*[@id='holder_content']/center[1]/strong[2]"

			carry_capacity = config['Drugs']['CarryCapacity']
			if 'BrokenDownAwaitingRepair' in str(running_thread[4]):
				# NO CAR FOR EXTRA CAPACITY
				carry_capacity = 5

			# write bm prices

			list_of_blackmarket_items = []
			list_of_blackmarket_prices = []
			dict_of_blackmarket_values = {}
			zero_priced_goods = 0

			blackmarket_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='shop_holder']/div[@id='holder_content']/form/table", "innerHTML")
			blackmarket_table_row = blackmarket_table.split("<tr>")
			break_outer_loop = False
			sell_blackmarket_goods = False
			item_click_index = 1
			blackmarket_database_string = ''
			for row in blackmarket_table_row:
				# SKIP NON ENTRIES
				if '/images/black_market' in row:
					table_data = row.split("<td ")
					blackmarket_item = regex_match_between('>', '</td', table_data[2])
					blackmarket_price = regex_match_between('>', '</td', table_data[3])
					blackmarket_price = re.sub('[^0-9]', "", blackmarket_price)
					if (int(blackmarket_price) == 0):
						zero_priced_goods = int(zero_priced_goods) + 1
					blackmarket_quantity_owned = regex_match_between('>', '</td', table_data[4])
					print_function('item: ' + str(blackmarket_item) + ' price: ' + str(blackmarket_price) + ' quantity: ' + str(blackmarket_quantity_owned))
					blackmarket_item_formatted = blackmarket_item.replace(" ", "")
					if blackmarket_database_string == '':
						blackmarket_database_string = '{"' + blackmarket_item_formatted + '": ' + str(blackmarket_price)
					else:
						blackmarket_database_string = blackmarket_database_string + ', "' + blackmarket_item_formatted + '": ' + str(blackmarket_price)
					list_of_blackmarket_items.append(blackmarket_item)
					list_of_blackmarket_prices.append(blackmarket_price)
					item_click_index += 1
					if int(blackmarket_quantity_owned) > 0:
						dict_of_blackmarket_values[blackmarket_item] = [blackmarket_price, blackmarket_quantity_owned, 1,
																		item_click_index]
						sell_blackmarket_goods = True
					else:
						dict_of_blackmarket_values[blackmarket_item] = [blackmarket_price, blackmarket_quantity_owned, 0,
																		item_click_index]
				else:
					continue

			# SELL BLACKMARKET GOODS
			if sell_blackmarket_goods:
				for item in list_of_blackmarket_items:
					if int(dict_of_blackmarket_values[item][1]) > 0:
						lock_webdriver.acquire()
						driver.find_element(By.XPATH,
											".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
												dict_of_blackmarket_values[item][
													3]) + "]/td[@class='display_border'][4]/input[@class='input']").clear()
						release_webdriver(lock_webdriver)
						sendkeys(lock_webdriver, "XPATH",
								 ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
									 dict_of_blackmarket_values[item][
										 3]) + "]/td[@class='display_border'][4]/input[@class='input']", 1)
				# CLICK SELL
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p/input[@class='input'][2]",
							  running_thread)
			# BUY BLACKMARKET GOODS
			else:
				break_outer_loop = False
				# GET BUY QUANTITIES
				print_function('BLACKMARKET - DIRTY MONEY AVAILABLE: ' + str(dirty_money))
				if int(dirty_money) < 0:
					print_function('BLACKMARKET - NO MONEY AVAILABLE AS ALL RESERVED. BUY 0 PRICE STOCKS')
					while True:
						for item in list_of_blackmarket_items:
							print_function('item: ' + str(item) + ' price: ' + str(dict_of_blackmarket_values[item][0]) + ' qtyown: ' + str(dict_of_blackmarket_values[item][1]) + ' qtybuy: ' + str(dict_of_blackmarket_values[item][2]))
							if (int(dict_of_blackmarket_values[item][0]) == 0) and (int(carry_capacity) > 0):
								dirty_money = int(dirty_money) - int(dict_of_blackmarket_values[item][0])
								quantity_to_buy = math.floor(int(carry_capacity) / int(zero_priced_goods))
								dict_of_blackmarket_values[item][2] = quantity_to_buy
								print_function('BLACKMARKET - BUYING: ' + str(dict_of_blackmarket_values[item][1]) + " " + str(dict_of_blackmarket_values[item][2]))
							else:
								break_outer_loop = True
						if break_outer_loop:
							print_function('BLACKMARKET - DONE BUYING CALC')
							break
				else:
					while True:
						for item in list_of_blackmarket_items:
							print_function('item: ' + str(item) + ' price: ' + str(dict_of_blackmarket_values[item][0]) + ' qtyown: ' + str(dict_of_blackmarket_values[item][1]) + ' qtybuy: ' + str(dict_of_blackmarket_values[item][2]))
							if (int(dirty_money) >= int(dict_of_blackmarket_values[item][0])) and (int(carry_capacity) > 0):
								dirty_money = int(dirty_money) - int(dict_of_blackmarket_values[item][0])
								quantity_to_buy = dict_of_blackmarket_values[item][2]
								quantity_to_buy += 1
								carry_capacity = int(carry_capacity) - 1
								dict_of_blackmarket_values[item][2] = quantity_to_buy
								print_function('BLACKMARKET - BUYING: ' + str(dict_of_blackmarket_values[item][1]) + " " + str(dict_of_blackmarket_values[item][2]))
							else:
								break_outer_loop = True
						if break_outer_loop:
							print_function('BLACKMARKET - DONE BUYING CALC')
							break

				# BUY GOODS
				for item in list_of_blackmarket_items:
					if int(dict_of_blackmarket_values[item][2]) > 0:
						lock_webdriver.acquire()
						driver.find_element(By.XPATH,
											".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
												dict_of_blackmarket_values[item][
													3]) + "]/td[@class='display_border'][4]/input[@class='input']").clear()
						release_webdriver(lock_webdriver)
						sendkeys(lock_webdriver, "XPATH",
								 ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
									 dict_of_blackmarket_values[item][
										 3]) + "]/td[@class='display_border'][4]/input[@class='input']",
								 str(dict_of_blackmarket_values[item][2]))
				# CLICK BUY
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p/input[@class='input'][1]",
							  running_thread)

				# GET RESULTS
				if element_found(lock_webdriver, "ID", "fail"):
					results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
					if 'more than' in results:
						# PROBABLY BROKEN DOWN
						vehicle_get_status(lock_webdriver, running_thread, waiting_thread_list)
						if 'Vehicle:WaitingRepair' in str(running_thread[4]):
							# WAITING FOR REPAIR BUT CANNOT CARRY BM GOODS. MUST BE BROKEN DOWN
							variables_list = running_thread[4]
							for item in running_thread[4]:
								if 'Vehicle:WaitingRepair' in item:
									try:
										variables_list.remove(item)
									except:
										pass
							variables_list.append('Vehicle:BrokenDownAwaitingRepair')
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])
					else:
						discord_message(config['Auth']['discord_id'] + " NEW BM BUY FAIL REASON: " + str(results))

			blackmarket_database_string = blackmarket_database_string + '}'
			update_database('BlackMarket', 'City', str(current_city), eval(blackmarket_database_string))

			globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Trafficking', running_thread))
			thread_remove_from_queue(running_thread, waiting_thread_list)
	return