from globalvars import *
from code_modules.function import *


def casino(lock_webdriver, running_thread, waiting_thread_list):
	if config.getboolean('Misc', 'DoBlackJack'):
		try:
			casino_timer = read_file("env/casino_timer.txt")
			try:
				casino_timer = datetime.datetime.strptime(casino_timer, '%Y-%m-%d %H:%M:%S')
			except:
				casino_timer = datetime.datetime.strptime(casino_timer, '%Y-%m-%d %H:%M:%S.%f')
		except:
			casino_timer = datetime.datetime.utcnow()
		time_difference = datetime.datetime.utcnow() - casino_timer

		if not '-' in str(time_difference):
			# CASINO TIMER READY
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_blackmarket)

			url_check = get_url(lock_webdriver)
			if ('blackjack.asp' in url_check) or ('casino.asp' in url_check) or ('businesses.asp?name=Casino' in url_check):
				pass
			else:
				# OPEN CASINO
				open_city(lock_webdriver, running_thread)

				if element_found(lock_webdriver, "XPATH", ".//*[@class='maintenance']/a[@class='business casino']"):
					# CASINO TORCHED
					random_timer = random.randrange(30, 60)
					casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
					write_file("env/casino_timer.txt", casino_timer)
					print_function('CASINO TORCHED')
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return
				else:
					element_click(lock_webdriver, "XPATH", "//*[@class='business casino']", running_thread)

			# CASINO OPEN
			if element_found(lock_webdriver, "XPATH", ".//*[@id='blackjack']"):
				# CHOOSING GAME
				element_click(lock_webdriver, "XPATH", ".//*[@id='blackjack']", running_thread)
				element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)

				# CHECK IF WE ALREADY USED ALL GAMBLING TRIES
				if element_found(lock_webdriver, "XPATH", ".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']"):
					# end of gambling
					results = element_get_attribute(lock_webdriver, "XPATH",
													".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']",
													"innerHTML")
					if 'get an addiction' in results:
						# FINISHED BLACKJACK
						random_timer = random.randrange(1452, 1572)
						casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
						write_file("env/casino_timer.txt", casino_timer)
						print_function('FINISHED BLACKJACK')
						thread_remove_from_queue(running_thread, waiting_thread_list)
						return

			new_hand = True
			while True:
				url_check = get_url(lock_webdriver)
				if 'blackjack.asp?action=bet' in url_check:
					# PLACE BET
					element_click(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/table[3]/tbody/tr[4]/td[2]/input", running_thread)
					continue
				elif ((not 'blackjack.asp?action=blackjack2' in url_check) and ('blackjack.asp?action=blackjack' in url_check)) or (not (new_hand)):
					# CHECK FOR AUTO BLACKJACK WIN
					if element_found(lock_webdriver, "XPATH","/html/body/div[4]/div[4]/b/div/font"):
						blackjack_check = element_get_attribute(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/b/div/font", "innerHTML")
						if 'Blackjack, you won!' in blackjack_check:
							new_hand = True
							element_click(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/table[3]/tbody/tr[3]/td[2]/input", running_thread)
							continue

					if (not (new_hand)):
						# ACCOUNT FOR MULTIPLE DRAWS ON THE SAME HAND
						hand_results = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/b/div", "innerHTML")
						if ('you Lost' in str(hand_results)) or ('You won' in str(hand_results)) or ('was a push' in str(hand_results)):
							print_function('multiple cards new hand - click continue')
							new_hand = True
							element_click(lock_webdriver, "XPATH",
										  "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/table[@id='AutoNumber4'][2]/tbody/tr[3]/td[@class='s1'][2]/input",
										  running_thread)
							continue

					if (new_hand):
						# PLAYING HAND
						your_total = element_get_attribute(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/table[2]/tbody/tr[3]/td[2]/font/b", "innerHTML")
						if 'or' in str(your_total):
							your_total = regex_match_between('total', 'or', your_total)
							your_hand_type = 'Soft'
						else:
							your_hand_type = 'Hard'
						your_total = re.sub('[^0-9]', "", your_total)
						# your_card1 = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/table[2]/tbody/tr[2]/td[@class='cell'][1]", "innerHTML")
						# your_card1 = regex_match_between('cards/', '\.', your_card1)
						# your_card2 = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/table[2]/tbody/tr[2]/td[@class='cell'][2]", "innerHTML")
						# your_card2 = regex_match_between('cards/', '\.', your_card2)
						their_card = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/table[2]/tbody/tr[2]/td[@class='cell'][5]", "innerHTML")
						their_card = regex_match_between('cards/', '\.', their_card)
						their_total = 0

						# THEIR TOTAL
						if ('j' in str(their_card)) or ('q' in str(their_card)) or ('k' in str(their_card)):
							their_total = 10
						elif ('a' in str(their_card)):
							their_total = 11
						else:
							their_total = re.sub('[^0-9]', "", their_card)

						'''
						if ('a' in str(your_card1)) or ('a' in str(your_card2)):
							your_hand_type = 'Soft'
						else:
							your_hand_type = 'Hard'
						'''
					else:
						# EXISTING HAND
						your_total = element_get_attribute(lock_webdriver, "XPATH", "/html/body/div[4]/div[4]/table[2]/tbody/tr[3]/td[2]/font/b", "innerHTML")
						if 'or' in str(your_total):
							your_total = regex_match_between('total', 'or', your_total)
							your_hand_type = 'Soft'
						else:
							your_hand_type = 'Hard'
						your_total = re.sub('[^0-9]', "", your_total)
					print_function('BLACKJACK - TOTAL: ' + str(your_hand_type) + " " + str(your_total) + " / " + str(their_card) + " / " + str(their_total))

					your_action = 'None'

					# SOFT
					if 'Soft' == str(your_hand_type):
						if (int(your_total) > 12) and (int(your_total) < 17):
							if (int(their_total) > 3) and (int(their_total) < 7):
								your_action = 'Double'
							else:
								your_action = 'Hit'
						elif (int(your_total) == 17):
							if (int(their_total) > 6):
								your_action = 'Hit'
							else:
								your_action = 'Double'
						elif (int(your_total) == 18):
							if (int(their_total) > 8):
								your_action = 'Hit'
							elif (int(their_total) > 2) and (int(their_total) < 7):
								your_action = 'Double'
							else:
								your_action = 'Stand'
						elif (int(your_total) == 19):
							if (int(their_total) == 6):
								your_action = 'Double'
							else:
								your_action = 'Stand'
						elif (int(your_total) > 19):
							your_action = 'Stand'
						else:
							your_action = 'Hit'

					# HARD
					else:
						if (int(your_total) > 16):
							your_action = 'Stand'
						elif (int(your_total) > 12):
							if (int(their_total) > 6):
								your_action = 'Hit'
							else:
								your_action = 'Stand'
						elif (int(your_total) == 12):
							if (int(their_total) == 4) or (int(their_total) == 5) or (int(their_total) == 6):
								your_action = 'Stand'
							else:
								your_action = 'Hit'
						elif (int(your_total) == 10) or (int(your_total) == 11):
							if (int(their_total) > 9):
								your_action = 'Hit'
							else:
								your_action = 'Double'
						elif (int(your_total) == 9):
							if (int(their_total) > 6):
								your_action = 'Hit'
							else:
								your_action = 'Double'
						elif (int(your_total) == 8):
							if (int(their_total) == 5) or (int(their_total) == 6):
								your_action = 'Double'
							else:
								your_action = 'Hit'
						elif (int(your_total) < 8):
							your_action = 'Hit'

					if ('None' in str(your_action)) or (int(their_total) == 0):
						print_function('YOUR ACTION: ' + str(your_action) + ' THEIR TOTAL: ' + str(their_total))
						input('NO CASINO ACTION')

					print_function('YOUR ACTION: ' + str(your_action))

					# DOUBLE
					if ('Double' in str(your_action)) and (new_hand):
						print_function('DOUBLE')
						element_click(lock_webdriver, "XPATH", ".//*[@id='content']/table[@id='AutoNumber4'][2]/tbody/tr[5]/td[@class='s1'][2]", running_thread)
						# HIT
					elif ('Hit' in str(your_action)) or ('Double' in str(your_action)):
						print_function('HIT')
						element_click(lock_webdriver, "XPATH", ".//*[@id='content']/table[@id='AutoNumber4'][2]/tbody/tr[3]/td[@class='s1'][2]", running_thread)
					# STAND
					elif 'Stand' in str(your_action):
						print_function('STAND')
						element_click(lock_webdriver, "XPATH", ".//*[@id='content']/table[@id='AutoNumber4'][2]/tbody/tr[4]/td[@class='s1'][2]", running_thread)
				elif 'blackjack.asp?action=blackjack2' in url_check:
					# FINISHED A HAND
					if element_found(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/b/div"):
						hand_results = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/b/div", "innerHTML")
						print_function('hand results: ' + str(hand_results))

					if ('you Lost' in str(hand_results)) or ('You won' in str(hand_results)) or ('was a push' in str(hand_results)):
						print_function('click continue')
						new_hand = True
						element_click(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='content']/table[@id='AutoNumber4'][2]/tbody/tr[3]/td[@class='s1'][2]/input", running_thread)
					elif 'Your current hand total' in str(hand_results):
						new_hand = False
					else:
						print_function('NEW HAND RESULTS: ' + str(hand_results))
						input('NEW HAND RESULTS')
					continue
				elif 'businesses.asp?name=Casino' in url_check:
					# choosing game or too much gambling
					if element_found(lock_webdriver, "XPATH",
									 ".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']"):
						# end of gambling
						results = element_get_attribute(lock_webdriver, "XPATH",
														".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']",
														"innerHTML")
						if 'get an addiction' in results:
							# FINISHED SLOTS
							random_timer = random.randrange(1452, 1572)
							casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
							write_file("env/casino_timer.txt", casino_timer)
							break
					else:
						thread_remove_from_queue(running_thread, waiting_thread_list)
						return

				elif 'local.asp' in url_check:
					# LOST CASINO PAGE. PROBABLY TORCHED
					results = element_get_attribute(lock_webdriver, "XPATH",
													".//*[@id='wrapper']/div[@id='content']",
													"innerHTML")
					if 'under going repairs' in results:
						# CASINO TORCHED
						random_timer = random.randrange(30, 60)
						casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
						write_file("env/casino_timer.txt", casino_timer)
						break

	elif config.getboolean('Misc', 'DoSlots'):
		casino_timer = read_file("env/casino_timer.txt")
		try:
			casino_timer = datetime.datetime.strptime(casino_timer, '%Y-%m-%d %H:%M:%S')
		except:
			casino_timer = datetime.datetime.strptime(casino_timer, '%Y-%m-%d %H:%M:%S.%f')
		time_difference = datetime.datetime.utcnow() - casino_timer

		if not '-' in str(time_difference):
			# CASINO TIMER READY
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_blackmarket)

			url_check = get_url(lock_webdriver)
			if ('businesses.asp?name=Casino' in url_check) or ('casino.asp' in url_check) or ('businesses.asp?name=Casino' in url_check):
				pass
			else:
				# OPEN CASINO
				open_city(lock_webdriver, running_thread)

				if element_found(lock_webdriver, "XPATH", ".//*[@class='maintenance']/a[@class='business casino']"):
					# CASINO TORCHED
					random_timer = random.randrange(30, 60)
					casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
					write_file("env/casino_timer.txt", casino_timer)
					print_function('CASINO TORCHED')
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return
				else:
					element_click(lock_webdriver, "XPATH", "//*[@class='business casino']", running_thread)

			# CASINO OPEN
			if element_found(lock_webdriver, "XPATH", ".//*[@id='slot']"):
				# CHOOSING GAME
				element_click(lock_webdriver, "XPATH", ".//*[@id='slot']", running_thread)
				element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)

				# CHECK IF WE ALREADY USED ALL GAMBLING TRIES
				if element_found(lock_webdriver, "XPATH", ".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']"):
					# end of gambling
					results = element_get_attribute(lock_webdriver, "XPATH",
													".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']",
													"innerHTML")
					if 'get an addiction' in results:
						# FINISHED SLOTS
						random_timer = random.randrange(1452, 1572)
						casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
						write_file("env/casino_timer.txt", casino_timer)
						print_function('FINISHED SLOTS')
						thread_remove_from_queue(running_thread, waiting_thread_list)
						return

				sendkeys(lock_webdriver, "XPATH", ".//*[@class='input']", 100)

			while True:
				url_check = get_url(lock_webdriver)
				if 'casino.asp' in url_check:
					# doing slots
					element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)
					continue
				elif 'businesses.asp?name=Casino' in url_check:
					# choosing game or too much gambling
					if element_found(lock_webdriver, "XPATH", ".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']"):
						# end of gambling
						results = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='body']/div[@id='wrapper']/div[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/div[@id='fail']", "innerHTML")
						if 'get an addiction' in results:
							# FINISHED SLOTS
							random_timer = random.randrange(1452, 1572)
							casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
							write_file("env/casino_timer.txt", casino_timer)
							break
					else:
						thread_remove_from_queue(running_thread, waiting_thread_list)
						return
				elif 'local.asp' in url_check:
					# LOST CASINO PAGE. PROBABLY TORCHED
					results = element_get_attribute(lock_webdriver, "XPATH",
													".//*[@id='wrapper']/div[@id='content']",
													"innerHTML")
					if 'under going repairs' in results:
						# CASINO TORCHED
						random_timer = random.randrange(30, 60)
						casino_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
						write_file("env/casino_timer.txt", casino_timer)
						break

			print_function('CASINO FINISHED')
			thread_remove_from_queue(running_thread, waiting_thread_list)
	return