from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

__all__ = ["add_bne_targets_to_arrays", "check_bne_target", "do_bne_thread"]

def add_bne_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager, currentcity_bne_list, your_character_name, bold_list):
	# CREATE LISTS
	count = 3
	while count < 32:
		globals()['bne_targets_minute' + str(count)] = []
		locals()['dict_min' + str(count)] = {}
		count += 1

	# DO CALCULATION
	try:
		your_hours = aggtarget_person_list_manager[your_character_name].get_online_hours()
	except:
		your_hours = 1

	for name in currentcity_bne_list:
		try:
			their_hours = aggtarget_person_list_manager[name].get_online_hours()
		except:
			# SKIP ANY TARGET NOT FOUND. PRESUMABLY DEAD
			continue

		if (your_character_name == name) or ('' == name):
			continue

		if (name in config['BnE']['BnE_Blacklist']):
			print_function('BNE - SKIP BLACKLIST TARGET ' + str(name))
			continue

		if config.getboolean('BnE', 'Avoid_Bolds'):
			skip_this_name = False
			for bold_name_raw in bold_list['Items']:
				bold_name = bold_name_raw['PlayerName']
				if bold_name == name:
					skip_this_name = True
					break
			if skip_this_name:
				continue

		our_aggstr_mins = 29
		while True:
			our_aggstr = math.ceil( your_hours * float(aggstr_percent_modify(our_aggstr_mins)) )

			their_aggstr_modifier = config['BnE']['BnEAggstrModify']
			their_house_type = get_house_from_string(aggtarget_person_list_manager[your_character_name].get_house())
			if "Studio" == their_house_type:
				their_aggstr_modifier = float(their_aggstr_modifier) + float(config['BnE']['BnEAdditionalModifyStudio'])
			elif "Penthouse" == their_house_type:
				their_aggstr_modifier = float(their_aggstr_modifier) + float(config['BnE']['BnEAdditionalModifyPenthouse'])
			elif "Palace" == their_house_type:
				their_aggstr_modifier = float(their_aggstr_modifier) + float(config['BnE']['BnEAdditionalModifyPalace'])

			their_aggstr = math.floor(their_hours * float(their_aggstr_modifier))

			if (our_aggstr_mins <= 2) or (their_aggstr >= our_aggstr):
				# APPLY LOCAL MODIFIERS TO TARGET REQUIRED MINS
				mins_adjusted = int(our_aggstr_mins) + 1

				if os.path.isfile('./agg_targets/bne/' + name + '.txt'):
					adjust_value = read_file('./agg_targets/bne/' + name + '.txt')
					if adjust_value == '':
						adjust_value = 0
				else:
					adjust_value = 0

				if adjust_value == 'FAIL':
					mins_adjusted = 31
				else:
					mins_adjusted = int(mins_adjusted) + int(adjust_value)

					if int(mins_adjusted) > 30:
						mins_adjusted = 30
					elif int(mins_adjusted) < 3:
						mins_adjusted = 3

				globals()['bne_targets_minute' + str(mins_adjusted)].append(name)
				# print('AGGS - BNE ARRAY - ADDED ', name, ' TO MINS ', mins_adjusted, " THEIRS: ", their_aggstr, " VS YOURS: ", our_aggstr)
				break

			our_aggstr_mins -= 1

	count = 3
	while count < 32:
		print_function('BnE list:' + str(count) + ' // ' + str(globals()['bne_targets_minute' + str(count)]))
		count += 1
	return


def check_bne_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, your_current_city, currentcity_bne_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, bold_list):
	viable_bne_targets = []

	for agg_target in globals()['bne_targets_minute' + str(aggstr_min_checking)]:
		write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BnE - CHECKING TARGET: " + str(agg_target))
		if config.getboolean('BnE', 'Avoid_Bolds'):
			skip_this_name = False
			for bold_name_raw in bold_list['Items']:
				bold_name = bold_name_raw['PlayerName']
				if bold_name == agg_target:
					skip_this_name = True
					break
			if skip_this_name:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BnE TARGET: " + str(agg_target) + " SKIP AS BOLD")
				continue


		# AGGPRO - LOCAL
		aggpro_timer = aggtarget_person_list_manager[agg_target].get_local_aggpro_timer()

		try:
			time_difference = datetime.datetime.utcnow() - aggpro_timer
		except Exception as e:
			if "unsupported operand type" in str(e):
				discord_error("BNE Time_Difference - UNSUPPORTED DATETYPE + STRING  -- Aggpro_Timer is:" + str(aggpro_timer))
				pass
			else:
				raise Exception(e)

		if not '-' in str(time_difference):
			# AGGPRO - SHARED
			aggpro_timer = aggtarget_person_list_manager[agg_target].get_shared_aggpro_timer()
			time_difference = datetime.datetime.utcnow() - aggpro_timer
			if not '-' in str(time_difference):
				# AGGPRO - SHARED

				# CHECK NO HOUSE TIMER
				aggpro_timer = aggtarget_person_list_manager[agg_target].get_bne_timer()
				time_difference = datetime.datetime.utcnow() - aggpro_timer
				if not '-' in str(time_difference):
					viable_bne_targets.append(agg_target)
					write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BNE TARGET: " + str(agg_target) + " MINS REQUIRED: " + str(aggstr_min_checking) )
				else:
					write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BNE SHARED AGGPRO: " + str(agg_target) )
			else:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - BNE LOCAL AGGPRO: " + str(agg_target) )

	if viable_bne_targets == []:
		pass
	else:
		# TERMINATE LESSER PRIORITY AGGS - MUG
		if 'do_mug_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY PICKPOCKET
				return

		if 'do_mug_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BNE - REQUESTED TERMINATE MUG")
			waiting_thread_list.append('9zterminate_do_mug_thread')
			print_function('9zterminate_do_mug_thread THREAD QUEUED', waiting_thread_list)
			while True:
				if 'do_mug_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BNE - TERMINATED MUG")
					break
			# TERMINATED MUG

		# TERMINATE LESSER PRIORITY AGGS - PICKPOCKET
		if 'do_pickpocket_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY PICKPOCKET
				return

		if 'do_pickpocket_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BNE - REQUESTED TERMINATE PICKPOCKET")
			waiting_thread_list.append('9zterminate_do_pickpocket_thread')
			print_function('9zterminate_do_pickpocket_thread THREAD QUEUED' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_pickpocket_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BNE - TERMINATED PICKPOCKET")
					break
			# TERMINATED PICKPOCKET

		print_function('viable bne targets - ' + str(viable_bne_targets) + " " + str(aggstr_min_checking), "BLUE")
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - VIABLE TARGETS FOR MINUTE " + str(aggstr_min_checking) + ": " + str(viable_bne_targets))

		waiting_thread_list.append('9zAggstrLowest' + str(aggstr_min_checking))
		print_function('9zAggstrLowest' + str(aggstr_min_checking) + ' THREAD QUEUED' + str(waiting_thread_list), "GREEN")

		do_bne(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_current_city, your_character_name)
	return


def do_bne(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_current_city, your_character_name):
	thread_bne = Process(target=do_bne_thread, name='BnEThread',
									args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_current_city, your_character_name))
	thread_bne.start()
	waiting_thread_list.append('9zAwaitingBnE')
	print_function(str(waiting_thread_list))

	# WAIT TILL THREAD STARTED
	print_function('BNE - WAITING FOR THREAD TO BE RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - WAITING FOR THREAD TO BE RUNNING")
	while True:
		if 'do_bne_thread' in str(waiting_thread_list):
			break
	print_function('BNE - THREAD RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - THREAD RUNNING")
	return


def do_bne_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_bne_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, your_current_city, your_character_name):
	try:
		import multiprocessing
		write_file("env/BnEPID.txt", str(multiprocessing.current_process().pid))

		for thread in waiting_thread_list:
			if 'AwaitingBnE' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE QUEUED")
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_bne_targets)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE STARTED")
		random_timer_haspro = random.randrange(590, 915)

		for target in viable_bne_targets:
			# RETURN PRIORITY TO NORMAL
			running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]

			if go_to_page(lock_webdriver, "BnE", running_thread):
				pass
			else:
				unlocked_aggs_list = running_thread[3]
				try:
					unlocked_aggs_list.remove('BnE')
				except:
					pass
				running_thread[3] = unlocked_aggs_list
				write_file("env/agg_unlocks.txt", running_thread[3])

				print_function('BnE - NOT UNLOCKED', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** BnE - NOT UNLOCKED ****")
				return

			if 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** BnE - REQUIRES CS FIRST ****")
				return

			clearkeys(lock_webdriver, "NAME", "breaking")
			sendkeys(lock_webdriver, "NAME", "breaking", target)
			sendkeys(lock_webdriver, "NAME", "breaking", Keys.ESCAPE)

			# INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
			running_thread[0] = str('1') + inspect.stack()[0][3]
			click_continue(lock_webdriver, running_thread)

			# AGG DONE - GET RESULTS
			agg_results = None
			if element_found(lock_webdriver, "ID", "fail"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			elif element_found(lock_webdriver, "ID", "success"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			else:
				print_function('NO AGG RESULTS FOUND', "BLUE")
				print_function('NO AGG RESULTS FOUND', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - NO AGG RESULTS FOUND")
				continue

			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - RESULTS: " + str(agg_results))

			# AGG DONE - EXAMINE RESULTS
			if ("doesn't exist" in agg_results) or ("same city" in agg_results):
				print_function('BnE Results - Target ' + str(target) + " Doesn't Exist", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - Target " + str(target) + " Doesn't Exist")
				random_timer = random.randrange(20, 25)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)


			elif ('recently survived' in agg_results):
				print_function('BnE Results - Target ' + str(target) + "has pro", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - Target " + str(target) + " has pro")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer_haspro)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				continue

			elif ('doesnt have' in agg_results):
				print_function('BnE Results - Target ' + str(target) + "no house", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - Target " + str(target) + " no house")
				random_timer = random.randrange(24, 48)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)
				aggtarget_person_list_manager[target].set_bne_timer(agg_timer)
				continue

			elif ('failed' in agg_results) or ('ran off' in agg_results):
				print_function('BnE Results - Target ' + str(target) + ' FAILED', "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - Target " + str(target) + " FAILED")
				last_agg_time[0] = datetime.datetime.utcnow()
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
				agg_timer = agg_timer + datetime.timedelta(minutes=10)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

				house = get_house_from_string(agg_results)
				if house != "NOTFOUND":
					aggtarget_person_list_manager[target].set_house(house)

				# UPDATE LOCAL MODIFIERS
				desired_mins = int(aggstr_mins_max) + 2
				if desired_mins > 30:
					desired_mins = 30

				mins_adjusted = int(desired_mins) - int(aggstr_min_checking)

				if int(aggstr_mins_max) == 30:
					mins_adjusted = 'FAIL'

				write_file('./agg_targets/bne/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/BnE.txt', "\nBnE FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " HOUSE: " + str(house))
				append_file('./records/AllAggs.txt', "\nBnE FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " HOUSE: " + str(house))

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE THREAD FINISHED")
				return


			elif ('managed to' in agg_results):
				# You managed to break-into KobeBryant`s Palace and after turning the place up, found yourself $7,410! You also managed to find Shotgun (20/20) - after tearing the place apart!
				repay = True
				print_function('BnE Results - Target ' + str(target) + ' SUCCESS' + " AGG: " + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE - Target " + str(target) + " SUCCESS")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
				agg_timer = agg_timer + datetime.timedelta(minutes=10)
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

				house = get_house_from_string(agg_results)
				if house != "NOTFOUND":
					aggtarget_person_list_manager[target].set_house(house)

				# UPDATE LOCAL MODIFIERS
				try:
					mins_adjusted = read_file('./agg_targets/bne/' + target + '.txt')
					if mins_adjusted == 'FAIL':
						mins_adjusted = 30
					mins_adjusted = int(mins_adjusted)
				except:
					mins_adjusted = 0

				mins_adjusted -= 1
				write_file('./agg_targets/bne/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/BnE.txt', "\nBnE SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " HOUSE: " + str(house))
				append_file('./records/AllAggs.txt', "\nBnE SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " HOUSE: " + str(house))

				# TOOK DRUGS
				if 'helped' in agg_results:
					if config.getboolean('BnE', 'Discord_Notify_Drugs'):
						discord_message(config['Auth']['discord_id'] + "BNE TOOK DRUGS: " + agg_results)

				# TOOK WEAPON
				# You managed to break-into chadwick_is_dead`s Flat and after turning the place up, found yourself $0! You also managed to find a Colt .45 Revolver (30/30) - after tearing the place apart!
				if 'also' in agg_results:
					if 'to find a' in agg_results:
						which_weapon_taken = regex_match_between('to find a ', ' \(', agg_results)
					else:
						which_weapon_taken = regex_match_between('to find ', ' \(', agg_results)
					weapon_durability = regex_match_between('\(', '\)', agg_results)
					print_function('weapon: ' + str(which_weapon_taken) + ' durability: ' + str(weapon_durability) + ' target: ' + str(target))

					if config.getboolean('BnE_Weapon_Found', 'Discord_Notify_Weapon'):
						discord_message(config['Auth']['discord_id'] + "BNE TOOK WEAPON: " + agg_results)

					whitelist_return_weapon = False
					repay_whitelist = config['BnE']['Repay_Whitelist'].split()
					for whitelist_name in repay_whitelist:
						if target == whitelist_name:
							print_function('BnE - Return Weapon - TARGET IS WHITELISTED: ' + str(target), "BLUE")
							whitelist_return_weapon = True

					if whitelist_return_weapon:
						waiting_thread_list.append('9zSellItem//' + str(which_weapon_taken) + '//' + str(target) + '//1')
						discord_message(config['Auth']['discord_id'] + "RETURNING " + str(which_weapon_taken) + " AS TARGET " + str(target) + " IS IN WHITELIST")
					else:
						if config.getboolean('BnE_Weapon_Found', 'Return_Items'):
							print_function('BnE - Return Weapon - return items TRUE: ' + str(target), "BLUE")
							return_weapon_found = False
							if config['BnE_Weapon_Found']['Items_To_Return'] == '':
								config['BnE_Weapon_Found']['Items_To_Return'] = 'None'
							for item in config['BnE_Weapon_Found']['Items_To_Return'].split():
								if (item in which_weapon_taken) or (which_weapon_taken in item) or (item == 'All'):
									return_weapon_found = True

							if return_weapon_found:
								waiting_thread_list.append('9zSellItem//' + str(which_weapon_taken) + '//' + str(target) + '//1')
								print_function('BnE Zero - Return Weapon - RETURNING WEAPON TO: ' + str(target), "BLUE")
								print_function('9zSellItem THREAD QUEUED' + str(waiting_thread_list), "GREEN")
								# UPDATE TEXT BACKUP
								write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
								if config.getboolean('BnE_Weapon_Found', 'Discord_Notify_Weapon'):
									discord_message(config['Auth']['discord_id'] + "BNE RETURNING WEAPON: " + str(which_weapon_taken) + " TO: " + str(target))
							else:
								print_function('BnE Zero - Return Weapon - KEEPING WEAPON FROM: ' + str(target), "BLUE")
								repay = False
								discord_message(config['Auth']['discord_id'] + "KEEPING " + str(which_weapon_taken) + " AS IT IS NOT IN RETURN LIST - TV: " + config['Auth']['teamviewer_details'])
						else:
							print_function('BnE - Return Weapon - Return Items FALSE: ' + str(target), "BLUE")
							repay = False
							discord_message(config['Auth']['discord_id'] + "KEEPING " + str(which_weapon_taken) + " AS RETURN ITEMS TURNED OFF - TV: " + config['Auth']['teamviewer_details'])

				# UPDATE SHARED ALL AGGS RECORDS
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.utcnow().year) + '-' + str(datetime.datetime.utcnow().month) + '-' + str(datetime.datetime.utcnow().day) + '.txt', "\r\n" + str(your_character_name) + " BnE " + str(target) + " (Success) in " + str(globals()[your_current_city].which_city) + " on " + str(datetime.datetime.utcnow()))

				# REPAY CHECKS
				if not config.getboolean('BnE', 'Repay'):
					print_function('BnE - Repay - TURNED OFF', "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - Repay - TURNED OFF")
					repay = False

				repay_blacklist = config['BnE']['Repay_Blacklist'].split()
				for blacklist_name in repay_blacklist:
					if target == blacklist_name:
						print_function('BnE - Repay - TARGET IS BLACKLISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE - Repay - TARGET IS BLACKLISTED: " + str(target))
						repay = False

				repay_whitelist = config['BnE']['Repay_Whitelist'].split()
				for whitelist_name in repay_whitelist:
					if target == whitelist_name:
						print_function('BnE - Repay - TARGET IS WHITELISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE - Repay - TARGET IS WHITELISTED: " + str(target))
						repay = True

				if repay:
					repay_amount = regex_match_between('yourself', '!', agg_results)
					repay_amount = re.sub('[^0-9]', "", repay_amount)

					print_function('BnE - Repaying ' + str(repay_amount) + ' TO ' + str(target), "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE - Repaying " + str(repay_amount) + " TO " + str(target))
					# ADD REPAY TO RECORDS
					append_file('./records/BnE.txt', "\n BnE - Repaying " + repay_amount + " TO " + target)
					append_file('./records/AllAggs.txt', "\n BnE - Repaying " + repay_amount + " TO " + target)

					if int(repay_amount) > 0:
						transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target)

						# WAIT FOR TRANSFER TO BE QUEUED
						print_function('BnE - Waiting for repay to be queued', "BLUE")
						while True:
							if 'transfer_money_thread' in str(waiting_thread_list):
								break
						print_function('BnE - repay is queued', "BLUE")

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE THREAD FINISHED")
				return

			else:
				print_function('BnE - results not found' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BnE - results not found" + str(agg_results))
				continue

		for thread in waiting_thread_list:
			if ('AggstrLowest' in thread):
				try:
					waiting_thread_list.remove(thread)
				except:
					pass
		thread_remove_from_queue(running_thread, waiting_thread_list)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t BNE THREAD FINISHED")
		return
	except:
		from code_modules.function import PrintException
		PrintException()
