from globalvars import *
from code_modules.function import *

def hospital(lock_webdriver, running_thread, waiting_thread_list, your_character_name):
	if config.getboolean('Career-Hospital', 'Do_Cases'):
		if globals()['timers'].__dict__['resting_page_timer'] is None:
			globals()['timers'].__dict__['resting_page_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['resting_page_timer']
		hospital_stuff_found = False
		if not '-' in str(time_difference):
			# RESTING PAGE UPDATED
			url_check = get_url(lock_webdriver)
			if 'hospital.asp' in url_check:

				if element_found(lock_webdriver, "XPATH", ".//*[@id='holder_table']/form/div[@id='holder_content']/center/table"):
					hospital_table = element_get_attribute(lock_webdriver, "XPATH",
														   ".//*[@id='holder_table']/form/div[@id='holder_content']/center/table",
														   "innerHTML")
					for entry in hospital_table.split("<tr>"):
						if "PROCESS SAMPLE" in entry:
							hospital_stuff_found = True
							print_function('resting page dna')
						elif "COMMENCE SURGERY" in entry:
							hospital_stuff_found = True
							print_function('resting page surgery')
						elif "PROVIDE ASSISTANCE" in entry:
							hospital_stuff_found = True
							print_function('resting page heal')
						elif "START TREATMENT" in entry:
							hospital_stuff_found = True
							print_function('resting page flu')
					print_function('resting page checked')
				globals()['timers'].__dict__['resting_page_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

		if globals()['timers'].__dict__['career_timer'] is None:
			globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=30)
		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['career_timer']
		if (not '-' in str(time_difference)) or (hospital_stuff_found):
			print_function('HOSPITAL - QUEUED')
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)
			print_function("HOSPITAL - START")

			# TIMER FOR MANUAL CHECK
			url_check = get_url(lock_webdriver)
			if 'hospital.asp' in url_check:
				# REFRESH PAGE
				print_function('HOSPITAL - REFRESH')
				element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/div/table/tbody/tr[1]/td[1]/a", running_thread)
			else:
				# NO GOTOPAGE AS WE NEED TO CHECK FOR TORCH
				open_city(lock_webdriver, running_thread)

				if element_found(lock_webdriver, "XPATH", ".//*[@class='maintenance']/a[@class='business hospital']"):
					# HOSPITAL TORCHED
					random_timer = random.randrange(20, 30)
					globals()['timers'].__dict__['resting_page_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
					globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
					print_function('hospital torched')
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return
				else:
					element_click(lock_webdriver, "XPATH", ".//*[@class='business hospital']", running_thread)
				print_function('HOSPITAL - CLICKED')

				# HOSPITAL TORCHED
				if element_found(lock_webdriver, "ID", "fail"):
					results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
					if 'under going repairs' in results:
						print_function('hospital torched')
						random_timer = random.randrange(20, 30)
						globals()['timers'].__dict__['resting_page_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
						globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
						print_function('hospital torched')
						thread_remove_from_queue(running_thread, waiting_thread_list)
						return

			# GET TABLE. CHECK FOR LINK TEXT
			if element_found(lock_webdriver, "XPATH", ".//*[@id='holder_table']/form/div[@id='holder_content']/center/table"):
				pass
			else:
				element_click(lock_webdriver, "XPATH", ".//*[@id='content']/center/div[@id='holder_table']/form/div[@id='holder_content']/div[@class='links']/table/tbody/tr[1]/td[1]/a", running_thread)
			hospital_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_table']/form/div[@id='holder_content']/center/table", "innerHTML")
			hospital_stuff_clicked = False
			surgery_count = 0
			for entry in hospital_table.split("<tr>"):
				if "PROCESS SAMPLE" in entry:
					hospital_stuff_clicked = True
					element_click(lock_webdriver, "LINK", "PROCESS SAMPLE", running_thread)
					break
				elif "COMMENCE SURGERY" in entry:
					surgery_name = regex_match_between('username=', '"', entry)
					if str(your_character_name) == str(surgery_name):
						pass
					else:
						hospital_stuff_clicked = True
						element_click(lock_webdriver, "LINK", "COMMENCE SURGERY", running_thread, surgery_count)
						break
					surgery_count = int(surgery_count) + 1
				elif "START TREATMENT" in entry:
					surgery_name = regex_match_between('username=', '"', entry)
					if str(your_character_name) == str(surgery_name):
						pass
					else:
						hospital_stuff_clicked = True
						element_click(lock_webdriver, "LINK", "START TREATMENT", running_thread, surgery_count)
						break
					surgery_count = int(surgery_count) + 1
				elif "PROVIDE ASSISTANCE" in entry:
					hospital_stuff_clicked = True
					element_click(lock_webdriver, "LINK", "PROVIDE ASSISTANCE", running_thread)
					break
				else:
					# NO HOSPITAL STUFF
					random_timer = random.randrange(22, 43)
					globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
						seconds=random_timer)


			if hospital_stuff_clicked:
				case_timer_seconds = get_timer(lock_webdriver, 'Case', running_thread)
				if int(case_timer_seconds) > 0:
					globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=case_timer_seconds)

			thread_remove_from_queue(running_thread, waiting_thread_list)
	return

