from globalvars import *
from code_modules.function import *

def mayor_sell(lock_webdriver, running_thread, waiting_thread_list):
	# CHANGE PRIORITY OF THREAD
	for thread in waiting_thread_list:
		if 'mayor_sell' in thread:
			try:
				waiting_thread_list.remove(thread)
			except:
				pass
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)

	print_function('ACTION - MAYOR - SELL STOCKS')

	go_to_page(lock_webdriver, "MayorStocks", running_thread)

	running_thread[0] = str('1mayor_sell')

	stocks_list = ["MafiaMatrix Times", "International Airport Federation",
				   "MafiaMatrix Public Transport System", "Academy of MafiaMatrix Education",
				   "MafiaMatrix Vehicle Association", "MafiaMatrix Telecommunications"]

	stocks_dict_quantity_to_sell = {}

	# GET ALL STOCK DETAILS
	stocks_table = element_get_attribute(lock_webdriver, "XPATH",
										 ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table",
										 "innerHTML")
	stocks_table_split = stocks_table.split("<tr>")
	for stock in stocks_table_split:
		if 'name="qty' in stock:
			stock_details = stock.split("<td ")
			stock_name = regex_match_between('center">', '<', stock_details[1])
			stock_quantity_owned = regex_match_between('center">', '<', stock_details[3])
			stock_quantity_owned = re.sub('[^0-9]', "", stock_quantity_owned)
			stocks_dict_quantity_to_sell[stock_name] = stock_quantity_owned

	# BUY STOCKS BASED ON QUANTITY VARIABLE
	for stock in stocks_list:
		if int(stocks_dict_quantity_to_sell[stock]) > 0:
			clearkeys(lock_webdriver, "XPATH",
					  ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
						  int(stocks_list.index(
							  stock)) + 2) + "]/td[@class='display_border'][4]/p/input[@class='input']")
			sendkeys(lock_webdriver, "XPATH",
					 ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
						 int(stocks_list.index(
							 stock)) + 2) + "]/td[@class='display_border'][4]/p/input[@class='input']",
					 str(int(stocks_dict_quantity_to_sell[stock])))

	element_click(lock_webdriver, "XPATH", ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[@class='nohover']/td[5]/p/input[@class='submit']", running_thread)
	print_function('ACTION - MAYOR - STOCKS SOLD')

	for thread in waiting_thread_list:
		if 'mayor_sell' in thread:
			try:
				waiting_thread_list.remove(thread)
			except:
				pass
	return
