from globalvars import *
from code_modules.function import *

def online_time_record(lock_webdriver, running_thread, waiting_thread_list, next_onlinehours_timer, onlinehours_locked_until):
	time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['next_online_list_timer']
	if not '-' in str(time_difference):
		onlinehours_time_difference = (datetime.datetime.utcnow() - next_onlinehours_timer)
		if not '-' in str(onlinehours_time_difference):
			locked_time_difference = (datetime.datetime.utcnow() - onlinehours_locked_until)
			# print_function("online_time_record - PASSED TIMER 1", "BLUE")
			if not '-' in str(locked_time_difference):
				print_function("online_time_record - PASSED TIMER 2", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ONLINE TIME RECORDS UPDATE - ADD TO QUEUE")
				thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_onlinelist)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ONLINE TIME RECORDS UPDATE - RUNNING")

				# SET LOCKEDTIME NOW + 3MINS - TO PREVENT MULTIPLE PEOPLE ATTEMPTING THE SAME UPDATE
				my_cached_lockeduntil = datetime.datetime.utcnow() + datetime.timedelta(minutes=3)
				update_database('Timers', 'Timer', 'OnlineHours', {"LockedUntil": str(my_cached_lockeduntil)})

				online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
				if '*' in online_player_list_raw:
					# ALREADY FULL LIST
					pass
				else:
					element_click(lock_webdriver, "XPATH", ".//*[@id='footer_content']/a", running_thread)
					online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")

				full_online_list = ""

				online_year = globals()['timers'].__dict__['next_online_list_timer'].year
				online_month = globals()['timers'].__dict__['next_online_list_timer'].month
				if int(online_month) < 10:
					online_month = "0" + str(online_month)
				online_day = globals()['timers'].__dict__['next_online_list_timer'].day
				if int(online_day) < 10:
					online_day = "0" + str(online_day)
				online_hour = globals()['timers'].__dict__['next_online_list_timer'].hour
				if int(online_hour) < 10:
					online_hour = "0" + str(online_hour)
				online_minute = globals()['timers'].__dict__['next_online_list_timer'].minute
				if int(online_minute) < 10:
					online_minute = "0" + str(online_minute)


				# GET EXISTING PLAYER CLOUD DATABASE
				player_bulk_update_list = []
				player_database = get_from_database('Player', None)
				print_function("PLAYER DATABASE:" + str(player_database), "BLUE")


				online_player_list_raw_split = online_player_list_raw.split("|")
				for player_raw in online_player_list_raw_split:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ONLINE TIME RECORDS UPDATE - PLAYER RAW: " + str(player_raw))
					if (':Alive:player:' in player_raw) or (':In-Jail:player:' in player_raw):
						if '<font color="#DB70DB">' in str(player_raw):
							player_name = regex_match_between('#DB70DB">', '<', player_raw)
						else:
							player_name = regex_match_between('>', '<', player_raw)
						full_online_list = full_online_list + player_name + " | "

				filepath = 'OnlineTimes/' + str(online_year) + '-' + str(online_month) + '-' + str(online_day) + '/' + str(
					online_hour) + '-' + str(online_minute) + ".txt"





				# CHECK NO DUPLICATE BEFORE UPDATE
				response = get_from_database('Timers', 'LockedUntil', "Key('Timer').eq('OnlineHours')")
				onlinehours_locked_until = datetime.datetime.strptime(response['Items'][0]['LockedUntil'], '%Y-%m-%d %H:%M:%S.%f')
				if my_cached_lockeduntil == onlinehours_locked_until:
					# NO ONE ELSE HAS STARTED THIS ONLINE HOURS UPDATE

					# INCREMENT ONLINE HOURS FOR PEOPLE IN THE CURRENT ONLINE LIST
					item_count = (len(player_database['Items']) - 1)
					while item_count >= 0:
						database_player_name = player_database['Items'][item_count]['PlayerName']

						if database_player_name in str(full_online_list):
							try:
								online_hours = player_database['Items'][item_count]['Hours']
								online_hours = int(online_hours) + 1
							except:
								try:
									response = get_from_database('Players', 'Hours', "Key('PlayerName').eq('" + str(database_player_name) + "')")
									online_hours = response['Items'][0]['Hours']
								except:
									print_function("ONLINE TIME RECORD - NO ONLINE HOURS FOUND IN DATABASE FOR " + str(database_player_name), "RED")
									item_count -= 1
									continue

							this_player_list = ['PlayerName', database_player_name, 'UpdatedBy', 'OnlineHours', 'Hours', online_hours]
							for item_key in player_database['Items'][item_count]:
								if item_key in this_player_list:
									pass
								else:
									item_value = player_database['Items'][item_count][item_key]
									this_player_list.append(item_key)
									this_player_list.append(item_value)
							player_bulk_update_list.append(this_player_list)
							print_function("ONLINE HOURS - INCREMENTING HOURS FOR " + str(this_player_list), "BLUE")
						else:
							# SKIP THIS NAME AS NOT IN THE ONLINE LIST
							pass
						item_count -= 1



					if s3_file_exists('roastbusters', filepath):
						# ALREADY DONE BY SOMEONE
						print_function("ONLINE TIME RECORD - FILEPATH ALREADY DONE: " + str(filepath), "RED")
						thread_remove_from_queue(running_thread, waiting_thread_list)

						response = get_from_database('Timers', 'LockedUntil', "Key('Timer').eq('OnlineHours')")
						onlinehours_locked_until = datetime.datetime.strptime(response['Items'][0]['LockedUntil'], '%Y-%m-%d %H:%M:%S.%f')
						if my_cached_lockeduntil == onlinehours_locked_until:
							# S3 file exists and no one else has taken over - how did this happen? set timer to prevent infinite loop
							# UPDATE ONLINE HOURS TIMER FOR NEXT CHECK - CLOUD
							globals()['timers'].set_online_list_timer()
							print_function('NEXT ONLINE TIME RECORD ' + str(globals()['timers'].__dict__['next_online_list_timer']), "BLUE")
							lation: -10
							update_database('Timers', 'Timer', 'OnlineHours', {"NextTimer": str(globals()['timers'].__dict__['next_online_list_timer'])})
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ONLINE TIME RECORDS UPDATE - FINISHED FUNCTION")

						return True
					else:
						bulk_update_database('Player', player_bulk_update_list)

						append_s3('roastbusters', filepath, str(full_online_list))
						print_function("ONLINE TIME RECORD - FILEPATH DONE: " + str(filepath), "GREEN")
						print_function("ADDED ONLINE LIST: " + str(full_online_list), "GREEN")

						# UPDATE ONLINE HOURS TIMER FOR NEXT CHECK - CLOUD
						globals()['timers'].set_online_list_timer()
						print_function('NEXT ONLINE TIME RECORD ' + str(globals()['timers'].__dict__['next_online_list_timer']), "BLUE")
						lation: -10
						update_database('Timers', 'Timer', 'OnlineHours', {"NextTimer": str(globals()['timers'].__dict__['next_online_list_timer'])})
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ONLINE TIME RECORDS UPDATE - FINISHED FUNCTION")

						thread_remove_from_queue(running_thread, waiting_thread_list)
						return True
				else:
					print_function("ONLINE TIME RECORD - SKIP UPDATE AS SOMEONE ELSE STARTED", "RED")
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return True