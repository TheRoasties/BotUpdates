from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

def bank_career(lock_webdriver, running_thread, waiting_thread_list, home_city):
	if globals()['timers'].__dict__['banker_add_clients'] is None:
		random_timer = random.randrange(5, 20)
		globals()['timers'].__dict__['banker_add_clients'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)

	time_difference_add_clients = datetime.datetime.utcnow() - globals()['timers'].__dict__['banker_add_clients']

	# LAUNDERING WILL USE CASE TIMER - THIS IS CHECKED PRIOR TO bank_career BY THE MISC THREAD

	if config.getboolean('Career-Bank', 'do_launders') or (config.getboolean('Career-Bank', 'add_clients') and (not '-' in str(time_difference_add_clients))):
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)
		print_function('MISC - BANK CAREER - START')

		url_check = get_url(lock_webdriver)
		if 'display=establish' in str(url_check):
			open_city(lock_webdriver, running_thread)

		go_to_page(lock_webdriver, "BankCareer", running_thread)

		# DO LAUNDER
		if config.getboolean('Career-Bank', 'do_launders'):
			clients_list = element_get_attribute(lock_webdriver, "XPATH",
													".//*[@id='account_profile']/div[@id='holder_content']",
													"innerHTML")

			if 'no deals' in clients_list:
				# NO ONE ADDED FOR LAUNDERING
				print_function('MISC - BANK CAREER - NO CLIENTS. SET TIMER FOR ADDING CLIENTS TO NOW')
				globals()['timers'].__dict__['banker_add_clients'] = datetime.datetime.utcnow() - datetime.timedelta(hours=2)
			else:
				print_function('MISC - BANK CAREER - CHECKING CLIENTS')
				# PROCESS LAUNDERS

				clients_list_split = clients_list.split("<tr>")
				item_split = clients_list_split[2].split("<td")

				if "<tr>" in str(clients_list):
					pass
				else:
					discord_error("could not find client list - results: " + str(clients_list))

				client_name = item_split[1]
				client_name = regex_match_between('\d+">', '<', client_name)

				launder_amount = item_split[3]
				launder_amount = regex_match_between('\$', '<', launder_amount)
				launder_amount = re.sub('[^0-9]', "", launder_amount)
				transfer_launder_amount = float(launder_amount) * 0.94
				transfer_launder_amount = int(transfer_launder_amount)

				if int(launder_amount) > 4:
					# INCREASE PRIORITY DURING LAUNDER
					running_thread[0] = str('1') + inspect.stack()[0][3]

					'''
					# QUEUE BACKUP TRANSFER
					transfer_money(lock_webdriver, running_thread, waiting_thread_list, transfer_launder_amount, client_name)
					print_function('MISC - BANK CAREER - BACKUP TRANSFER ' + str(transfer_launder_amount) + ' TO ' + str(client_name))
					print_function(str(waiting_thread_list))
					# UPDATE TEXT BACKUP
					write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
					'''

					# CLICK BALANCE
					element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/table/tbody/tr[2]/td[3]/a", running_thread)

					# LAUNDER DROPDOWN
					select_dropdown_option(lock_webdriver, "NAME", "display", "Launder Money")

					click_continue(lock_webdriver, running_thread)
					print_function('MISC - BANK CAREER - LAUNDERED ' + str(launder_amount) + ' FOR ' + str(client_name))

					# CLICK AUTO TRANSFER
					element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/p/input[1]", running_thread)
					print_function('MISC - BANK CAREER - TRANSFERRED (GROSS) ' + str(launder_amount) + ' TO ' + str(client_name))

					'''
					# REMOVE QUEUED BACKUP TRANSFER
					TransferMoneyPID = read_file("env/TransferMoneyPID.txt")
					try:
						if platform.system() != 'Windows':
							os.kill(int(TransferMoneyPID), signal.SIGKILL)
						else:
							os.kill(int(TransferMoneyPID), signal.SIGTERM)
					except:
						pass

					for thread in waiting_thread_list:
						if ('transfer_money' in thread) and (client_name in thread):
							try:
								waiting_thread_list.remove(thread)
							except:
								pass
							print_function('MISC - BANK CAREER - REMOVE BACKUP TRANSFER ' + str(transfer_launder_amount) + ' TO ' + str(client_name))
							print_function(str(waiting_thread_list))

							# UPDATE TEXT BACKUP
							write_file("env/waiting_thread_list.txt", str(waiting_thread_list))
					'''

					# RETURN PRIORITY TO NORMAL
					running_thread[0] = str(priority_thread_career) + inspect.stack()[0][3]

					globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Case', running_thread))
				else:
					print_function('MISC - BANK CAREER - TOP LAUNDER INSUFFICIENT - ' + str(launder_amount) + ' FOR ' + str(client_name))
					random_timer = random.randrange(6, 20)
					globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)

		# ADD CLIENTS
		if config.getboolean('Career-Bank', 'add_clients'):
			time_difference_add_clients = datetime.datetime.utcnow() - globals()['timers'].__dict__['banker_add_clients']
			if not '-' in str(time_difference_add_clients):
				print_function('MISC - BANK CAREER - ADDING CLIENTS', "BLUE")

				# MAKE SURE ON CLIENTS PAGE FOR LISTS
				if 'banklaunder.asp?display=deals' in get_url(lock_webdriver):
					pass
				else:
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='account_holder']/div[@id='account_nav']/ul/li[1]/a", running_thread)

				clients_list = element_get_attribute(lock_webdriver, "XPATH",
														   ".//*[@id='account_profile']/div[@id='holder_content']",
														   "innerHTML")


				existing_clients_list = []
				admin_list = ["LuciferMorningstar", "Roger", "Mookota", "Animosity", "Masonist"]
				clients_list_split = clients_list.split("<tr>")
				for client in clients_list_split:
					if 'display=gangster' in client:
						item_split = client.split("<td")
						client_name = item_split[1]
						client_name = regex_match_between('\d+">', '<', client_name)
						existing_clients_list.append(client_name)

				for admin_name in admin_list:
					existing_clients_list.append(admin_name)
				print_function('EXISTING LIST: ' + str(existing_clients_list))

				clients_list_to_add = get_from_database('Player', 'PlayerName, HomeCity, AliveStatus')
				item_count = (len(clients_list_to_add['Items']) - 1)
				while item_count >= 0:
					client = clients_list_to_add['Items'][item_count]['PlayerName']

					try:
						client_homecity = clients_list_to_add['Items'][item_count]['HomeCity']
					except:
						client_homecity = ""

					try:
						client_status = clients_list_to_add['Items'][item_count]['AliveStatus']
					except:
						client_status = ""

					# SKIP LOCKED & DEAD CLIENTS
					if client_status != 'Alive':
						print_function('MISC - BANK CAREER - SKIP NON-ALIVE CLIENT ' + str(client) + " STATUS:" + str(client_status),  "BLUE")
						clients_list_to_add['Items'].pop(item_count)
						item_count -= 1
						continue

					# SKIP EXISTING CLIENTS
					if client in existing_clients_list:
						print_function('MISC - BANK CAREER - SKIP EXISTING CLIENT ' + str(client), "BLUE")
						clients_list_to_add['Items'].pop(item_count)
						item_count -= 1
						continue

					# SKIP SAME HOMECITY
					if home_city == client_homecity:
						print_function('MISC - BANK CAREER - CLIENT ' + str(client) + ' SKIPPED AS HOMECITY ' + str(client_homecity), "BLUE")
						clients_list_to_add['Items'].pop(item_count)
						item_count -= 1
						continue


					# ESTABLISH NEW DEAL
					print_function('MISC - BANK CAREER - ADDING NEW CLIENT ' + str(client), "BLUE")
					element_click(lock_webdriver, "XPATH", ".//*[@id='account_nav']/ul/li[2]/a", running_thread)
					sendkeys(lock_webdriver, "NAME", "gangster", client)
					click_continue(lock_webdriver, running_thread)

					# CHECK ADDED OKAY
					if element_found(lock_webdriver, "ID", "fail"):
						fail_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
						if 'appear to exist' in fail_results:
							print_function('MISC - BANK CAREER - ADD CLIENT ' + str(client) + ' FAILED DEAD', "BLUE")
							update_database('Player', 'PlayerName', str(client), {"AliveStatus": "Unknown", "UpdatedBy": "BankCareer-Dead"})

						if 'from your home city' in fail_results:
							print_function('MISC - BANK CAREER - ADD CLIENT ' + str(client) + ' FAILED SAME HOMECITY', "BLUE")
							update_database('Player', 'PlayerName', str(client), {"AliveStatus": "HomecityChanged", "HomeCity": "Unknown", "UpdatedBy": "BankCareer-HomecityChanged"})
					clients_list_to_add['Items'].pop(item_count)
					item_count -= 1


				print_function('MISC - BANK CAREER - ALL CLIENTS ADDED')
				random_timer = random.randrange(60, 180)
				globals()['timers'].__dict__['banker_add_clients'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
			else:
				print_function("MISC - BANK CAREER - SKIP ADDING CLIENTS DUE TO TIMER", "BLUE")

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return True
	return False
