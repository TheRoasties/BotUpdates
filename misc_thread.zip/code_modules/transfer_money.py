from globalvars import *
from code_modules.function import *


def transfer_money(lock_webdriver, running_thread, waiting_thread_list,  amount, recipient):
	additional_string = '<|>' + str(amount) + '<|>' + str(recipient)
	thread_transfer_money = Process(target=transfer_money_thread,
									args=(lock_webdriver, running_thread, waiting_thread_list, additional_string))
	thread_transfer_money.start()
	waiting_thread_list.append('9zAwaitingTransferMoney')
	print_function(waiting_thread_list)
	return


def transfer_money_thread(lock_webdriver, running_thread, waiting_thread_list, additional_string):
	# THIS SHOULD NOT BE CALLED DIRECTLY. THIS IS USED BY TRANSFER_MONEY() AS A BACKEND
	import multiprocessing
	write_file("env/TransferMoneyPID.txt", str(multiprocessing.current_process().pid))

	for thread in waiting_thread_list:
		if 'AwaitingTransferMoney' in thread:
			try:
				waiting_thread_list.remove(thread)
			except:
				pass

	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_transfermoney, additional_string)

	parse_additional_string = additional_string.split("<|>")
	amount = parse_additional_string[1]
	recipient = parse_additional_string[2]

	if 'NoTransferMoneyRecipient' in recipient:
		print_function('transfer_money_thread WITH NO VALID RECIPIENT. HOW DID THIS HAPPEN? RECIPIENT: ' + str(recipient), "RED")
		input('ERROR')

	if 'REPAYBIZ--' in recipient:
		if '--PUBLIC' in recipient:
			type = 'PUBLIC'
			biz_name = regex_match_between('--PUBLIC--', '//', recipient)
			biz_city = regex_match_between('//', None, recipient)

			for city_item_spaces in globals()['cities_list_spaces']:
				city_item_check = city_item_spaces.replace(" ", "")
				if city_item_check == biz_city:
					biz_city = city_item_spaces

			open_city(lock_webdriver, running_thread)

			# OPEN YELLOW PAGES
			element_click(lock_webdriver, "XPATH", ".//*[@class='business yellow_pages']", running_thread)

			# BANK
			if 'Bank' in biz_name:
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/center/div/div[2]/table[2]/tbody/tr[2]/td[@class='display_border'][3]/form",
							  running_thread)

			# HOSPITAL
			elif 'Hospital' in biz_name:
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/center/div/div[2]/table[2]/tbody/tr[2]/td[@class='display_border'][4]/form",
							  running_thread)

			# ENGINEERING
			elif 'Construction' in biz_name:
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/center/div/div[2]/table[2]/tbody/tr[2]/td[@class='display_border'][5]/form",
							  running_thread)

			# FUNERAL
			elif 'Funeral' in biz_name:
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/center/div/div[2]/table[2]/tbody/tr[2]/td[@class='display_border'][6]/form",
							  running_thread)

			# FIRE
			elif 'Fire' in biz_name:
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/center/div/div[2]/table[2]/tbody/tr[4]/td[@class='display_border'][1]/form",
							  running_thread)

			# CUSTOMS
			elif 'Airport' in biz_name:
				element_click(lock_webdriver, "XPATH",
							  ".//*[@id='content']/center/div/div[2]/table[2]/tbody/tr[4]/td[@class='display_border'][3]/form",
							  running_thread)

			found_repay_name = False
			yellowpages_table = element_get_attribute(lock_webdriver, "XPATH",
													  ".//*[@id='wrapper']/div[@id='content']/center/div/div[2]/table",
													  "innerHTML")
			yellowpages_table_split = yellowpages_table.split('<tr>')
			for row in yellowpages_table_split:
				if 'userprofile.asp' in row:
					name = row.splitlines()[2]
					name = regex_match_between('>', '<', name)
					occupation = row.splitlines()[5].strip()
					rank = row.splitlines()[8].strip()
					city = row.splitlines()[11].strip()
					print_function('name: ' + str(name) + ' occupation: ' + str(occupation) + ' rank: ' + str(rank) + ' city: ' + str(city))

					if (biz_city == city) and (occupation == 'Bank Manager') and ('Bank' in biz_name):
						recipient = name
						found_repay_name = True
						break
					elif (biz_city == city) and (occupation == 'Hospital Director') and ('Hospital' in biz_name):
						recipient = name
						found_repay_name = True
						break
					elif (biz_city == city) and (occupation == 'Chief Engineer') and ('Construction' in biz_name):
						recipient = name
						found_repay_name = True
						break
					elif (biz_city == city) and (occupation == 'Funeral Director') and ('Funeral' in biz_name):
						recipient = name
						found_repay_name = True
						break
					elif (biz_city == city) and (occupation == 'Fire Chief') and ('Fire' in biz_name):
						recipient = name
						found_repay_name = True
						break
					elif (biz_city == city) and (rank == 'Commissioner-General') and ('Airport' in biz_name):
						recipient = name
						found_repay_name = True
						break
				else:
					continue
			if found_repay_name:
				pass
			else:
				print_function('NOT REPAYING ' + str(biz_name) + ' IN ' + str(biz_city) + ' AS UNOWNED')
				write_file("env/Aggs_Thread_Log.txt", "NOT REPAYING " + str(biz_name) + " IN: " + str(biz_city) + " AS UNOWNED")

				for thread in waiting_thread_list:
					if ('transfer_money_thread' in thread) and (amount in thread) and (recipient in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass

				# UPDATE TEXT BACKUP
				waiting_thread_list.sort()
				write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

				thread_remove_from_queue(running_thread, waiting_thread_list)
				return True

		elif '--PRIVATE' in recipient:
			type = 'PRIVATE'
			biz_name = regex_match_between('--PRIVATE--', '//', recipient)
			biz_city = regex_match_between('//', None, recipient)

			for city_item_spaces in globals()['cities_list_spaces']:
				city_item_check = city_item_spaces.replace(" ", "")
				if city_item_check == biz_city:
					biz_city = city_item_spaces

			element_click(lock_webdriver, "XPATH", ".//*[@class='shake-slow'][4]/a[1]/span[@class='business']", running_thread)

			biz_page_check = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='biz_holder']/div[@id='holder_top']/h1", "innerHTML")
			if 'Businesses' in biz_page_check:
				# ON CORRECT PAGE
				if biz_city in biz_page_check:
					private_business_table = element_get_attribute(lock_webdriver, "XPATH",
																   ".//*[@id='content']/div[@id='biz_holder']/div[@id='holder_content']/table",
																   "innerHTML")
					private_business_split = private_business_table.split('<tr class="nohover">')
					for business in private_business_split:
						if 'a href' in business:
							business_details = business.split('<td width=')
							business_name = business_details[1]
							business_name = regex_match_between('>', '<', business_name)
							business_name = business_name.strip()
							business_owner = business_details[2]
							business_owner = regex_match_between('u=', '">', business_owner)
							business_owner = business_owner.strip()
							if biz_name == business_name:
								recipient = business_owner
								break
						else:
							continue
				else:
					discord_message(config['Auth']['discord_id'] + get_your_character_name(lock_webdriver) + ' TRANSFER MONEY - FAILED SENDING ' + str(amount) + ' TO: ' + str(recipient) + " REASON: YOU ARE IN THE WRONG CITY TO FIND THE OWNER -- TV: " + config['Auth']['teamviewer_details'])
			else:
				print_function('biz page check: ' + str(biz_page_check))
				input("TRANSFER MONEY PRIVATE - NOT ON CORRECT BUSINESS PAGE?")

		else:
			input('TRANSFER MONEY TO BIZ OWNER - TYPE NOT FOUND')
		print_function('repay: ' + str(recipient) + ' type: ' + str(type) + ' biz name: ' + str(biz_name) + ' city: ' + str(biz_city))

		if recipient == 'Administrator':
			print_function('NOT REPAYING ' + str(biz_name) + ' IN ' + str(biz_city) + ' AS UNOWNED')
			write_file("env/Aggs_Thread_Log.txt", "NOT REPAYING " + str(biz_name) + " IN: " + str(biz_city) + " AS UNOWNED")

			for thread in waiting_thread_list:
				if ('transfer_money_thread' in thread) and (amount in thread) and (recipient in thread):
					try:
						waiting_thread_list.remove(thread)
					except:
						pass

			# UPDATE TEXT BACKUP
			waiting_thread_list.sort()
			write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

			thread_remove_from_queue(running_thread, waiting_thread_list)
			return True

	go_to_page(lock_webdriver, "TransferMoney", running_thread)

	if '--' in recipient:
		discord_message(config['Auth']['discord_id'] + get_your_character_name(lock_webdriver) + ' TRANSFER MONEY - FAILED SENDING ' + str(amount) + ' TO: ' + str(recipient) + " REASON: COULD NOT FIND BUSINESS OWNER -- TV: " + config['Auth']['teamviewer_details'])
		input('REPAY NAME BROKEN')

	print_function('TRANSFER MONEY - ENTERED DETAILS: ' + str(amount) + " " + str(recipient))
	sendkeys(lock_webdriver, "NAME", "transferamount", amount)
	sendkeys(lock_webdriver, "NAME", "transfername", recipient)

	print_function('TRANSFER MONEY - SUBMIT')
	# SUBMIT
	click_continue(lock_webdriver, running_thread)

	if element_found(lock_webdriver, "ID", "success"):
		was_transfer_successful = True
		print_function('TRANSFER MONEY - SUCCESS: ' + str(amount) + ' TO: ' + str(recipient))
		write_file("env/Aggs_Thread_Log.txt","PAID: " + str(amount) + " TO: " + str(recipient))
	else:
		was_transfer_successful = False
		transfer_failed_reason = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='content']/div[@id='fail']", "innerHTML")

		print_function('TRANSFER MONEY - FAILED: ' + str(amount) + ' TO: ' + str(recipient) + " REASON: " + str(transfer_failed_reason), "RED")
		write_file("env/Aggs_Thread_Log.txt", "COULD NOT REPAY: " + str(amount) + " TO: " + str(recipient))

		if ('not playing anymore' in transfer_failed_reason) or ('blocked due to possible spam' in transfer_failed_reason):
			pass
		else:
			discord_message(config['Auth']['discord_id'] + get_your_character_name(lock_webdriver) + ' TRANSFER MONEY - FAILED SENDING ' + str(amount) + ' TO: ' + str(recipient) + " REASON: " + transfer_failed_reason + " TV: " + config['Auth']['teamviewer_details'])

	for thread in waiting_thread_list:
		if ('transfer_money_thread' in thread) and (amount in thread) and (recipient in thread):
			try:
				waiting_thread_list.remove(thread)
			except:
				pass

	# UPDATE TEXT BACKUP
	waiting_thread_list.sort()
	write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

	thread_remove_from_queue(running_thread, waiting_thread_list)

	return was_transfer_successful