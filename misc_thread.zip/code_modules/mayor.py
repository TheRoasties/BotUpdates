from globalvars import *
from code_modules.function import *

def mayor_buy(lock_webdriver, running_thread, waiting_thread_list):
	if globals()['timers'].__dict__['career_timer'] is None:
		globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
			seconds=get_timer(lock_webdriver, 'Trafficking', running_thread))
	time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['career_timer']
	if not '-' in str(time_difference):
		# TRAFFIC TIMER READY
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)
		print_function('MISC - MAYOR - START')
		go_to_page(lock_webdriver, "MayorStocks", running_thread)

		available_funds = element_get_attribute(lock_webdriver, "XPATH",
												".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/p[1]/b",
												"innerHTML")
		available_funds = re.sub('[^0-9]', "", available_funds)
		total_assets_value = available_funds

		stocks_list = ["MafiaMatrix Times", "International Airport Federation",
					   "MafiaMatrix Public Transport System", "Academy of MafiaMatrix Education",
					   "MafiaMatrix Vehicle Association", "MafiaMatrix Telecommunications"]

		stocks_dict_price = {}
		stocks_dict_quantity = {}
		stocks_dict_owned = {}
		stocks_dict_quantity_to_buy = {}
		most_expensive_owned_stock = None
		cheapest_unowned_stock = None

		# CLICK BUY TO REFRESH PRICES
		element_click(lock_webdriver, "XPATH",
					  ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[@class='nohover']/td[4]/p/input[@class='submit']", running_thread)

		# GET ALL STOCK DETAILS
		stocks_table = element_get_attribute(lock_webdriver, "XPATH",
											 ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table",
											 "innerHTML")
		stocks_table_split = stocks_table.split("<tr>")
		for stock in stocks_table_split:
			if 'name="qty' in stock:
				stock_details = stock.split("<td ")
				stock_name = regex_match_between('center">', '<', stock_details[1])
				stock_price = regex_match_between('center">', '<', stock_details[2])
				stock_quantity_owned = regex_match_between('center">', '<', stock_details[3])
				stock_price = re.sub('[^0-9]', "", stock_price)
				stock_quantity_owned = re.sub('[^0-9]', "", stock_quantity_owned)
				total_value = int(stock_price) * int(stock_quantity_owned)
				total_assets_value = int(total_assets_value) + int(total_value)
				stocks_dict_price[stock_name] = stock_price
				stocks_dict_quantity[stock_name] = stock_quantity_owned
				stocks_dict_owned[stock_name] = False
				stocks_dict_quantity_to_buy[stock_name] = 0

		# GET LOWEST QUANTITY TO DETERMINE WHICH STOCKS WE OWN
		we_own_any_stock = False
		lowest_stock_quantity = None
		for stock in stocks_list:
			if lowest_stock_quantity is None:
				lowest_stock_quantity = stocks_dict_quantity[stock]
			elif int(stocks_dict_quantity[stock]) <= int(lowest_stock_quantity):
				lowest_stock_quantity = stocks_dict_quantity[stock]
			else:
				we_own_any_stock = True

		# CHECK WHICH STOCKS WE OWN
		for stock in stocks_list:
			if int(stocks_dict_quantity[stock]) > int(lowest_stock_quantity):
				stocks_dict_owned[stock] = True

		# GET MOST EXPENSIVE OWNED, AND CHEAPEST NOT OWNED
		for stock in stocks_list:
			# WE OWN THIS STOCK
			if stocks_dict_owned[stock]:
				if most_expensive_owned_stock is None:
					most_expensive_owned_stock = stocks_dict_price[stock]
				elif int(stocks_dict_price[stock]) > int(most_expensive_owned_stock):
					most_expensive_owned_stock = stocks_dict_price[stock]
			else:
				# WE DONT OWN THIS
				if cheapest_unowned_stock is None:
					cheapest_unowned_stock = stocks_dict_price[stock]
				elif int(stocks_dict_price[stock]) < int(cheapest_unowned_stock):
					cheapest_unowned_stock = stocks_dict_price[stock]

		# CALCULATE WHAT TO DO

		# BUYING ANY STOCK BELOW PRICE AND QUANTITY
		if (int(total_assets_value) >= 3000000):
			# DO SINGLE FOR ALL STOCKS IF WE HAVE ENOUGH TOTAL ASSETS
			available_funds = int(available_funds) - 1000000

		while True:
			# RECHECK CHEAPEST STOCK TO BUY
			cheapest_stock = None
			for stock in stocks_list:
				if (int(stocks_dict_quantity_to_buy[stock]) + int(stocks_dict_quantity[stock])) >= 1900:
					print_function('MISC - MAYOR - SKIPPING STOCK AS AT CAPACITY: ' + str(stock))
					# ALREADY AT CAPACITY
					pass
				else:
					# BELOW CAPACITY - ASSESS CHEAPEST
					if cheapest_stock is None:
						cheapest_stock = stocks_dict_price[stock]
					elif int(stocks_dict_price[stock]) < int(cheapest_stock):
						cheapest_stock = stocks_dict_price[stock]

			# END IF NOTHING CHEAP
			if cheapest_stock is None:
				print_function('MISC - MAYOR - CHEAPEST STOCK IS NONE. MUST HAVE CHECKED EVERYTHING')
				break

			# END IF NOTHING CHEAP ENOUGH
			if (int(cheapest_stock) > int(config['Career-Mayor']['stocks_highest_price_to_buy'])):
				print_function('MISC - MAYOR - CHEAPEST STOCK TOO EXPENSIVE TO BUY: ' + str(cheapest_stock))
				break

			# END IF NO FUNDS LEFT
			if (int(available_funds) < int(cheapest_stock)):
				print_function('MISC - MAYOR - NOT ENOUGH FUNDS TO BUY MORE - STOCK: ' + str(cheapest_stock) + " FUNDS: " + str(available_funds))
				break

			# BUY CHEAPEST
			for stock in stocks_list:
				if int(stocks_dict_price[stock]) == int(cheapest_stock):
					# find cheapest. reserve if applicable and buy 1900 or max with remaining cash
					if (int(total_assets_value) < 3000000):
						available_funds = int(available_funds) - 200000

					stocks_dict_quantity_to_buy[stock] = (
								int(available_funds) / int(cheapest_stock))
					if (int(stocks_dict_quantity_to_buy[stock]) + int(stocks_dict_quantity[stock])) >= 1900:
						stocks_dict_quantity_to_buy[stock] = (1900 - int(stocks_dict_quantity[stock]))
					available_funds = int(available_funds) - (
							int(stocks_dict_quantity_to_buy[stock]) * int(cheapest_stock))
					print_function("MISC - MAYOR - BUY: " + str(stock) + " QTY: " + str(stocks_dict_quantity_to_buy[stock]) + " FUNDS LEFT:" + str(available_funds))



		if we_own_any_stock:
			# BUY WHICHEVER STOCKS WE OWN
			for stock in stocks_list:
				if stocks_dict_quantity_to_buy[stock] == 0:
					if stocks_dict_owned[stock]:
						stocks_dict_quantity_to_buy[stock] = 1
						print_function('MISC - MAYOR - BUY OUR STOCK: ' + str(stock))
					elif int(total_assets_value) >= 3000000:
						stocks_dict_quantity_to_buy[stock] = 1
						print_function('MISC - MAYOR - BUY NON-OWNED STOCK AS ASSETS HIGH ENOUGH: ' + str(stock))
		else:
			# NO STOCK OWNED - CHECK IF BUYING ANY
			buying_stock = False
			for stock in stocks_list:
				if stocks_dict_quantity_to_buy[stock] > 0:
					buying_stock = True
			if not buying_stock:
				# NO STOCK OWNED AND NOT BUYING ANY. BUY EVERYTHING TO HOPE FOR CRASH
				print_function('MISC - MAYOR - NOTHING OWNED/BUYING. BUY 1 OF EACH HOPING FOR CRASH')
				cannot_afford_one_of_each = False
				for stock in stocks_list:
					if int(available_funds) >= int(stocks_dict_price[stock]):
						stocks_dict_quantity_to_buy[stock] = 1
						available_funds = int(available_funds) - int(stocks_dict_price[stock])
					else:
						cannot_afford_one_of_each = True

				if cannot_afford_one_of_each:
					# SELL EVERYTHING SINCE WE USED ALL FUNDS
					if 'mayor_sell' not in str(waiting_thread_list):
						waiting_thread_list.append('9zmayor_sell')
						print_function('9zmayor_sell THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
						# UPDATE TEXT BACKUP
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

		if config.getboolean('Career-Mayor', 'buy_stocks'):
			# BUY STOCKS BASED ON QUANTITY VARIABLE
			for stock in stocks_list:
				if int(stocks_dict_quantity_to_buy[stock]) > 0:
					clearkeys(lock_webdriver, "XPATH",
							  ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
								  int(stocks_list.index(
									  stock)) + 2) + "]/td[@class='display_border'][4]/p/input[@class='input']")
					sendkeys(lock_webdriver, "XPATH",
							 ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(
								 int(stocks_list.index(
									 stock)) + 2) + "]/td[@class='display_border'][4]/p/input[@class='input']",
							 str(int(stocks_dict_quantity_to_buy[stock])))

			# CLICK BUY
			element_click(lock_webdriver, "XPATH", ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[@class='nohover']/td[4]/p/input[@class='submit']", running_thread)

			# SET TIMER
			traffic_timer = get_timer(lock_webdriver, 'Trafficking', running_thread)
			globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=traffic_timer)
			globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=traffic_timer)
		else:
			# NOT BUYING STOCKS
			print_function('MAYOR - NOT BUYING STOCKS - TIMER SET')
			restock_random_timer = random.randrange(1200, 2400) # 20-40 mins
			globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
				seconds=restock_random_timer)


		if config.getboolean('Career-Mayor', 'sell_stocks'):
			# CLICK BUY TO REFRESH PRICES
			element_click(lock_webdriver, "XPATH",
						  ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[@class='nohover']/td[4]/p/input[@class='submit']",
						  running_thread)

			# RECHECK PRICES
			stocks_table = element_get_attribute(lock_webdriver, "XPATH",
												 ".//*[@id='content']/center/div[@id='shop_holder']/div[@id='holder_content']/form/table",
												 "innerHTML")
			stocks_table_split = stocks_table.split("<tr>")
			for stock in stocks_table_split:
				if 'name="qty' in stock:
					stock_details = stock.split("<td ")
					stock_name = regex_match_between('center">', '<', stock_details[1])
					stock_price = regex_match_between('center">', '<', stock_details[2])
					stock_quantity_owned = regex_match_between('center">', '<', stock_details[3])
					stock_price = re.sub('[^0-9]', "", stock_price)
					stock_quantity_owned = re.sub('[^0-9]', "", stock_quantity_owned)
					total_value = int(stock_price) * int(stock_quantity_owned)
					total_assets_value = int(total_assets_value) + int(total_value)
					stocks_dict_price[stock_name] = stock_price
					stocks_dict_quantity[stock_name] = stock_quantity_owned
					stocks_dict_owned[stock_name] = False
					stocks_dict_quantity_to_buy[stock_name] = 0

			# GET LOWEST QUANTITY TO DETERMINE WHICH STOCKS WE OWN
			we_own_any_stock = False
			lowest_stock_quantity = None
			for stock in stocks_list:
				if lowest_stock_quantity is None:
					lowest_stock_quantity = stocks_dict_quantity[stock]
				elif int(stocks_dict_quantity[stock]) <= int(lowest_stock_quantity):
					lowest_stock_quantity = stocks_dict_quantity[stock]
				else:
					we_own_any_stock = True

			# CHECK WHICH STOCKS WE OWN
			for stock in stocks_list:
				if int(stocks_dict_quantity[stock]) > int(lowest_stock_quantity):
					stocks_dict_owned[stock] = True

			# GET MOST EXPENSIVE OWNED, AND CHEAPEST NOT OWNED
			for stock in stocks_list:
				# WE OWN THIS STOCK
				if stocks_dict_owned[stock]:
					if most_expensive_owned_stock is None:
						most_expensive_owned_stock = stocks_dict_price[stock]
					elif int(stocks_dict_price[stock]) > int(most_expensive_owned_stock):
						most_expensive_owned_stock = stocks_dict_price[stock]
				else:
					# WE DONT OWN THIS
					if cheapest_unowned_stock is None:
						cheapest_unowned_stock = stocks_dict_price[stock]
					elif int(stocks_dict_price[stock]) < int(cheapest_unowned_stock):
						cheapest_unowned_stock = stocks_dict_price[stock]

			# CHECK PRICE DIFFERENCE IF WE SHOULD CHANGE STOCKS
			if (most_expensive_owned_stock == None) or (cheapest_unowned_stock == None):
				pass
			else:
				price_difference = int(most_expensive_owned_stock) - int(cheapest_unowned_stock)
				if int(price_difference) >= int(config['Career-Mayor']['stocks_price_difference_to_swap']):
					print_function('MISC - MAYOR - CHANGE STOCKS AS PRICE DIFFERENCE HIGH ENOUGH ' + str(price_difference) + str(config['Career-Mayor']['stocks_price_difference_to_swap']))
					# queue sell order for action timer. this should verify before selling incase the price has changed (click buy without quantity. refreshes prices)
					# it should add sell order to waiting thread list at a high number which will not be processed. this is then checked for on action thread which rewrites the priority and does the stocks
					if 'mayor_sell' not in str(waiting_thread_list):
						waiting_thread_list.append('9zmayor_sell')
						print_function('9zmayor_sell THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
						# UPDATE TEXT BACKUP
						write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

			# CHECK IF ANY OWNED ARE HIGH ENOUGH TO SELL
			for stock in stocks_list:
				if stocks_dict_owned[stock]:
					if int(stocks_dict_price[stock]) >= int(config['Career-Mayor']['stocks_lowest_price_to_sell']):
						print_function('MISC - MAYOR - PRICE HIGH ENOUGH TO SELL: ' + str(stock) + str(stocks_dict_price[stock]) + str(config['Career-Mayor']['stocks_lowest_price_to_sell']))
						if 'mayor_sell' not in str(waiting_thread_list):
							waiting_thread_list.append('9zmayor_sell')
							print_function('9zmayor_sell THREAD QUEUED ' + str(waiting_thread_list), "GREEN")
							# UPDATE TEXT BACKUP
							write_file("env/waiting_thread_list.txt", str(waiting_thread_list))

		if 'mayor_buy' in str(waiting_thread_list):
			thread_remove_from_queue(running_thread, waiting_thread_list)
	return

