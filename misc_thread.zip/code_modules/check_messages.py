from globalvars import *
from code_modules.function import *

__all__ = ["check_messages", "send_message"]


def check_messages_by_admin(lock_webdriver, running_thread):
	loopcount = 1
	admin_messaged = False

	while True:
		if not element_found(lock_webdriver, "XPATH", ".//*[@class='mailRow'][" + str(loopcount) + "]/table/tbody/tr/td[2]/strong/a[2]"):
			# END OF SENDERS
			break
		else:
			message_sender = element_get_attribute(lock_webdriver, "XPATH", ".//*[@class='mailRow'][" + str(loopcount) + "]/table/tbody/tr/td[2]/strong/a[2]", "innerHTML")
			if 'Administrator' == message_sender:
				# OPEN MESSAGE
				if element_found(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='comms_holder']/form/div[@class='mailRow'][1]/table/tbody/tr[2]/td[3]/a[@class='mailRowContent']/span[@class='mailRowSubject']"):
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='comms_holder']/form/div[@class='mailRow'][1]/table/tbody/tr[2]/td[3]/a[@class='mailRowContent']/span[@class='mailRowSubject']", running_thread)

					# BLOCK MESSAGES
					print_function('blocking message by ' + str(message_sender))
					element_click(lock_webdriver, "XPATH", ".//*[@id='mailsBlock']", running_thread)
				admin_messaged = True
				break
		loopcount += 1
	return admin_messaged


def check_smuggle_ready(lock_webdriver, running_thread, waiting_thread_list, message_sender):
	online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
	if '*' in online_player_list_raw:
		# ALREADY FULL LIST
		pass
	else:
		element_click(lock_webdriver, "XPATH", ".//*[@id='footer_top']/a", running_thread)
		online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")

	online_player_list_raw_split = online_player_list_raw.split("|")
	for player_raw in online_player_list_raw_split:
		if (':Alive:player:' in player_raw) or (':In-Jail:player:' in player_raw):
			player_name = regex_match_between('>', '<', player_raw)
			if (player_name == message_sender):
				if (':In-Jail:player:' in player_raw) or (">*<" in player_raw):
					# STILL IN CITY OR IN JAIL
					pass
				else:
					your_character_name = element_get_attribute(lock_webdriver, "XPATH",
																"/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display'][1]/a",
																"innerHTML")

					discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' Smuggle Ready for: **' + message_sender + '**')
					print_function('SmuggleReady FOR ' + str(message_sender) + " " + str(waiting_thread_list), "GREEN")
				break
	return


def check_messages(lock_webdriver, running_thread, waiting_thread_list, occupation):
	# AVOID CHECKING IF CAPTCHA. THIS GAVE A FALSE POSITIVE FOR SOME REASON
	if 'captcha_thread' in str(waiting_thread_list):
		print_function('MISC - CHECK_MESSAGES - SKIPPED AS CAPTCHA')
		return

	if 'In-Jail' in str(running_thread[4]):
		new_messages = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='nav_left']/p[1]/a/span", "outerHTML")
	else:
		new_messages = element_get_attribute(lock_webdriver, "XPATH", "//*[@id='nav_left']/div[1]/a[1]/span", "outerHTML")
	new_messages = re.sub('[^0-9]', "", new_messages)
	if new_messages == '':
		new_messages = 0

	if int(new_messages) > 0:
		print_function(str(inspect_stack()) + ' check_messages - ' + str(new_messages) + ' new messages found')

		print_function('MISC - CHECK_MESSAGES - THREAD QUEUED')
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_messages)
		print_function('MISC - CHECK_MESSAGES - THREAD ACTIVE')
		go_to_page(lock_webdriver, "Messages", running_thread)
		print_function('MISC - CHECK_MESSAGES - ON MESSAGES PAGE')

		# CHECK FOR ADMIN MESSAGES
		# admin_messaged = check_messages_by_admin(lock_webdriver, running_thread)

		if 'In-Jail' in str(running_thread[4]):
			new_message_count = element_count(lock_webdriver, "XPATH", ".//*[2]/td[3]/a[@class='jail_mailRowContent']/span[@class='jail_mailRowSubject']")
		else:
			new_message_count = element_count(lock_webdriver, "XPATH", ".//*[2]/td[3]/a[@class='mailRowContent']/span[@class='mailRowSubject']")
		print_function('MISC - CHECK_MESSAGES - NEW MESSAGES COUNT ' + str(new_message_count))

		loopcount_outer = 1
		loopcount_inner = 1
		while True:

			'''
			if element_found(lock_webdriver, "ID", "holder_top"):
				id_to_check = "holder_top"
			else:
				id_to_check = "jail_holder_top"

			if 'Communications' in element_get_attribute(lock_webdriver, "ID", id_to_check, "innerHTML"):
				print('MISC - CHECK_MESSAGES - MESSAGE OPEN')
				# ON MESSAGE PAGE ALREADY
			else:
				# OPEN MESSAGE PAGE
				print('MISC - CHECK_MESSAGES - OPENING MESSAGE')
				element_click(lock_webdriver, "XPATH", "//*[@id='nav_left']/div[1]/a[1]/span", running_thread)
			'''

			if 'In-Jail' in str(running_thread[4]):
				if element_found(lock_webdriver, "XPATH", ".//*[@class='jail_mailRow'][" + str(loopcount_outer) + "]/table/tbody/tr[2]/td[3]/a[@class='jail_mailRowContent']/span[@class='jail_mailRowSubject']"):
					element_click(lock_webdriver, "XPATH", ".//*[@class='jail_mailRow'][" + str(loopcount_outer) + "]/table/tbody/tr[2]/td[3]/a[@class='jail_mailRowContent']/span[@class='jail_mailRowSubject']",running_thread)
				else:
					loopcount_outer += 1
					continue
			else:
				if element_found(lock_webdriver, "XPATH", ".//*[@class='mailRow'][" + str(loopcount_outer) + "]/table/tbody/tr[2]/td[3]/a[@class='mailRowContent']/span[@class='mailRowSubject']"):
					element_click(lock_webdriver, "XPATH", ".//*[@class='mailRow'][" + str(loopcount_outer) + "]/table/tbody/tr[2]/td[3]/a[@class='mailRowContent']/span[@class='mailRowSubject']", running_thread)
				else:
					loopcount_outer += 1
					continue

			if 'In-Jail' in str(running_thread[4]):
				new_messages_from_same_person = element_count(lock_webdriver, "ID", "jail_comms_msg_top_super")
			else:
				new_messages_from_same_person = element_count(lock_webdriver, "ID", "comms_msg_top_super")

			if 'In-Jail' in str(running_thread[4]):
				if element_found(lock_webdriver, "XPATH", ".//*[@class='jail_mailRow'][1]/table/tbody/tr/td[2]/strong/a[2]"):
					message_sender_path = ".//*[@class='jail_mailRow'][1]/table/tbody/tr/td[2]/strong/a[2]"
				else:
					message_sender_path = ".//*[@class='jail_mailRow']/table/tbody/tr/td[2]/strong/a[2]"
			else:
				if element_found(lock_webdriver, "XPATH", ".//*[@class='mailRow'][1]/table/tbody/tr/td[2]/strong/a[2]"):
					message_sender_path = ".//*[@class='mailRow'][1]/table/tbody/tr/td[2]/strong/a[2]"
				else:
					message_sender_path = ".//*[@class='mailRow']/table/tbody/tr/td[2]/strong/a[2]"

			message_sender = element_get_attribute(lock_webdriver, "XPATH", message_sender_path, "innerHTML")
			print_function('MISC - CHECK_MESSAGES - THREAD COUNT: ' + str(new_messages_from_same_person))
			print_function('MISC - CHECK_MESSAGES - SENDER: ' + str(message_sender))

			if int(new_messages_from_same_person) > 0:
				# CHECK ALL NEW MESSAGES FROM SAME PERSON
				for i in range(1, int(new_messages_from_same_person + 1)):
					print_function("MISC - CHECK_MESSAGES - MESSAGES: " + str(loopcount_inner) + " OF: " + str(new_messages_from_same_person))

					if 'In-Jail' in str(running_thread[4]):
						message_content = element_get_attribute(lock_webdriver, "XPATH", ".//*[@class='jail_mailRowBody']/div[1]", "innerHTML", (int(loopcount_inner) - 1) )
					else:
						message_content = element_get_attribute(lock_webdriver, "XPATH", ".//*[@class='mailRowBody']/div[1]", "innerHTML", (int(loopcount_inner) - 1) )

					print_function('MISC - CHECK_MESSAGES - MESSAGE CONTENT RAW: ' + str(message_content))

					message_content = message_content.replace('<br>', '')
					message_content = re.sub('[^0-9a-zA-Z:_?/ -]', "", message_content)
					print_function('MISC - CHECK_MESSAGES - MESSAGE CONTENT FORMATTED: ' + str(message_content))

					if 'In-Jail' in str(running_thread[4]):
						sent_time = element_get_attribute(lock_webdriver, "XPATH", ".//*[@class='jail_mailRowTimestamp']/abbr[@class='timestamp']", "innerHTML", (int(loopcount_inner) - 1) )
					else:
						sent_time = element_get_attribute(lock_webdriver, "XPATH", ".//*[@class='mailRowTimestamp']/abbr[@class='timestamp']", "innerHTML", (int(loopcount_inner) - 1) )

					print_function('MISC - CHECK_MESSAGES - SENT TIME: ' + str(sent_time))

					your_character_name = element_get_attribute(lock_webdriver, "XPATH",
																"/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display'][1]/a",
																"innerHTML")

					if 'Administrator' == message_sender:
						print_function('MESSAGES - MESSAGED BY ADMIN. BLOCK THEM')
						element_click(lock_webdriver, "XPATH", ".//*[@id='mailsBlock']", running_thread)
					else:
						if 'In-Jail' in str(running_thread[4]):
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' Messaged (JAIL) By **' + message_sender + '** On ' + sent_time + ' Content: **' + message_content + '**')
						else:
							if ('Mortician' in occupation) or ('Funeral' in occupation) or ('Undertaker' in occupation):
								if ('SmuggleDrugs:' + str(message_sender)) in str(waiting_thread_list):
									check_smuggle_ready(lock_webdriver, running_thread, waiting_thread_list, message_sender)
							discord_message(config['Auth']['discord_id'] + str(your_character_name) + ' Messaged By **' + message_sender + '** On ' + sent_time + ' Content: **' + message_content + '**')
					loopcount_inner += 1

				if loopcount_outer >= new_message_count:
					print_function('MISC - CHECK_MESSAGES - END OF ALL MESSAGES - ' + str(loopcount_outer) + ' OF ' + str(new_message_count) + ' - OPENING CITY')
					if 'In-Jail' in str(running_thread[4]):
						element_click(lock_webdriver, "XPATH", ".//*[@id='nav_left']/p[3]/a/span[@class='city']", running_thread)
					else:
						open_city(lock_webdriver, running_thread)
					break

				print_function('MISC - CHECK_MESSAGES - THIS MESSAGE DONE. GO BACK')

			go_back(lock_webdriver)
			loopcount_outer += 1

		thread_remove_from_queue(running_thread, waiting_thread_list)
	return


def send_message(lock_webdriver, running_thread, waiting_thread_list, thread):
	print_function('MISC - SEND MESSAGE - THREAD QUEUED')
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_messages)
	print_function('MISC - SEND MESSAGE - THREAD ACTIVE')
	thread_split = thread.split('//')
	recipient = thread_split[1]
	subject = thread_split[2]
	message_to_send = thread_split[3]
	print("recipient: ", recipient)
	print("subject: ", subject)
	print("message: ", message_to_send)

	element_click(lock_webdriver, "XPATH", ".//*[@id='nav_left']/div[1]/a[1]/span", running_thread)
	count = 1

	while True:
		PageCheck = get_url(lock_webdriver)
		if 'comms.asp' in str(PageCheck):
			# ON MESSAGE PAGE ALREADY
			pass
		else:
			# OPEN MESSAGE PAGE
			element_click(lock_webdriver, "XPATH", ".//*[@id='nav_left']/div[1]/a[1]/span", running_thread)

		if not element_found(lock_webdriver, "XPATH", ".//*/div[@class='mailRow'][" + str(count) + "]/table/tbody/tr/td[2]/strong/a[2]"):
			# END OF SENDERS
			print("SEND MESSAGE - END OF SENDERS")
			element_click(lock_webdriver, "XPATH", ".//*[@id='holder_content']/p/a[3]/b", running_thread)
			clearkeys(lock_webdriver, "NAME", "toname")
			sendkeys(lock_webdriver, "NAME", "toname", str(recipient))
			sendkeys(lock_webdriver, "NAME", "msgsubject", str(subject))
			sendkeys(lock_webdriver, "NAME", "messagebody", str(message_to_send))
			time.sleep(1)
			click_continue(lock_webdriver, running_thread)

			while True:
				if element_found(lock_webdriver, "ID", "fail"):
					MessageStatus = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
					break
				elif element_found(lock_webdriver, "ID", "success"):
					MessageStatus = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
					break

			discord_message(config['Auth']['discord_id'] + ' Messaged: **' + recipient + '** Subject: **' + subject + '** Message: **' + message_to_send + '** Status: **' + MessageStatus + '**')
			break
		else:
			MessageSender = element_get_attribute(lock_webdriver, "XPATH", ".//*/div[@class='mailRow'][" + str(count) + "]/table/tbody/tr/td[2]/strong/a[2]", "innerHTML")
			print("SENDMESSAGE - CHECKING RECIPIENT: ", recipient.lower(), " VS ", MessageSender.lower())
			if (recipient.lower() == MessageSender.lower()):
				print("SENDMESSAGE - RECIPIENT MATCH")
				element_click(lock_webdriver, "XPATH", ".//*/div[@class='mailRow'][" + str(count) + "]/table/tbody/tr/td[3]/a[@class='mailRowContent']/span[@class='mailRowSubject']", running_thread)
				sendkeys(lock_webdriver, "NAME", "newmessagebody", str(message_to_send))
				time.sleep(1)
				click_continue(lock_webdriver, running_thread)

				while True:
					if element_found(lock_webdriver, "ID", "fail"):
						MessageStatus = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
						break
					elif element_found(lock_webdriver, "ID", "success"):
						MessageStatus = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
						break
				discord_message(config['Auth']['discord_id'] + ' Replied To: **' + recipient + '** Message: **' + message_to_send + '** Status: **' + MessageStatus + '**')
				break
		count += 1

	for thread in waiting_thread_list:
		if 'SendMessage' in str(thread):
			try:
				waiting_thread_list.remove(thread)
			except:
				pass

	# THIS WILL REMOVE THE CHECK_MESSAGES THREAD NOT THE 9zSENDMESSAGE
	thread_remove_from_queue(running_thread, waiting_thread_list)
	return
