from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

__all__ = ["add_pickpocket_targets_to_arrays", "get_pickpocket_list_currentcity", "check_pickpocket_target", "do_pickpocket_thread"]

def add_pickpocket_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager):
	# CREATE LISTS
	count = 3
	while count < 32:
		globals()['pickpocket_targets_minute' + str(count)] = []
		locals()['dict_min' + str(count)] = {}
		count += 1

	try:
		your_hours = aggtarget_person_list_manager[get_your_character_name(lock_webdriver)].get_online_hours()
	except:
		your_hours = 1

	agg_target_count = 0
	for name in globals()['all_agg_targets']:
		agg_target_count += 1
		
		# skip garbage names
		pickpocket_target_blank_check = re.sub(r'\W+', '', str(name))
		if pickpocket_target_blank_check == '':
			print("pickpocket - skip garbage name: " + str(name))
			continue
		
		while True:
			try:
				their_hours = aggtarget_person_list_manager[name].get_online_hours()
				break
			except Exception as except_message:
				print_function("SOCKET ERROR ADDING PICKPOCKET TARGET: " + str(name) + " ERROR: " + str(except_message), "RED")
				time.sleep(10)


		our_aggstr_mins = 29
		while True:
			our_aggstr = math.ceil( your_hours * float(aggstr_percent_modify(our_aggstr_mins)) )
			their_aggstr = math.floor( their_hours * float(config['Pickpocket']['PPAggstrModify']) )

			if (our_aggstr_mins <= 2) or (their_aggstr >= our_aggstr):
				# APPLY LOCAL MODIFIERS TO TARGET REQUIRED MINS
				mins_adjusted = int(our_aggstr_mins) + 1

				if os.path.isfile('./agg_targets/pickpocket/' + name + '.txt'):
					adjust_value = read_file('./agg_targets/pickpocket/' + name + '.txt')
					if adjust_value == '':
						adjust_value = 0
				else:
					adjust_value = 0

				if adjust_value == 'FAIL':
					mins_adjusted = 31
				else:
					mins_adjusted = int(mins_adjusted) + int(adjust_value)

					if int(mins_adjusted) > 30:
						mins_adjusted = 30
					elif int(mins_adjusted) < 3:
						mins_adjusted = 3

				globals()['pickpocket_targets_minute' + str(mins_adjusted)].append(name)
				# print('AGGS - PICKPOCKET ARRAY - ADDED ', name, ' TO MINS ', mins_adjusted, " THEIRS: ", their_aggstr, " VS YOURS: ", our_aggstr)
				break

			our_aggstr_mins -= 1

	count = 3
	while count < 32:
		print_function('PP list:' + str(count) + ' // ' + str(globals()['pickpocket_targets_minute' + str(count)]))
		count += 1
	return


def get_pickpocket_list_currentcity(lock_webdriver, aggtarget_person_list_manager, running_thread):
	# CLEAR SAVED NAMES
	online_player_list_currentcity = []

	# GETS FULL LIST OF NAMES
	while True:
		online_player_list_raw = element_get_attribute(lock_webdriver, "ID", "whosonlinecell", "innerHTML")
		if '|' in online_player_list_raw:
			break

	is_local_list_only = True
	if '*' in online_player_list_raw:
		is_local_list_only = False

	online_player_list_raw_split = online_player_list_raw.split("|")
	for player_raw in online_player_list_raw_split:
		if ':Alive:player:' in player_raw:
			if is_local_list_only or ('*' in player_raw):
				player_name = regex_match_between('>', '<', player_raw)

				skip_this_pickpocket_target = False
				
				# filter out junk names
				pickpocket_target_blank_check = re.sub(r'\W+', '', str(player_name))
				if pickpocket_target_blank_check == '':
					print("pickpocket - skip garbage name: " + str(player_name))
					skip_this_pickpocket_target = True
				
				pickpocket_blacklist = config['Pickpocket']['Pickpocket_Blacklist'].split()
				for blacklist_name in pickpocket_blacklist:
					if blacklist_name == player_name:
						print_function('PICKPOCKET - SKIP BLACKLIST TARGET: ' + str(player_name), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - SKIP BLACKLIST TARGET: " + str(player_name))
						skip_this_pickpocket_target = True

				if ( (skip_this_pickpocket_target) or (player_name == "") ):
					pass
				else:
					online_player_list_currentcity.append(player_name)

					if player_name in globals()['all_agg_targets']:
						pass
					else:
						# NEW PICKPOCKET TARGET
						server_port = read_file("env/ServerPort.txt")
						manager = BaseManager(address=('127.0.0.1', int(server_port)))
						BaseManager.register('person', person)
						BaseManager.register('city', city)

						while True:
							try:
								manager.connect()
								break
							except:
								print_function('AGGS - check_pickpocket_target - FAILED TO CONNECT TO BASEMANAGER', "RED")

						aggtarget_person_list_manager[player_name] = manager.person(player_name)
						aggtarget_person_list_manager[player_name].add_online_hours(1)
						globals()['all_agg_targets'].append(player_name)
						update_database('Player', 'PlayerName', str(player_name), {"AliveStatus": "Alive", "Aggpro_Personal": str(datetime.datetime.utcnow()), "Aggpro_Hack": str(datetime.datetime.utcnow()), "Aggpro_BnE": str(datetime.datetime.utcnow()), "FirstSeen": str(datetime.datetime.utcnow()), "Hours": 1, "UpdatedBy": "Pickpocket-NewName"})

						# DO CALCULATION FOR WHICH AGG MINUTE LIST TO ADD THE NEW TARGET
						try:
							your_hours = aggtarget_person_list_manager[
								get_your_character_name(lock_webdriver)].get_online_hours()
						except:
							your_hours = 1

						their_hours = aggtarget_person_list_manager[player_name].get_online_hours()

						our_aggstr_mins = 29
						while True:
							our_aggstr = math.ceil(your_hours * float(aggstr_percent_modify(our_aggstr_mins)))
							their_aggstr = math.floor(their_hours * float(config['Pickpocket']['PPAggstrModify']))

							if (our_aggstr_mins <= 2) or (their_aggstr >= our_aggstr):
								# APPLY LOCAL MODIFIERS TO TARGET REQUIRED MINS
								mins_adjusted = int(our_aggstr_mins) + 1

								if os.path.isfile('./agg_targets/pickpocket/' + player_name + '.txt'):
									adjust_value = read_file('./agg_targets/pickpocket/' + player_name + '.txt')
									if adjust_value == '':
										adjust_value = 0
								else:
									adjust_value = 0

								if adjust_value == 'FAIL':
									mins_adjusted = 31
								else:
									mins_adjusted = int(mins_adjusted) + int(adjust_value)

									if int(mins_adjusted) > 30:
										mins_adjusted = 30
									elif int(mins_adjusted) < 3:
										mins_adjusted = 3

								globals()['pickpocket_targets_minute' + str(mins_adjusted)].insert(0 ,player_name)
								print_function('AGGS - PICKPOCKET ARRAY - ADDED ' + str(player_name) + ' TO MINS ' + str(mins_adjusted) + " THEIRS: " + str(their_aggstr) + " VS YOURS: " + str(our_aggstr))
								print_function('list: ' + str(globals()['pickpocket_targets_minute' + str(mins_adjusted)]))
								break
							our_aggstr_mins -= 1

	return online_player_list_currentcity


def check_pickpocket_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, pickpocket_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, bold_list):
	viable_pickpocket_targets = []

	for pickpocket_target in globals()['pickpocket_targets_minute' + str(aggstr_min_checking)]:
		if pickpocket_target in pickpocket_list:
			pass
		else:
			continue
			
		write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP CHECKING TARGET: " + str(pickpocket_target))

		if (your_character_name == pickpocket_target) or ('' == pickpocket_target) or (
				pickpocket_target in config['Pickpocket']['Pickpocket_Blacklist']):
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP TARGET: " + str(pickpocket_target) + " SKIP AS BLACKLIST OR SELF")
			continue

		if config.getboolean('Pickpocket', 'Avoid_Bolds'):
			skip_this_name = False
			for bold_name_raw in bold_list['Items']:
				bold_name = bold_name_raw['PlayerName']
				if bold_name == pickpocket_target:
					skip_this_name = True
					break
			if skip_this_name:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP TARGET: " + str(pickpocket_target) + " SKIP AS BOLD")
				continue

		# AGGPRO - LOCAL
		aggpro_timer = aggtarget_person_list_manager[pickpocket_target].get_local_aggpro_timer()

		try:
			time_difference = datetime.datetime.utcnow() - aggpro_timer
		except Exception as e:
			if 'datetime.datetime' in str(e):
				aggpro_timer = datetime.datetime.strptime(aggpro_timer, '%Y-%m-%d %H:%M:%S.%f')
				time_difference = datetime.datetime.utcnow() - aggpro_timer
			else:
				raise Exception(e)
		if not '-' in str(time_difference):
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP TARGET: " + str(pickpocket_target) + " PASSED LOCAL AGGPRO")
			# AGGPRO - SHARED
			aggpro_timer = aggtarget_person_list_manager[pickpocket_target].get_shared_aggpro_timer()
			time_difference = datetime.datetime.utcnow() - aggpro_timer
			if not '-' in str(time_difference):
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP TARGET: " + str(pickpocket_target) + " PASSED SHARED AGGPRO")
				# AGGPRO - SHARED
				viable_pickpocket_targets.append(pickpocket_target)
				# print(Fore.BLUE + 'PICKPOCKET: ', pickpocket_target, " MINS REQUIRED: ", aggstr_min_checking, " AGGPRO: ", aggtarget_person_list_manager[pickpocket_target].get_aggpro_timer())
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP TARGET: " + str(pickpocket_target) + " MINS REQUIRED: " + str(aggstr_min_checking))
			else:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP SHARED AGGPRO: " + str(pickpocket_target))
		else:
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - PP LOCAL AGGPRO: " + str(pickpocket_target))

	if viable_pickpocket_targets == []:
		pass
	else:
		print_function('viable pickpocket targets - ' + str(viable_pickpocket_targets) + " " + str(aggstr_min_checking), "BLUE")
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - VIABLE TARGETS FOR MINUTE " + str(aggstr_min_checking) + ": " + str(viable_pickpocket_targets))

		waiting_thread_list.append('9zAggstrLowest' + str(aggstr_min_checking))
		print_function('9zAggstrLowest' + str(aggstr_min_checking) + ' THREAD QUEUED ' + str(waiting_thread_list), "GREEN")

		do_pickpockets(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager)
	return


def do_pickpockets(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager):
	thread_pickpocket = Process(target=do_pickpocket_thread, name='PickpocketThread',
									args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager))
	thread_pickpocket.start()
	waiting_thread_list.append('9zAwaitingPickpocket')
	print_function(waiting_thread_list)

	# WAIT TILL THREAD STARTED
	print_function('PICKPOCKET - WAITING FOR THREAD TO BE RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - WAITING FOR THREAD TO BE RUNNING")
	while True:
		if 'pickpocket' in str(waiting_thread_list):
			break
	print_function('PICKPOCKET - THREAD RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - THREAD RUNNING")
	return


def do_pickpocket_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_pickpocket_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager):
	try:
		import multiprocessing
		write_file("env/PickpocketPID.txt", str(multiprocessing.current_process().pid))

		for thread in waiting_thread_list:
			if 'AwaitingPickpocket' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET QUEUED")
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_pickpocket_targets)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET STARTED")
		random_timer_haspro = random.randrange(590, 915)

		for target in viable_pickpocket_targets:
			# RETURN PRIORITY TO NORMAL
			running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]

			if go_to_page(lock_webdriver, "Pickpocket", running_thread):
				pass
			else:
				# CANNOT GO TO PICKPOCKET PAGE. LIKELY DUE TO BEING IN JAIL
				return

			if 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** PICKPOCKET - REQUIRES CS FIRST ****")
				return

			clearkeys(lock_webdriver, "NAME", "pickpocket")
			sendkeys(lock_webdriver, "NAME", "pickpocket", target)
			sendkeys(lock_webdriver, "NAME", "pickpocket", Keys.ESCAPE)
			
			clearkeys(lock_webdriver, "NAME", "cap")
			sendkeys(lock_webdriver, "NAME", "cap", config['Pickpocket']['Max_PP_Amount'])
			sendkeys(lock_webdriver, "NAME", "cap", Keys.ESCAPE)
			

			# INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
			running_thread[0] = str('1') + inspect.stack()[0][3]
			click_continue(lock_webdriver, running_thread)

			# AGG DONE - GET RESULTS
			agg_results = None
			if element_found(lock_webdriver, "ID", "fail"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			elif element_found(lock_webdriver, "ID", "success"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			else:
				print_function('NO AGG RESULTS FOUND', "BLUE")
				print_function('NO AGG RESULTS FOUND', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - NO AGG RESULTS FOUND")
				continue

			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - RESULTS: " + str(agg_results))

			# AGG DONE - EXAMINE RESULTS
			if "doesn't exist" in agg_results:
				print_function('Pickpocket Results - Target ' + str(target) + " Doesn't Exist", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Target " + str(target) + " Doesn't Exist")
				random_timer = random.randrange(60, 90)
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				continue

			elif ('same city' in agg_results) or ('must be online' in agg_results) or ('recently survived' in agg_results):
				print_function('Pickpocket Results - Target ' + str(target) + " has pro or not found", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Target " + str(target) + " has pro or not found")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer_haspro)
				aggtarget_person_list_manager[target].set_local_aggpro_timer(agg_timer)
				continue

			elif ('failed' in agg_results) or ('ran off' in agg_results):
				print_function('Pickpocket Results - Target ' + str(target) + ' FAILED', "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Target " + str(target) + " FAILED")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=70)
				print_function("SETTING PP AGGPRO TIMER2 - TARGET: " + str(target) + " TO: " + str(agg_timer))
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)


				# UPDATE LOCAL MODIFIERS
				desired_mins = int(aggstr_mins_max) + 2
				if desired_mins > 30:
					desired_mins = 30

				mins_adjusted = int(desired_mins) - int(aggstr_min_checking)

				if int(aggstr_mins_max) == 30:
					mins_adjusted = 'FAIL'

				write_file('./agg_targets/pickpocket/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/Pickpocket.txt', "\nPickpocket FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nPickpocket FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET THREAD FINISHED")
				return


			elif ('You pickpocketed' in agg_results):
				print_function('Pickpocket Results - Target ' + str(target) + ' SUCCESS - AGG: ' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Target " + str(target) + " SUCCESS")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(minutes=70)
				print_function("SETTING PP AGGPRO TIMER - TARGET: " + str(target) + " TO: " + str(agg_timer))
				aggtarget_person_list_manager[target].set_shared_aggpro_timer(agg_timer)

				# UPDATE LOCAL MODIFIERS
				try:
					mins_adjusted = read_file('./agg_targets/pickpocket/' + target + '.txt')
					if mins_adjusted == 'FAIL':
						mins_adjusted = 30
					mins_adjusted = int(mins_adjusted)
				except:
					mins_adjusted = 0

				mins_adjusted -= 1
				write_file('./agg_targets/pickpocket/' + target + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/Pickpocket.txt', "\nPickpocket SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))
				append_file('./records/AllAggs.txt', "\nPickpocket SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target))

				# UPDATE SHARED ALL AGGS RECORDS
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.utcnow().year) + '-' + str(datetime.datetime.utcnow().month) + '-' + str(datetime.datetime.utcnow().day) + '.txt', "\r\n" + str(get_your_character_name(lock_webdriver)) + " Pickpocket " + str(target) + " (Success) in " + str(
					globals()[get_current_city(lock_webdriver)].which_city) + " on " + str(datetime.datetime.utcnow()))

				# REPAY CHECKS
				repay = True
				if not config.getboolean('Pickpocket', 'Repay'):
					print_function('Pickpocket - Repay - TURNED OFF', "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Repay - TURNED OFF")
					repay = False

				repay_blacklist = config['Pickpocket']['Repay_Blacklist'].split()
				for blacklist_name in repay_blacklist:
					if target == blacklist_name:
						print_function('Pickpocket - Repay - TARGET IS BLACKLISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Repay - TARGET IS BLACKLISTED: " + str(target))
						repay = False

				repay_whitelist = config['Pickpocket']['Repay_Whitelist'].split()
				for whitelist_name in repay_whitelist:
					if target == whitelist_name:
						print_function('Pickpocket - Repay - TARGET IS WHITELISTED: ' + str(target), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Repay - TARGET IS WHITELISTED: " + str(target))
						repay = True

				if repay:
					repay_amount = regex_match_between('\$', '!', agg_results)
					repay_amount = re.sub('[^0-9]', "", repay_amount)

					print_function('Pickpocket - Repaying ' + str(repay_amount) + ' TO ' + str(target), "BLUE")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET - Repaying " + str(repay_amount) + " TO " + str(target))
					# ADD REPAY TO RECORDS
					append_file('./records/Pickpocket.txt', "\n Pickpocket - Repaying " + repay_amount + " TO " + target)
					append_file('./records/AllAggs.txt', "\n Pickpocket - Repaying " + repay_amount + " TO " + target)

					if int(repay_amount) > 0:
						transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target)

						# WAIT FOR TRANSFER TO BE QUEUED
						print_function('Pickpocket - Waiting for repay to be queued', "BLUE")
						while True:
							if 'transfer_money_thread' in str(waiting_thread_list):
								break
						print_function('Pickpocket - repay is queued', "BLUE")

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET THREAD FINISHED")
				return

			else:
				print_function('Pickpocket - results not found' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t Pickpocket - results not found" + str(agg_results))
				continue

		for thread in waiting_thread_list:
			if ('AggstrLowest' in thread):
				try:
					waiting_thread_list.remove(thread)
				except:
					pass
		thread_remove_from_queue(running_thread, waiting_thread_list)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t PICKPOCKET THREAD FINISHED")
		return
	except:
		from code_modules.function import PrintException
		PrintException()
