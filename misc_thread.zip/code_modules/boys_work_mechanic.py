from globalvars import *
from code_modules.function import *


def boys_work_mechanic(lock_webdriver, running_thread, waiting_thread_list, boys_list, online_list, your_character_name):
	if ('Vehicle:BrokenDownAwaitingRepair' in str(running_thread[4])) or ('Vehicle:WaitingRepair' in str(running_thread[4])) or ('Vehicle:None' in str(running_thread[4])):
		return

	boys_mechanic = False
	for boys_name in boys_list:
		if boys_name == str(your_character_name):
			continue
		elif boys_name in online_list:
			print_function(str(boys_name) + ' mechanic')
			boys_mechanic = True

	if boys_mechanic:
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)

		open_city(lock_webdriver, running_thread)

		# OPEN CONSTRUCTION
		element_click(lock_webdriver, "XPATH", ".//*[@class='business vehicle_repair_shop']", running_thread)

		# CONSTRUCTION TORCHED
		if element_found(lock_webdriver, "ID", "fail"):
			results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			if 'while under going repairs' in str(results):
				# SET TIMER FOR RECHECK LATER
				print_function('REPAIR - CONSTRUCTION TORCHED')
				random_timer = random.randrange(20, 30)
				globals()['timers'].__dict__['repair_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=random_timer)
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return

		url_check = get_url(lock_webdriver)
		if 'repairs.asp' in url_check:
			# ON CORRECT PAGE


			# CHECK IF FULLY REPAIRED OR NO VEHICLE
			if element_found(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/div[@id='fail']"):
				results = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/div[@id='fail']", "innerHTML")
				if ('need any repairs just yet' in str(results)):
					print_function('VEHICLE ALREADY REPAIRED')
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if 'Vehicle:' in item:
							try:
								variables_list.remove(item)
							except:
								pass
					variables_list.append('Vehicle:FullyRepaired')
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return

				elif ('own a vehicle' in str(results)):
					print_function('NO VEHICLE')
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if 'Vehicle:' in item:
							try:
								variables_list.remove(item)
							except:
								pass
					variables_list.append('Vehicle:None')
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return

			if element_found(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/table[@id='username_content']/tbody/tr[4]/td[@class='box']/div[@id='respect_bar']"):
				results = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/table[@id='username_content']/tbody/tr[4]/td[@class='box']/div[@id='respect_bar']",
												"innerHTML")
				results = re.sub('[^0-9]', "", results)

				if int(results) == 0:
					# BROKEN DOWN

					# CHECK IF ALREADY AWAITING REPAIR
					if element_found(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/div[@id='success']"):
						variables_list = running_thread[4]
						for item in running_thread[4]:
							if 'Vehicle:' in item:
								try:
									variables_list.remove(item)
								except:
									pass
						variables_list.append('Vehicle:BrokenDownAwaitingRepair')
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])
						return

					# PUT IN FOR REPAIR
					print_function('REPAIR - PUT IN FOR REPAIRS - FULLY BROKEN DOWN')
					select_dropdown_option(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/form/p[2]/select[@class='dropdown']", "Yes")
					element_click(lock_webdriver, "XPATH", ".//*[@class='input']", running_thread)

					# CHECK VEHICLE PUT IN FOR REPAIR
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if 'Vehicle:' in item:
							try:
								variables_list.remove(item)
							except:
								pass

					if element_found(lock_webdriver, "ID", "success"):
						results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
						if 'in for repairs' in results:
							variables_list.append('Vehicle:BrokenDownAwaitingRepair')
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])

							#UPDATE BOYS
							sqs = boto3.resource('sqs',
												 region_name='ap-southeast-2',
												 aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
												 aws_secret_access_key='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',
												 )
							for boys_name in boys_list:
								if boys_name in online_list:
									try:
										queue = sqs.get_queue_by_name(QueueName=str(boys_name))
									except:
										continue
									response = queue.send_message(MessageBody="ResetCaseTimer", DelaySeconds=1)
									print_function('BOYS MECHANIC - RESET TIMER FOR ' + str(boys_name))
				else:
					# PUT IN FOR REPAIR
					print_function('REPAIR - PUTTING IN FOR REPAIRS')

					# CHECK IF ALREADY AWAITING REPAIR
					if element_found(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/div[@id='success']"):
						variables_list = running_thread[4]
						for item in running_thread[4]:
							if 'Vehicle:' in item:
								try:
									variables_list.remove(item)
								except:
									pass
						variables_list.append('Vehicle:WaitingRepair')
						running_thread[4] = variables_list
						print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
						write_file("env/variables.txt", running_thread[4])
						return

					select_dropdown_option(lock_webdriver, "XPATH", ".//*[@id='show_vehrepairs']/form/p[2]/select[@class='dropdown']", "Yes")
					element_click(lock_webdriver, "XPATH", ".//*[@class='input']", running_thread)

					# CHECK VEHICLE PUT IN FOR REPAIR
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if 'Vehicle:' in item:
							try:
								variables_list.remove(item)
							except:
								pass

					if element_found(lock_webdriver, "ID", "success"):
						results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
						if 'in for repairs' in results:
							variables_list.append('Vehicle:WaitingRepair')
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])

							# UPDATE BOYS
							sqs = boto3.resource('sqs',
												 region_name='ap-southeast-2',
												 aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
												 aws_secret_access_key='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',
												 )
							for boys_name in boys_list:
								if boys_name in online_list:
									try:
										queue = sqs.get_queue_by_name(QueueName=str(boys_name))
									except:
										continue
									response = queue.send_message(MessageBody="ResetCaseTimer", DelaySeconds=1)
									print_function('BOYS MECHANIC - RESET TIMER FOR ' + str(boys_name))
			else:
				# NO CAR?
				if element_found(lock_webdriver, "XPATH", ".//*[@id='wrapper']/div[@id='nav_left']/p[8]/a[2]"):
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if 'Vehicle:' in item:
							try:
								variables_list.remove(item)
							except:
								pass
					variables_list.append('Vehicle:NONE')
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])

		thread_remove_from_queue(running_thread, waiting_thread_list)
	return