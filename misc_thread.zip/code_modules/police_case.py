from globalvars import *
from code_modules.function import *

__all__ = ["police_case"]

def police_case(lock_webdriver, running_thread, waiting_thread_list, home_city, character_name):
	if config.getboolean('Career-Police', 'Do_Cases'):
		print_function('POLICE - THREAD QUEUED')
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_earn)
		print_function('POLICE - THREAD ACTIVE')

		'''
		# MANUAL CHECK ONLINE RECORDS FOR AGG
		case_agg_time = "6/8/2021 5:29:36 AM"
		Our_Online_List = Get_Our_Online_List(case_agg_time)
		Online_List_Before = read_s3('roastbusters', 'OnlineTimes/' + str(Our_Online_List[0]) + '.txt')
		Online_List_After = read_s3('roastbusters', 'OnlineTimes/' + str(Our_Online_List[2]) + '.txt')
		Results_911 = Check_911_Results(case_agg_time, "Toronto")

		print("BEFORE DIFF: " + str(Our_Online_List[1]) + " - " + str(Online_List_Before))
		print("AFTER DIFF: " + str(Our_Online_List[3]) + " - " + str(Online_List_After))
		print("911 DIFF: " + str(Results_911[1]) + " - " + str(Results_911[2]))
		while True:
			time.sleep(30)
		'''



		Police_Timer_Set = False

		Open_Police_Case_Page(lock_webdriver, running_thread, waiting_thread_list)
		skip_cases = read_file("env/PoliceSkipCase.txt")

		if Open_Case(lock_webdriver, running_thread, waiting_thread_list, skip_cases) is None:
			print_function("POLICE - END OF CASES", "RED")
			globals()['timers'].__dict__['case_timer'] = globals()['timers'].__dict__['career_timer']
			thread_remove_from_queue(running_thread, waiting_thread_list)
			return

		while True:
			if Process_Case(lock_webdriver, running_thread, waiting_thread_list, home_city, character_name, skip_cases):
				# RETURNS TRUE UNLESS FORENSICS JUST DONE
				break

		if not Police_Timer_Set:
			case_timer = get_timer(lock_webdriver, 'Case', running_thread)
			if str(case_timer) == "0":
				print_function("POLICE - NO CASE TIMER. USE ROUGHLY 30SEC", "RED")
				globals()['timers'].__dict__['case_timer'] = globals()['timers'].__dict__['career_timer']
			else:
				globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=case_timer)

		print("POLICE - DONE")
		thread_remove_from_queue(running_thread, waiting_thread_list)
	return

def Open_Police_Case_Page(lock_webdriver, running_thread, waiting_thread_list):
	print_function('MISC - POLICE CASE - OPENING CASE PAGE')
	go_to_page(lock_webdriver, 'PoliceCase', running_thread)
	print_function('MISC - POLICE CASE - CASE PAGE OPEN')
	return

def Open_Case(lock_webdriver, running_thread, waiting_thread_list, skip_case):
	print_function('MISC - POLICE CASE - OPEN CASE - START')
	Case_Details = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']", "innerHTML")
	if ">Case:<" in str(Case_Details):
		# CASE ALREADY OPEN
		print_function('MISC - POLICE CASE - OPEN CASE - CASE ALREADY OPEN')
		CaseToOpen = "AlreadyOpen"
		pass
	else:
		if "You don't currently have an assigned case" in str(Case_Details):
			# OPEN UNASSIGNED CASES FIRST
			print_function('MISC - POLICE CASE - OPEN CASE - OPEN UNASSIGNED CASES PAGE')
			element_click(lock_webdriver, 'XPATH', ".//*[@class='box red']", running_thread)

			random_timer = random.randrange(31, 52)
			globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
			print_function("POLICE - OPENED CASES TIMER SET", "RED")

		CaseToOpen = Get_Case_To_Open(lock_webdriver, running_thread, waiting_thread_list, skip_case)
		if CaseToOpen is None:
			return CaseToOpen
		else:
			element_click(lock_webdriver, 'ID', CaseToOpen, running_thread)
			element_click(lock_webdriver, 'NAME', "result", running_thread)

			if element_found(lock_webdriver, "XPATH", ".//*[@id='fail']"):
				print_function("POLICE - OTHER PD GOT CASE", "RED")
				random_timer = random.randrange(31, 52)
				globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
				CaseToOpen = None

		print_function('MISC - POLICE CASE - OPEN CASE - FINISHED')
	return CaseToOpen

def Get_Case_To_Open(lock_webdriver, running_thread, waiting_thread_list, skip_case):
	print_function('MISC - POLICE CASE - GET CASE TO OPEN - START')

	Selected_Case = None
	Selected_Case_Type = None
	Cases_Awaiting_Forensics = False

	action_timer = get_timer(lock_webdriver, 'Action', running_thread)

	Case_Index = 2
	while True:
		This_Case_Number = None
		This_Case_Type = None

		if element_found(lock_webdriver, "XPATH", ".//*[@id='holder_content']/div/form/table/tbody/tr[" + str(Case_Index) + "]/td[1]"):
			pass
		else:
			if Cases_Awaiting_Forensics:
				print_function("POLICE - NO CASES LEFT EXCEPT FORENSICS - USE ACTION TIMER", "RED")
				globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Action', running_thread))
			else:
				case_timeout_count = element_count(lock_webdriver, "XPATH", ".//*[@id='fail']")
				if int(case_timeout_count) > 0:
					case_timeout_check = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='fail']", "outerHTML", int(case_timeout_count-1))
					if "30 seconds" in str(case_timeout_check):
						print_function("POLICE - 30SEC TIMEOUT", "RED")
						random_timer = random.randrange(31, 64)  # 30 - 60mins
						globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
					else:
						print_function("POLICE - NO CASES LEFT", "RED")
						random_timer = random.randrange(1821, 3652) # 30 - 60mins
						globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
			return Selected_Case


		Whacking_Check = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/div/form/table/tbody/tr[" + str(Case_Index) + "]/td[2]", "outerHTML")
		if "WHACKING" in str(Whacking_Check):
			Case_Index += 1
			continue

		This_Case_Raw = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/div/form/table/tbody/tr[" + str(Case_Index) + "]/td[1]", "outerHTML")
		This_Case_Number = regex_match_between('label for="', '">', This_Case_Raw)

		if ( (str(This_Case_Number) in str(skip_case)) and (action_timer != 0) ):
			print_function(str(This_Case_Number) + " SKIP AS AWAITING FORENSICS")
			Case_Index += 1
			Cases_Awaiting_Forensics = True
			continue

		if "background: #336699" in str(This_Case_Raw):
			This_Case_Type = "Witness"
		else:
			This_Case_Type = "Normal"

		This_Case_Awaiting_Results = Is_Case_Awaiting_Results(lock_webdriver, str(Case_Index))

		if This_Case_Awaiting_Results:
			print_function(str(This_Case_Number) + " SKIP AS AWAITING RESULTS")
			Case_Index += 1
			continue
		else:
			if Selected_Case_Type == "Normal":
				return Selected_Case
			elif Selected_Case is None:
				Selected_Case = This_Case_Number
				Selected_Case_Type = This_Case_Type
			elif (Selected_Case_Type == "Witness") and (This_Case_Type == "Normal"):
				Selected_Case = This_Case_Number
				Selected_Case_Type = This_Case_Type

		print_function(str(This_Case_Number))
		Case_Index += 1

	print_function("END OF CASES? - SET AND TEST USING ACTION TIMER HERE", "RED")
	while True:
		time.sleep(30)

	print_function('MISC - POLICE CASE - GET CASE TO OPEN - FINISHED: ' + str(Selected_Case))
	return

def Is_Case_Awaiting_Results(lock_webdriver, Case_Index):
	Case_Is_Awaiting_Results = False
	Fire_Investigation_Required = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/div/form/table/tbody/tr[" + str(Case_Index) + "]/td[6]", "outerHTML")
	if "e68f12" in str(Fire_Investigation_Required):
		Case_Is_Awaiting_Results = True

	if not Case_Is_Awaiting_Results:
		DNA_Investigation_Required = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/div/form/table/tbody/tr[" + str(Case_Index) + "]/td[4]", "outerHTML")
		if "e68f12" in str(DNA_Investigation_Required):
			Case_Is_Awaiting_Results = True

	if not Case_Is_Awaiting_Results:
		Autopsy_Investigation_Required = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/div/form/table/tbody/tr[" + str(Case_Index) + "]/td[7]", "outerHTML")
		if "e68f12" in str(Autopsy_Investigation_Required):
			Case_Is_Awaiting_Results = True

	return Case_Is_Awaiting_Results

def Process_Case(lock_webdriver, running_thread, waiting_thread_list, home_city, character_name, skip_cases):
	Case_Details_Raw = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']",
											 "innerHTML")

	if Case_Is_Witness(Case_Details_Raw):
		Bury_Case(lock_webdriver, running_thread)
		return True

	Case_Details_Raw = Request_Evidence(lock_webdriver, running_thread, Case_Details_Raw)

	if Awaiting_Evidence(Case_Details_Raw):
		Return_Case(lock_webdriver, running_thread)
		return True

	case_witness_statement = "None"
	suspect = "None"
	case_forensics = "None"
	case_fire = "None"
	boys_witnessed = "None"
	travel_evidence_entered = False
	forensics_done = False
	for Record_Item in Case_Details_Raw.split("<tr>"):
		print_function("ITEM: " + str(Record_Item), "BLUE")
		if "Case:" in str(Record_Item):
			Record_Item_Line = Record_Item.splitlines()
			case_number = regex_match_between('<td>#', '</td>', Record_Item_Line[2].strip())
			case_agg_type = regex_match_between('<td>', '</td>', Record_Item_Line[4].strip())
			if "Breaking" in str(case_agg_type):
				case_agg_type = "BnE"
			elif "Hacking" in str(case_agg_type):
				case_agg_type = "Hack"
			elif "Armed Robbery" in str(case_agg_type):
				case_agg_type = "AR"
			elif "BIZ TORCH" in str(case_agg_type):
				case_agg_type = "Torch"
			elif "MUGGING" in str(case_agg_type):
				case_agg_type = "Mug"
		elif "Time of Crime:" in str(Record_Item):
			Record_Item_Line = Record_Item.splitlines()
			case_agg_time = Record_Item_Line[3].strip()
		elif "Victim:" in str(Record_Item):
			case_victim = regex_match_between('u=', '">', Record_Item)
		elif "Victim Statement:" in str(Record_Item):
			if ( (case_agg_type == "AR") or (case_agg_type == "Torch") ):
				if ( ("Flat" in str(Record_Item)) or ("Studio" in str(Record_Item)) or ("Penthouse" in str(Record_Item)) or ("Palace" in str(Record_Item)) ):
					pass
				else:
					case_victim = regex_match_between('Your ', ' in ', Record_Item)
					case_victim = case_victim.replace(" ", "")

			if 'ended with' in str(Record_Item):
				Record_Item = regex_match_between('ended', None, Record_Item)

				if 'with: ' in str(Record_Item):
					if '.' in str(Record_Item):
						case_victim_statement = regex_match_between('with: ', '.', Record_Item).strip()
					else:
						case_victim_statement = regex_match_between('with: ', '<br>', Record_Item).strip()
				else:
					if '.' in str(Record_Item):
						case_victim_statement = regex_match_between('with ', '\.', Record_Item).strip()
					else:
						case_victim_statement = regex_match_between('with ', '<br>', Record_Item).strip()
			elif 'whacked your dog' in str(Record_Item):
				case_victim_statement = regex_match_between('<strong>', '</strong>', Record_Item).strip()
				suspect = case_victim_statement
			else:
				case_victim_statement = "None"

		elif "Witness Statement:" in str(Record_Item):
			if 'name ended with' in str(Record_Item):
				if '.' in str(Record_Item):
					case_witness_statement = regex_match_between('name ended with ', '\.', Record_Item).strip()
				else:
					case_witness_statement = regex_match_between('name ended with ', '<br>', Record_Item).strip()
		elif "DNA Log:" in str(Record_Item):
			case_dna = "None"
			if "was at the crime scene" in str(Record_Item):
				case_dna = regex_match_between('The DNA revealed ', ' was at the crime scene', Record_Item)
				suspect = case_dna

		elif "Fire Investigation:" in str(Record_Item):
			if "identity: " in str(Record_Item):
				case_fire = regex_match_between("identity: ", "</td>", Record_Item)
				case_fire = re.sub('[^a-zA-Z0-9_-]', "", case_fire)
		elif "Fingerprint Evidence:" in str(Record_Item):
			print("FINGERPRINT: " + str(Record_Item))
			if "owner could be, " in str(Record_Item):
				case_fingerprint = regex_match_between('owner could be, ', '\.', Record_Item).strip()

				regexsearch = re.search("\d\d\d\d\d<br>",Record_Item)
				if 'match=' in str(regexsearch):
					suspect = case_fingerprint
			else:
				case_fingerprint = "None"
		elif "Travel Log:" in str(Record_Item):
			travel_evidence_entered = True
		elif "Forensic Log" in str(Record_Item):
			forensics_done = True
			if "name is " in str(Record_Item):
				case_forensics = regex_match_between('name is ', '!', Record_Item).strip()
				suspect = case_forensics
			if "name ended with " in str(Record_Item):
				case_forensics = regex_match_between('name ended with ', '!', Record_Item).strip()


	Update_Database_For_AggTimer(case_victim, case_agg_type, case_agg_time, home_city)

	if not travel_evidence_entered:
		Enter_Travel_Evidence(lock_webdriver, running_thread)

	case_notes = element_get_attribute(lock_webdriver, "NAME", "notes", "innerHTML")
	if "- Statement made by" in str(case_notes):
		victim_notes_statement = regex_match_between('%;">', ' - Statement made by', Record_Item).strip()
	else:
		victim_notes_statement = "None"

	Results_911 = Check_911_Results(case_agg_time, home_city)

	Our_Online_List = Get_Our_Online_List(case_agg_time)
	Online_List_Before = read_s3('roastbusters', 'OnlineTimes/' + str(Our_Online_List[0]) + '.txt')
	Online_List_After = read_s3('roastbusters', 'OnlineTimes/' + str(Our_Online_List[2]) + '.txt')

	Boys_Did_Agg = Check_If_Boys_Did_Agg(case_victim, case_agg_type, home_city, case_agg_time)
	if Boys_Did_Agg == "":
		pass
	elif "(WITNESS)" in str(Boys_Did_Agg):
		print_function("BOYS WITNESSED:" + str(Boys_Did_Agg))
		boys_witnessed = regex_match_between('\)', None, Boys_Did_Agg)
	else:
		suspect = Boys_Did_Agg
		print_function("BOYS DID: " + str(Boys_Did_Agg))

	if (suspect == character_name):
		print_function("POLICE - YOU ARE THE SUSPECT", "RED")
		Bury_Case(lock_webdriver, running_thread)
		return True


	print("BEFORE DIFF: " + str(Our_Online_List[1]) + " - " + str(Online_List_Before) )
	print("AFTER DIFF: " + str(Our_Online_List[3]) + " - " + str(Online_List_After) )
	print("911 DIFF: " + str(Results_911[1]) + " - " + str(Results_911[2]))

	print("CASE:" + case_number)
	print("AGG:" + case_agg_type)
	print("TIME:" + case_agg_time)
	print("VICTIM:" + case_victim)
	print("VICSTATEMENT:" + case_victim_statement)
	print("WITSTATEMENT:" + case_witness_statement)
	print("DNA:" + case_dna)
	print("FINGERPRINT:" + case_fingerprint)
	print("FIRE:" + case_fire)
	print("FORENSIC:" + case_forensics)
	print("NOTES:" + case_notes)
	print("SUSPECT: " + suspect)
	print("VIC NOTES STATEMENT: " + victim_notes_statement)
	print("911SUSPECT:" + Results_911[0])
	print("BOYSWITNESS:" + boys_witnessed)

	name_ending = "None"
	if (suspect == "None"):
		longest_name_ending = 0

		if (boys_witnessed != "None"):
			if len(boys_witnessed) > int(longest_name_ending):
				longest_name_ending = len(boys_witnessed)
				print_function("POLICE - NAME ENDING VIA BOYS WITNESS")
				name_ending = str(boys_witnessed)
		if (case_victim_statement != "None"):
			if len(case_victim_statement) > int(longest_name_ending):
				longest_name_ending = len(case_victim_statement)
				print_function("POLICE - NAME ENDING VIA VICTIM STATEMENT")
				name_ending = str(case_victim_statement)
		if (case_witness_statement != "None"):
			if len(case_witness_statement) > int(longest_name_ending):
				longest_name_ending = len(case_witness_statement)
				print_function("POLICE - NAME ENDING VIA WITNESS STATEMENT")
				name_ending = str(case_witness_statement)
		if (case_fire != "None"):
			if len(case_fire) > int(longest_name_ending):
				longest_name_ending = len(case_fire)
				print_function("POLICE - NAME ENDING VIA FIRE")
				name_ending = str(case_fire)
		if (case_forensics != "None"):
			if len(case_forensics) > int(longest_name_ending):
				longest_name_ending = len(case_forensics)
				print_function("POLICE - NAME ENDING VIA FORENSICS")
				name_ending = str(case_forensics)
		if (Results_911[0] != "None"):
			if len(Results_911[0]) > int(longest_name_ending):
				longest_name_ending = len(Results_911[0])
				print_function("POLICE - NAME ENDING VIA 911")
				name_ending = str(Results_911[0])

	# if ( (boys_witnessed == "None") and (Boys_Did_Agg == "") and (case_victim_statement == "None") and (case_witness_statement == "None") and (case_fire == "None") and (case_forensics == "None") and (suspect == "None") and (victim_notes_statement == "None") and (Results_911[0] == "None") ):
	if ( (suspect == "None") and (name_ending == "None") ):

		# CHECK
		if victim_notes_statement != "None":
			# VICTIM PROVIDED A STATEMENT, BUT WE HAVE NO EVIDENCE TO COMPARE THIS AGAINST
			# CHECK VS ENTIRE PLAYER LIST
			player_database = get_from_database('Player', None)
			item_count = (len(player_database['Items']) - 1)
			while item_count >= 0:
				try:
					database_player_name = player_database['Items'][item_count]['PlayerName']
				except:
					item_count -= 1
					continue

				if database_player_name == "":
					item_count -= 1
					continue

				if (database_player_name.upper() in str(victim_notes_statement.upper())):
					suspect = database_player_name
					break

		if (suspect == "None"):
			if forensics_done:
				print_function("POLICE - NO EVIDENCE AND FORENSICS DONE - BURY CASE", "RED")
				Bury_Case(lock_webdriver, running_thread)
			else:
				action_timer = get_timer(lock_webdriver, 'Action', running_thread)
				if ( (action_timer == 0) and (config.getboolean('Career-Police', 'Do_Forensics')) ):
					print_function("POLICE - DO FORENSICS", "BLUE")
					Request_Forensics(lock_webdriver, running_thread, character_name)
					return False
				elif (config.getboolean('Career-Police', 'Require_Forensics_Before_Bury')):
					skip_cases = skip_cases + " " + str(case_number)
					write_file("env/PoliceSkipCase.txt", str(skip_cases))

					print_function("POLICE - NO EVIDENCE - RETURN CASE", "RED")
					Return_Case(lock_webdriver, running_thread)
				else:
					print_function("POLICE - NO EVIDENCE - BURY CASE", "RED")
					Bury_Case(lock_webdriver, running_thread)
			return True

	if (suspect == "None"):
		possible_suspects_list = []

		if ((Our_Online_List[1] != "") and (int(Our_Online_List[1]) <= 120)):
			for list_name in Online_List_Before.split("|"):
				list_name = list_name.strip()
				if list_name == "":
					continue

				if str(list_name) in possible_suspects_list:
					pass
				elif (str(list_name[-int(longest_name_ending):]) == str(name_ending)):
					possible_suspects_list.append(list_name)
					print_function("LIST NAME BEFORE: " + str(list_name) + " LAST:" + str(list_name[-int(longest_name_ending):]) )
		else:
			print_function("POLICE - SKIP CHECKING NAME AGAINST BEFORE LIST - TIME DIFF TOO HIGH: " + str(Our_Online_List[1]), "RED")

		if ((Our_Online_List[3] != "") and (int(Our_Online_List[3]) <= 120)):
			for list_name in Online_List_After.split("|"):
				list_name = list_name.strip()
				if list_name == "":
					continue

				if str(list_name) in possible_suspects_list:
					pass
				elif (str(list_name[-int(longest_name_ending):]) == str(name_ending)):
					possible_suspects_list.append(list_name)
					print_function("LIST NAME AFTER: " + str(list_name) + " LAST:" + str(list_name[-int(longest_name_ending):]))
		else:
			print_function("POLICE - SKIP CHECKING NAME AGAINST AFTER LIST - TIME DIFF TOO HIGH: " + str(Our_Online_List[3]), "RED")

		if ((Results_911[1] != "") and (int(float(Results_911[1])) <= 120)):
			for list_name in Results_911[2].split("|"):
				list_name = list_name.strip()
				if list_name == "":
					continue
				list_name = list_name.replace('*', '')

				if str(list_name) in possible_suspects_list:
					pass
				elif (str(list_name[-int(longest_name_ending):]) == str(name_ending)):
					possible_suspects_list.append(list_name)
					print_function("LIST NAME 911: " + str(list_name) + " LAST:" + str(list_name[-int(longest_name_ending):]))
		else:
			print_function("POLICE - SKIP CHECKING NAME AGAINST 911 LIST - TIME DIFF TOO HIGH: " + str(Results_911[1]), "RED")


		print_function("POLICE - NAME: " + str(name_ending), "RED")
		print_function("POLICE - SUSPECTS LIST: " + str(possible_suspects_list) + " LENGTH:" + str(len(possible_suspects_list)), "RED")

		if ( ( len(possible_suspects_list) > 1) and (case_fingerprint == "None") and (victim_notes_statement == "None") ):
			print_function("TOO MANY SUSPECTS AND NO FINGERPRINT OR VICTIM NOTES - BURY", "GREEN")
			Bury_Case(lock_webdriver, running_thread)
			return True

		if ((len(possible_suspects_list) > 1) and (suspect == "None")):
			for name in possible_suspects_list:
				if name.upper() in str(victim_notes_statement.upper()):
					suspect = name
					print("VICTIM NOTES SUSPECT: ", suspect)
					break

		if ( ( len(possible_suspects_list) > 1) and (suspect == "None") ):
			print_function("POLICE - TOO MANY SUSPECTS AND FINGERPRINT EVIDENCE")
			fingerprint_match_list = []
			for name in possible_suspects_list:
				if name in str(case_fingerprint):
					fingerprint_match_list.append(name)
			print("POLICE - FINGERPRINT MATCHES: " + str(len(fingerprint_match_list)))
			if (len(possible_suspects_list) == 1):
				suspect = fingerprint_match_list[0]
				print_function("POLICE - MULTIPLE SUSPECTS BUT ONLY ONE MATCHES FINGERPRINT: " + suspect)
			else:
				print_function("TOO MANY SUSPECT AND FINGERPRINT MATCHES - BURY", "GREEN")
				Bury_Case(lock_webdriver, running_thread)
				return True

		if ( len(possible_suspects_list) == 1):
			suspect = possible_suspects_list[0]

		if ( (len(possible_suspects_list) == 0) and (int(len(name_ending)) >= 2) ):
			phonebook_name = Check_Phonebook(lock_webdriver, running_thread, name_ending, case_agg_time)
			if phonebook_name == "":
				suspect = "None"
			else:
				suspect = str(phonebook_name)
			print_function("PHONEBOOK NAME: " + str(phonebook_name) + " SUSPECT: " + str(suspect))

	if (suspect != "None"):
		print_function("POLICE - SOLVING CASE", "GREEN")

		if (suspect == character_name):
			print_function("YOU ARE THE SUSPECT - BURY", "GREEN")
			Bury_Case(lock_webdriver, running_thread)
			return True
		else:
			case_action = "Close"
			while True:
				suspect = Enter_Suspect(lock_webdriver, suspect, character_name)

				if ( str(suspect) == str(character_name) ):
					print_function("YOU ARE THE SUSPECT - BURY", "GREEN")
					Bury_Case(lock_webdriver, running_thread)
					return True

				if Is_Name_Bold(suspect):
					sendkeys(lock_webdriver, "NAME", "notes", "\r\nNG - BOLD")

				Update_Case(lock_webdriver, running_thread, case_agg_type)

				if element_found(lock_webdriver, "XPATH", ".//*[@id='fail']"):
					if 'is now dead' in str(element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='fail']", "innerHTML")):
						suspect = Get_New_Name_Phonebook(lock_webdriver, running_thread, suspect)
						if (suspect == "None"):
							case_action = "Bury"
							break
				else:
					break

			if case_action == "Close":
				Close_Case(lock_webdriver, running_thread)
			else:
				Bury_Case(lock_webdriver, running_thread)
			return True
	else:
		print_function("POLICE - TOO MANY SUSPECTS - BURY", "RED")
		Bury_Case(lock_webdriver, running_thread)
		return True
	return True

def Get_New_Name_Phonebook(lock_webdriver, running_thread, suspect):
	new_name = "None"
	open_city(lock_webdriver, running_thread)
	element_click(lock_webdriver, "XPATH", ".//*[@class='phone_book']", running_thread)
	sendkeys(lock_webdriver, "XPATH", ".//*[@id='AutoNumber4']/tbody/tr[5]/td[@class='s1'][2]/p/input", str(suspect))
	element_click(lock_webdriver, "XPATH", ".//*[@id='AutoNumber4']/tbody/tr[7]/td[@class='s1'][2]/p/input", running_thread)

	element_click(lock_webdriver, "LINK", str(suspect), running_thread)
	profile_quote = str(element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='profile_quote']/div[@class='quote_content']", "innerHTML"))
	if "NAME CHANGED TO" in profile_quote:
		new_name = regex_match_between('NAME CHANGED TO ', None, profile_quote)
		new_name = regex_match_between('username=', '"', new_name)

	element_click(lock_webdriver, "XPATH", ".//*[@class='police']", running_thread)
	return str(new_name)

def Update_Database_For_AggTimer(case_victim, case_agg_type, case_agg_time, home_city):
	case_agg_time = datetime.datetime.strptime(case_agg_time, '%m/%d/%Y %I:%M:%S %p')

	Update_Business = False
	if (case_agg_type == "AR") or (case_agg_type == "Torch"):
		case_victim = str(home_city) + str(case_victim)
		Update_Business = True


	if (case_agg_type == "Pickpocket"):
		new_pro_time = case_agg_time + datetime.timedelta(minutes=70)
	elif (case_agg_type == "Mug"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif (case_agg_type == "Hack"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=12)
	elif (case_agg_type == "Torch"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=2)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif (case_agg_type == "BnE"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=10)
	elif (case_agg_type == "GTA"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif (case_agg_type == "AR"):
		new_pro_time = case_agg_time + datetime.timedelta(hours=1)
		new_pro_time = new_pro_time + datetime.timedelta(minutes=40)
	elif ("Dog Whack" in str(case_agg_type)):
		new_pro_time = case_agg_time - datetime.timedelta(hours=1)
	else:
		print_function("POLICE - UPDATE DATABASE - AGG NOT FOUND: " + str(case_agg_type), "RED")
		while True:
			time.sleep(30)

	minutes_diff = (new_pro_time - datetime.datetime.utcnow()).total_seconds() / 60.0
	if '-' in str(minutes_diff):
		# AGG IS IN THE PAST - SKIP UPDATING DATABASE
		pass
	else:
		if Update_Business:
			update_database('Business', 'BizName', str(case_victim), {"AggPro": str(new_pro_time)})
		else:
			update_database('Player', 'PlayerName', str(case_victim), {"Aggpro_Personal": str(new_pro_time), "UpdatedBy": "Police-Case"})
	return

def Request_Forensics(lock_webdriver, running_thread, character_name):
	go_to_page(lock_webdriver, 'PoliceDuties', running_thread)
	forensics_unlocked = False

	Police_Duties_List = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='earns_holder']/div[@id='holder_content']/form", "innerHTML")
	# print_function("DUTIES: " + str(Police_Duties_List))
	count = 0
	for duty in Police_Duties_List.split("<tr>"):
		duty_line = duty.splitlines()
		duty_line_check = re.sub('[^a-zA-Z]', "", str(duty_line[2]))
		if duty_line_check == "":
			continue
		if "forensics" in str(duty_line):
			forensics_unlocked = True
			element_click(lock_webdriver, "NAME", "duty", running_thread, count)
		if "Submit" in str(duty_line):
			if forensics_unlocked:
				break
			else:
				discord_error(str(character_name) + " - FORENSICS NOT UNLOCKED")
				print_function("POLICE - ATTEMPTING TO USE FORENSICS - BUT THIS IS NOT UNLOCKED")
				while True:
					time.sleep(30)
		count += 1

	element_click(lock_webdriver, "XPATH", ".//*[@class='buttons']", running_thread)
	element_click(lock_webdriver, "XPATH", ".//*[@class='police']", running_thread)
	return

def Case_Is_Witness(Case_Details_Raw):
	if "<i>Not reported yet" in str(Case_Details_Raw):
		print_function("POLICE - OPEN CASE IS WITNESS")
		return True
	else:
		return False

def Request_Evidence(lock_webdriver, running_thread, Case_Details_Raw):
	Refresh_Case_Details = False
	Fingerprint_Lookup_Required = False
	DNA_Lookup_Required = False

	if "Torch" in str(Case_Details_Raw):
		Agg_Is__Torch = True
	else:
		Agg_Is__Torch = False

	if (Agg_Is__Torch):
		for Record_Item in Case_Details_Raw.split("<tr>"):
			if "Fire Investigation:" in str(Record_Item):
				if "None" in str(Record_Item):
					print_function("POLICE - FIRE INVESTIGATION REQUIRED", "BLUE")
					element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[5]", running_thread)
					Refresh_Case_Details = True
				break

	if not "Fingerprint Evidence:" in str(Case_Details_Raw):
		print_function("POLICE - FINGERPRINT EVIDENCE REQUIRED", "BLUE")
		if (Agg_Is__Torch):
			element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[6]", running_thread)
		else:
			element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[5]", running_thread)
		Refresh_Case_Details = True

	if not "DNA Log:" in str(Case_Details_Raw):
		print_function("POLICE - DNA EVIDENCE REQUIRED 1", "BLUE")
		if (Agg_Is__Torch):
			element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[7]", running_thread)
		else:
			element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[6]", running_thread)

		random_timer = random.randrange(31, 42)
		globals()['timers'].__dict__['career_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
		print_function("POLICE - DNA TIMER SET")

		Refresh_Case_Details = True
	else:
		for Record_Item in Case_Details_Raw.split("<tr>"):
			if "DNA Log:" in str(Record_Item):
				regexsearch = re.search("\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d", Record_Item)
				if 'match=' in str(regexsearch):
					break

				Record_Item_Line = Record_Item.splitlines()
				empty_check = Record_Item_Line[3]
				empty_check = re.sub('[^a-zA-Z]', "", empty_check)
				if empty_check == "":
					print_function("POLICE - DNA EVIDENCE REQUIRED 2", "BLUE")
					if (Agg_Is__Torch):
						element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[7]", running_thread)
					else:
						element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[6]", running_thread)
					Refresh_Case_Details = True
				break

	if Refresh_Case_Details:
		Case_Details_Raw = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']", "innerHTML")
		Refresh_Case_Details = False

	for Record_Item in Case_Details_Raw.split("<tr>"):
		if "Fingerprint Evidence:" in str(Record_Item):
			if "None" in str(Record_Item):
				break
			elif ( ("owner could be" in str(Record_Item)) or ("no fingerprint matches" in str(Record_Item)) ):
				# FINGERPRINT ALREADY LOOKED UP
				pass
			else:
				Fingerprint_Lookup_Required = True
				break

	for Record_Item in Case_Details_Raw.split("<tr>"):
		if "DNA Log:" in str(Record_Item):
			if "None" in str(Record_Item):
				break
			elif "Awaiting results" in str(Record_Item):
				# DNA AWAITING RESULTS
				pass
			elif "was at the crime scene" in str(Record_Item):
				pass
			elif "no DNA matches" in str(Record_Item):
				# DNA ALREADY LOOKED UP
				pass
			else:
				DNA_Lookup_Required = True
				break

	if ( (Fingerprint_Lookup_Required) or (DNA_Lookup_Required) ):
		# OPEN RECORDS DATABASE
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@class='links']/a[2]", running_thread)

	if (Fingerprint_Lookup_Required):
		# SEARCH FINGERPRINT & ADD TO RECORDS
		print_function("POLICE - SEARCH FINGERPRINT & ADD TO RECORDS")
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/table[@class='s6']/tbody/tr[7]/td[@id='police_content']/input", running_thread)
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/table[@id='holder_table']/tbody/tr[4]/td[@id='police_content']/input", running_thread)
		Refresh_Case_Details = True

	if (DNA_Lookup_Required):
		# SEARCH DNA & ADD TO RECORDS
		print_function("POLICE - SEARCH DNA & ADD TO RECORDS")
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/table[@class='s6']/tbody/tr[11]/td[@id='police_content']/input", running_thread)
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/table[@id='holder_table']/tbody/tr[5]/td[@id='police_content']/form/p/input", running_thread)
		Refresh_Case_Details = True

	if ( (Fingerprint_Lookup_Required) or (DNA_Lookup_Required) ):
		# GO BACK TO CASE
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@class='links']/a[2]", running_thread)

	if (Refresh_Case_Details):
		Case_Details_Raw = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']", "innerHTML")
		Refresh_Case_Details = False

	return Case_Details_Raw

def Awaiting_Evidence(Case_Details_Raw):
	if "Awaiting results" in str(Case_Details_Raw):
		print_function("POLICE - CASE IS AWAITING EVIDENCE", "RED")
		return True
	return False

def Close_Case(lock_webdriver, running_thread):
	print_function("POLICE - CLOSE CASE")
	element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[1]", running_thread)
	return

def Bury_Case(lock_webdriver, running_thread):
	print_function("POLICE - BURY CASE")
	element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[2]", running_thread)
	return

def Return_Case(lock_webdriver, running_thread):
	print_function("POLICE - RETURN CASE")
	element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[3]", running_thread)
	return

def Update_Case(lock_webdriver, running_thread, case_agg_type):
	print_function("POLICE - UPDATE CASE")
	if "Torch" in str(case_agg_type):
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[8]", running_thread)
	else:
		element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[7]", running_thread)
	return

def Check_If_Boys_Did_Agg(case_victim, case_agg_type, case_city, case_agg_time):
	case_agg_time = datetime.datetime.strptime(case_agg_time, '%m/%d/%Y %I:%M:%S %p')

	results = read_s3('roastbusters', 'FullAggsList/' + str(case_agg_time.year) + '-' + str(case_agg_time.month) + '-' + str(case_agg_time.day) + '.txt')
	Boys_Did_Agg = ""

	if ( (case_agg_type == "Dog Whack") or (case_agg_type == "Pickpocket") or (case_agg_type == "Mug") or (case_agg_type == "Hack") or (case_agg_type == "Torch") or (case_agg_type == "BnE") or (case_agg_type == "GTA") or (case_agg_type == "AR")):
		pass
	else:
		print_function("NEW CASE AGG TYPE: " + str(case_agg_type), "RED")
		while True:
			time.sleep(30)

	for line in results.splitlines():
		if line == "":
			continue

		agg_time = regex_match_between(' on ', None, line)
		if '.' in str(agg_time):
			agg_time = regex_match_between(None, '\.', agg_time)
		agg_time = datetime.datetime.strptime(agg_time, '%Y-%m-%d %H:%M:%S')


		word_number = 1
		suspect = word_in_string(word_number, line)

		word_number += 1
		agg_type = word_in_string(word_number, line)
		word_number += 1

		if "Old Trafford" in str(line):
			victim = "OldTrafford"
			word_number += 1
		elif "Dog Fights" in str(line):
			victim = "DogFights"
			word_number += 1
		elif "Clothing Shop" in str(line):
			victim = "ClothingShop"
			word_number += 1
		elif "Tattoo Parlour" in str(line):
			victim = "TattooParlour"
			word_number += 1
		elif "Underground Auction" in str(line):
			victim = "UndergroundAuction"
			word_number += 1
		elif "Weapon Shop" in str(line):
			victim = "WeaponShop"
			word_number += 1
		elif "Funeral Parlour" in str(line):
			victim = "FuneralParlour"
			word_number += 1
		elif "Fire Station" in str(line):
			victim = "FireStation"
			word_number += 1
		elif "Construction Company" in str(line):
			victim = "ConstructionCompany"
			word_number += 1
		elif "Horse Racing" in str(line):
			victim = "HorseRacing"
			word_number += 1
		elif "Parking Lot" in str(line):
			victim = "ParkingLot"
			word_number += 1
		elif "Vehicle Yard" in str(line):
			victim = "VehicleYard"
			word_number += 1
		elif "Drug Store" in str(line):
			victim = "DrugStore"
			word_number += 1
		elif "Dog Training School" in str(line):
			victim = "DogTrainingSchool"
			word_number += 2
		elif "Dog Pound" in str(line):
			victim = "DogPound"
			word_number += 1
		elif "Town Hall" in str(line):
			victim = "TownHall"
			word_number += 1
		elif "Eden Park" in str(line):
			victim = "EdenPark"
			word_number += 1
		elif "ConstructionCompany Company" in str(line):
			victim = "ConstructionCompany"
			word_number += 1
		else:
			victim = word_in_string(word_number, line)

		if ('(Witness)' in str(line)) or ('(Success)' in str(line)):
			word_number += 1
			witness = word_in_string(word_number, line)
		else:
			witness = "(Success)"

		if " Biz AR " in str(line):
			word_number += 3
			agg_type = "AR"
		elif " AR AR " in str(line):
			word_number += 3
			agg_type = "AR"
		elif " AR Robbery! " in str(line):
			word_number += 3
			agg_type = "AR"
		elif "AR Robbery!" in str(line):
			word_number += 1
			agg_type = "AR"
		elif "BnE Zero" in str(line):
			word_number += 3
			agg_type = "BnE"
		elif "Armed Robbery" in str(line):
			word_number += 3
			agg_type = "AR"
		elif "BIZ TORCH" in str(line):
			word_number += 3
			agg_type = "Torch"
		else:
			word_number += 2

		city = word_in_string(word_number, line)


		if (agg_type == "BnEZero"):
			agg_type = "BnE"
		elif (agg_type == "MUGGING"):
			agg_type = "Mug"
		elif (agg_type == "Break-in!"):
			agg_type = "BnE"


		if ( (agg_type == "Pickpocket") or (agg_type == "Mug") or (agg_type == "Hack") or (agg_type == "BnE") or (agg_type == "GTA") or (agg_type == "AR") or (agg_type == "Torch") ):
			pass
		else:
			print_function("POLICE - NEW AGG TYPE: " + str(agg_type) + " - " + str(line), "RED")
			while True:
				time.sleep(30)


		if (city == "RO"):
			city = "RioDeJaneiro"
		elif (city == "TO"):
			city = "Toronto"
		elif (city == "MN"):
			city = "Manila"
		elif (city == "MC"):
			city = "Manchester"
		elif (city == "AK"):
			city = "Auckland"
		elif (city == "LD"):
			city = "London"
		elif (city == "NY"):
			city = "NewYork"
		elif ( ("(Witness)" in str(line)) and (not " in " in str(line)) ):
			city = "Unknown"

		if ( (city == "Auckland") or (city == "London") or (city == "NewYork") or (city == "Toronto") or (city == "Manila") or (city == "Manchester") or (city == "RioDeJaneiro") or (city == "Unknown") ):
			pass
		else:
			print_function("NEW CITY TYPE: " + str(city) + " - " + str(line) + " - wordnumber:" + str(word_number), "RED")
			while True:
				time.sleep(30)

		formatted_line = str(suspect) + " " + str(agg_type) + " " + str(victim) + " " + str(witness) + " in " + str(city) + " on " + str(agg_time)
		if ( (case_victim == victim) and (case_agg_type == agg_type) and ((case_city == city) or (city == "Unknown")) ):
			minutes_diff = abs((case_agg_time - agg_time).total_seconds() / 60.0)
			if int(minutes_diff) <= 6:
				print_function("LIKELY BOYS MATCH - VERIFY TIME MATCHES - TIME DIFFERENCE " + str(minutes_diff) + " MINUTES")
				print(formatted_line)
				if "Witness" in str(witness):
					Boys_Did_Agg = "(WITNESS)" + str(suspect)
				else:
					Boys_Did_Agg = suspect
				break

	return Boys_Did_Agg

def Check_911_Results(case_agg_time, home_city):
	case_agg_time = datetime.datetime.strptime(case_agg_time, '%m/%d/%Y %I:%M:%S %p')
	Date_911 = str(case_agg_time.year) + "-" + str(case_agg_time.month)
	Results_911 = read_s3('roastbusters', '911' + str(home_city) + '/' + str(Date_911) + '.txt')

	found_911_match = ""
	last_line = ""
	lowest_minutes_diff = ""
	online_list = ""
	suspect = "None"


	for line in Results_911.splitlines():
		if last_line == "":
			last_line = line

		if str(case_agg_time) in str(line):
			count = 1
			agg_time = ""
			agg = ""
			victim = ""
			suspect = "None"
			for Tab_Detail in line.split():
				if (count == 1):
					agg_time = Tab_Detail
				elif (count == 2):
					agg_time = agg_time + " " + Tab_Detail
				elif (count == 3):
					agg = Tab_Detail
				elif (count == 4):
					victim = Tab_Detail
				elif (count == 5):
					suspect = Tab_Detail
					if suspect == "escaped":
						suspect = ""
				count += 1
			print("TIME: " + str(agg_time) + " AGG:" + str(agg) + " VICTIM:" + str(victim) + " SUSPECT:" + str(suspect))
			found_911_match = line
			lowest_minutes_diff = "0"

		if "|" in str(line):
			# ONLINE LIST
			if (lowest_minutes_diff == "0"):
				online_list = str(line)
				print_function("911 ONLINE LIST - MATCH FOUND: " + str(online_list), "BLUE")
				print_function("911 - " + str(found_911_match), "BLUE")
				return [str(suspect), str(lowest_minutes_diff), str(online_list)]
			else:
				count = 1
				agg_time = ""
				for Tab_Detail in last_line.split():
					if (count == 1):
						agg_time = Tab_Detail
					elif (count == 2):
						agg_time = agg_time + " " + Tab_Detail
					if int(count) >= 3:
						break
					count += 1

				# print_function("AGG TIME:" + str(agg_time) + " IN LINE:" + str(last_line), "RED")
				if "." in str(agg_time):
					try:
						agg_time = datetime.datetime.strptime(agg_time, '%Y-%m-%d %H:%M:%S.%f')
					except:
						continue
				else:
					try:
						agg_time = datetime.datetime.strptime(agg_time, '%Y-%m-%d %H:%M:%S')
					except:
						continue
				minutes_diff = abs((case_agg_time - agg_time).total_seconds() / 60.0)

				if lowest_minutes_diff == "":
					lowest_minutes_diff = minutes_diff
					online_list = str(line)
				elif (int(minutes_diff) < int(lowest_minutes_diff)):
					lowest_minutes_diff = minutes_diff
					online_list = str(line)

		last_line = line

	print_function("911 TIME DIFFERENCE: " + str(lowest_minutes_diff), "BLUE")
	print_function("911 ONLINE LIST: " + str(online_list), "BLUE")

	return [str(suspect), str(lowest_minutes_diff), str(online_list)]

def Get_Our_Online_List(case_agg_time):
	case_agg_time = datetime.datetime.strptime(case_agg_time, '%m/%d/%Y %I:%M:%S %p')
	search_month = str(case_agg_time.month)
	search_day = str(case_agg_time.day)
	if len(search_month) == 1:
		search_month = "0" + str(search_month)
	if len(search_day) == 1:
		search_day = "0" + str(search_day)

	response = s3_get_files('roastbusters', 'OnlineTimes/' + str(case_agg_time.year) + '-' + search_month + '-' + search_day + "/")

	online_list_before = ""
	online_list_before_difference = ""
	online_list_after = ""
	online_list_after_difference = ""

	if 'Contents' in str(response):
		for object in response['Contents']:
			key = object['Key']
			key = key.replace('OnlineTimes/', "")
			key = key.replace(".txt", "")
			online_time = datetime.datetime.strptime(str(key), '%Y-%m-%d/%H-%M')
			minutes_diff = (online_time - case_agg_time).total_seconds() / 60.0
			# print("MINS:" + str(minutes_diff) + " BETWEEN " + str(case_agg_time) + " AND " + str(online_time))
			if '-' in str(minutes_diff):
				online_list_before = key
				online_list_before_difference = abs(minutes_diff)
			else:
				online_list_after = key
				online_list_after_difference = minutes_diff
				break
	else:
		print_function("POLICE - NO OnlineTimes ON RECORD")

	return [online_list_before, online_list_before_difference, online_list_after, online_list_after_difference]

def Is_Name_Bold(suspect):
	bold_list = get_from_database('BoldList', None)
	for bold_name_raw in bold_list['Items']:
		bold_name = bold_name_raw['PlayerName']
		if bold_name == suspect:
			print_function("POLICE - SUSPECT IS BOLD: " + str(suspect), "BLUE")
			return True
	return False

def Enter_Suspect(lock_webdriver, suspect, character_name):
	clearkeys(lock_webdriver, "NAME", "suspect")

	while True:
		response = get_from_database('Player', 'AliveStatus', "Key('PlayerName').eq('" + str(suspect) + "')")
		try:
			alive_status = response['Items'][0]['AliveStatus']
		except:
			while True:
				discord_message(config['Auth']['discord_id'] + str(get_your_character_name(lock_webdriver)) + " POLICE - SUSPECT " + str(suspect) + " ALIVESTATUS NOT FOUND IN DATABASE. PROCESS THIS CASE MANUALLY THEN RESTART BOT")
				time.sleep(30)
		if alive_status != "Dead":
			break

		response2 = get_from_database('Player', 'NewName', "Key('PlayerName').eq('" + str(suspect) + "')")
		try:
			new_name = response2['Items'][0]['NewName']
			sendkeys(lock_webdriver, "NAME", "notes", "\r\nname change " + str(suspect) + " to " + str(new_name))

			if ( str(suspect) == str(new_name) ):
				break
			elif (str(new_name) == str(character_name)):
				break

			suspect = new_name
		except:
			break

	if (suspect == character_name):
		pass
	else:
		sendkeys(lock_webdriver, "NAME", "suspect", suspect)
	return suspect

def Enter_Travel_Evidence(lock_webdriver, running_thread):
	print_function("POLICE - ADD TRAVEL EVIDENCE")
	element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@id='shop_holder']/div[@id='holder_content']/div[@class='body']/form/div[@class='links']/input[4]", running_thread)
	element_click(lock_webdriver, 'XPATH', ".//*[@id='noevidence']", running_thread)
	element_click(lock_webdriver, 'XPATH', ".//*[@id='pd']/div[@class='body']/p[3]/input[@class='submit']", running_thread)
	return

def Check_Phonebook(lock_webdriver, running_thread, name_ending, case_agg_time):
	case_agg_time = datetime.datetime.strptime(case_agg_time, '%m/%d/%Y %I:%M:%S %p')

	open_city(lock_webdriver, running_thread)
	element_click(lock_webdriver, "XPATH", ".//*[@class='phone_book']", running_thread)
	sendkeys(lock_webdriver, "XPATH", ".//*[@id='AutoNumber4']/tbody/tr[5]/td[@class='s1'][2]/p/input", str(name_ending))
	element_click(lock_webdriver, "XPATH", ".//*[@id='AutoNumber4']/tbody/tr[7]/td[@class='s1'][2]/p/input", running_thread)

	phonebook_matches = []
	phonebook_results = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content'][1]", "innerHTML")
	for line in phonebook_results.splitlines():
		if "username=" in str(line):
			name = regex_match_between('username=', '"', line)
			if (str(name[-int(len(name_ending)):]) == str(name_ending)):
				phonebook_matches.append(name)

	obituaries_results = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content'][3]", "innerHTML")
	for line in obituaries_results.splitlines():
		if "username=" in str(line):
			name = regex_match_between('username=', '"', line)
			if (str(name[-int(len(name_ending)):]) == str(name_ending)):
				try:
					response = get_from_database('Player', 'DeathTime', "Key('PlayerName').eq('" + str(name) + "')")
					death_time = response['Items'][0]['DeathTime']
					death_time = datetime.datetime.strptime(death_time, '%Y-%m-%d %H:%M:%S.%f')

					minutes_diff = (death_time - case_agg_time).total_seconds() / 60.0
					if '-' in str(minutes_diff):
						# AGG IS IN THE PAST - SKIP
						pass
					else:
						phonebook_matches.append(name)
				except:
					continue

	print_function("POLICE - PHONEBOOK RESULTS: " + str(phonebook_matches), "BLUE")
	element_click(lock_webdriver, "XPATH", ".//*[@class='police']", running_thread)

	if (len(phonebook_matches) == 1):
		return str(phonebook_matches[0])
	else:
		return ""
