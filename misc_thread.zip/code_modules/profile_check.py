from globalvars import *
from code_modules.function import *

def profile_check(lock_webdriver, running_thread, waiting_thread_list, extra_string=None):
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_earn)

	# sell request que 9z item. if that's found misc thread sends a profile check request with the sell string included
	# CORRECT THIS EXTRA SRING STUFF TO GET THE VALUES OF WHAT TO SELL ETC

	if extra_string is None:
		sell_fromhand_item = None
		sell_to_name = None
		sell_to_amount = None
	elif 'SellItem' in extra_string:
		string_split = extra_string.split('//')
		sell_fromhand_item = string_split[1]
		sell_to_name = string_split[2]
		sell_to_amount = string_split[3]

	# PROFILE CHECK START
	go_to_page(lock_webdriver, "Profile", running_thread)

	sell_correct_item_found = "No"
	sell_button_count = ""
	which_sell_button = ""

	profile_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='account_holder']/div[@id='account_profile']/div[@id='holder_content']", "innerHTML")
	#profile_table = element_get_attribute(lock_webdriver, "XPATH", ".///html/body/div[2]/div/div[2]/ul/li[2]/a", "innerHTML")

	# BIONICS
	bios_needed = ""
	if 'Bionic Brain|Not installed' in profile_table:
		bios_needed = bios_needed + " Brain"
	if 'Bionic Eyes|Not installed' in profile_table:
		bios_needed = bios_needed + " Eyes"
	if 'Bionic Heart|Not installed' in profile_table:
		bios_needed = bios_needed + " Heart"
	if 'Bionic Arms|Not installed' in profile_table:
		bios_needed = bios_needed + " Arms"
	if 'Bionic Legs|Not installed' in profile_table:
		bios_needed = bios_needed + " Legs"
	if bios_needed == "":
		bios_needed = "NONE"

	# INITIAL VARIABLES
	pseudo_count = 0
	house = 'None'
	free_storage = 0
	vehicle = 'NONE'
	vehicle_condition = 'None'
	hand1 = 'None'
	hand2 = 'None'
	medipack = 'None'
	stash = 'None'
	vest = 'None'
	next_line = ''

	variables_list = running_thread[4]
	for item in running_thread[4]:
		if 'profile-' in item:
			try:
				variables_list.remove(item)
			except:
				pass

	for line in profile_table.splitlines():
		if '>Sell<' in line:
			if sell_button_count == '':
				sell_button_count = 0
			else:
				sell_button_count = int(sell_button_count) + 1
			if sell_correct_item_found == "Yes":
				which_sell_button = sell_button_count
				sell_correct_item_found = "No"

		if next_line == 'House':
			house = regex_match_between('>', '<', line)
			next_line = ''
			continue
		elif next_line == 'Storage':
			free_storage = regex_match_between('>', '<', line)
			free_storage = re.sub('[^0-9]', "", free_storage)
			next_line = ''
			continue
		elif next_line == 'VehicleCondition':
			vehiclecondition = regex_match_between('>', '<', line)
			print_function('vehicle condition: ' + str(vehiclecondition))
			if 'Serviceable' in vehiclecondition:
				# USABLE
				for item in running_thread[4]:
					if 'Vehicle:' in item:
						try:
							variables_list.remove(item)
						except:
							pass
				variables_list.append('Vehicle:Repaired')
			elif 'Undergoing repairs' in vehiclecondition:
				if 'BrokenDownAwaitingRepair' in str(running_thread[4]):
					pass
				else:
					# REPAIR WAITING
					for item in running_thread[4]:
						if 'Vehicle:' in item:
							try:
								variables_list.remove(item)
							except:
								pass
					variables_list.append('Vehicle:WaitingRepair')
			next_line = ''
			continue
		elif next_line == 'Vehicle':
			vehicle = regex_match_between('>', '<', line)
			next_line = ''
			continue
		elif next_line == 'Stash':
			if 'item_content' in line:
				free_storage = int(free_storage) - 1
				stash_item = regex_match_between('<b>', '</b>', line)

				if stash == 'None':
					stash = stash_item
				else:
					stash = stash + " / " + stash_item
				next_line = ''
				continue
			else:
				continue

		# PSEUDO
		if 'Pseudoephedrine -' in line:
			pseudo_count = regex_match_between('Pseudoephedrine -', None, line)
			pseudo_count = re.sub('[^0-9]', "", pseudo_count)

		elif 'Apartment:' in line:
			next_line = 'House'
			continue
		elif 'Storage:' in line:
			next_line = 'Storage'
			continue
		elif 'Type:' in line:
			next_line = 'Vehicle'
			continue
		elif 'Condition:' in line:
			next_line = 'VehicleCondition'
			continue
		elif 'Right Hand' in line:
			hand1 = regex_match_between('You have ', ' in your right hand', line)
			if sell_fromhand_item is None:
				pass
			else:
				if sell_fromhand_item in hand1:
					sell_correct_item_found = "Yes"
		elif 'Left Hand' in line:
			hand2 = regex_match_between('You have ', ' in your left hand', line)
			if sell_fromhand_item is None:
				pass
			else:
				if sell_fromhand_item in hand2:
					sell_correct_item_found = "Yes"
		elif 'Medipack' in line:
			medipack = 'YES'
		elif ('Stash #' in line) and ('item_info' in line):
			next_line = 'Stash'
			continue
		elif 'You are wearing' in line:
			vest = regex_match_between('You are wearing ', '"', line)

	print_function("BIOS NEEDED: " + str(bios_needed) + " PSEUDO: " + str(pseudo_count) + " HOUSE: " + str(house) + " STORAGE FREE: " + str(free_storage) + " VEHICLE: " + str(vehicle) + " HAND1 " + str(hand1) + " HAND2 " + str(hand2) + " MEDIPACK: " + str(medipack) + " STASH: " + str(stash) + " VEST: " + str(vest))

	if sell_fromhand_item is None:
		pass
	else:
		element_click(lock_webdriver, 'LINK', "Sell", running_thread, which_sell_button)
		verify_selling_correct_item = element_get_attribute(lock_webdriver, "XPATH",
															".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form",
															"innerHTML")
		if ('sell your' in verify_selling_correct_item) and (sell_fromhand_item in verify_selling_correct_item):
			sendkeys(lock_webdriver, "XPATH",
					 ".//*[@id='shop_holder']/div[@id='holder_content']/form/input[@class='input'][1]", sell_to_name)
			sendkeys(lock_webdriver, "XPATH",
					 ".//*[@id='shop_holder']/div[@id='holder_content']/form/input[@class='input'][2]", sell_to_amount)
			click_continue(lock_webdriver, running_thread)

			if element_found(lock_webdriver, "ID", "success"):
				sell_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			elif element_found(lock_webdriver, "ID", "fail"):
				sell_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")

			print_function('SOLD: ' + str(sell_fromhand_item) + ' TO: ' + str(sell_to_name) + ' FOR: ' + str(sell_to_amount) + ' RESULTS: ' + str(sell_results))
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t SOLD " + str(sell_fromhand_item) + " TO " + str(sell_to_name))
			append_file('./records/BnE.txt', "\n SOLD " + str(sell_fromhand_item) + " TO " + str(sell_to_name))
			append_file('./records/AllAggs.txt', "\n SOLD " + str(sell_fromhand_item) + " TO " + str(sell_to_name))
			discord_message(config['Auth']['discord_id'] + "SOLD " + str(sell_fromhand_item) + " TO: " + str(sell_to_name) + " FOR: " + str(sell_to_amount)  + " RESULTS: " + str(sell_results))
		else:
			print_function('SELLING INCORRECT ITEM: ' + str(sell_fromhand_item) + ' VS: ' + str(verify_selling_correct_item))
			discord_message(config['Auth']['discord_id'] + "SELL ITEM FAILED - INCORRECT ITEM: " + str(sell_fromhand_item) + " VS: " + str(verify_selling_correct_item))

		for thread in waiting_thread_list:
			if 'SellItem' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

	variables_list.append('profile-vest:' + str(vest))
	variables_list.append('profile-medipack:' + str(medipack))
	variables_list.append('profile-pseudo:' + str(pseudo_count))
	variables_list.append('profile-house:' + str(house))
	variables_list.append('profile-vehicle:' + str(vehicle))
	variables_list.append('profile-hand1:' + str(hand1))
	variables_list.append('profile-hand2:' + str(hand2))
	variables_list.append('profile-stash:' + str(stash))
	running_thread[4] = variables_list
	print_function('UPDATED VARIABLES FOR PROFILE: ' + str(running_thread[4]))
	write_file("env/variables.txt", running_thread[4])

	# SET TIMER FOR NEXT PROFILE CHECK. THIS WILL EXTEND IF ALREADY SET
	random_timer = random.randrange(26, 32)
	write_file("env/profile_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(hours=random_timer)))

	thread_remove_from_queue(running_thread, waiting_thread_list)
	return