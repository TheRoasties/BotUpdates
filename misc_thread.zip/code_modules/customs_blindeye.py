from globalvars import *
from code_modules.function import *

def customs_blindeye(lock_webdriver, running_thread, waiting_thread_list, your_character_name):
	if 'BlindEye:' in str(waiting_thread_list):
		if globals()['timers'].__dict__['traffic_timer'] is None:
			globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Trafficking', running_thread))
		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['traffic_timer']
		if not '-' in str(time_difference):
			print_function('CUSTOMS BLINDEYE - QUEUED')
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_earn)
			print_function("CUSTOMS BLINDEYE  - START")

			for thread in waiting_thread_list:
				if ('BlindEye:') in thread:
					smuggle_name = regex_match_between('BlindEye:', None, thread)
					print_function("CUSTOMS BLINDEYE - SMUGGLE NAME: " + str(smuggle_name))

					if go_to_page(lock_webdriver, "Customs_Blindeye", running_thread):
						pass
					else:
						# CANNOT GO TO AGGS PAGE - LIKELY CS NEEDED
						return

					if element_found(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p[1]/select"):
						dropdown = get_dropdown_options(lock_webdriver, "XPATH",
														".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p[1]/select")
						print_function("CUSTOMS BLINDEYE - DROPDOWN OPTIONS: " + str(dropdown))

						if smuggle_name in dropdown:
							select_dropdown_option(lock_webdriver, "XPATH",
												   ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p[1]/select", smuggle_name)
							element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p[2]/input", running_thread)

							# SET TIMER
							traffic_timer = get_timer(lock_webdriver, 'Trafficking', running_thread)
							globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=traffic_timer)

							try:
								waiting_thread_list.remove(thread)
							except:
								pass

							break
						else:
							input("SMUGGLE NAME NOT IN DROPDOWN?")
					else:
						input("SMUGGLE DROPDOWN NOT FOUND?")

			thread_remove_from_queue(running_thread, waiting_thread_list)
	return

