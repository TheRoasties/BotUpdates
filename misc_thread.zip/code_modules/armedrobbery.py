from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

__all__ = ["check_armedrobbery_target", "do_armedrobbery_thread"]


def check_armedrobbery_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name):
	viable_armedrobbery_targets = []
	business_list = globals()['public_businesses'] + globals()['private_businesses_' + your_current_city]

	aggstr_minutes_needed = config['ArmedRobbery']['StartingMinutesRequired']

	# GET MODIFIED AGGSTR - USE TORCH TIMER IF RELEVANT
	if (config.getboolean('Torch', 'Do_Torch')) and ('Torch' in running_thread[3]):
		if os.path.isfile('./agg_targets/torch/' + your_current_city + '.txt'):
			mins_adjusted = int(read_file('./agg_targets/torch/' + your_current_city + '.txt'))
		else:
			mins_adjusted = 0
	else:
		# NO TORCH - USE REGULAR AR TIMER
		if os.path.isfile('./agg_targets/armedrobbery/' + your_current_city + '.txt'):
			mins_adjusted = int(read_file('./agg_targets/armedrobbery/' + your_current_city + '.txt'))
		else:
			mins_adjusted = 0

	# CHECK VALID INTEGERS
	try:
		if (int(aggstr_minutes_needed) > 0):
			pass
	except:
		aggstr_minutes_needed = 30

	try:
		if (int(mins_adjusted) > 0):
			pass
	except:
		mins_adjusted = 0

	aggstr_minutes_needed = int(aggstr_minutes_needed) + int(mins_adjusted)
	if aggstr_minutes_needed > 30:
		aggstr_minutes_needed = 30
	elif aggstr_minutes_needed < 3:
		aggstr_minutes_needed = 3

	# CHECK ENOUGH AGGSTR
	if int(aggstr_mins_max) >= int(aggstr_minutes_needed):
		# SUFFICIENT AGGSTRENGTH
		if 'Torch|AR' in running_thread[4]:
			pass
		else:
			variables_list = running_thread[4]
			variables_list.append('Torch|AR')
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES - NOT GO BELOW TORCH/AR')
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " UPDATED VARIABLES - NOT GO BELOW TORCH/AR")
	else:
		# NOT ENOUGH AGGSTRENGTH
		return


	# AVOID BLACKLIST TARGETS
	for business in business_list:
		# BLACKLIST
		blacklist = config['ArmedRobbery']['ArmedRobbery_Blacklist_' + your_current_city].split()
		blacklist_item_found = False
		for item in blacklist:
			if item in business:
				blacklist_item_found = True
				break

			if 'PRIVATE' in blacklist:
				if business in globals()['private_businesses_' + your_current_city]:
					blacklist_item_found = True

			if 'PUBLIC' in blacklist:
				if business in globals()['public_businesses']:
					blacklist_item_found = True

		if blacklist_item_found:
			continue

		# AGGPRO - LOCAL
		aggpro_timer = aggtarget_business_list_manager[your_current_city].get_local_aggpro_timer(business)
		time_difference = datetime.datetime.utcnow() - aggpro_timer

		if not '-' in str(time_difference):
			# AGGPRO - SHARED
			aggpro_timer = aggtarget_business_list_manager[your_current_city].get_shared_aggpro_timer(business)

			time_difference = datetime.datetime.utcnow() - aggpro_timer

			if not '-' in str(time_difference):
				# AGGPRO - SHARED
				viable_armedrobbery_targets.append(business)
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - ARMEDROBBERY - VIABLE TARGET " + str(business))
			else:
				write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - ARMEDROBBERY - HAS SHARED AGGPRO " + str(business))
		else:
			write_file("env/Aggs_Thread_Log.txt", str(log_agg_time()) + " - ARMEDROBBERY - HAS LOCAL AGGPRO " + str(business))


	if viable_armedrobbery_targets == []:
		pass
	else:
		# TERMINATE LESSER PRIORITY AGGS - HACK
		if 'do_hack_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY HACK
				return

		if 'do_hack_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - REQUESTED TERMINATE HACK")
			waiting_thread_list.append('9zterminate_do_hack_thread')
			print_function('9zterminate_do_hack_thread THREAD QUEUED' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_hack_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - TERMINATED HACK")
					break
			# TERMINATED HACK

		# TERMINATE LESSER PRIORITY AGGS - BNE
		if 'do_bne_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY BNE
				return

		if 'do_bne_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - REQUESTED TERMINATE BNE")
			waiting_thread_list.append('9zterminate_do_bne_thread')
			print_function('9zterminate_do_bne_thread THREAD QUEUED' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_bne_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - TERMINATED BNE")
					break
			# TERMINATED BNE

		# TERMINATE LESSER PRIORITY AGGS - MUG
		if 'do_mug_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY MUG
				return

		if 'do_mug_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - REQUESTED TERMINATE MUG")
			waiting_thread_list.append('9zterminate_do_mug_thread')
			print_function('9zterminate_do_mug_thread THREAD QUEUED' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_mug_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - TERMINATED MUG")
					break
			# TERMINATED MUG

		# TERMINATE LESSER PRIORITY AGGS - PICKPOCKET
		if 'do_pickpocket_thread' in str(running_thread[0]):
			if '1' in str(running_thread[0]):
				# SKIP INTERRUPTING HIGH PRIORITY PICKPOCKET
				return

		if 'do_pickpocket_thread' in str(waiting_thread_list):
			# SEND TERMINATE REQUEST TO MAIN VIA WAITING THREAD LIST
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - REQUESTED TERMINATE PICKPOCKET")
			waiting_thread_list.append('9zterminate_do_pickpocket_thread')
			print_function('9zterminate_do_pickpocket_thread THREAD QUEUED' + str(waiting_thread_list), "GREEN")
			while True:
				if 'do_pickpocket_thread' in str(waiting_thread_list):
					pass
				else:
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - TERMINATED PICKPOCKET")
					break
			# TERMINATED PICKPOCKET

		print_function('viable armedrobbery targets - ' + str(viable_armedrobbery_targets), "BLUE")
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ARMEDROBBERY - VIABLE TARGETS " + str(viable_armedrobbery_targets))

		if 'AggstrLowest' in str(waiting_thread_list):
			pass
		else:
			waiting_thread_list.append('9zAggstrLowest' + str(aggstr_min_checking))
			print_function('9zAggstrLowest' + str(aggstr_min_checking) + ' THREAD QUEUED' + str(waiting_thread_list), "GREEN")

		do_armedrobbery(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_armedrobbery_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name)
	return


def do_armedrobbery(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_armedrobbery_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name):
	thread_armedrobbery = Process(target=do_armedrobbery_thread, name='ArmedRobberyThread',
									args=(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_armedrobbery_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name))

	thread_armedrobbery.start()
	waiting_thread_list.append('9zAwaitingArmedRobbery')
	print_function(str(waiting_thread_list))

	# WAIT TILL THREAD STARTED
	print_function('ArmedRobbery - WAITING FOR THREAD TO BE RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - WAITING FOR THREAD TO BE RUNNING")
	while True:
		if 'armedrobbery' in str(waiting_thread_list):
			break
	print_function('ArmedRobbery - THREAD RUNNING', "BLUE")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - THREAD RUNNING")
	return


def do_armedrobbery_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, viable_armedrobbery_targets, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name):
	try:
		import multiprocessing
		write_file("env/ArmedRobberyPID.txt", str(multiprocessing.current_process().pid))

		for thread in waiting_thread_list:
			if 'AwaitingArmedRobbery' in thread:
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ARMEDROBBERY QUEUED")
		thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_agg, viable_armedrobbery_targets)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ARMEDROBBERY STARTED")
		# random_timer = random.randrange(590, 915)
		random_timer = random.randrange(62, 187)

		for target in viable_armedrobbery_targets:
			# RETURN PRIORITY TO NORMAL
			running_thread[0] = str(priority_thread_agg) + inspect.stack()[0][3]

			if go_to_page(lock_webdriver, "ArmedRobbery", running_thread):
				pass
			else:
				unlocked_aggs_list = running_thread[3]
				try:
					unlocked_aggs_list.remove('ArmedRobbery')
				except:
					pass
				running_thread[3] = unlocked_aggs_list
				write_file("env/agg_unlocks.txt", running_thread[3])

				print_function('ArmedRobbery - NOT UNLOCKED', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** ArmedRobbery - NOT UNLOCKED ****")
				return

			if 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t **** ArmedRobbery - REQUIRES CS FIRST ****")
				return

			# ENTER DROPDOWN OPTION OF TARGET
			# element_click(lock_webdriver, 'XPATH', ".//*[@id='earns_holder']/div[@id='holder_content']/form/p[2]/select[@class='dropdown']", running_thread)
			dropdown = get_dropdown_options(lock_webdriver, "XPATH", ".//*[@id='earns_holder']/div[@id='holder_content']/form/p[2]/select[@class='dropdown']")
			if target in dropdown:
				pass
			else:
				discord_error('ARMED ROBBERY TARGET NOT IN DROPDOWN: ' + str(target))
				input('INPUT ARMED ROBBERY BROKEN')

			# GET THE TARGET FROM THE DROPDOWN LIST. ITS DONE THIS WAY TO ACCOUNT FOR WEIRD WORDING LIKE BANK TILLS
			continue_outer_loop = False
			for line in dropdown.splitlines():
				if target in line:
					if config.getboolean('ArmedRobbery', 'RequireAsterisk'):
						if '*' in line:
							pass
						else:
							print_function('ArmedRobbery Results - Target ' + str(target) + " in " + str(your_current_city) + " NO ASTERISK", "BLUE")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Target " + str(target) + " in " + str(your_current_city) + " NO ASTERISK")
							agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
							aggtarget_business_list_manager[your_current_city].set_local_aggpro_timer(target, agg_timer)
							continue_outer_loop = True
					target_dropdown = line.strip()
					break
			if continue_outer_loop:
				continue

			select_dropdown_option(lock_webdriver, "XPATH", ".//*[@id='earns_holder']/div[@id='holder_content']/form/p[2]/select[@class='dropdown']", target_dropdown)

			# INCREASE THREAD PRIORITY TILL WE HAVE RESULTS. THIS IS TO PREVENT THE THREAD BEING INTERRUPTED BEFORE REPAYMENT FOR AN EARN ETC
			running_thread[0] = str('1') + inspect.stack()[0][3]
			click_continue(lock_webdriver, running_thread)

			# AGG DONE - GET RESULTS
			agg_results = None
			if element_found(lock_webdriver, "ID", "fail"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
			elif element_found(lock_webdriver, "ID", "success"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			elif element_found(lock_webdriver, "ID", "gbh"):
				agg_results = element_get_attribute(lock_webdriver, "ID", "gbh", "innerHTML")
			else:
				print_function('NO AGG RESULTS FOUND', "BLUE")
				print_function('NO AGG RESULTS FOUND', "RED")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ARMEDROBBERY - NO AGG RESULTS FOUND")
				continue

			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ARMEDROBBERY - RESULTS: " + str(agg_results))

			# AGG DONE - EXAMINE RESULTS
			if 'need a weapon' in agg_results:
				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass

				variables_list = running_thread[4]
				variables_list.append('NoWeapon')
				running_thread[4] = variables_list

				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t *** ARMEDROBBERY TURNED OFF - NO WEAPON ***")
				return

			elif 'about to rob and were hit on the head' in agg_results:
				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return

			elif ('recently been attacked' in agg_results):
				print_function('ArmedRobbery Results - Target ' + str(target) + " in " + str(your_current_city) + " has pro", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Target " + str(target) + " in " + str(your_current_city) + " has pro")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
				aggtarget_business_list_manager[your_current_city].set_local_aggpro_timer(target, agg_timer)
				continue
			elif ('own business' in agg_results):
				print_function('ArmedRobbery Results - Target ' + str(target) + " in " + str(your_current_city) + " your own biz", "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Target " + str(target) + " in " + str(your_current_city) + " your own biz")
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(days=1)
				aggtarget_business_list_manager[your_current_city].set_local_aggpro_timer(target, agg_timer)
				continue

			elif ('failed' in agg_results) or ('ran off' in agg_results):
				print_function('ArmedRobbery Results - Target ' + str(target) + ' in ' + str(your_current_city) + ' FAILED', "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Target " + str(target) + " in " + str(your_current_city) + " FAILED")
				last_agg_time[0] = datetime.datetime.utcnow()
				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
				agg_timer = agg_timer + datetime.timedelta(minutes=40)
				aggtarget_business_list_manager[your_current_city].set_shared_aggpro_timer(target, agg_timer)

				# UPDATE LOCAL MODIFIERS
				desired_mins = int(aggstr_mins_max) + 2
				if desired_mins > 30:
					desired_mins = 30

				mins_adjusted = int(desired_mins) - int(aggstr_min_checking)

				write_file('./agg_targets/armedrobbery/' + your_current_city + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/ArmedRobbery.txt', "\nArmedRobbery FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))
				append_file('./records/AllAggs.txt', "\nArmedRobbery FAILED - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))

				# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
				for thread in waiting_thread_list:
					if ('AggstrLowest' in thread):
						try:
							waiting_thread_list.remove(thread)
						except:
							pass
				thread_remove_from_queue(running_thread, waiting_thread_list)
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery THREAD FINISHED")
				return


			elif ('hold up the' in agg_results):
				print_function('ArmedRobbery Results - Target ' + str(target) + ' SUCCESS - AGG: ' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Target " + str(target) + " in " + str(your_current_city) + " SUCCESS")
				last_agg_time[0] = datetime.datetime.utcnow()

				agg_timer = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
				agg_timer = agg_timer + datetime.timedelta(minutes=40)
				aggtarget_business_list_manager[your_current_city].set_shared_aggpro_timer(target, agg_timer)

				# UPDATE LOCAL MODIFIERS
				try:
					mins_adjusted = int(read_file('./agg_targets/armedrobbery/' + your_current_city + '.txt'))
				except:
					mins_adjusted = 0

				mins_adjusted -= 1

				write_file('./agg_targets/armedrobbery/' + your_current_city + '.txt', str(mins_adjusted))

				# ADD TO RECORDS
				append_file('./records/ArmedRobbery.txt', "\nArmedRobbery SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))
				append_file('./records/AllAggs.txt', "\nArmedRobbery SUCCESS - ON " + str(datetime.datetime.utcnow()) + " TARGET: " + str(target) + " IN: " + str(your_current_city))

				# UPDATE SHARED ALL AGGS RECORDS
				target_s3_string = target.replace(" ", "")
				append_s3('roastbusters', 'FullAggsList/' + str(datetime.datetime.utcnow().year) + '-' + str(datetime.datetime.utcnow().month) + '-' + str(datetime.datetime.utcnow().day) + '.txt', "\r\n" + str(your_character_name) + " AR " + str(target_s3_string) + " (Success) in " + str(globals()[your_current_city].which_city) + " on " + str(datetime.datetime.utcnow()))

				# REPAY CHECKS
				if ('found no money' in agg_results) or ('nothing in them' in agg_results):
					# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
					for thread in waiting_thread_list:
						if ('AggstrLowest' in thread):
							try:
								waiting_thread_list.remove(thread)
							except:
								pass
					thread_remove_from_queue(running_thread, waiting_thread_list)
					print_function('ARMED ROBBERY - NO MONEY TAKEN')
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery NO MONEY TAKEN")
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery THREAD FINISHED")
					return
				else:
					repay = True
					if not config.getboolean('ArmedRobbery', 'Repay'):
						print_function('ArmedRobbery - Repay - TURNED OFF', "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Repay - TURNED OFF")
						repay = False

					repay_blacklist = config['ArmedRobbery']['Repay_Blacklist_' + your_current_city].split()
					for blacklist_name in repay_blacklist:
						if blacklist_name in target:
							print_function('ArmedRobbery - Repay - TARGET IS BLACKLISTED: ' + str(target), "BLUE")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Repay - TARGET IS BLACKLISTED: " + str(target))
							repay = False

						if 'PRIVATE' in repay_blacklist:
							if target in globals()['private_businesses_' + your_current_city]:
								repay = False

						if 'PUBLIC' in repay_blacklist:
							if target in globals()['public_businesses']:
								repay = False

					repay_whitelist = config['ArmedRobbery']['Repay_Whitelist_' + your_current_city].split()
					for whitelist_name in repay_whitelist:
						if whitelist_name in target:
							print_function('ArmedRobbery - Repay - TARGET IS WHITELISTED: ' + str(target), "BLUE")
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Repay - TARGET IS WHITELISTED: " + str(target))
							repay = True

						if 'PRIVATE' in repay_whitelist:
							if target in globals()['private_businesses_' + your_current_city]:
								repay = True

						if 'PUBLIC' in repay_whitelist:
							if target in globals()['public_businesses']:
								repay = True

					if repay:
						repay_amount = regex_match_between('\$', '!', agg_results)
						repay_amount = re.sub('[^0-9]', "", repay_amount)
						print_function('ARMED ROBBERY - REPAY AMOUNT ' + str(repay_amount))

						if target in globals()['public_businesses']:
							repay_type = 'PUBLIC'
						elif target in globals()['private_businesses_' + your_current_city]:
							repay_type = 'PRIVATE'
						else:
							print_function('ARMED ROBBERY - BUSINESS TYPE NOT FOUND FOR ' + str(target))
							write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery BUSINESS TYPE NOT FOUND FOR " + str(target))

						target_string = 'REPAYBIZ--' + str(repay_type) + '--' + str(target) + '//' + str(your_current_city)
						print_function('ARMED ROBBERY - REPAY TARGET STRING: ' + str(target_string))

						print_function('ArmedRobbery - Repaying ' + str(repay_amount) + ' TO ' + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' + str(repay_type), "BLUE")
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - Repaying " + str(repay_amount) + " TO " + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' +  str(repay_type))
						# ADD REPAY TO RECORDS
						append_file('./records/ArmedRobbery.txt', "\n ArmedRobbery - Repaying " + str(repay_amount) + " TO " + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' +  str(repay_type))
						append_file('./records/AllAggs.txt', "\n ArmedRobbery - Repaying " + str(repay_amount) + " TO " + str(target) + ' IN ' + str(your_current_city) + ' WHICH IS ' +  str(repay_type))

						if int(repay_amount) > 0:
							transfer_money(lock_webdriver, running_thread, waiting_thread_list, repay_amount, target_string)

							# WAIT FOR TRANSFER TO BE QUEUED
							print_function('ArmedRobbery - Waiting for repay to be queued', "BLUE")
							while True:
								if 'transfer_money_thread' in str(waiting_thread_list):
									break
							print_function('ArmedRobbery repay is queued', "BLUE")

					# REMOVING WITH HIGH PRIORITY RATHER THAN THE DEFAULT FOR AGGS. THIS IS TO PREVENT UNNECESSARY THREAD INTERRUPTS IF WE LOWER THE PRIORITY FIRST
					for thread in waiting_thread_list:
						if ('AggstrLowest' in thread):
							try:
								waiting_thread_list.remove(thread)
							except:
								pass
					thread_remove_from_queue(running_thread, waiting_thread_list)
					write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery THREAD FINISHED")
					return

			else:
				print_function('ArmedRobbery - results not found' + str(agg_results), "BLUE")
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery - results not found" + str(agg_results))
				continue

		# THIS DOES NOT LOWER THE AGGSTR MINS. IT WILL BE REMOVED WHEN WE GET A TORCH OR ARMEDROBBERY
		thread_remove_from_queue(running_thread, waiting_thread_list)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + "\t\t ArmedRobbery THREAD FINISHED")
		return
	except:
		from code_modules.function import PrintException
		PrintException()