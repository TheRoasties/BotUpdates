from globalvars import *
from code_modules.function import *

def mechanic(lock_webdriver, running_thread, waiting_thread_list, your_character_name, current_city, aggtarget_person_list_manager):
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_career)
	go_to_page(lock_webdriver, 'Mechanic', running_thread)

	random_timer = random.randrange(37, 126)
	globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
		seconds=random_timer)

	# INCREASE PRIORITY - THIS IS TO PREVENT EARNS ETC MESSING WITH THE TIMER. SINCE REPAIRS ARE WORTH MORE
	running_thread[0] = str('1') + inspect.stack()[0][3]

	all_table_details = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']", "innerHTML")

	tables = all_table_details.split("<div class=")
	building_requests = tables[1]
	business_repair = tables[2]
	vehicle_repair = tables[3]
	vault_construction = tables[4]

	# CHECK VAULT
	if 'You must wait' in str(vault_construction):
		print_function('MECHANIC PAGE TOO SOON')
	else:
		id_to_repair = None
		what_to_repair = None
		which_submit_button = None
		submit_buttons_found = 0

		# REPAIR PRIORITY ORDER:
		# Brahma , vault , front, palace , pent , torches , gkt , solaris , studio , flat, other vehicles

		priority_list = ['VAULT', 'CREW_FRONT', 'Brahma', 'Palace', 'Penthouse', 'BUSINESS_REPAIR', 'Studio', 'Flat', 'Galaxy', 'Solaris', 'Nekkar', 'Scorpii', 'Electra', 'Sirius']
		# EVERY TIME WE FIND SOMETHING TO DO, RUN THROUGH THE PRIORITY LIST. BREAK WHEN IT FINDS THE CURRENT THING ASSIGNED. REPLACE IF IT FINDS ITS OWN NAME AS HIGHER PRIORITY


		# BUILDING
		if 'id="fail"' in building_requests:
			print_function('MECHANIC - NO BUILDING')
		else:
			print_function('MECHANIC - BUILDING')
			submit_buttons_found += 1
			building_requests_details = building_requests.split("<tr>")
			for this_repair in building_requests_details:
				print_function('THIS BUILDING REQUEST' + str(this_repair))

				if 'label for' in this_repair:
					this_repair_details = this_repair.split("<td class")
					repair_id = regex_match_between('id="', '"', this_repair_details[1]).strip()
					repair_vehicle = regex_match_between('label for="', None, this_repair_details[2]).strip()
					repair_vehicle = regex_match_between('>', '</label>', repair_vehicle)
					repair_vehicle = re.sub('[^a-zA-Z]', "", repair_vehicle)
					repair_name = regex_match_between('label for="', None, this_repair_details[3]).strip()
					repair_name = regex_match_between('>', '</label>', repair_name)

					print_function('BUILDING REQUEST')
					print_function('repair id: ' + str(repair_id))
					print_function('repair name: ' + str(repair_name))
					print_function('repair vehicle: ' + str(repair_vehicle))

					if str(your_character_name) == str(repair_name):
						print_function('MECHANIC - SKIP YOUR OWN BUILD')
						continue

					if ('Palace' in repair_vehicle) or ('Penthouse' in repair_vehicle) or ('Studio' in repair_vehicle) or ('Flat' in repair_vehicle):
						pass
					else:
						print_function('MECHANIC - BUILD TYPE ' + str(repair_vehicle) + ' IS UNKNOWN. ASSUME A CREW FRONT')
						repair_vehicle = "CREW_FRONT"

					if what_to_repair is None:
						print_function('FIRST REPAIR OPTION FOUND: ' + str(repair_vehicle))
						id_to_repair = repair_id
						what_to_repair = repair_vehicle
						which_submit_button = submit_buttons_found
					else:
						for priority_item in priority_list:
							if priority_item in what_to_repair:
								break
							elif priority_item in repair_vehicle:
								# BETTER OPTION FOUND
								print_function('MECHANIC - BETTER OPTION FOUND: ' + str(repair_vehicle) + ' VS ' + str(what_to_repair))
								id_to_repair = repair_id
								what_to_repair = repair_vehicle
								which_submit_button = submit_buttons_found
				else:
					continue

		# BUSINESS REPAIR
		if 'id="fail"' in business_repair:
			print_function('MECHANIC - NO BUSINESS REPAIR')
		else:
			print_function('MECHANIC - BUSINESS REPAIR')
			submit_buttons_found += 1
			business_repair_details = business_repair.split("<tr>")
			for this_repair in business_repair_details:
				print_function('MECHANIC - THIS BUSINESS REPAIR' + str(this_repair))

				if 'label for' in this_repair:
					this_repair_details = this_repair.split("<td class")
					repair_id = regex_match_between('id="', '"', this_repair_details[1]).strip()
					repair_vehicle = regex_match_between('\d+">', '<', this_repair_details[2]).strip()
					repair_name = regex_match_between('\d+">', '<', this_repair_details[3]).strip()

					print_function('BUSINESS REPAIR')
					print_function('repair id: ' + str(repair_id))
					print_function('repair name: ' + str(repair_name))
					print_function('repair vehicle: ' + str(repair_vehicle))

					# CHECK WEAPON SHOP / BIONICS IF WE REPAIRED THAT
					set_weapon_restock_check = False
					set_bionic_restock_check = False

					if 'Weapon' in repair_vehicle:
						set_weapon_restock_check = True
					elif 'Bionic' in repair_vehicle:
						set_bionic_restock_check = True

					repair_vehicle = "BUSINESS_REPAIR"

					if what_to_repair is None:
						print_function('FIRST REPAIR OPTION FOUND: ' + str(repair_vehicle))
						id_to_repair = repair_id
						what_to_repair = repair_vehicle
						which_submit_button = submit_buttons_found
					else:
						for priority_item in priority_list:
							if priority_item in what_to_repair:
								break
							elif priority_item in repair_vehicle:
								# BETTER OPTION FOUND
								print_function('MECHANIC - BETTER OPTION FOUND: ' + str(repair_vehicle) + ' VS ' + str(what_to_repair))
								id_to_repair = repair_id
								what_to_repair = repair_vehicle
								which_submit_button = submit_buttons_found
				else:
					continue

		# VEHICLE
		if 'id="fail"' in vehicle_repair:
			print_function('MECHANIC - NO VEHICLE REPAIR')
		else:
			print_function('MECHANIC - VEHICLE REPAIR')
			submit_buttons_found += 1
			print_function('VEHICLE REPAIR: ' + str(vehicle_repair))
			vehicle_repair_details = vehicle_repair.split("<tr>")
			for this_repair in vehicle_repair_details:
				print_function('MECHANIC - VEHICLE - THIS REPAIR')
				if 'label for' in this_repair:
					this_repair_details = this_repair.split("<td class")
					repair_id = regex_match_between('id="', '"', this_repair_details[1]).strip()
					repair_vehicle = regex_match_between('\d+">', '<', this_repair_details[2]).strip()
					repair_vehicle = re.sub('[^a-zA-Z]', "", repair_vehicle)
					repair_name = regex_match_between('\d+">', '<', this_repair_details[3]).strip()

					if str(your_character_name) == str(repair_name):
						print_function('MECHANIC - SKIP YOUR OWN REPAIR')
						continue

					print_function('VEHICLE REPAIR')
					print_function('repair id: ' + str(repair_id))
					print_function('repair name: ' + str(repair_name))
					print_function('repair vehicle: ' + str(repair_vehicle))

					if what_to_repair is None:
						print_function('FIRST REPAIR OPTION FOUND: ' + str(repair_vehicle))
						id_to_repair = repair_id
						what_to_repair = repair_vehicle
						which_submit_button = submit_buttons_found
					else:
						for priority_item in priority_list:
							if priority_item in what_to_repair:
								break
							elif priority_item in repair_vehicle:
								# BETTER OPTION FOUND
								print_function('MECHANIC - BETTER OPTION FOUND: ' + str(repair_vehicle) + ' VS ' + str(what_to_repair))
								id_to_repair = repair_id
								what_to_repair = repair_vehicle
								which_submit_button = submit_buttons_found
				else:
					continue

		# VAULT
		if 'id="fail"' in vault_construction:
			print_function('MECHANIC - NO VAULTS REQUIRED')
		else:
			print_function('MECHANIC - VAULT')
			submit_buttons_found += 1
			vault_construction_details = vault_construction.split("<tr>")
			for this_repair in vault_construction_details:
				print_function('MECHANIC - THIS VAULT REQUEST' + str(this_repair))

				if 'label for' in this_repair:
					this_repair_details = this_repair.split("<td class")
					repair_id = regex_match_between('id="', '"', this_repair_details[1]).strip()
					repair_vehicle = regex_match_between('\d+">', '<', this_repair_details[2]).strip()
					repair_name = regex_match_between('\d+">', '<', this_repair_details[3]).strip()

					print_function('VAULT REQUEST')
					print_function('repair id: ' + str(repair_id))
					print_function('repair name: ' + str(repair_name))
					print_function('repair vehicle: ' + str(repair_vehicle))
					repair_vehicle = "VAULT"

					if what_to_repair is None:
						print_function('FIRST REPAIR OPTION FOUND: ' + str(repair_vehicle))
						id_to_repair = repair_id
						what_to_repair = repair_vehicle
						which_submit_button = submit_buttons_found
					else:
						for priority_item in priority_list:
							if priority_item in what_to_repair:
								break
							elif priority_item in repair_vehicle:
								# BETTER OPTION FOUND
								print_function('MECHANIC - BETTER OPTION FOUND: ' + str(repair_vehicle) + ' VS ' + str(what_to_repair))
								id_to_repair = repair_id
								what_to_repair = repair_vehicle
								which_submit_button = submit_buttons_found
				else:
					continue

		if id_to_repair is None:
			pass
		else:
			element_click(lock_webdriver, 'XPATH', ".//*[@id='" + str(id_to_repair) + "']", running_thread)
			print_function('MECHANIC - CLICKED REPAIR ID ' + str(id_to_repair) + ' FOR ' + str(what_to_repair))

			# THE SUBMIT BUTTON XPATH CHANGES WITH HOW MANY OTHER SUBMIT BUTTONS EXIST
			if submit_buttons_found == 1:
				element_click(lock_webdriver, 'XPATH', ".//*[@id='holder_content']/form/p/input[@class='submit']", running_thread)
			else:
				element_click(lock_webdriver, 'XPATH', ".//*[@id='holder_content']/form[" + str(which_submit_button) + "]/p/input[@class='submit']", running_thread)

			if what_to_repair == "BUSINESS_REPAIR":
				# SET RESTOCK TIMERS IF RELEVANT
				if set_weapon_restock_check:
					globals()[current_city].__dict__['Weapon Shop'].__dict__['restock_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=10)
					print_function('MECHANIC - REPAIRED WEAPON SHOP IN ' + str(current_city) + ' SETTING THE TIMER TO CHECK THAT NOW')
				elif set_bionic_restock_check:
					globals()[current_city].__dict__['Bionics'].__dict__['restock_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=10)
					print_function('MECHANIC - REPAIRED BIONICS IN ' + str(current_city) + ' SETTING THE TIMER TO CHECK THAT NOW')


			# USE CASE TIMER IF WE GOT THE REPAIR. OTHERWISE 30SEC RANDOM SINCE THE ATTEMPT REFRESHED THE PAGE
			case_timer_seconds = get_timer(lock_webdriver, 'Case', running_thread)
			if int(case_timer_seconds) > 0:
				globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=case_timer_seconds)
				print_function('MECHANIC - REPAIRED ' + str(what_to_repair) + " FOR " + str(repair_name))

				house = get_house_from_string(what_to_repair)
				if house != "NOTFOUND":

					# CONNECT TO PERSON OBJECT FOR TIMERS
					server_port = read_file("env/ServerPort.txt")
					manager = BaseManager(address=('127.0.0.1', int(server_port)))
					BaseManager.register('person', person)

					try:
						# ALREADY EXISTS
						aggtarget_person_list_manager[repair_name].set_house(house)
					except:
						# CREATE NEW
						aggtarget_person_list_manager[repair_name] = manager.person(repair_name)
						aggtarget_person_list_manager[repair_name].set_house(house)

				which_vehicle = get_vehicle_from_string(what_to_repair)
				if which_vehicle != "NOTFOUND":

					# CONNECT TO PERSON OBJECT FOR TIMERS
					server_port = read_file("env/ServerPort.txt")
					manager = BaseManager(address=('127.0.0.1', int(server_port)))
					BaseManager.register('person', person)

					try:
						# ALREADY EXISTS
						aggtarget_person_list_manager[repair_name].set_vehicle(which_vehicle)
					except:
						# CREATE NEW
						aggtarget_person_list_manager[repair_name] = manager.person(repair_name)
						aggtarget_person_list_manager[repair_name].set_vehicle(which_vehicle)
			else:
				globals()['timers'].__dict__['case_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=random_timer)
				print_function('MECHANIC - MISSED REPAIR FOR ' + str(what_to_repair) + " FOR " + str(repair_name))

	open_city(lock_webdriver, running_thread)
	thread_remove_from_queue(running_thread, waiting_thread_list)
	return

