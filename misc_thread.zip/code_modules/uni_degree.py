from globalvars import *
from code_modules.function import *


def uni_degree(lock_webdriver, running_thread, waiting_thread_list):
	if 'AllDegrees' in str(running_thread[4]):
		pass
	else:
		if config.getboolean('Action', 'StudyDegree'):

			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)

			print_function(str(inspect_stack()) + 'uni_degree')
			# OPEN STUDY PAGE IF NOT ALREADY
			go_to_page(lock_webdriver, 'UniversityDegree', running_thread)

			if element_found(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='study_holder']/div[@id='holder_content']/p[@class='center']"):
				results = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='study_holder']/div[@id='holder_content']/p[@class='center']", "innerHTML")
				if 'no more university studies to complete' in results:
					variables_list = running_thread[4]
					variables_list.append('AllDegrees')
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES FOR UNI DEGREES: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return False

			dropdown = get_dropdown_options(lock_webdriver, "XPATH",
											".//*[@id='study_holder']/div[@id='holder_content']/form/select")

			if "study" in dropdown:
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Yes, I would like to study")
				print_function(str(inspect_stack()) + ' uni_degree - Study Chosen')

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				print_function(str(inspect_stack()) + ' uni_degree - Submit')
				open_city(lock_webdriver, running_thread)
			elif "Business" in dropdown:
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Business")
				print_function(str(inspect_stack()) + ' uni_degree - Business Chosen')

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				print_function(str(inspect_stack()) + ' uni_degree - Submit')
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Yes, I would like to study for a business degree")

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				open_city(lock_webdriver, running_thread)
			elif "Science" in dropdown:
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Science")
				print_function(str(inspect_stack()) + ' uni_degree - Science Chosen')

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				print_function(str(inspect_stack()) + ' uni_degree - Submit')
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Yes, I would like to study for a science degree")

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				open_city(lock_webdriver, running_thread)
			elif "Engineering" in dropdown:
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Engineering")
				print_function(str(inspect_stack()) + ' uni_degree - Engineering Chosen')

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				print_function(str(inspect_stack()) + ' uni_degree - Submit')
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Yes, I would like to study for a engineering degree")

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				open_city(lock_webdriver, running_thread)
			elif "Medicine" in dropdown:
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Medicine")
				print_function(str(inspect_stack()) + ' uni_degree - Medicine Chosen')

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				print_function(str(inspect_stack()) + ' uni_degree - Submit')
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Yes, I would like to study for a medicine degree")

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				open_city(lock_webdriver, running_thread)
			elif "Law" in dropdown:
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Law")

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				print_function(str(inspect_stack()) + ' uni_degree - Submit')
				select_dropdown_option(lock_webdriver, "XPATH",
									   ".//*[@id='study_holder']/div[@id='holder_content']/form/select",
									   "Yes, I would like to study for a law degree")
				print_function(str(inspect_stack()) + ' uni_degree - Law Chosen')

				# CLICK SUBMIT
				click_continue(lock_webdriver, running_thread)
				open_city(lock_webdriver, running_thread)
			else:
				print_function(str(inspect_stack()) + ' uni_degree - study not in options', "RED")

			thread_remove_from_queue(running_thread, waiting_thread_list)
			return True
	return False
