from globalvars import *
from code_modules.function import *

def launder(lock_webdriver, running_thread, waiting_thread_list, dirty_money, Boys_Launder_List):
	if globals()['timers'].__dict__['launder_timer'] is None:
		globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Launder', running_thread))
	time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['launder_timer']
	if not '-' in str(time_difference):
		if int(dirty_money) > 4:
			dirty_money = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='nav_right']/div[@id='display_end'][2]", "innerHTML")
			dirty_money = re.sub('[^0-9]', "", dirty_money)

			try:
				dirty_money = int(dirty_money) - int(config['Launder']['reserve_for_drugs'])
			except:
				dirty_money = int(dirty_money)

			bm_reserved = None
			for item in running_thread[4]:
				if ('blackmarket-reserved' in str(item)):
					bm_reserved = regex_match_between('blackmarket-reserved:', None, item)

			if bm_reserved == None:
				pass
			else:
				dirty_money = int(dirty_money) - int(bm_reserved)

			if int(dirty_money) < 5:
				dirty_money = 5

		if int(dirty_money) > 4:
			if config.getboolean('Launder', 'Do_Launder'):
				launder_timer = get_timer(lock_webdriver, "Launder", running_thread)
				if launder_timer == 0:
					thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_launder)
					print_function('LAUNDER - START')

					if int(dirty_money) > 4:
						# DO LAUNDER
						if go_to_page(lock_webdriver, "Laundering", running_thread):
							pass
						else:
							print_function('LAUNDER NOT UNLOCKED')
							globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=5)
							thread_remove_from_queue(running_thread, waiting_thread_list)
							return


						# GBH FAIL MESSAGE WHEN NO LAUNDERERS ADDED YOU
						if element_found(lock_webdriver, "ID", "gbh"):
							globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(hours=99)
							print_function('MISC - LAUNDER - NO LAUNDERERS ADDED YOU IN CITY - RECHECK AT ' + str(globals()['timers'].__dict__['launder_timer']))
							thread_remove_from_queue(running_thread, waiting_thread_list)
							return

						all_launderers_list_details = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/table", "innerHTML")
						all_launderers_list = re.findall(rf'id=\d+">(.*?)</a></td>', all_launderers_list_details)

						launderer_index_to_click = None

						Boys_List = ""
						for Boys_Name in Boys_Launder_List:
							Boys_List = str(Boys_List) + str(Boys_Name) + " "
						launder_priority_list = str(Boys_List) + config['Launder']['Preferred_Launderers']
						launder_priority_list = launder_priority_list.split()
						preferred_launderer_found = False
						for preferred_name in launder_priority_list:
							if preferred_name in all_launderers_list:
								print_function('Launder - Found preferred launderer: ' + str(preferred_name))
								preferred_launderer_found = True
								launderer_index_to_click = int(all_launderers_list.index(preferred_name)) + 1

								sqs = boto3.resource('sqs',
													 region_name='ap-southeast-2',
													 aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
													 aws_secret_access_key='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',
													 )
								try:
									queue = sqs.get_queue_by_name(QueueName=str(preferred_name))
									player_command = "ResetTimerCase"
									queue.send_message(MessageBody=str(player_command), DelaySeconds=1)
								except:
									pass
								break

						if launderer_index_to_click is None:
							launder_blacklist = config['Launder']['Blacklist_Launderers']

							for launderer_name in all_launderers_list:
								if launderer_name in launder_blacklist:
									print_function('Launder - Skipping Blacklist: ' + str(launderer_name))
									continue
								else:
									print_function('Launder - Using First Viable: ' + str(launderer_name))
									launderer_index_to_click = int(all_launderers_list.index(launderer_name)) + 1
									break

						if launderer_index_to_click is None:
							# NO LAUNDERERS
							print_function('Launder - No Valid Launderers')
							config['Launder']['Do_Launder'] = 'False'

							random_launder_timer = random.randrange(327, 669)
							globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
								seconds=random_launder_timer)
							thread_remove_from_queue(running_thread, waiting_thread_list)
							return
						else:
							# USE LAUNDERER
							element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/table/tbody/tr[@class='nohover'][" + str(launderer_index_to_click) + "]/td[@class='display_border']/a", running_thread)

							max_launder_amount = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='holder_content']/form/p/font", "innerHTML")
							max_launder_amount = re.sub('[^0-9]', "", max_launder_amount)

							print_function('MISC - LAUNDER - MAX LAUNDER: ' + str(max_launder_amount) + ' DIRTY MONEY: ' + str(dirty_money))

							if int(dirty_money) > int(max_launder_amount):
								launder_amount = max_launder_amount
							else:
								launder_amount = dirty_money

							print_function('Laundering ' + str(launder_amount))
							sendkeys(lock_webdriver, "NAME", "amount", launder_amount)
							click_continue(lock_webdriver, running_thread)

					print_function('Launder - Finished')
					thread_remove_from_queue(running_thread, waiting_thread_list)
				else:
					# WAITING ON LAUNDER TIMER. UPDATE THE VARIABLE SO THIS ISN'T CONSTANTLY RECHECKED BY MISC THREAD
					globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
						seconds=launder_timer)
		else:
			# NOT ENOUGH MONEY TO LAUNDER
			globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(
				minutes=5)
	return