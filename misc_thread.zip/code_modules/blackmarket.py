from globalvars import *
from code_modules.function import *
from code_modules.vehicle_get_status import *

def blackmarket_travel(lock_webdriver, running_thread, waiting_thread_list, bm_travel_city, current_city):
	print_function('BLACKMARKET TRAVEL - ADDED TO QUEUE')
	thread_add_to_queue(running_thread, waiting_thread_list, 2)
	print_function('BLACKMARKET TRAVEL - RUNNING')
	if element_found(lock_webdriver, "XPATH", "/html/body/div[4]/div[3]/p[8]/a[2]/img"):
		element_click(lock_webdriver, "XPATH", ".//*[@id='wrapper']/div[@id='nav_left']/p[8]/a[2]", running_thread)
		travel_dropdown = get_dropdown_options(lock_webdriver, "XPATH", ".//*[@id='docTipsLayer']/div[@class='tipClass']/form/select")
		cannot_travel = True
		for line in travel_dropdown.splitlines():
			line_formatted = line.replace(' ', '')
			print_function('line: ' + str(line))
			if str(bm_travel_city) in str(line_formatted):
				select_dropdown_option(lock_webdriver, "NAME", "vehicletravel", line)
				cannot_travel = False

				if element_found(lock_webdriver, "ID", "fail"):
					results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
				elif element_found(lock_webdriver, "ID", "success"):
					results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")

				print_function('TRAVEL RESULTS: ' + str(results))

				if 'travelled' in results:
					# UPDATE STATUS
					variables_list = running_thread[4]
					bm_status = None
					for item in running_thread[4]:
						if 'blackmarket-status' in str(item):
							bm_status = regex_match_between('blackmarket-status:', None, item)
							try:
								variables_list.remove(item)
							except:
								pass

					if 'bought' in str(bm_status):
						variables_list.append('blackmarket-status:selling')
					elif 'sold' in str(bm_status):
						variables_list.append('blackmarket-status:buying')
					else:
						variables_list.append('blackmarket-status:UNKNOWN')

					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])

					globals()['timers'].__dict__['travel_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Travel', running_thread))
					globals()['timers'].__dict__['launder_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Launder', running_thread))
					globals()['timers'].__dict__['drugwork_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=10)
					globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=10)
					globals()['timers'].__dict__['event_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Event', running_thread))

					# UPDATE CLICK RECORDS SO IT RECHECKS EVERYTHING AFTER TRAVEL
					running_thread[1] = datetime.datetime.utcnow()

					# UPDATE LAST TRAVEL TIMER SO THINGS UPDATE
					running_thread[5] = datetime.datetime.utcnow()


					# TRAVELLED - DELETE VEHICLE STATUS VARIABLE
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if ('Vehicle:' in item):
							try:
								variables_list.remove(item)
								print_function("travelled - deleted saved vehicle variable")
							except:
								pass
						elif 'blackmarket-currentcitysaved:' in str(item):
							try:
								variables_list.remove(item)
							except:
								pass
					variables_list.append('blackmarket-currentcitysaved:' + str(current_city))
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES AS BLACKMARKET NOT UNLOCKED: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])

					# HAVE TRAVELLED - TERMINATE ANY THREADS THAT MAY REFERENCE OLD CITY
					waiting_thread_list.append('9zterminate-everything')
					print_function('9zterminate-everything THREAD QUEUED AS TRAVELLED - QUEUED VIA AGG TARGET THREAD ' + str(waiting_thread_list), "GREEN")

					# WAIT FOR TERMINATE TO FINISH
					while True:
						if ('terminate-everything' in str(waiting_thread_list)):
							pass
						else:
							break

					# PAUSE MISC THREAD UNTIL RESTARTED. THIS IS TO PREVENT JOBS ETC IN THE WRONG CITY
					print_function("BLACKMARKET TRAVEL - END - HAVE TRAVELLED", "BLUE")
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return True

				elif 'undergoing repairs' in results:
					# CAR AWAITING REPAIR
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if 'Vehicle:' in item:
							try:
								variables_list.remove(item)
							except:
								pass
					variables_list.append('Vehicle:WaitingRepair')
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES AS TRAVEL FAILED - REPAIR PENDING: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])
					thread_remove_from_queue(running_thread, waiting_thread_list)
					print_function("BLACKMARKET TRAVEL - END - UNDERGOING REPAIRS", "BLUE")
					return False
				elif ('broke down' in results) or ('broken down' in results):
					variables_list = running_thread[4]
					for item in running_thread[4]:
						if ('Vehicle:' in item):
							try:
								variables_list.remove(item)
							except:
								pass
					running_thread[4] = variables_list
					print_function('UPDATED VARIABLES AS BROKEN DOWN: ' + str(running_thread[4]))
					write_file("env/variables.txt", running_thread[4])
					print_function("BLACKMARKET TRAVEL - END - BROKEN DOWN", "BLUE")
					return False
				elif 'found guilty of' in results:
					pass
				elif 'enough money on you' in results:
					if (withdraw_money(lock_webdriver, running_thread, '5000')):
						pass
					else:
						discord_error("TRAVEL - CANNOT WITHDRAW TO TRAVEL")
						while True:
							time.sleep(30)
				else:
					# You have been charged with and found guilty of committing the crime of Breaking &amp; Entering on 10/21/2020 6:13:06 AM, against Elegance.  The Police Officer investigating the case was Ghettorig. You were sentenced by Dark to pay a instant $500 fine!
					# NO CASE NUMBER - convictions track all details? otherwise this may be a problem
					discord_error("NEW TRAVEL RESULTS: " + str(results))
					while True:
						time.sleep(30)
				break
	else:
		print_function('TRAVEL - NO CAR?')
		cannot_travel = True
		globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
		thread_remove_from_queue(running_thread, waiting_thread_list)
		print_function("BLACKMARKET TRAVEL - END - NO CAR", "BLUE")
		return False

	if (cannot_travel):
		# CANNOT TRAVEL - LIKELY MANUALLY TRAVELLED TO TRAVEL CITY
		# CLEAR SAVED CITY SO IT CHECKS BM STATUS ETC
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'blackmarket-currentcitysaved:' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
			elif 'blackmarket-status' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES AS CANNOT TRAVEL: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

		# REFRESH TO CLEAR THE TRAVEL DROPDOWN
		click_refresh(lock_webdriver, running_thread)

	thread_remove_from_queue(running_thread, waiting_thread_list)
	print_function("BLACKMARKET TRAVEL - END - CANNOT TRAVEL", "BLUE")
	return False


def blackmarket_get_status(lock_webdriver, running_thread, waiting_thread_list, current_city, home_city, dirty_money, bm_buy_city, bm_sell_city):
	print_function('BLACKMARKET GET STATUS - ADDED TO QUEUE')
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_blackmarket)
	print_function('BLACKMARKET GET STATUS - RUNNING')

	# CHECK BLACKMARKET GOODS
	if go_to_page(lock_webdriver, "Blackmarket", running_thread):
		pass
	else:
		print_function('BLACKMARKET - NOT UNLOCKED', "RED")
		click_refresh(lock_webdriver, running_thread)

		# UPDATE STATUS
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'blackmarket' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES AS BLACKMARKET NOT UNLOCKED: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

		unlocked_aggs_list = running_thread[3]
		if 'BlackMarket' in unlocked_aggs_list:
			try:
				unlocked_aggs_list.remove('BlackMarket')
			except:
				pass
		running_thread[3] = unlocked_aggs_list
		write_file("env/agg_unlocks.txt", running_thread[3])
		print_function('UPDATED VARIABLES FOR BLACKMARKET NOT UNLOCKED: ' + str(running_thread[3]))

		globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return

	# CHECK IF WE OWN ANY BLACKMARKET ITEMS
	we_own_blackmarket_items = False
	blackmarket_table = element_get_attribute(lock_webdriver, "XPATH",
											  ".//*[@id='shop_holder']/div[@id='holder_content']/form/table",
											  "innerHTML")
	blackmarket_table_row = blackmarket_table.split("<tr>")
	for row in blackmarket_table_row:
		# SKIP NON ENTRIES
		if '/images/black_market' in row:
			table_data = row.split("<td ")
			blackmarket_quantity_owned = regex_match_between('>', '</td', table_data[4])
			if int(blackmarket_quantity_owned) > 0:
				we_own_blackmarket_items = True

	# FIGURE OUT BLACKMARKET ITEMS STATUS
	if we_own_blackmarket_items:
		if str(current_city) == str(bm_buy_city):
			# STATUS BOUGHT / SET CURRENTCITY AS KNOWN
			variables_list = running_thread[4]
			for item in running_thread[4]:
				if 'blackmarket-status' in str(item):
					try:
						variables_list.remove(item)
					except:
						pass
			variables_list.append('blackmarket-status:bought')

			# UPDATE CURRENTCITY SAVED
			for item in running_thread[4]:
				if 'blackmarket-currentcitysaved:' in str(item):
					try:
						variables_list.remove(item)
					except:
						pass
			variables_list.append('blackmarket-currentcitysaved:' + str(current_city))
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES FOR BLACKMARKET: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])
		elif str(current_city) == str(bm_sell_city):
			# STATUS SELLING
			variables_list = running_thread[4]
			for item in running_thread[4]:
				if 'blackmarket-status' in str(item):
					try:
						variables_list.remove(item)
					except:
						pass
			variables_list.append('blackmarket-status:selling')
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])
		else:
			# NOT IN BUY OR SELL CITY - SELL GOODS AND IT WILL RECALCULATE
			variables_list = running_thread[4]
			for item in running_thread[4]:
				if 'blackmarket-status' in str(item):
					try:
						variables_list.remove(item)
					except:
						pass
			variables_list.append('blackmarket-status:selling')
			running_thread[4] = variables_list
			print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
			write_file("env/variables.txt", running_thread[4])
	else:
		# NO BLACKMARKET OWNED - STATUS SOLD
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'blackmarket-status' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
		variables_list.append('blackmarket-status:sold')
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

	thread_remove_from_queue(running_thread, waiting_thread_list)
	return

def blackmarket_buy(lock_webdriver, running_thread, waiting_thread_list, current_city, home_city, dirty_money, bm_item, bm_sell_city):
	print_function('BLACKMARKET BUY - ADDED TO QUEUE')
	thread_add_to_queue(running_thread, waiting_thread_list, 3)
	print_function('BLACKMARKET BUY - RUNNING')

	carry_capacity = config['Drugs']['CarryCapacity']
	if 'BrokenDownAwaitingRepair' in str(running_thread[4]):
		# NO CAR FOR EXTRA CAPACITY
		carry_capacity = 5

	if go_to_page(lock_webdriver, "Blackmarket", running_thread):
		pass
	else:
		print_function('BLACKMARKET - NOT UNLOCKED', "RED")
		click_refresh(lock_webdriver, running_thread)

		# UPDATE STATUS
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'blackmarket' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES AS BLACKMARKET NOT UNLOCKED: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

		unlocked_aggs_list = running_thread[3]
		if 'BlackMarket' in unlocked_aggs_list:
			try:
				unlocked_aggs_list.remove('BlackMarket')
			except:
				pass
		running_thread[3] = unlocked_aggs_list
		write_file("env/agg_unlocks.txt", running_thread[3])
		print_function('UPDATED VARIABLES FOR BLACKMARKET NOT UNLOCKED: ' + str(running_thread[3]))

		globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return

	list_of_blackmarket_items = []
	list_of_blackmarket_prices = []
	dict_of_blackmarket_values = {}
	blackmarket_database_string = ''

	blackmarket_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='shop_holder']/div[@id='holder_content']/form/table", "innerHTML")
	blackmarket_table_row = blackmarket_table.split("<tr>")
	item_click_index = 1
	for row in blackmarket_table_row:
		# SKIP NON ENTRIES
		if '/images/black_market' in row:
			table_data = row.split("<td ")
			blackmarket_item = regex_match_between('>', '</td', table_data[2])
			blackmarket_price = regex_match_between('>', '</td', table_data[3])
			blackmarket_price = re.sub('[^0-9]', "", blackmarket_price)
			blackmarket_quantity_owned = regex_match_between('>', '</td', table_data[4])
			print_function('item1: ' + str(blackmarket_item) + ' price: ' + str(blackmarket_price) + ' quantity: ' + str(blackmarket_quantity_owned))

			blackmarket_item_formatted = blackmarket_item.replace(" ", "")
			if blackmarket_database_string == '':
				blackmarket_database_string = '{"' + blackmarket_item_formatted + '": ' + str(blackmarket_price)
			else:
				blackmarket_database_string = blackmarket_database_string + ', "' + blackmarket_item_formatted + '": ' + str(blackmarket_price)

			carry_capacity = int(carry_capacity) - int(blackmarket_quantity_owned)
			list_of_blackmarket_items.append(blackmarket_item)
			list_of_blackmarket_prices.append(blackmarket_price)
			item_click_index += 1
			dict_of_blackmarket_values[blackmarket_item] = [blackmarket_price, blackmarket_quantity_owned, 0, item_click_index]
		else:
			continue

	# BUY BLACKMARKET GOODS
	# GET BUY QUANTITIES
	for item in list_of_blackmarket_items:
		if int(bm_item) == (int(dict_of_blackmarket_values[item][3]) - 2):
			print_function('item2: ' + str(item) + ' dirty: ' + str(dirty_money) + ' price: ' + str(dict_of_blackmarket_values[item][0]) + ' qtyown: ' + str(dict_of_blackmarket_values[item][1]) + ' qtybuy: ' + str(dict_of_blackmarket_values[item][2]))
			quantity_to_buy = min(math.floor(int(dirty_money) / int(dict_of_blackmarket_values[item][0])), int(carry_capacity))
			bm_reserved = (int(carry_capacity) - int(quantity_to_buy)) * int(dict_of_blackmarket_values[item][0])
			dict_of_blackmarket_values[item][2] = quantity_to_buy
			print_function('BLACKMARKET - BUYING: ' + str(dict_of_blackmarket_values[item][1]) + " " + str(dict_of_blackmarket_values[item][2]))

	# BUY GOODS
	for item in list_of_blackmarket_items:
		if int(dict_of_blackmarket_values[item][2]) > 0:
			clearkeys(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(dict_of_blackmarket_values[item][3]) + "]/td[@class='display_border'][4]/input[@class='input']")
			sendkeys(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(dict_of_blackmarket_values[item][3]) + "]/td[@class='display_border'][4]/input[@class='input']", str(dict_of_blackmarket_values[item][2]))
	# CLICK BUY
	element_click(lock_webdriver, "XPATH",".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p/input[@class='input'][1]",running_thread)

	# GET RESULTS
	if element_found(lock_webdriver, "ID", "fail"):
		results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
		if 'more than' in results:
			# PROBABLY BROKEN DOWN
			vehicle_get_status(lock_webdriver, running_thread, waiting_thread_list)
			if 'Vehicle:WaitingRepair' in str(running_thread[4]):
				# WAITING FOR REPAIR BUT CANNOT CARRY BM GOODS. MUST BE BROKEN DOWN
				variables_list = running_thread[4]
				for item in running_thread[4]:
					if 'Vehicle:WaitingRepair' in item:
						try:
							variables_list.remove(item)
						except:
							pass
				variables_list.append('Vehicle:BrokenDownAwaitingRepair')
				running_thread[4] = variables_list
				print_function('UPDATED VARIABLES FOR VEHICLE: ' + str(running_thread[4]))
				write_file("env/variables.txt", running_thread[4])
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return
		else:
			discord_message(config['Auth']['discord_id'] + " NEW BM BUY FAIL REASON: " + str(results))
			thread_remove_from_queue(running_thread, waiting_thread_list)
			return

	# write_file(config['Auth']['database_path'] + "/Records/BlackMarket/" + str(current_city) + ".txt", list_of_blackmarket_prices)
	blackmarket_database_string = blackmarket_database_string + '}'
	update_database('BlackMarket', 'City', str(current_city), eval(blackmarket_database_string))

	globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Trafficking', running_thread))

	# UPDATE STATUS & RESERVED AMOUNT
	variables_list = running_thread[4]
	for item in running_thread[4]:
		if ('blackmarket-status' in str(item)) or ('blackmarket-travel' in str(item)) or ('blackmarket-reserved' in str(item)):
			try:
				variables_list.remove(item)
			except:
				pass

	variables_list.append('blackmarket-status:bought')
	variables_list.append('blackmarket-travel:' + str(bm_sell_city))
	variables_list.append('blackmarket-reserved:' + str(bm_reserved))
	running_thread[4] = variables_list
	print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
	write_file("env/variables.txt", running_thread[4])

	thread_remove_from_queue(running_thread, waiting_thread_list)
	return

def blackmarket_sell(lock_webdriver, running_thread, waiting_thread_list, current_city, home_city, dirty_money):
	print_function('BLACKMARKET SELL - ADDED TO QUEUE')
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_blackmarket)
	print_function('BLACKMARKET SELL - RUNNING')

	if go_to_page(lock_webdriver, "Blackmarket", running_thread):
		pass
	else:
		print_function('BLACKMARKET - NOT UNLOCKED', "RED")
		click_refresh(lock_webdriver, running_thread)

		# UPDATE STATUS
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'blackmarket' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES AS BLACKMARKET NOT UNLOCKED: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

		unlocked_aggs_list = running_thread[3]
		if 'BlackMarket' in unlocked_aggs_list:
			try:
				unlocked_aggs_list.remove('BlackMarket')
			except:
				pass
		running_thread[3] = unlocked_aggs_list
		write_file("env/agg_unlocks.txt", running_thread[3])
		print_function('UPDATED VARIABLES FOR BLACKMARKET NOT UNLOCKED: ' + str(running_thread[3]))

		globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return

	list_of_blackmarket_items = []
	list_of_blackmarket_prices = []
	dict_of_blackmarket_values = {}
	blackmarket_database_string = ''

	blackmarket_table = element_get_attribute(lock_webdriver, "XPATH", ".//*[@id='shop_holder']/div[@id='holder_content']/form/table", "innerHTML")
	blackmarket_table_row = blackmarket_table.split("<tr>")
	item_click_index = 1
	for row in blackmarket_table_row:
		# SKIP NON ENTRIES
		if '/images/black_market' in row:
			table_data = row.split("<td ")
			blackmarket_item = regex_match_between('>', '</td', table_data[2])
			blackmarket_price = regex_match_between('>', '</td', table_data[3])
			blackmarket_price = re.sub('[^0-9]', "", blackmarket_price)
			blackmarket_quantity_owned = regex_match_between('>', '</td', table_data[4])
			print_function('item: ' + str(blackmarket_item) + ' price: ' + str(blackmarket_price) + ' quantity: ' + str(blackmarket_quantity_owned))

			blackmarket_item_formatted = blackmarket_item.replace(" ", "")
			if blackmarket_database_string == '':
				blackmarket_database_string = '{"' + blackmarket_item_formatted + '": ' + str(blackmarket_price)
			else:
				blackmarket_database_string = blackmarket_database_string + ', "' + blackmarket_item_formatted + '": ' + str(blackmarket_price)

			list_of_blackmarket_items.append(blackmarket_item)
			list_of_blackmarket_prices.append(blackmarket_price)
			item_click_index += 1
			dict_of_blackmarket_values[blackmarket_item] = [blackmarket_price, blackmarket_quantity_owned, 1, item_click_index]
		else:
			print_function('count items continue')
			continue

	# SELL GOODS
	print_function('sell goods start')
	for item in list_of_blackmarket_items:
		if int(dict_of_blackmarket_values[item][1]) > 0:
			clearkeys(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(dict_of_blackmarket_values[item][3]) + "]/td[@class='display_border'][4]/input[@class='input']")
			sendkeys(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/table/tbody/tr[" + str(dict_of_blackmarket_values[item][3]) + "]/td[@class='display_border'][4]/input[@class='input']", str(dict_of_blackmarket_values[item][1]))

	# CLICK SELL
	element_click(lock_webdriver, "XPATH", ".//*[@id='content']/div[@id='shop_holder']/div[@id='holder_content']/form/p/input[@class='input'][2]", running_thread)

	# write_file(config['Auth']['database_path'] + "/Records/BlackMarket/" + str(current_city) + ".txt", list_of_blackmarket_prices)
	blackmarket_database_string = blackmarket_database_string + '}'
	update_database('BlackMarket', 'City', str(current_city), eval(blackmarket_database_string))

	globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Trafficking', running_thread))

	# UPDATE STATUS
	variables_list = running_thread[4]
	for item in running_thread[4]:
		if 'blackmarket-status' in str(item):
			try:
				variables_list.remove(item)
			except:
				pass
	variables_list.append('blackmarket-status:sold')
	running_thread[4] = variables_list
	print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
	write_file("env/variables.txt", running_thread[4])

	thread_remove_from_queue(running_thread, waiting_thread_list)
	return

def blackmarket_calculation(lock_webdriver, running_thread, waiting_thread_list, current_city, home_city, dirty_money):
	print_function('BLACKMARKET CALC - ADDED TO QUEUE')
	thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_blackmarket)
	print_function('BLACKMARKET CALC - RUNNING')


	carry_capacity = config['Drugs']['CarryCapacity']
	if 'BrokenDownAwaitingRepair' in str(running_thread[4]):
		# NO CAR FOR EXTRA CAPACITY
		carry_capacity = 5

	travel_to_city = None
	highest_profit_item = None
	highest_profit = None
	blackmarket_sell_city = None
	blackmarket_buy_city = None
	# USED FOR HOW MUCH MONEY TO RESERVE
	absolute_highest_profit_item = 0
	blackmarket_reserve_money = 0

	# GET CURRENT CITY DETAILS FIRST
	city_short = globals()[current_city].city_short_string
	cases_in_city = os.listdir('cases/' + str(city_short))
	cases_in_city = len(cases_in_city)
	if (config.getboolean('Blackmarket-Travel', 'AvoidCitiesWithCases')) and (int(cases_in_city) > 0):
		print_function('BLACKMARKET - CANNOT TRAVEL AS CASES IN CURRENT CITY: ' + str(current_city) + " " + str(cases_in_city))
		# REMOVE SAVED VARIABLES
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if ('blackmarket-reserved' in str(item)) or ('blackmarket-status' in str(item)) or ('blackmarket-currentcitysaved' in str(item)):
				pass
			elif 'blackmarket' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
		running_thread[4] = variables_list
		write_file("env/variables.txt", running_thread[4])
		print_function('BLACKMARKET - VARIABLES UPDATED AS CANNOT TRAVEL ' + str(running_thread[4]))

		globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return
	else:
		# blackmarket_prices_currentcity = eval(read_file(config['Auth']['database_path'] + "/Records/BlackMarket/" + str(current_city) + ".txt"))
		blackmarket_prices_currentcity = []
		response = get_from_database('BlackMarket', None, "Key('City').eq('" + current_city + "')")
		blackmarket_prices_currentcity.append(str(response['Items'][0]['Alcohol']))
		blackmarket_prices_currentcity.append(str(response['Items'][0]['Televisions']))
		blackmarket_prices_currentcity.append(str(response['Items'][0]['CarParts']))
		blackmarket_prices_currentcity.append(str(response['Items'][0]['ItalianSuits']))
		blackmarket_prices_currentcity.append(str(response['Items'][0]['FurCoats']))
		blackmarket_prices_currentcity.append(str(response['Items'][0]['Porn']))

		print_function(str(current_city) + ' // ' + str(blackmarket_prices_currentcity[0]) + " " + str(blackmarket_prices_currentcity[1]) + " " +
			  str(blackmarket_prices_currentcity[2]) + " " + str(blackmarket_prices_currentcity[3]) + " " + str(blackmarket_prices_currentcity[4]) + " " +
			  str(blackmarket_prices_currentcity[5]) + ' // ' + str(blackmarket_prices_currentcity))


	homecity_short = globals()[home_city].city_short_string
	cases_in_homecity = os.listdir('cases/' + str(homecity_short))
	cases_in_homecity = len(cases_in_homecity)


	# GET DETAILS FOR GYM TRAVEL
	travel_specific_city = 'None'

	if (config.getboolean('Misc', 'TravelForCasino')):
		casino_timer = read_file("env/casino_timer.txt")
		try:
			casino_timer = datetime.datetime.strptime(casino_timer, '%Y-%m-%d %H:%M:%S')
		except:
			casino_timer = datetime.datetime.strptime(casino_timer, '%Y-%m-%d %H:%M:%S.%f')
		time_difference = datetime.datetime.utcnow() - casino_timer
		if not '-' in str(time_difference):
			# Casino READY. CHECK WHICH CITY
			for city_casino in globals()['cities_list']:
				if city_casino == current_city:
					pass
				elif 'Casino' in globals()['private_businesses_' + city_casino]:
					cases_passed = True
					if (config.getboolean('Blackmarket-Travel', 'AvoidCitiesWithCases')):
						city_short_casino = globals()[city_casino].city_short_string
						cases_in_city_casino = os.listdir('cases/' + str(city_short_casino))
						cases_in_city_casino = len(cases_in_city_casino)
						if (int(cases_in_city_casino) > 0):
							cases_passed = False
					if (cases_passed):
						travel_specific_city = city_casino

	if (config.getboolean('Misc', 'TravelForGym')):
		gym_timer = read_file("env/gym_timer.txt")
		try:
			gym_timer = datetime.datetime.strptime(gym_timer, '%Y-%m-%d %H:%M:%S')
		except:
			gym_timer = datetime.datetime.strptime(gym_timer, '%Y-%m-%d %H:%M:%S.%f')
		time_difference = datetime.datetime.utcnow() - gym_timer
		if not '-' in str(time_difference):
			# GYM READY. CHECK WHICH CITY
			for city_gym in globals()['cities_list']:
				if city_gym == current_city:
					pass
				elif 'Gym' in globals()['private_businesses_' + city_gym]:
					cases_passed = True
					if (config.getboolean('Blackmarket-Travel', 'AvoidCitiesWithCases')):
						city_short_gym = globals()[city_gym].city_short_string
						cases_in_city_gym = os.listdir('cases/' + str(city_short_gym))
						cases_in_city_gym = len(cases_in_city_gym)
						if (int(cases_in_city_gym) > 0):
							cases_passed = False
					if (cases_passed):
						travel_specific_city = city_gym


	# GET TRAVEL TO CITY DETAILS
	for city in globals()['cities_list']:
		if city == current_city:
			print_function('BLACKMARKET - SKIPPING CURRENT CITY ' + str(city))
			continue

		city_short = globals()[city].city_short_string
		cases_in_city = os.listdir('cases/' + str(city_short))
		cases_in_city = len(cases_in_city)

		# blackmarket_prices_temp = eval(read_file(config['Auth']['database_path'] + "/Records/BlackMarket/" + str(city) + ".txt"))
		blackmarket_prices_temp = []
		response = get_from_database('BlackMarket', None, "Key('City').eq('" + city + "')")
		blackmarket_prices_temp.append(str(response['Items'][0]['Alcohol']))
		blackmarket_prices_temp.append(str(response['Items'][0]['Televisions']))
		blackmarket_prices_temp.append(str(response['Items'][0]['CarParts']))
		blackmarket_prices_temp.append(str(response['Items'][0]['ItalianSuits']))
		blackmarket_prices_temp.append(str(response['Items'][0]['FurCoats']))
		blackmarket_prices_temp.append(str(response['Items'][0]['Porn']))


		print_function(str(city) + ' // ' + str(blackmarket_prices_temp[0]) + " " + str(blackmarket_prices_temp[1]) + " " + str(blackmarket_prices_temp[2]) + " " +
					   str(blackmarket_prices_temp[3]) + " " + str(blackmarket_prices_temp[4]) + " " + str(blackmarket_prices_temp[5]) + ' // ' + str(blackmarket_prices_temp))

		count = 0
		while True:
			if int(count) > 5:
				break
			pricediff = abs(int(blackmarket_prices_currentcity[count]) - int(blackmarket_prices_temp[count]))
			print_function(str(count) + " " + str(blackmarket_prices_currentcity[count]) + " " + str(blackmarket_prices_temp[count]) + " " + str(pricediff))

			if (int(blackmarket_prices_currentcity[count]) > 0) or (int(blackmarket_prices_temp[count]) > 0):
				max_afford = math.floor(int(dirty_money) / max(int(blackmarket_prices_currentcity[count]), int(blackmarket_prices_temp[count])))
				max_carry = min(int(carry_capacity), int(max_afford))
				this_item_profit = int(max_carry) * int(pricediff)

				if int(pricediff) > int(absolute_highest_profit_item):
					absolute_highest_profit_item = pricediff
					cheaper_item = min(int(blackmarket_prices_currentcity[count]), int(blackmarket_prices_temp[count]))
					blackmarket_reserve_money = int(cheaper_item) * int(carry_capacity)
			else:
				this_item_profit = 0

			# TRAVEL TO GYM / CASINO IF RELEVANT
			if (travel_specific_city != 'None') and (city != travel_specific_city):
				print_function('BLACKMARKET - REQUIRE GYM OR CASINO. SKIP IRRELEVANT CITY')
				pass
			# AVOID CASES
			elif (config.getboolean('Blackmarket-Travel', 'AvoidCitiesWithCases')) and (int(cases_in_city) > 0):
				print_function('BLACKMARKET - SKIPPING CITY ' + str(city) + ' WITH CASES: ' + str(cases_in_city))
				pass
			# GET HOME CITY AS DESTINATION IF RELEVANT
			elif (config.getboolean('Blackmarket-Travel', 'RequireHomecity')) and (travel_specific_city == 'None') and (current_city != home_city) and (city != home_city) and ((int(cases_in_homecity) == 0) or not (config.getboolean('Blackmarket-Travel', 'AvoidCitiesWithCases'))):
				print_function('BLACKMARKET - REQUIRE HOMECITY AS DESTINATION - SKIP NON HOMECITY ' + str(city))
				pass
			else:
				if highest_profit_item == None:
					highest_profit_item = count
					highest_profit = this_item_profit
					travel_to_city = city
					if int(blackmarket_prices_currentcity[count]) >= int(blackmarket_prices_temp[count]):
						blackmarket_buy_city = city
						blackmarket_sell_city = current_city
					else:
						blackmarket_buy_city = current_city
						blackmarket_sell_city = city
				elif int(this_item_profit) > int(highest_profit):
					highest_profit_item = count
					highest_profit = this_item_profit
					travel_to_city = city
					if int(blackmarket_prices_currentcity[count]) >= int(blackmarket_prices_temp[count]):
						blackmarket_buy_city = city
						blackmarket_sell_city = current_city
					else:
						blackmarket_buy_city = current_city
						blackmarket_sell_city = city
			count += 1

	if config.getboolean('Blackmarket-Travel', 'ReserveBlackmarketMoney'):
		pass
	else:
		blackmarket_reserve_money = 0

	print_function('BLACKMARKET - Item: ' + str(highest_profit_item) + " " + str(highest_profit) + ' To: ' + str(travel_to_city) + ' Buying: ' + str(blackmarket_buy_city) + ' Selling: ' + str(blackmarket_sell_city))

	# REMOVE SAVED VARIABLES
	variables_list = running_thread[4]
	for item in running_thread[4]:
		if ('blackmarket-status' in str(item)) or ('blackmarket-currentcitysaved' in str(item)):
			pass
		elif 'blackmarket' in str(item):
			try:
				variables_list.remove(item)
			except:
				pass

	print_function('VARIABLES BEFORE BLACKMARKET ADDED: ' + str(variables_list))
	variables_list.append('blackmarket-reserved:' + str(blackmarket_reserve_money))

	if travel_to_city == None:
		print_function('BLACKMARKET - CANNOT TRAVEL TO ANY CITY')
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES FOR BLACKMARKET AS NO DESTINATION CITY: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

		globals()['timers'].__dict__['blackmarket_timer'] = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

		thread_remove_from_queue(running_thread, waiting_thread_list)
		return

	variables_list.append('blackmarket-item:' + str(highest_profit_item))
	variables_list.append('blackmarket-sell:' + str(blackmarket_sell_city))
	variables_list.append('blackmarket-buy:' + str(blackmarket_buy_city))
	variables_list.append('blackmarket-travel:' + str(travel_to_city))
	running_thread[4] = variables_list
	print_function('UPDATED VARIABLES FOR BLACKMARKET CALCULATIONS: ' + str(running_thread[4]))
	write_file("env/variables.txt", running_thread[4])

	# BUY IF IN BUY CITY
	if ('blackmarket-status:sold' in str(running_thread[4])) and (blackmarket_buy_city == current_city):
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'blackmarket-status' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass
		variables_list.append('blackmarket-status:buying')
		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

	# DEAL WITH UNKNOWN STATUS
	if 'UNKNOWN' in str(running_thread[4]):
		variables_list = running_thread[4]
		for item in running_thread[4]:
			if 'blackmarket-status' in str(item):
				try:
					variables_list.remove(item)
				except:
					pass

		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])


		running_thread[4] = variables_list
		print_function('UPDATED VARIABLES FOR BLACKMARKET STATUS: ' + str(running_thread[4]))
		write_file("env/variables.txt", running_thread[4])

	print_function('BLACKMARKET - Item: ' + str(highest_profit_item) + " " + str(highest_profit) + ' To: ' + str(travel_to_city) + ' Buying: ' + str(blackmarket_buy_city) + " " +
				   ' Selling: ' + str(blackmarket_sell_city) + ' Reserved: ' + str(blackmarket_reserve_money))
	thread_remove_from_queue(running_thread, waiting_thread_list)
	return