from globalvars import *
from code_modules.function import *


def boys_work_hospital(lock_webdriver, running_thread, waiting_thread_list, boys_list, online_list, your_character_name):
	# hospital ignore if pimp/whore and not unlocked
	if ('Pimp' in str(config['Earn']['WhichEarn'])):
		print_function("BOYS WORK HOSPITAL - PIMP EARN SET")
		random_timer = random.randrange(721, 781)  # 12 hours
		write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(
			minutes=random_timer)))
		return
	elif ('Whore' in str(config['Earn']['WhichEarn'])):
		print_function("BOYS WORK HOSPITAL - WHORE EARN SET")
		random_timer = random.randrange(721, 781)  # 12 hours
		write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(
			minutes=random_timer)))
		return

	# CHECK SEXCHANGE TIMER READY
	sexchange_timer = read_file("env/sexchange_timer.txt")
	sexchange_timer = datetime.datetime.strptime(sexchange_timer, '%Y-%m-%d %H:%M:%S.%f')
	time_difference = datetime.datetime.utcnow() - sexchange_timer
	if not '-' in str(time_difference):
		boys_hospital = False
		for boys_name in boys_list:
			if boys_name == str(your_character_name):
				continue
			elif boys_name in online_list:
				print_function(str(boys_name) + ' hospital')
				boys_hospital = True

		if boys_hospital:
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_action)

			open_city(lock_webdriver, running_thread)

			if element_found(lock_webdriver, "XPATH", ".//*[@class='maintenance']/a[@class='business hospital']"):
				# HOSPITAL TORCHED
				print_function('hospital torched')
				random_timer = random.randrange(721, 781)  # 12 hours
				write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(
					seconds=random_timer)))
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return
			else:
				element_click(lock_webdriver, "XPATH", ".//*[@class='business hospital']", running_thread)
			print_function('HOSPITAL - CLICKED')

			# HOSPITAL TORCHED
			if element_found(lock_webdriver, "ID", "fail"):
				results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
				if 'under going repairs' in results:
					print_function('hospital torched')
					random_timer = random.randrange(721, 781)  # 12 hours
					write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(
						seconds=random_timer)))
					thread_remove_from_queue(running_thread, waiting_thread_list)
					return

			# APPLY FOR SEX CHANGE
			element_click(lock_webdriver, "XPATH", ".//*[@id='content']/center/div[@id='holder_table']/form/div[@id='holder_content']/div[@class='links']/table/tbody/tr[2]/td[4]/a", running_thread)

			if element_found(lock_webdriver, "XPATH", ".//*[@id='content']/center/div[@id='holder_table']/form/div[@id='holder_content']/center/table/tbody/tr[4]/td/select[@class='dropdown']"):
				select_dropdown_option(lock_webdriver, "XPATH", ".//*[@id='content']/center/div[@id='holder_table']/form/div[@id='holder_content']/center/table/tbody/tr[4]/td/select[@class='dropdown']", "Yes")
			else:
				print_function('Boys Hospital - NO DROPDOWN. SEXCHANGE ALREADY DONE?')
				random_timer = random.randrange(721, 781)  # 12 hours
				write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(
					minutes=random_timer)))
				thread_remove_from_queue(running_thread, waiting_thread_list)
				return

			element_click(lock_webdriver, "XPATH", ".//*[@class='submit']", running_thread)

			if element_found(lock_webdriver, "ID", "success"):
				results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")
			else:
				results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")

			if 'wait for your operation' in results:
				# UPDATE BOYS
				sqs = boto3.resource('sqs',
									 region_name='ap-southeast-2',
									 aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
									 aws_secret_access_key='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',
									 )
				for boys_name in boys_list:
					if boys_name in online_list:
						try:
							queue = sqs.get_queue_by_name(QueueName=str(boys_name))
						except:
							continue
						response = queue.send_message(MessageBody="ResetCaseTimer", DelaySeconds=1)
						print_function('BOYS HOSPITAL - RESET TIMER FOR ' + str(boys_name))

				random_timer = random.randrange(721, 781)  # 12 hours
				write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(
					minutes=random_timer)))
			else:
				random_timer = random.randrange(721, 781)  # 12 hours
				write_file("env/sexchange_timer.txt", str(datetime.datetime.utcnow() + datetime.timedelta(
					minutes=random_timer)))

			thread_remove_from_queue(running_thread, waiting_thread_list)
	return
