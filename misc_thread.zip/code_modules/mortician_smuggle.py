from globalvars import *
from code_modules.function import *

def mortician_smuggle(lock_webdriver, running_thread, waiting_thread_list, your_character_name, smuggle_name):
	if (1 == 1):
		if globals()['timers'].__dict__['traffic_timer'] is None:
			globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=get_timer(lock_webdriver, 'Trafficking', running_thread))
		time_difference = datetime.datetime.utcnow() - globals()['timers'].__dict__['traffic_timer']
		if not '-' in str(time_difference):
			print_function('FUNERAL SMUGGLE - QUEUED')
			thread_add_to_queue(running_thread, waiting_thread_list, priority_thread_earn)
			print_function("FUNERAL SMUGGLE - START")

			print_function("FUNERAL SMUGGLE - SMUGGLE NAME: " + str(smuggle_name))

			if go_to_page(lock_webdriver, "Funeral_Smuggle", running_thread):
				pass
			else:
				# CANNOT GO TO AGGS PAGE - LIKELY CS NEEDED
				return

			if element_found(lock_webdriver, "XPATH", ".//*[@id='content']/table[@id='AutoNumber4']/tbody/tr[5]/td[@class='s0'][2]/p/select"):
				dropdown = get_dropdown_options(lock_webdriver, "XPATH",
										".//*[@id='content']/table[@id='AutoNumber4']/tbody/tr[5]/td[@class='s0'][2]/p/select")
				print_function("FUNERAL SMUGGLE - DROPDOWN OPTIONS: " + str(dropdown))

				if smuggle_name in dropdown:
					select_dropdown_option(lock_webdriver, "XPATH",
										".//*[@id='content']/table[@id='AutoNumber4']/tbody/tr[5]/td[@class='s0'][2]/p/select",
										smuggle_name)
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/table[@id='AutoNumber4']/tbody/tr[7]/td[@class='s0'][2]/p/input", running_thread)
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/table[@id='AutoNumber4']/tbody/tr[6]/td[@class='s0'][2]/p/input", running_thread)
					element_click(lock_webdriver, "XPATH", ".//*[@id='content']/table[@id='AutoNumber4']/tbody/tr[8]/td[@class='s0'][2]/p/input", running_thread)

					if element_found(lock_webdriver, "ID", "fail"):
						results = element_get_attribute(lock_webdriver, "ID", "fail", "innerHTML")
					elif element_found(lock_webdriver, "ID", "success"):
						results = element_get_attribute(lock_webdriver, "ID", "success", "innerHTML")

					if 'collected the drugs' in results:
						# SMUGGLE DONE
						try:
							waiting_thread_list.remove(thread)
						except:
							pass

						# SET TIMER
						traffic_timer = get_timer(lock_webdriver, 'Trafficking', running_thread)
						globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=traffic_timer)
						thread_remove_from_queue(running_thread, waiting_thread_list)
						return
					elif 'in the city to pick them up' in results:
						discord_message(config['Auth']['discord_id'] + str(your_character_name) + " SMUGGLE FAIL: " + str(results) )

						# SMUGGLE FAILED
						try:
							waiting_thread_list.remove(thread)
						except:
							pass

						# SET TIMER
						traffic_timer = get_timer(lock_webdriver, 'Trafficking', running_thread)
						globals()['timers'].__dict__['traffic_timer'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=traffic_timer)
						thread_remove_from_queue(running_thread, waiting_thread_list)
						return
				else:
					print_function("SMUGGLE NAME NOT IN DROPDOWN? NAME: " + str(smuggle_name), "RED")
					try:
						waiting_thread_list.remove(thread)
					except:
						pass
			else:
				print_function("SMUGGLE DROPDOWN NOT FOUND?", "RED")
				try:
					waiting_thread_list.remove(thread)
				except:
					pass

			thread_remove_from_queue(running_thread, waiting_thread_list)
	return

