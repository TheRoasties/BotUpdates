from globalvars import *
from code_modules.function import *
from code_modules.transfer_money import *

from code_modules.torch import *
from code_modules.armedrobbery import *
from code_modules.hack import *
from code_modules.bne import *
from code_modules.bne_zero import *
from code_modules.mug import *
from code_modules.pickpocket import *

global driver
global lock_webdriver

__all__ = ["aggstr_percent_modify", "get_aggstr_mins", "find_agg_target_thread"]


def get_all_targets_online_hours(aggtarget_person_list_manager):
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GETTING ALL ONLINE HOURS - FUNCTION START")
	server_port = read_file("env/ServerPort.txt")
	manager = BaseManager(address=('127.0.0.1', int(server_port)))
	BaseManager.register('person', person)

	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GETTING ALL ONLINE HOURS - CONNECTING TO BASEMANAGER")
	while True:
		try:
			manager.connect()
			break
		except:
			print_function('AGGS - ALL TARGETS ONLINE HOURS - FAILED TO CONNECT TO BASEMANAGER', "RED")
	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GETTING ALL ONLINE HOURS - CONNECTED TO BASEMANAGER")

	# GET ONLINE HOURS FOR ALL ALIVE PLAYERS
	player_database = get_from_database('Player', None)
	item_count = (len(player_database['Items']) - 1)
	while item_count >= 0:
		database_player_name = player_database['Items'][item_count]['PlayerName']

		try:
			database_player_status = player_database['Items'][item_count]['AliveStatus']
		except:
			try:
				response = get_from_database('Player', 'AliveStatus', "Key('PlayerName').eq('" + str(database_player_name) + "')")
				database_player_status = response['Items'][0]['AliveStatus']
			except:
				print_function("find-agg-targets - failed to get alive status for " + str(database_player_name), "RED")
				item_count -= 1
				continue

		if database_player_status == 'Alive':
			pass
		else:
			item_count -= 1
			continue
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GETTING ALL ONLINE HOURS - CHECKING NAME: " + str(database_player_name))

		try:
			database_player_hours = player_database['Items'][item_count]['Hours']
		except:
			database_player_hours = 1

		try:
			database_player_aggpro = player_database['Items'][item_count]['Aggpro_Personal']
			database_player_aggpro = datetime.datetime.strptime(database_player_aggpro, '%Y-%m-%d %H:%M:%S.%f')
		except:
			database_player_aggpro = datetime.datetime.utcnow()

		try:
			database_player_hackpro = player_database['Items'][item_count]['Aggpro_Hack']
			database_player_hackpro = datetime.datetime.strptime(database_player_hackpro, '%Y-%m-%d %H:%M:%S.%f')
		except:
			database_player_hackpro = datetime.datetime.utcnow()

		try:
			database_player_bnepro = player_database['Items'][item_count]['Aggpro_BnE']
			database_player_bnepro = datetime.datetime.strptime(database_player_bnepro, '%Y-%m-%d %H:%M:%S.%f')
		except:
			database_player_bnepro = datetime.datetime.utcnow()

		try:
			database_player_house = player_database['Items'][item_count]['House']
		except:
			database_player_house = "None"

		try:
			database_player_vehicle = player_database['Items'][item_count]['Vehicle']
		except:
			database_player_vehicle = "None"

		attempt_count = 1
		while True:
			try:
				aggtarget_person_list_manager[str(database_player_name)] = manager.person(str(database_player_name))
				break
			except:
				print_function("FindAggTargets - FAILED CREATE MANAGER FOR " + str(database_player_name) + " ATTEMPT " + str(attempt_count), "RED")
				attempt_count += 1

		attempt_count = 1
		while True:
			try:
				aggtarget_person_list_manager[str(database_player_name)].add_online_hours(int(database_player_hours))
				break
			except:
				discord_error("FindAggTargets - FAILED ADD ONLINE HOURS FOR " + str(database_player_name) + " ATTEMPT " + str(attempt_count))
				attempt_count += 1

		attempt_count = 1
		while True:
			try:
				aggtarget_person_list_manager[str(database_player_name)].set_local_aggpro_timer(database_player_aggpro)
				break
			except:
				print_function("FindAggTargets - FAILED SET LOCAL AGGPRO FOR " + str(database_player_name) + " ATTEMPT " + str(attempt_count), "RED")
				attempt_count += 1

		attempt_count = 1
		while True:
			try:
				aggtarget_person_list_manager[str(database_player_name)].set_local_hack_timer(database_player_hackpro)
				break
			except:
				print_function("FindAggTargets - FAILED SET LOCAL HACKPRO FOR " + str(database_player_name) + " ATTEMPT " + str(attempt_count), "RED")
				attempt_count += 1

		attempt_count = 1
		while True:
			try:
				aggtarget_person_list_manager[str(database_player_name)].set_local_bne_timer(database_player_bnepro)
				break
			except:
				print_function("FindAggTargets - FAILED SET LOCAL BNE TIMER FOR " + str(database_player_name) + " ATTEMPT " + str(attempt_count), "RED")
				attempt_count += 1

		attempt_count = 1
		while True:
			try:
				if database_player_house == "None":
					aggtarget_person_list_manager[str(database_player_name)].set_local_house(database_player_house)
					break
				else:
					break
			except:
				print_function("FindAggTargets - FAILED SET LOCAL HOUSE FOR " + str(database_player_name) + " ATTEMPT " + str(attempt_count), "RED")
				attempt_count += 1

		attempt_count = 1
		while True:
			try:
				if database_player_vehicle == "None":
					aggtarget_person_list_manager[str(database_player_name)].set_local_vehicle(database_player_vehicle)
					break
				else:
					break
			except:
				print_function("FindAggTargets - FAILED SET LOCAL VEHICLE FOR " + str(database_player_name) + " ATTEMPT " + str(attempt_count), "RED")
				attempt_count += 1


		globals()['all_agg_targets'].append(database_player_name)

		item_count -= 1

	write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GETTING ALL ONLINE HOURS - DONE")
	# END OF SINGLE FILEPATH
	return


def get_aggstr_mins(lock_webdriver):
	aggstr_percent = element_get_attribute(lock_webdriver, "XPATH", "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']/div[@id='display_bar'][4]/div[@class='progress-bar bg-energy']", "innerHTML")
	aggstr_percent = float(aggstr_percent.replace('%', ''))

	if aggstr_percent >= 99:
		aggstr_mins_max = 30
	elif aggstr_percent >= 64:
		aggstr_mins_max = 29
	elif aggstr_percent >= 62:
		aggstr_mins_max = 28
	elif aggstr_percent >= 60:
		aggstr_mins_max = 27
	elif aggstr_percent >= 57:
		aggstr_mins_max = 26
	elif aggstr_percent >= 55:
		aggstr_mins_max = 25
	elif aggstr_percent >= 53:
		aggstr_mins_max = 24
	elif aggstr_percent >= 38:
		aggstr_mins_max = 23
	elif aggstr_percent >= 36:
		aggstr_mins_max = 22
	elif aggstr_percent >= 35:
		aggstr_mins_max = 21
	elif aggstr_percent >= 33:
		aggstr_mins_max = 20
	elif aggstr_percent >= 31:
		aggstr_mins_max = 19
	elif aggstr_percent >= 30:
		aggstr_mins_max = 18
	elif aggstr_percent >= 18:
		aggstr_mins_max = 17
	elif aggstr_percent >= 17:
		aggstr_mins_max = 16
	elif aggstr_percent >= 16:
		aggstr_mins_max = 15
	elif aggstr_percent >= 15:
		aggstr_mins_max = 14
	elif aggstr_percent >= 14:
		aggstr_mins_max = 13
	elif aggstr_percent >= 13:
		aggstr_mins_max = 12
	elif aggstr_percent >= 9:
		aggstr_mins_max = 11
	elif aggstr_percent >= 8:
		aggstr_mins_max = 10
	elif aggstr_percent >= 7:
		aggstr_mins_max = 9
	elif aggstr_percent >= 6:
		aggstr_mins_max = 8
	elif aggstr_percent >= 5.5:
		aggstr_mins_max = 7
	elif aggstr_percent >= 5:
		aggstr_mins_max = 6
	elif aggstr_percent >= 3:
		aggstr_mins_max = 5
	elif aggstr_percent >= 2.5:
		aggstr_mins_max = 4
	elif aggstr_percent >= 2:
		aggstr_mins_max = 3
	else:
		aggstr_mins_max = 0

	return aggstr_mins_max


def find_agg_target_thread(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, aggtarget_person_list_manager, aggtarget_business_list_manager):
	try:
		# WAIT TILL CITY LIST HAS FINISHED UPDATING
		while True:
			if 'city_list_record' in str(waiting_thread_list):
				print_function('AGGS - WAITING ON CITY LIST TO FINISH')
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " WAITING FOR CITY LIST TO FINISH")
				time.sleep(10)
			else:
				break


		# MAKE CITY PLAYER LISTS FOR HACK / BNE
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " CREATING CITY LISTS - START")
		for city in globals()['cities_list']:
			globals()['player_list_city_' + str(city)] = []
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " CREATING CITY LISTS - FINISHED")

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GET ONLINE HOURS - START")
		player_database = get_from_database('Player', None)
		item_count = (len(player_database['Items']) - 1)
		while item_count >= 0:
			try:
				player_alive_status = player_database['Items'][item_count]['AliveStatus']
			except:
				try:
					response = get_from_database('Players', 'AliveStatus', "Key('PlayerName').eq('" + str(database_player_name) + "')")
					player_alive_status = response['Items'][0]['AliveStatus']
				except:
					print_function("FIND AGG TARGETS - NO ALIVE STATUS FOUND IN DATABASE FOR " + str(database_player_name), "RED")
					item_count -= 1
					continue

			if str(player_alive_status) == "Alive":
				try:
					database_player_name = player_database['Items'][item_count]['PlayerName']
				except:
					print_function("FIND AGG TARGETS  - NO ONLINE HOURS FOUND IN DATABASE FOR NUMBER " + str(item_count) + " DATABASE STRING: " + str(player_database), "RED")
					item_count -= 1
					continue

				try:
					database_player_city = player_database['Items'][item_count]['HomeCity']
				except:
					print_function("FIND AGG TARGETS - NO HOME CITY FOUND IN DATABASE FOR " + str(database_player_name), "RED")
					item_count -= 1
					continue

				if str(database_player_city) in str(globals()['cities_list']):
					globals()['player_list_city_' + str(database_player_city)].append(database_player_name)
			item_count -= 1
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GET ONLINE HOURS - FINISHED")

		for city in globals()['cities_list']:
			random.shuffle(globals()['player_list_city_' + str(city)])



		your_homecity = get_home_city(lock_webdriver)
		your_current_city = get_current_city(lock_webdriver)
		your_character_name = get_your_character_name(lock_webdriver)

		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GET ONLINE HOURS - START")
		get_all_targets_online_hours(aggtarget_person_list_manager)
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " GET ONLINE HOURS - FINISHED")


		# GET BOLD LIST
		bold_list = get_from_database('BoldList', None)


		if config.getboolean('Pickpocket', 'Do_Pickpocket'):
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO PP ARRAYS - START")
			add_pickpocket_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager)
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO PP ARRAYS - FINISHED")
		if config.getboolean('Mug', 'Do_Mug'):
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO MUG ARRAYS - START")
			add_mug_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager)
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO MUG ARRAYS - FINISHED")
		if config.getboolean('Hack', 'Do_Hack'):
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO HACK ARRAYS - START")
			hack_target_list = globals()['player_list_city_' + str(your_homecity)]
			add_hack_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager, hack_target_list, your_character_name, bold_list)
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO HACK ARRAYS - FINISHED")
		if config.getboolean('BnE', 'Do_BnE'):
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO BNE ARRAYS - START")
			bne_target_list = globals()['player_list_city_' + str(your_current_city)]
			add_bne_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager, bne_target_list, your_character_name, bold_list)
			write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - INITIAL ADD TO BNE ARRAYS - FINISHED")

		# GET INITIAL AGGSTR
		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - GETTING AGGSTR")
		last_agg_time[0] = datetime.datetime.utcnow() - datetime.timedelta(minutes=get_aggstr_mins(lock_webdriver))
		aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
		if (aggstr_mins_max > 30):
			aggstr_mins_max = 30

		aggstr_min_checking = 0

		last_click_timer = None
		last_travel_timer = None
		your_current_city_saved = your_current_city
		last_travel_timer = running_thread[5]


		write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGS - STARTING LOOP")
		while True:
			while 'In-Jail' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " CANNOT AGG - IN JAIL")
				time.sleep(20)

			# WAIT FOR CS TO BE COMPLETED
			while 'CS:' in str(running_thread[4]):
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " NEED TO CLEAR CS BEFORE AGGS")
				time.sleep(20)

			# WAIT TILL CITY LIST HAS FINISHED UPDATING
			while 'city_list_record' in str(waiting_thread_list):
				print_function('AGGS - WAITING ON CITY LIST TO FINISH')
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " WAITING FOR CITY LIST TO FINISH")
				time.sleep(10)


			if (aggstr_min_checking <= 0):
				aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
				if aggstr_mins_max > 30:
					aggstr_mins_max = 30

				if (aggstr_mins_max == 0):
					if 'Torch|AR' in running_thread[4]:
						variables_list = running_thread[4]
						for item in running_thread[4]:
							if 'Torch|AR' in item:
								try:
									variables_list.remove(item)
								except:
									pass
								break
						running_thread[4] = variables_list

					# CHECK BNE ZERO TIMERS
					last_bne_zero = read_file("env/last_bne_zero.txt")
					try:
						last_bne_zero = datetime.datetime.strptime(last_bne_zero, '%Y-%m-%d %H:%M:%S')
					except:
						last_bne_zero = datetime.datetime.strptime(last_bne_zero, '%Y-%m-%d %H:%M:%S.%f')
					time_difference = datetime.datetime.utcnow() - last_bne_zero

					if not '-' in str(time_difference) and (config.getboolean('BnE_Zero', 'Do_BnE_Zero')) and ('BnE' in running_thread[3]):
						bne_zero_min_to_check_list = ['30', '29', '28', '27', '26', '25', '24', '23', '22', '21', '20', '19', '18', '17', '16', '15', '14', '13', '12', '11', '10', '9', '8', '7', '6', '5', '4', '3']

						# USE LAST AGG TO FIGURE OUT IF A BNE ZERO WAS DONE
						last_agg_saved_record = last_agg_time[0]

						# WAIT FOR PREVIOUS AGG TO FINISH. THIS MAY BE DELAYED DUE TO REPAY ETC
						while True:
							if ('transfer_money' in str(waiting_thread_list)) or ('do_torch_thread' in str(waiting_thread_list)) or ('do_armedrobbery_thread' in str(waiting_thread_list)) or ('do_hack_thread' in str(waiting_thread_list)) or ('do_pickpocket_thread' in str(waiting_thread_list)) or ('do_bne_thread' in str(waiting_thread_list)) or ('do_mug_thread' in str(waiting_thread_list)):
								print_function('BNE Zero - WAITING FOR PREVIOUS AGG & REPAY TO FINISH')
								time.sleep(1)
								pass
							else:
								print_function('BNE ZERO - PREVIOUS AGGS CLEARED')
								write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BnE Zero - PREVIOUS AGGS CLEARED")
								break

						# DO BNE ZERO
						while True:
							if (last_agg_saved_record != last_agg_time[0]):
								print_function('BNE ZERO DONE')
								write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BnE Zero - DONE")
								write_file("env/last_bne_zero.txt", datetime.datetime.utcnow() + datetime.timedelta(minutes=int(config['BnE_Zero']['Minutes_Between_BnE_Zero'])))
								break

							aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
							if (aggstr_mins_max >= 3):
								print_function('BNE ZERO - TOOK LONGER THAN 3 MINUTES')
								write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BnE Zero - TOOK LONGER THAN 3 MINUTES")
								break

							if ('bne' in str(waiting_thread_list)):
								pass
							else:
								check_bne_zero_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, your_current_city, globals()['player_list_city_' + str(your_current_city)], aggtarget_person_list_manager, bold_list)

								# WAIT BEFORE IT COULD BE READDED, SO THAT IT'S NOT ADDED AGAIN MIDWAY THROUGH A PREVIOUS TERMINATE
								while True:
									if 'bne_zero_thread' in str(waiting_thread_list):
										pass
									else:
										write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BnE Zero - NO LONGER IN QUEUE")
										break
					else:
						# NO BNE ZERO
						mins_between_aggs = config['Misc']['mins_between_aggs']
						mins_between_aggs_seconds = int(mins_between_aggs) * 60
						print_function('AGG JUST DONE - WAIT ' + str(mins_between_aggs) + ' MINS FOR AGGSTR TO RECOVER' + str(aggstr_mins_max))
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGG JUST DONE - WAIT " + str(mins_between_aggs) + " MINS FOR AGGSTR TO RECOVER")

						while mins_between_aggs_seconds > 0:
							if (mins_between_aggs_seconds >= 5):
								time.sleep(5)
								mins_between_aggs_seconds -= 5
								write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " WAITING FOR AGGSTR - SECS REMAINING: " + str(mins_between_aggs_seconds))

								if 'ResetAggstrTimer' in str(waiting_thread_list):
									for thread in waiting_thread_list:
										if 'ResetAggstrTimer' in thread:
											try:
												waiting_thread_list.remove(thread)
											except:
												pass
											last_agg_time[0] = datetime.datetime.utcnow() - datetime.timedelta(minutes=get_aggstr_mins(lock_webdriver))
											aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
											if (aggstr_mins_max > 30):
												aggstr_mins_max = 30
											aggstr_min_checking = aggstr_mins_max
											mins_between_aggs_seconds = 0
											write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " WAITING FOR AGGSTR - FINISHED AS RESETAGGSTR COMMAND RECEIVED")


							else:
								time.sleep(mins_between_aggs_seconds)
								mins_between_aggs_seconds -= int(mins_between_aggs_seconds)

						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGSTR WAIT FINISHED")
						time.sleep(mins_between_aggs_seconds)
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " AGGSTR WAIT FINISHED")

					aggstr_min_checking = 0
					continue

				# ONLY GET A NEW LIST IF THE PAGE HAS REFRESHED SINCE LAST TIME
				if last_click_timer != running_thread[1]:

					if config.getboolean('Pickpocket', 'Do_Pickpocket'):
						pickpocket_list = get_pickpocket_list_currentcity(lock_webdriver, aggtarget_person_list_manager, running_thread)

					if config.getboolean('Mug', 'Do_Mug'):
						mug_list = get_mug_list_currentcity(lock_webdriver, aggtarget_person_list_manager, running_thread)

					right_bar_details = running_thread[2]
					if right_bar_details == '':
						running_thread[2] = element_get_attribute(lock_webdriver, 'XPATH',
																  "/html/body[@id='body']/div[@id='wrapper']/div[@id='nav_right']",
																  'innerHTML')
						right_bar_details = running_thread[2]

					if 'Jail Rank' in right_bar_details:
						if 'In-Jail' in str(running_thread[4]):
							pass
						else:
							variables_list = running_thread[4]
							variables_list.append('In-Jail')
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR IN-JAIL: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])
					else:
						# NOT IN JAIL
						if 'In-Jail' in str(running_thread[4]):
							variables_list = running_thread[4]
							try:
								variables_list.remove('In-Jail')
							except:
								pass
							running_thread[4] = variables_list
							print_function('UPDATED VARIABLES FOR NOT IN-JAIL: ' + str(running_thread[4]))
							write_file("env/variables.txt", running_thread[4])

					if 'In-Jail' in str(running_thread[4]):
						pass
					else:
						right_bar_line = right_bar_details.splitlines()

						'''
						rank = regex_match_between('>', '<', right_bar_line[7])
						occupation = regex_match_between('>', '<', right_bar_line[11])
						desired_money_on_hand = int(config['Misc']['DesiredMoneyOnHand'])
						your_clean_money = regex_match_between('value="', '"', right_bar_line[15])
						your_clean_money = re.sub('[^0-9]', "", your_clean_money)
						dirty_money = regex_match_between('>', '<', right_bar_line[18])
						dirty_money = re.sub('[^0-9]', "", dirty_money)
						rank_percent = regex_match_between('title="', '"', right_bar_line[36])
						'''

						your_character_name = regex_match_between('username\=', '">', right_bar_line[4])
						your_current_city = regex_match_between('>', '<', right_bar_line[21])
						your_current_city = your_current_city.replace(' ', '')
						your_homecity = regex_match_between('>', '<', right_bar_line[23])
						your_homecity = your_homecity.replace(' ', '')

					last_click_timer = running_thread[1]


				# HAVE TRAVELLED - UPDATE TIMERS ETC
				if (last_travel_timer != running_thread[5]) or (str(your_current_city) != str(your_current_city_saved)):
					if (last_travel_timer != running_thread[5]):
						print_function('travel timer different' + str(last_travel_timer) + "|" + str(running_thread[5]))
					if (str(your_current_city) != str(your_current_city_saved)):
						print_function('current city different to saved' + str(your_current_city) + "|" + str(your_current_city_saved))

					last_travel_timer = running_thread[5]
					your_current_city_saved = your_current_city

					globals()['timers'].__dict__['torch_engi_list_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=10)
					globals()['timers'].__dict__['torch_engi_online_timer'] = datetime.datetime.utcnow() - datetime.timedelta(minutes=10)

					if config.getboolean('Hack', 'Do_Hack'):
						hack_target_list = globals()['player_list_city_' + str(your_homecity)]
						bold_list = get_from_database('BoldList', None)
						add_hack_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager, hack_target_list,
												   your_character_name, bold_list)
					if (config.getboolean('BnE', 'Do_BnE')):
						bne_target_list = globals()['player_list_city_' + str(your_current_city)]
						add_bne_targets_to_arrays(lock_webdriver, aggtarget_person_list_manager, bne_target_list,
												  your_character_name, bold_list)

				aggstr_min_checking = int(aggstr_mins_max)

				# LIST OF ALL MINS. START AT HIGHEST AND WORK DOWN. REMOVE FROM THE LIST WHEN CHECKED - THIS IS TO MANAGE THE THREAD STILL RUNNING WHILE
				count = int(aggstr_mins_max)
				pickpocket_min_to_check_list = []
				mug_min_to_check_list = []
				hack_min_to_check_list = []
				bne_min_to_check_list = []

				while True:
					pickpocket_min_to_check_list.append(count)
					mug_min_to_check_list.append(count)
					hack_min_to_check_list.append(count)
					bne_min_to_check_list.append(count)

					count -= 1
					if (count < 3):
						if int(aggstr_mins_max) == 30:
							pickpocket_min_to_check_list.append('31')
							mug_min_to_check_list.append('31')
							hack_min_to_check_list.append('31')
							bne_min_to_check_list.append('31')
						break

				if pickpocket_min_to_check_list == []:
					print_function('pickpocket min list blank - count: ' + str(count) + ' aggstr: ' + str(aggstr_mins_max))
					input('done')
				if mug_min_to_check_list == []:
					print_function('mug min list blank - count: ' + str(count) + ' aggstr: ' + str(aggstr_mins_max))
					input('done')
				if hack_min_to_check_list == []:
					print_function('hack min list blank - count: ' + str(count) + ' aggstr: ' + str(aggstr_mins_max))
					input('done')
				if bne_min_to_check_list == []:
					print_function('bne min list blank - count: ' + str(count) + ' aggstr: ' + str(aggstr_mins_max))
					input('done')

			if ('armedrobbery' in str(waiting_thread_list)) or ('torch' in str(waiting_thread_list)) or ('hack' in str(waiting_thread_list)) or ('do_bne' in str(waiting_thread_list)) or ('mug' in str(waiting_thread_list)) or ('pickpocket' in str(waiting_thread_list)):
				pass
			else:
				write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " CHECKING MIN: " + str(aggstr_min_checking))

			if (aggstr_min_checking > 2):
				# AGGS HERE IN ORDER OF PRIORITY

				# CHECK WEAPON VARIABLE
				variables_list = running_thread[4]
				if 'NoWeapon' in variables_list:
					config['ArmedRobbery']['Do_ArmedRobbery'] = 'False'
					if 'Torch|AR' in running_thread[4]:
						variables_list = running_thread[4]
					for item in running_thread[4]:
						if 'Torch|AR' in item:
							try:
								variables_list.remove(item)
							except:
								pass
							break
					running_thread[4] = variables_list

					for item in running_thread[4]:
						if 'NoWeapon' in item:
							try:
								variables_list.remove(item)
							except:
								pass

				if 'NoMug' in variables_list:
					config['Mug']['Do_Mug'] = 'False'
					for item in running_thread[4]:
						if 'NoMug' in item:
							try:
								variables_list.remove(item)
							except:
								pass
				running_thread[4] = variables_list


				# TORCH
				if (config.getboolean('Torch', 'Do_Torch')) and ('Torch' in running_thread[3]):
					# SKIP IF AN AGG DONE BEFORE THIS
					aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
					if aggstr_mins_max > 30:
						aggstr_mins_max = 30
					if aggstr_mins_max == 0:
						aggstr_min_checking = 0
						print_function('Torch - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE')
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " Torch - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE")
						continue

					if ('torch' in str(waiting_thread_list)):
						pass
					else:
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " CHECKING TORCH TARGETS - AGGSTR MINS " + str(aggstr_mins_max))
						check_torch_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name)


				# ArmedRobbery
				if (config.getboolean('ArmedRobbery', 'Do_ArmedRobbery')) and (('ArmedRobbery' in running_thread[3])):
					# SKIP IF AN AGG DONE BEFORE THIS
					aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
					if aggstr_mins_max > 30:
						aggstr_mins_max = 30
					if aggstr_mins_max == 0:
						aggstr_min_checking = 0
						print_function('ArmedRobbery - ARMEDROBBERY - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE')
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " ARMEDROBBERY - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE")
						continue

					if ('armedrobbery' in str(waiting_thread_list)) or ('torch' in str(waiting_thread_list)):
						pass
					else:
						write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " CHECKING AR TARGETS - AGGSTR MINS " + str(aggstr_mins_max))
						check_armedrobbery_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, aggstr_min_checking, aggstr_mins_max, aggtarget_business_list_manager, your_current_city, your_character_name)

				if not 'Torch|AR' in running_thread[4]:
					# HACKING
					if your_current_city == your_homecity:
						if (config.getboolean('Hack', 'Do_Hack')) and (('Hack' in running_thread[3])):
							# SKIP IF AN AGG DONE BEFORE THIS
							aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
							if aggstr_mins_max > 30:
								aggstr_mins_max = 30
							if aggstr_mins_max == 0:
								aggstr_min_checking = 0
								print_function('HACK - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE')
								continue

							if int(aggstr_mins_max) > int(config['Hack']['MaxMinute']):
								pass
							else:
								if ('hack' in str(waiting_thread_list)) or ('armedrobbery' in str(waiting_thread_list)) or ('torch' in str(waiting_thread_list)):
									pass
								else:
									try:
										if (len(hack_min_to_check_list) > 0):
											if (int(hack_min_to_check_list[0]) == int(aggstr_min_checking)):
												# print_function('HACK CHECKING HIGHEST MIN: ' + str(hack_min_to_check_list[0]) + ' OUT OF: ' + str(hack_min_to_check_list), "BLUE")
												write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK CHECKING HIGHEST MIN: " + str(hack_min_to_check_list[0]))

												check_hack_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, your_homecity, hack_target_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager)
												# REMOVE HIGHEST MINUTE AS ALREADY CHECKED
												hack_min_to_check_list.pop(0)
									except Exception as e:
										write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " HACK MIN TO CHECK BROKEN | " + str(hack_min_to_check_list) + " | " + str(aggstr_min_checking))
										print_function('HACK MIN TO CHECK BROKEN | ' + str(hack_min_to_check_list) + " | " + str(aggstr_min_checking), "RED")
										discord_error(config['Auth']['discord_id'] + str(your_character_name) + " HACK BROKEN - EXCEPTION: " + str(e))
										from code_modules.function import PrintException
										PrintException()
										while True:
											time.sleep(30)
										aggstr_min_checking = 0
										continue

					# BnE
					if (config.getboolean('BnE', 'Do_BnE')) and (('BnE' in running_thread[3])):
						# SKIP IF AN AGG DONE BEFORE THIS
						aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
						if aggstr_mins_max > 30:
							aggstr_mins_max = 30
						if aggstr_mins_max == 0:
							aggstr_min_checking = 0
							print_function('BnE - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE')
							continue

						if int(aggstr_mins_max) > int(config['BnE']['MaxMinute']):
							pass
						else:
							if ('hack' in str(waiting_thread_list)) or ('do_bne' in str(waiting_thread_list)) or ('armedrobbery' in str(waiting_thread_list)) or ('torch' in str(waiting_thread_list)):
								pass
							else:
								try:
									if (len(bne_min_to_check_list) > 0):
										if (int(bne_min_to_check_list[0]) == int(aggstr_min_checking)):
											# print_function('BnE CHECKING HIGHEST MIN: ' + str(bne_min_to_check_list[0]) + ' OUT OF: ' + str(bne_min_to_check_list), "BLUE")
											write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BnE CHECKING HIGHEST MIN: " + str(bne_min_to_check_list[0]))

											check_bne_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, your_current_city, bne_target_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, bold_list)

											# REMOVE HIGHEST MINUTE AS ALREADY CHECKED
											bne_min_to_check_list.pop(0)
								except Exception as e:
									write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " BNE MIN TO CHECK BROKEN | " + str(bne_min_to_check_list) + " | " + str(aggstr_min_checking))
									print_function('BNE MIN TO CHECK BROKEN | ' + str(bne_min_to_check_list) + " | " + str(aggstr_min_checking), "RED")
									discord_error(config['Auth']['discord_id'] + str(your_character_name) + " BNE BROKEN - EXCEPTION: " + str(e))
									from code_modules.function import PrintException
									PrintException()
									while True:
										time.sleep(30)
									aggstr_min_checking = 0
									continue

					# MUG
					if (config.getboolean('Mug', 'Do_Mug')) and (('Mug' in running_thread[3])):
						# SKIP IF AN AGG DONE BEFORE THIS
						aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
						if aggstr_mins_max > 30:
							aggstr_mins_max = 30
						if aggstr_mins_max == 0:
							aggstr_min_checking = 0
							print_function('MUG - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE')
							continue

						if int(aggstr_mins_max) > int(config['Mug']['MaxMinute']):
							pass
						else:
							if ('mug' in str(waiting_thread_list)) or ('hack' in str(waiting_thread_list)) or ('bne' in str(waiting_thread_list)) or ('armedrobbery' in str(waiting_thread_list)) or ('torch' in str(waiting_thread_list)):
								pass
							else:
								try:
									if (len(mug_min_to_check_list) > 0):
										if (int(mug_min_to_check_list[0]) == int(aggstr_min_checking)):
											# print_function('MUG CHECKING HIGHEST MIN: ' + str(mug_min_to_check_list[0]) + ' OUT OF: ' + str(mug_min_to_check_list), "BLUE")
											write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " MUG CHECKING HIGHEST MIN: " + str(mug_min_to_check_list[0]))

											check_mug_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, mug_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, bold_list)

											# REMOVE HIGHEST MINUTE AS ALREADY CHECKED
											mug_min_to_check_list.pop(0)
								except Exception as e:
									write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " MUG MIN TO CHECK BROKEN | " + str(mug_min_to_check_list) + " | " + str(aggstr_min_checking))
									print_function('MUG MIN TO CHECK BROKEN | ' + str(mug_min_to_check_list) + " | " + str(aggstr_min_checking), "RED")
									discord_error(config['Auth']['discord_id'] + str(your_character_name) + " MUG BROKEN - EXCEPTION: " + str(e))
									from code_modules.function import PrintException
									PrintException()
									while True:
										time.sleep(30)
									aggstr_min_checking = 0
									continue

					# PICKPOCKET
					if config.getboolean('Pickpocket', 'Do_Pickpocket'):
						# SKIP IF AN AGG DONE BEFORE THIS
						aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
						if aggstr_mins_max > 30:
							aggstr_mins_max = 30
						if aggstr_mins_max == 0:
							aggstr_min_checking = 0
							print_function('Pickpocket - AGG JUST DONE. SKIPPING ATTEMPTING A NEW ONE')
							continue

						if int(aggstr_mins_max) > int(config['Pickpocket']['MaxMinute']):
							pass
						else:
							if ('pickpocket' in str(waiting_thread_list)) or ('mug' in str(waiting_thread_list)) or ('hack' in str(waiting_thread_list)) or ('bne' in str(waiting_thread_list)) or ('armedrobbery' in str(waiting_thread_list)) or ('torch' in str(waiting_thread_list)):
								pass
							else:
								try:
									if (len(pickpocket_min_to_check_list) > 0):
										if(int(pickpocket_min_to_check_list[0]) == int(aggstr_min_checking)):
											# print_function('PICKPOCKET CHECKING HIGHEST MIN: ' + str(pickpocket_min_to_check_list[0]) + ' OUT OF: ' + str(pickpocket_min_to_check_list), "BLUE")
											write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " PICKPOCKET CHECKING HIGHEST MIN: " + str(pickpocket_min_to_check_list[0]))

											check_pickpocket_target(lock_webdriver, running_thread, waiting_thread_list, last_agg_time, your_character_name, pickpocket_list, aggstr_min_checking, aggstr_mins_max, aggtarget_person_list_manager, bold_list)

											# REMOVE HIGHEST MINUTE AS ALREADY CHECKED
											pickpocket_min_to_check_list.pop(0)
								except Exception as e:
									write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " PICKPOCKET MIN TO CHECK BROKEN | " + str(pickpocket_min_to_check_list) + " | " + str(aggstr_min_checking))
									try:
										discord_error("PP MIN TO CHECK LIST AS INT - " + str(int(pickpocket_min_to_check_list[0])))
									except:
										aggstr_min_checking = 0
										continue
									try:
										discord_error("PP MIN CHECKING AS INT - " + str(int(aggstr_min_checking)))
									except:
										discord_error("PP MIN CHECKING AS INT - BROKEN")
									while True:
										time.sleep(30)
									aggstr_min_checking = 0
									continue

			# write_file("env/Aggs_Thread_Log.txt", log_agg_time() + " FINISHED CHECKING MIN: " + str(aggstr_min_checking) + " LIST: " + str(waiting_thread_list))

			if aggstr_min_checking == 31:
				aggstr_min_checking = 0

			aggstr_min_checking -= 1

			# NOT GO BELOW CURRENT AGG WE ARE CHECKING
			lowest_aggstr_min_to_check = 0
			for thread in waiting_thread_list:
				if 'AggstrLowest' in str(thread):
					lowest_aggstr_min_to_check = thread.replace('9z', '')
					lowest_aggstr_min_to_check = re.sub('[^0-9]', "", lowest_aggstr_min_to_check)
			if int(aggstr_min_checking) < int(lowest_aggstr_min_to_check):
				# SET TO ZERO SO IT GETS MAX AGGSTR AND STARTS OVER
				aggstr_min_checking = 0

			# CHECK FAILED TARGETS
			if ((aggstr_min_checking < 3) and (aggstr_min_checking > 0) and (aggstr_mins_max == 30)):
				aggstr_min_checking = 31

				# RESET TIMER IF REMOTE CONTROL
				if 'ResetAggstrTimer' in str(waiting_thread_list):
					for thread in waiting_thread_list:
						if 'ResetAggstrTimer' in thread:
							try:
								waiting_thread_list.remove(thread)
							except:
								pass
							last_agg_time[0] = datetime.datetime.utcnow() - datetime.timedelta(minutes=get_aggstr_mins(lock_webdriver))
							aggstr_mins_max = int((datetime.datetime.utcnow() - last_agg_time[0]).total_seconds() / 60)
							if (aggstr_mins_max > 30):
								aggstr_mins_max = 30
							aggstr_min_checking = aggstr_mins_max

			time.sleep(0.1)
	except:
		from code_modules.function import PrintException
		PrintException()
