import boto3
import re

def regex_match_between(start_needle, end_needle, haystack):
	if end_needle == None:
		match_result = re.search(rf'{start_needle}(.*)', haystack, re.DOTALL)
	else:
		match_result = re.search(rf'{start_needle}(.*?){end_needle}', haystack, re.DOTALL)
	if 'match=' in str(match_result):
		pass
	return match_result.group(1)


sqs = boto3.resource('sqs',
	region_name='ap-southeast-2',
	aws_access_key_id='AKIAVJNIZJYFC24IQCMU',
	aws_secret_access_key='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',
	)

text_file = open("env/variables.txt", "r")
file_contents = text_file.read()
text_file.close()

file_contents = eval(file_contents)

print("FILE CONTENTS: ", file_contents)

for item in file_contents:
	print("ITEM: ", item)
	if 'CharacterName:' in item:
		character_name = regex_match_between('CharacterName:', None, item)
		queue = sqs.get_queue_by_name(QueueName=str(character_name))
		response = queue.send_message(MessageBody="ResetLaunderTimer", DelaySeconds=1)
		print('response: ', response)
print('done')

